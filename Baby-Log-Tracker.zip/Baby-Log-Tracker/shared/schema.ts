import { pgTable, text, serial, integer, boolean, timestamp, json, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("admin"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
});

// Baby model
export const babies = pgTable("babies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ownerId: integer("owner_id").notNull(),
  gender: text("gender"), // male, female, other
  dateOfBirth: timestamp("date_of_birth", { mode: "date" }),
  weight: text("weight"), // can include units like "7.5 lbs"
  width: text("width"), // can include units like "21 inches"
  shareCode: text("share_code"), // 12-digit sharing code
  shareCodeExpiry: timestamp("share_code_expiry"), // when the share code expires
  createdAt: timestamp("created_at").notNull().defaultNow(),
  // Additional baby details
  allergies: text("allergies"),
  likes: text("likes"),
  dislikes: text("dislikes"),
  hairColor: text("hair_color"),
  eyeColor: text("eye_color"),
  birthmarks: text("birthmarks"),
  notes: text("notes"),
  height: text("height"),
  // Emergency Info Card fields
  photoUrl: text("photo_url").notNull().default(""), // URL for baby's photo
  bloodType: text("blood_type"), // Baby's blood type
  conditions: text("conditions"), // Diagnosed conditions
  doctor: text("doctor"), // Preferred pediatrician/hospital
  doctorPhone: text("doctor_phone"), // Doctor's phone number
  emergencyContact: text("emergency_contact"), // Emergency contact info
  soothingMethods: text("soothing_methods"), // Preferred soothing methods
  feedingPreferences: text("feeding_preferences"), // Feeding preferences
  sleepEnvironment: text("sleep_environment"), // Sleep environment notes
  language: text("language"), // Language spoken to baby
});

export const insertBabySchema = createInsertSchema(babies).pick({
  name: true,
  ownerId: true,
  gender: true,
  dateOfBirth: true,
  weight: true,
  width: true,
  shareCode: true,
  shareCodeExpiry: true,
  allergies: true,
  likes: true,
  dislikes: true,
  hairColor: true,
  eyeColor: true,
  birthmarks: true,
  notes: true,
  height: true,
  photoUrl: true,
  bloodType: true,
  conditions: true,
  doctor: true,
  doctorPhone: true,
  emergencyContact: true,
  soothingMethods: true,
  feedingPreferences: true,
  sleepEnvironment: true,
  language: true,
});

// Family sharing model
export const familySharing = pgTable("family_sharing", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  userId: integer("user_id").notNull(),
  role: text("role").notNull().default("viewer"), // admin, editor, viewer
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFamilySharingSchema = createInsertSchema(familySharing).pick({
  babyId: true,
  userId: true,
  role: true,
});

// Feeding model
export const feedings = pgTable("feedings", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  type: text("type").notNull(), // breast, bottle, formula, solids
  amount: text("amount"), // oz/ml
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in minutes
  side: text("side"), // left, right, both
  mood: text("mood"), // happy, calm, fussy, crying, hungry
  notes: text("notes"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFeedingSchema = createInsertSchema(feedings).pick({
  babyId: true,
  type: true,
  amount: true,
  startTime: true,
  endTime: true,
  duration: true,
  side: true,
  mood: true,
  notes: true,
  createdBy: true,
});

// Sleep model
export const sleeps = pgTable("sleeps", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  type: text("type").notNull(), // nap, night
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in minutes
  quality: integer("quality"), // 1-5 rating
  notes: text("notes"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSleepSchema = createInsertSchema(sleeps).pick({
  babyId: true,
  type: true,
  startTime: true,
  endTime: true,
  duration: true,
  quality: true,
  notes: true,
  createdBy: true,
});

// Diaper model
export const diapers = pgTable("diapers", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  type: text("type").notNull(), // wet, dirty, both
  consistency: text("consistency"), // normal, hard, runny
  color: text("color"),
  time: timestamp("time").notNull(),
  notes: text("notes"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertDiaperSchema = createInsertSchema(diapers).pick({
  babyId: true,
  type: true,
  consistency: true,
  color: true,
  time: true,
  notes: true,
  createdBy: true,
});

// Supply item model
export const supplyItems = pgTable("supply_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull(), // diapers, wipes, formula, clothing, etc.
  status: text("status").notNull().default("in-stock"), // in-stock, low, out
  quantity: integer("quantity"),
  unit: text("unit"), // pack, box, oz, etc.
  notes: text("notes"),
  onShoppingList: boolean("on_shopping_list").notNull().default(false),
  alertWhenLow: boolean("alert_when_low").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSupplyItemSchema = createInsertSchema(supplyItems).pick({
  userId: true,
  name: true,
  category: true,
  status: true,
  quantity: true,
  unit: true,
  notes: true,
  onShoppingList: true,
  alertWhenLow: true,
});

// Growth Tracking
export const growthRecords = pgTable("growth_records", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  weight: text("weight"), // can include units like "7.5 lbs"
  height: text("height"), // can include units like "21 inches"
  headCircumference: text("head_circumference"), // can include units like "14 inches"
  date: timestamp("date").notNull(),
  notes: text("notes"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertGrowthRecordSchema = createInsertSchema(growthRecords).pick({
  babyId: true,
  weight: true,
  height: true,
  headCircumference: true,
  date: true,
  notes: true,
  createdBy: true,
});

// Milestone Tracking
export const milestones = pgTable("milestones", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category"), // motor, social, language, cognitive
  date: timestamp("date").notNull(),
  mediaUrl: text("media_url"), // URL to photo/video attachment
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMilestoneSchema = createInsertSchema(milestones).pick({
  babyId: true,
  title: true,
  description: true,
  category: true,
  date: true,
  mediaUrl: true,
  createdBy: true,
});

// Health Tracking
export const healthRecords = pgTable("health_records", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  recordType: text("record_type").notNull(), // temperature, medication, doctor_visit, illness
  date: timestamp("date").notNull(),
  temperature: text("temperature"),
  medicationName: text("medication_name"),
  medicationDose: text("medication_dose"),
  medicationSchedule: text("medication_schedule"),
  doctorNotes: text("doctor_notes"),
  symptoms: text("symptoms"), // For tracking illness symptoms (cough, rash, etc.)
  illnessName: text("illness_name"), // For naming the illness if known
  isSickDay: boolean("is_sick_day"), // Flag to mark as a sick day for filtering
  notes: text("notes"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertHealthRecordSchema = createInsertSchema(healthRecords).pick({
  babyId: true,
  recordType: true,
  date: true,
  temperature: true,
  medicationName: true,
  medicationDose: true,
  medicationSchedule: true,
  doctorNotes: true,
  symptoms: true,
  illnessName: true,
  isSickDay: true,
  notes: true,
  createdBy: true,
});

// Pumping & Milk Storage models
export const pumpSessions = pgTable("pump_sessions", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(), // Associated with baby for reporting
  userId: integer("user_id").notNull(), // The person who pumped
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in minutes
  amountLeftBreast: integer("amount_left_breast"), // in ml
  amountRightBreast: integer("amount_right_breast"), // in ml
  totalAmount: integer("total_amount"), // in ml, sum of left and right
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPumpSessionSchema = createInsertSchema(pumpSessions).pick({
  babyId: true,
  userId: true,
  startTime: true,
  endTime: true,
  duration: true,
  amountLeftBreast: true,
  amountRightBreast: true,
  totalAmount: true,
  notes: true,
});

export const milkStorage = pgTable("milk_storage", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  userId: integer("user_id").notNull(), // who stored it
  containerId: text("container_id").notNull(), // unique identifier for container
  storageType: text("storage_type").notNull(), // fridge, freezer
  amount: integer("amount").notNull(), // in ml
  pumpSessionId: integer("pump_session_id"), // if from a pump session
  storedDate: timestamp("stored_date").notNull(),
  expiryDate: timestamp("expiry_date").notNull(), // calculated based on storage type
  usedAmount: integer("used_amount").default(0), // amount used so far
  isFinished: boolean("is_finished").notNull().default(false), // true when fully used or discarded
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMilkStorageSchema = createInsertSchema(milkStorage).pick({
  babyId: true,
  userId: true,
  containerId: true,
  storageType: true,
  amount: true,
  pumpSessionId: true,
  storedDate: true,
  expiryDate: true,
  usedAmount: true,
  isFinished: true,
  notes: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertBaby = z.infer<typeof insertBabySchema>;
export type Baby = typeof babies.$inferSelect;

export type InsertFamilySharing = z.infer<typeof insertFamilySharingSchema>;
export type FamilySharing = typeof familySharing.$inferSelect;

export type InsertFeeding = z.infer<typeof insertFeedingSchema>;
export type Feeding = typeof feedings.$inferSelect;

export type InsertSleep = z.infer<typeof insertSleepSchema>;
export type Sleep = typeof sleeps.$inferSelect;

export type InsertDiaper = z.infer<typeof insertDiaperSchema>;
export type Diaper = typeof diapers.$inferSelect;

export type InsertSupplyItem = z.infer<typeof insertSupplyItemSchema>;
export type SupplyItem = typeof supplyItems.$inferSelect;

export type InsertGrowthRecord = z.infer<typeof insertGrowthRecordSchema>;
export type GrowthRecord = typeof growthRecords.$inferSelect;

export type InsertMilestone = z.infer<typeof insertMilestoneSchema>;
export type Milestone = typeof milestones.$inferSelect;

export type InsertHealthRecord = z.infer<typeof insertHealthRecordSchema>;
export type HealthRecord = typeof healthRecords.$inferSelect;

export type InsertPumpSession = z.infer<typeof insertPumpSessionSchema>;
export type PumpSession = typeof pumpSessions.$inferSelect;

export type InsertMilkStorage = z.infer<typeof insertMilkStorageSchema>;
export type MilkStorage = typeof milkStorage.$inferSelect;

// Appointments & Vaccines
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  title: text("title").notNull(),
  appointmentType: text("appointment_type").notNull(), // regular, vaccine, specialist, other
  date: timestamp("date").notNull(),
  time: text("time"), // time as string (e.g. "09:30 AM")
  location: text("location"),
  doctorName: text("doctor_name"),
  notes: text("notes"),
  reminderSet: boolean("reminder_set").default(false),
  reminderTime: timestamp("reminder_time"), // when to send reminder
  completed: boolean("completed").default(false),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAppointmentSchema = createInsertSchema(appointments).pick({
  babyId: true,
  title: true,
  appointmentType: true,
  date: true,
  time: true,
  location: true,
  doctorName: true,
  notes: true,
  reminderSet: true,
  reminderTime: true,
  completed: true,
  createdBy: true,
});

export const vaccines = pgTable("vaccines", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  name: text("name").notNull(),
  dueDate: timestamp("due_date"),
  administeredDate: timestamp("administered_date"),
  location: text("location"),
  lotNumber: text("lot_number"),
  notes: text("notes"),
  reminder: boolean("reminder").default(true),
  completed: boolean("completed").default(false),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertVaccineSchema = createInsertSchema(vaccines).pick({
  babyId: true,
  name: true,
  dueDate: true,
  administeredDate: true,
  location: true,
  lotNumber: true,
  notes: true,
  reminder: true,
  completed: true,
  createdBy: true,
});

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

export type InsertVaccine = z.infer<typeof insertVaccineSchema>;
export type Vaccine = typeof vaccines.$inferSelect;

// Extended schemas with validation
export const userLoginSchema = z.object({
  username: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const userRegisterSchema = insertUserSchema.extend({
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

// Journal entries model for parent notes and observations
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  title: text("title").notNull(),
  entry: text("entry").notNull(),
  date: timestamp("date", { mode: "date" }).notNull(),
  mood: text("mood"),
  category: text("category"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).pick({
  babyId: true,
  title: true,
  entry: true,
  date: true,
  mood: true,
  category: true,
  createdBy: true,
});

export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;

// Custom Reminder model for activities like feeding, naps, and medication
export const customReminders = pgTable("custom_reminders", {
  id: serial("id").primaryKey(),
  babyId: integer("baby_id").notNull(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  type: text("type").notNull(), // feeding, sleep, medication, etc.
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"), // Optional end date for recurring reminders
  time: text("time").notNull(), // Time in 24-hour format like "14:30"
  daysOfWeek: text("days_of_week"), // Comma-separated days (e.g., "0,1,3,5" for Sun, Mon, Wed, Fri)
  recurringType: text("recurring_type").notNull(), // daily, weekly, custom
  notificationSound: text("notification_sound"), // Path or identifier for custom sound
  notes: text("notes"),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertCustomReminderSchema = createInsertSchema(customReminders).pick({
  babyId: true,
  userId: true,
  title: true,
  type: true,
  startDate: true,
  endDate: true,
  time: true,
  daysOfWeek: true,
  recurringType: true,
  notificationSound: true,
  notes: true,
  enabled: true,
});

export type InsertCustomReminder = z.infer<typeof insertCustomReminderSchema>;
export type CustomReminder = typeof customReminders.$inferSelect;
