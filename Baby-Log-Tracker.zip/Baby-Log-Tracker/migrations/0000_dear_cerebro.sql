CREATE TABLE "appointments" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"title" text NOT NULL,
	"appointment_type" text NOT NULL,
	"date" timestamp NOT NULL,
	"time" text,
	"location" text,
	"doctor_name" text,
	"notes" text,
	"reminder_set" boolean DEFAULT false,
	"reminder_time" timestamp,
	"completed" boolean DEFAULT false,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "babies" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"owner_id" integer NOT NULL,
	"gender" text,
	"date_of_birth" timestamp,
	"weight" text,
	"width" text,
	"share_code" text,
	"share_code_expiry" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"allergies" text,
	"likes" text,
	"dislikes" text,
	"hair_color" text,
	"eye_color" text,
	"birthmarks" text,
	"notes" text,
	"height" text,
	"photoUrl" text,
	"blood_type" text,
	"conditions" text,
	"doctor" text,
	"emergency_contact" text,
	"soothing_methods" text,
	"feeding_preferences" text,
	"sleep_environment" text,
	"language" text
);
--> statement-breakpoint
CREATE TABLE "diapers" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"type" text NOT NULL,
	"consistency" text,
	"color" text,
	"time" timestamp NOT NULL,
	"notes" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "family_sharing" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"user_id" integer NOT NULL,
	"role" text DEFAULT 'viewer' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "feedings" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"type" text NOT NULL,
	"amount" text,
	"start_time" timestamp NOT NULL,
	"end_time" timestamp,
	"duration" integer,
	"side" text,
	"mood" text,
	"notes" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "growth_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"weight" text,
	"height" text,
	"head_circumference" text,
	"date" timestamp NOT NULL,
	"notes" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "health_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"record_type" text NOT NULL,
	"date" timestamp NOT NULL,
	"temperature" text,
	"medication_name" text,
	"medication_dose" text,
	"medication_schedule" text,
	"doctor_notes" text,
	"symptoms" text,
	"illness_name" text,
	"is_sick_day" boolean,
	"notes" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "journal_entries" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"title" text NOT NULL,
	"entry" text NOT NULL,
	"date" timestamp NOT NULL,
	"mood" text,
	"category" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "milestones" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"category" text,
	"date" timestamp NOT NULL,
	"media_url" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "milk_storage" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"user_id" integer NOT NULL,
	"container_id" text NOT NULL,
	"storage_type" text NOT NULL,
	"amount" integer NOT NULL,
	"pump_session_id" integer,
	"stored_date" timestamp NOT NULL,
	"expiry_date" timestamp NOT NULL,
	"used_amount" integer DEFAULT 0,
	"is_finished" boolean DEFAULT false NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "pump_sessions" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"user_id" integer NOT NULL,
	"start_time" timestamp NOT NULL,
	"end_time" timestamp,
	"duration" integer,
	"amount_left_breast" integer,
	"amount_right_breast" integer,
	"total_amount" integer,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sleeps" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"type" text NOT NULL,
	"start_time" timestamp NOT NULL,
	"end_time" timestamp,
	"duration" integer,
	"quality" integer,
	"notes" text,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "supply_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"status" text DEFAULT 'in-stock' NOT NULL,
	"quantity" integer,
	"unit" text,
	"notes" text,
	"on_shopping_list" boolean DEFAULT false NOT NULL,
	"alert_when_low" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	"full_name" text NOT NULL,
	"role" text DEFAULT 'admin' NOT NULL,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "vaccines" (
	"id" serial PRIMARY KEY NOT NULL,
	"baby_id" integer NOT NULL,
	"name" text NOT NULL,
	"due_date" timestamp,
	"administered_date" timestamp,
	"location" text,
	"lot_number" text,
	"notes" text,
	"reminder" boolean DEFAULT true,
	"completed" boolean DEFAULT false,
	"created_by" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
