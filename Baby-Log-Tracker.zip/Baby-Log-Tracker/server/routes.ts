import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { format, startOfDay, endOfDay, parseISO, isValid } from 'date-fns';
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { pumpSessions, milkStorage, insertPumpSessionSchema, insertMilkStorageSchema } from "../shared/schema";
import { getUpcomingReminders, hasBabyReminders, ReminderType } from "./reminder-service";
import { jsPDF } from 'jspdf';

// Middleware to check authentication
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Not authenticated" });
}

// Middleware to check access to a baby
async function hasBabyAccess(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  const babyId = parseInt(req.params.babyId || req.body.babyId);
  if (isNaN(babyId)) {
    return res.status(400).json({ message: "Invalid baby ID" });
  }
  
  try {
    const access = await storage.getBabyAccess(req.user!.id, babyId);
    if (!access) {
      return res.status(403).json({ message: "No access to this baby" });
    }
    
    // Set the access role for later use
    res.locals.accessRole = access.role;
    next();
  } catch (error) {
    next(error);
  }
}

// Middleware to check edit permission
function canEdit(req: Request, res: Response, next: NextFunction) {
  const role = res.locals.accessRole;
  if (role === 'admin' || role === 'editor') {
    return next();
  }
  res.status(403).json({ message: "You don't have permission to edit" });
}

// Middleware to check admin permission
function isAdmin(req: Request, res: Response, next: NextFunction) {
  const role = res.locals.accessRole;
  console.log("Checking admin permissions:", { 
    userId: req.user?.id, 
    babyId: req.params.babyId, 
    role, 
    url: req.url 
  });
  
  if (role === 'admin') {
    console.log("Admin permission granted");
    return next();
  }
  
  console.log("Admin permission denied, role is:", role);
  res.status(403).json({ message: "Admin permission required" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Baby routes
  app.post("/api/babies", isAuthenticated, async (req, res, next) => {
    try {
      const { name, dateOfBirth, gender, weight, width } = req.body;
      if (!name) {
        return res.status(400).json({ message: "Baby name is required" });
      }
      
      // Generate a unique 12-digit code
      const shareCode = Math.floor(100000000000 + Math.random() * 900000000000).toString();
      
      // Set expiration time to 5 minutes from now
      const shareCodeExpiry = new Date();
      shareCodeExpiry.setMinutes(shareCodeExpiry.getMinutes() + 5);
      
      const baby = await storage.createBaby({
        name,
        ownerId: req.user!.id,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : undefined,
        gender,
        weight,
        width,
        shareCode,
        shareCodeExpiry
      });
      
      res.status(201).json(baby);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies", isAuthenticated, async (req, res, next) => {
    try {
      const babies = await storage.getBabiesByOwner(req.user!.id);
      res.json(babies);
    } catch (error) {
      next(error);
    }
  });
  
  // Routes for sharing by code - these need to come before the /:babyId route
  // to ensure they are matched correctly
  app.get("/api/babies/find-by-code/:shareCode", isAuthenticated, async (req, res, next) => {
    try {
      const shareCode = req.params.shareCode;
      
      // Validate share code
      if (!shareCode || shareCode.length !== 12 || !/^\d+$/.test(shareCode)) {
        return res.status(400).json({ message: "Invalid share code format" });
      }
      
      const baby = await storage.getBabyByShareCode(shareCode);
      if (!baby) {
        return res.status(404).json({ message: "Baby not found with this share code" });
      }
      
      // Check if the share code is expired
      if (baby.shareCodeExpiry && new Date() > new Date(baby.shareCodeExpiry)) {
        return res.status(400).json({ message: "This share code has expired" });
      }
      
      // Check if user already has access
      const existingAccess = await storage.getBabyAccess(req.user!.id, baby.id);
      if (existingAccess) {
        return res.status(400).json({ 
          message: "You already have access to this baby",
          babyId: baby.id
        });
      }
      
      // Return limited baby info before joining
      res.json({
        id: baby.id,
        name: baby.name,
        ownerId: baby.ownerId
      });
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/babies/join/:shareCode", isAuthenticated, async (req, res, next) => {
    try {
      const shareCode = req.params.shareCode;
      
      // Validate share code
      if (!shareCode || shareCode.length !== 12 || !/^\d+$/.test(shareCode)) {
        return res.status(400).json({ message: "Invalid share code format" });
      }
      
      const baby = await storage.getBabyByShareCode(shareCode);
      if (!baby) {
        return res.status(404).json({ message: "Baby not found with this share code" });
      }
      
      // Check if the share code is expired
      if (baby.shareCodeExpiry && new Date() > new Date(baby.shareCodeExpiry)) {
        return res.status(400).json({ message: "This share code has expired" });
      }
      
      // Check if user already has access
      const existingAccess = await storage.getBabyAccess(req.user!.id, baby.id);
      if (existingAccess) {
        return res.status(400).json({ 
          message: "You already have access to this baby",
          babyId: baby.id
        });
      }
      
      // Add user with viewer role by default
      const sharing = await storage.createFamilySharing({
        babyId: baby.id,
        userId: req.user!.id,
        role: "viewer"
      });
      
      res.status(201).json({
        message: "Successfully joined baby's sharing group",
        babyId: baby.id,
        sharing
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Handle join with request body (for join-baby-form)
  app.post("/api/babies/join", isAuthenticated, async (req, res, next) => {
    try {
      const { shareCode } = req.body;
      
      // Validate share code
      if (!shareCode || shareCode.length !== 12 || !/^\d+$/.test(shareCode)) {
        return res.status(400).json({ message: "Invalid share code format" });
      }
      
      const baby = await storage.getBabyByShareCode(shareCode);
      if (!baby) {
        return res.status(404).json({ message: "Baby not found with this share code" });
      }
      
      // Check if the share code is expired
      if (baby.shareCodeExpiry && new Date() > new Date(baby.shareCodeExpiry)) {
        return res.status(400).json({ message: "This share code has expired" });
      }
      
      // Check if user already has access
      const existingAccess = await storage.getBabyAccess(req.user!.id, baby.id);
      if (existingAccess) {
        return res.status(400).json({ 
          message: "You already have access to this baby",
          babyId: baby.id
        });
      }
      
      // Add user with viewer role by default
      const sharing = await storage.createFamilySharing({
        babyId: baby.id,
        userId: req.user!.id,
        role: "viewer"
      });
      
      res.status(201).json({
        message: "Successfully joined baby's sharing group",
        babyId: baby.id,
        sharing
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Update baby endpoint
  app.patch("/api/babies/:babyId", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Get the baby first to check ownership
      const baby = await storage.getBaby(babyId);
      if (!baby) {
        return res.status(404).json({ message: "Baby not found" });
      }

      // Update baby details
      const updatedBaby = await storage.updateBaby(babyId, req.body);
      if (!updatedBaby) {
        return res.status(500).json({ message: "Failed to update baby details" });
      }
      
      res.status(200).json(updatedBaby);
    } catch (error) {
      next(error);
    }
  });
  
  // Delete baby endpoint - only needs authentication, not access check
  app.delete("/api/babies/:babyId", isAuthenticated, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Get the baby first to check ownership
      const baby = await storage.getBaby(babyId);
      if (!baby) {
        return res.status(404).json({ message: "Baby not found" });
      }
      
      // Only owner can delete a baby
      if (baby.ownerId !== req.user!.id) {
        return res.status(403).json({ message: "Only the owner can delete a baby profile" });
      }
      
      const success = await storage.deleteBaby(babyId);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to delete baby profile" });
      }
      
      res.status(200).json({ message: "Baby profile successfully deleted" });
    } catch (error) {
      next(error);
    }
  });

  // This needs to come after the specific routes
  app.get("/api/babies/:babyId", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const baby = await storage.getBaby(parseInt(req.params.babyId));
      if (!baby) {
        return res.status(404).json({ message: "Baby not found" });
      }
      res.json(baby);
    } catch (error) {
      next(error);
    }
  });
  
  // Family sharing routes
  app.post("/api/babies/:babyId/sharing", isAuthenticated, hasBabyAccess, isAdmin, async (req, res, next) => {
    try {
      const { email, role } = req.body;
      if (!email || !role) {
        return res.status(400).json({ message: "Email and role are required" });
      }
      
      // Validate role
      if (!['admin', 'editor', 'viewer'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      // Find user by email
      const user = await storage.getUserByUsername(email);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if already shared
      const existingSharing = await storage.getBabyAccess(user.id, parseInt(req.params.babyId));
      if (existingSharing) {
        return res.status(400).json({ message: "Already shared with this user" });
      }
      
      const sharing = await storage.createFamilySharing({
        babyId: parseInt(req.params.babyId),
        userId: user.id,
        role,
      });
      
      res.status(201).json(sharing);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/sharing", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const members = await storage.getFamilyMembers(parseInt(req.params.babyId));
      
      // Get user details for each sharing
      const enrichedMembers = await Promise.all(
        members.map(async (member) => {
          const user = await storage.getUser(member.userId);
          return {
            ...member,
            user: user ? { 
              id: user.id, 
              username: user.username, 
              fullName: user.fullName 
            } : null,
          };
        })
      );
      
      res.json(enrichedMembers);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/babies/:babyId/sharing/:sharingId", isAuthenticated, hasBabyAccess, isAdmin, async (req, res, next) => {
    try {
      const { role } = req.body;
      if (!role) {
        return res.status(400).json({ message: "Role is required" });
      }
      
      // Validate role
      if (!['admin', 'editor', 'viewer'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      const sharing = await storage.updateFamilySharing(parseInt(req.params.sharingId), role);
      if (!sharing) {
        return res.status(404).json({ message: "Sharing not found" });
      }
      
      res.json(sharing);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/babies/:babyId/sharing/:sharingId", isAuthenticated, hasBabyAccess, isAdmin, async (req, res, next) => {
    try {
      // Make sure we're not removing the owner's access
      const sharing = await storage.getFamilySharing(parseInt(req.params.sharingId));
      if (!sharing) {
        return res.status(404).json({ message: "Sharing not found" });
      }
      
      const baby = await storage.getBaby(sharing.babyId);
      if (!baby) {
        return res.status(404).json({ message: "Baby not found" });
      }
      
      if (baby.ownerId === sharing.userId) {
        return res.status(400).json({ message: "Cannot remove owner's access" });
      }
      
      const success = await storage.deleteFamilySharing(parseInt(req.params.sharingId));
      if (!success) {
        return res.status(404).json({ message: "Sharing not found" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });
  
  // Feeding routes
  app.post("/api/babies/:babyId/feedings", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { type, amount, startTime, endTime, duration, side, notes } = req.body;
      if (!type || !startTime) {
        return res.status(400).json({ message: "Type and start time are required" });
      }
      
      const feeding = await storage.createFeeding({
        babyId: parseInt(req.params.babyId),
        type,
        amount: amount || null,
        startTime: new Date(startTime),
        endTime: endTime ? new Date(endTime) : undefined,
        duration: duration || null,
        side: side || null,
        notes: notes || null,
        createdBy: req.user!.id,
      });
      
      res.status(201).json(feeding);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/feedings", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { date } = req.query;
      let feedings;
      
      if (date) {
        const selectedDate = new Date(date as string);
        feedings = await storage.getFeedingsByDate(parseInt(req.params.babyId), selectedDate);
      } else {
        feedings = await storage.getFeedingsByBaby(parseInt(req.params.babyId));
      }
      
      res.json(feedings);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/babies/:babyId/feedings/:feedingId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { type, amount, startTime, endTime, duration, side, notes } = req.body;
      const feeding = await storage.getFeeding(parseInt(req.params.feedingId));
      
      if (!feeding) {
        return res.status(404).json({ message: "Feeding not found" });
      }
      
      // Make sure the feeding belongs to the specified baby
      if (feeding.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Feeding not found for this baby" });
      }
      
      const updatedFeeding = await storage.updateFeeding(parseInt(req.params.feedingId), {
        type: type || feeding.type,
        amount: amount !== undefined ? amount : feeding.amount,
        startTime: startTime ? new Date(startTime) : feeding.startTime,
        endTime: endTime ? new Date(endTime) : feeding.endTime,
        duration: duration !== undefined ? duration : feeding.duration,
        side: side !== undefined ? side : feeding.side,
        notes: notes !== undefined ? notes : feeding.notes,
      });
      
      if (!updatedFeeding) {
        return res.status(404).json({ message: "Failed to update feeding" });
      }
      
      res.json(updatedFeeding);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/babies/:babyId/feedings/:feedingId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const feeding = await storage.getFeeding(parseInt(req.params.feedingId));
      
      if (!feeding) {
        return res.status(404).json({ message: "Feeding not found" });
      }
      
      // Make sure the feeding belongs to the specified baby
      if (feeding.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Feeding not found for this baby" });
      }
      
      const success = await storage.deleteFeeding(parseInt(req.params.feedingId));
      if (!success) {
        return res.status(404).json({ message: "Failed to delete feeding" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });
  
  // Sleep routes
  app.post("/api/babies/:babyId/sleeps", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { type, startTime, endTime, duration, quality, notes } = req.body;
      if (!type || !startTime) {
        return res.status(400).json({ message: "Type and start time are required" });
      }
      
      const sleep = await storage.createSleep({
        babyId: parseInt(req.params.babyId),
        type,
        startTime: new Date(startTime),
        endTime: endTime ? new Date(endTime) : undefined,
        duration: duration || null,
        quality: quality || null,
        notes: notes || null,
        createdBy: req.user!.id,
      });
      
      res.status(201).json(sleep);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/sleeps", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { date } = req.query;
      let sleeps;
      
      if (date) {
        const selectedDate = new Date(date as string);
        sleeps = await storage.getSleepsByDate(parseInt(req.params.babyId), selectedDate);
      } else {
        sleeps = await storage.getSleepsByBaby(parseInt(req.params.babyId));
      }
      
      res.json(sleeps);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/babies/:babyId/sleeps/:sleepId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { type, startTime, endTime, duration, quality, notes } = req.body;
      const sleep = await storage.getSleep(parseInt(req.params.sleepId));
      
      if (!sleep) {
        return res.status(404).json({ message: "Sleep not found" });
      }
      
      // Make sure the sleep belongs to the specified baby
      if (sleep.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Sleep not found for this baby" });
      }
      
      const updatedSleep = await storage.updateSleep(parseInt(req.params.sleepId), {
        type: type || sleep.type,
        startTime: startTime ? new Date(startTime) : sleep.startTime,
        endTime: endTime ? new Date(endTime) : sleep.endTime,
        duration: duration !== undefined ? duration : sleep.duration,
        quality: quality !== undefined ? quality : sleep.quality,
        notes: notes !== undefined ? notes : sleep.notes,
      });
      
      if (!updatedSleep) {
        return res.status(404).json({ message: "Failed to update sleep" });
      }
      
      res.json(updatedSleep);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/babies/:babyId/sleeps/:sleepId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const sleep = await storage.getSleep(parseInt(req.params.sleepId));
      
      if (!sleep) {
        return res.status(404).json({ message: "Sleep not found" });
      }
      
      // Make sure the sleep belongs to the specified baby
      if (sleep.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Sleep not found for this baby" });
      }
      
      const success = await storage.deleteSleep(parseInt(req.params.sleepId));
      if (!success) {
        return res.status(404).json({ message: "Failed to delete sleep" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });
  
  // Diaper routes
  app.post("/api/babies/:babyId/diapers", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { type, consistency, color, time, notes } = req.body;
      if (!type || !time) {
        return res.status(400).json({ message: "Type and time are required" });
      }
      
      const diaper = await storage.createDiaper({
        babyId: parseInt(req.params.babyId),
        type,
        consistency: consistency || null,
        color: color || null,
        time: new Date(time),
        notes: notes || null,
        createdBy: req.user!.id,
      });
      
      res.status(201).json(diaper);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/diapers", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { date } = req.query;
      let diapers;
      
      if (date) {
        const selectedDate = new Date(date as string);
        diapers = await storage.getDiapersByDate(parseInt(req.params.babyId), selectedDate);
      } else {
        diapers = await storage.getDiapersByBaby(parseInt(req.params.babyId));
      }
      
      res.json(diapers);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/babies/:babyId/diapers/:diaperId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { type, consistency, color, time, notes } = req.body;
      const diaper = await storage.getDiaper(parseInt(req.params.diaperId));
      
      if (!diaper) {
        return res.status(404).json({ message: "Diaper not found" });
      }
      
      // Make sure the diaper belongs to the specified baby
      if (diaper.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Diaper not found for this baby" });
      }
      
      const updatedDiaper = await storage.updateDiaper(parseInt(req.params.diaperId), {
        type: type || diaper.type,
        consistency: consistency !== undefined ? consistency : diaper.consistency,
        color: color !== undefined ? color : diaper.color,
        time: time ? new Date(time) : diaper.time,
        notes: notes !== undefined ? notes : diaper.notes,
      });
      
      if (!updatedDiaper) {
        return res.status(404).json({ message: "Failed to update diaper" });
      }
      
      res.json(updatedDiaper);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/babies/:babyId/diapers/:diaperId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const diaper = await storage.getDiaper(parseInt(req.params.diaperId));
      
      if (!diaper) {
        return res.status(404).json({ message: "Diaper not found" });
      }
      
      // Make sure the diaper belongs to the specified baby
      if (diaper.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Diaper not found for this baby" });
      }
      
      const success = await storage.deleteDiaper(parseInt(req.params.diaperId));
      if (!success) {
        return res.status(404).json({ message: "Failed to delete diaper" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });
  
  // Combined daily activities
  app.get("/api/babies/:babyId/daily", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { date } = req.query;
      const selectedDate = date ? new Date(date as string) : new Date();
      
      const startOfSelectedDay = startOfDay(selectedDate);
      const endOfSelectedDay = endOfDay(selectedDate);
      
      const feedings = await storage.getFeedingsByDate(parseInt(req.params.babyId), selectedDate);
      const sleeps = await storage.getSleepsByDate(parseInt(req.params.babyId), selectedDate);
      const diapers = await storage.getDiapersByDate(parseInt(req.params.babyId), selectedDate);
      const healthRecords = await storage.getHealthRecordsByDate(
        parseInt(req.params.babyId), 
        startOfSelectedDay, 
        endOfSelectedDay
      );
      
      res.json({
        date: format(selectedDate, 'yyyy-MM-dd'),
        feedings,
        sleeps,
        diapers,
        healthRecords
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Analytics endpoints
  app.get("/api/babies/:babyId/feedings/range", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const parsedStartDate = parseISO(startDate as string);
      const parsedEndDate = parseISO(endDate as string);
      
      if (!isValid(parsedStartDate) || !isValid(parsedEndDate)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      // Get all feedings for the baby
      const allFeedings = await storage.getFeedingsByBaby(parseInt(req.params.babyId));
      
      // Filter by date range
      const filteredFeedings = allFeedings.filter(feeding => {
        const feedingDate = new Date(feeding.startTime);
        return feedingDate >= startOfDay(parsedStartDate) && feedingDate <= endOfDay(parsedEndDate);
      });
      
      res.json(filteredFeedings);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/sleeps/range", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const parsedStartDate = parseISO(startDate as string);
      const parsedEndDate = parseISO(endDate as string);
      
      if (!isValid(parsedStartDate) || !isValid(parsedEndDate)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      // Get all sleeps for the baby
      const allSleeps = await storage.getSleepsByBaby(parseInt(req.params.babyId));
      
      // Filter by date range
      const filteredSleeps = allSleeps.filter(sleep => {
        const sleepDate = new Date(sleep.startTime);
        return sleepDate >= startOfDay(parsedStartDate) && sleepDate <= endOfDay(parsedEndDate);
      });
      
      res.json(filteredSleeps);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/diapers/range", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const parsedStartDate = parseISO(startDate as string);
      const parsedEndDate = parseISO(endDate as string);
      
      if (!isValid(parsedStartDate) || !isValid(parsedEndDate)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      // Get all diapers for the baby
      const allDiapers = await storage.getDiapersByBaby(parseInt(req.params.babyId));
      
      // Filter by date range
      const filteredDiapers = allDiapers.filter(diaper => {
        const diaperDate = new Date(diaper.time);
        return diaperDate >= startOfDay(parsedStartDate) && diaperDate <= endOfDay(parsedEndDate);
      });
      
      res.json(filteredDiapers);
    } catch (error) {
      next(error);
    }
  });
  
  // Combined analytics endpoint
  app.get("/api/babies/:babyId/analytics", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const parsedStartDate = parseISO(startDate as string);
      const parsedEndDate = parseISO(endDate as string);
      
      if (!isValid(parsedStartDate) || !isValid(parsedEndDate)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      // Get all activities for the baby
      const allFeedings = await storage.getFeedingsByBaby(parseInt(req.params.babyId));
      const allSleeps = await storage.getSleepsByBaby(parseInt(req.params.babyId));
      const allDiapers = await storage.getDiapersByBaby(parseInt(req.params.babyId));
      
      // Filter by date range
      const filteredFeedings = allFeedings.filter(feeding => {
        const feedingDate = new Date(feeding.startTime);
        return feedingDate >= startOfDay(parsedStartDate) && feedingDate <= endOfDay(parsedEndDate);
      });
      
      const filteredSleeps = allSleeps.filter(sleep => {
        const sleepDate = new Date(sleep.startTime);
        return sleepDate >= startOfDay(parsedStartDate) && sleepDate <= endOfDay(parsedEndDate);
      });
      
      const filteredDiapers = allDiapers.filter(diaper => {
        const diaperDate = new Date(diaper.time);
        return diaperDate >= startOfDay(parsedStartDate) && diaperDate <= endOfDay(parsedEndDate);
      });
      
      res.json({
        dateRange: {
          startDate: format(parsedStartDate, 'yyyy-MM-dd'),
          endDate: format(parsedEndDate, 'yyyy-MM-dd')
        },
        feedings: filteredFeedings,
        sleeps: filteredSleeps,
        diapers: filteredDiapers
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Export report as plain text file endpoint
  app.post("/api/babies/:babyId/export-report", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { startDate, endDate } = req.body;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const parsedStartDate = parseISO(startDate);
      const parsedEndDate = parseISO(endDate);
      
      if (!isValid(parsedStartDate) || !isValid(parsedEndDate)) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      // Get the baby info
      const baby = await storage.getBaby(parseInt(req.params.babyId));
      if (!baby) {
        return res.status(404).json({ message: "Baby not found" });
      }
      
      // Get data for the report
      const allFeedings = await storage.getFeedingsByBaby(parseInt(req.params.babyId));
      const allSleeps = await storage.getSleepsByBaby(parseInt(req.params.babyId));
      const allDiapers = await storage.getDiapersByBaby(parseInt(req.params.babyId));
      
      // Filter by date range
      const filteredFeedings = allFeedings.filter(feeding => {
        const feedingDate = new Date(feeding.startTime);
        return feedingDate >= startOfDay(parsedStartDate) && feedingDate <= endOfDay(parsedEndDate);
      });
      
      const filteredSleeps = allSleeps.filter(sleep => {
        const sleepDate = new Date(sleep.startTime);
        return sleepDate >= startOfDay(parsedStartDate) && sleepDate <= endOfDay(parsedEndDate);
      });
      
      const filteredDiapers = allDiapers.filter(diaper => {
        const diaperDate = new Date(diaper.time);
        return diaperDate >= startOfDay(parsedStartDate) && diaperDate <= endOfDay(parsedEndDate);
      });

      // Format date range for display
      const dateRangeText = `${format(parsedStartDate, 'MMMM d, yyyy')} to ${format(parsedEndDate, 'MMMM d, yyyy')}`;
      
      // Calculate summary statistics
      const totalFeedings = filteredFeedings.length;
      const totalSleeps = filteredSleeps.length;
      const totalDiapers = filteredDiapers.length;
      
      // Calculate average feedings per day
      const daysDiff = Math.max(1, Math.ceil((parsedEndDate.getTime() - parsedStartDate.getTime()) / (1000 * 60 * 60 * 24)));
      const avgFeedingsPerDay = totalFeedings / daysDiff;
      const avgDiapersPerDay = totalDiapers / daysDiff;
      
      // Calculate average sleep duration
      let totalSleepMinutes = 0;
      filteredSleeps.forEach(sleep => {
        if (sleep.duration) {
          totalSleepMinutes += sleep.duration;
        } else if (sleep.endTime && sleep.startTime) {
          const duration = (new Date(sleep.endTime).getTime() - new Date(sleep.startTime).getTime()) / (1000 * 60);
          totalSleepMinutes += duration;
        }
      });
      
      const avgSleepDuration = totalSleeps > 0 ? totalSleepMinutes / totalSleeps : 0;
      const avgSleepHours = Math.floor(avgSleepDuration / 60);
      const avgSleepMinutes = Math.floor(avgSleepDuration % 60);
      
      // Generate text report
      const formatDateTime = (dateStr: string | Date) => {
        const date = new Date(dateStr);
        return format(date, "MMM d, yyyy h:mm a");
      };
      
      const report = [
        `BABY ACTIVITY REPORT`,
        `===========================`,
        `Baby: ${baby.name}`,
        `Report Period: ${dateRangeText}`,
        `Generated on: ${format(new Date(), "MMMM d, yyyy h:mm a")}`,
        ``,
        `SUMMARY`,
        `---------------------------`,
        `Total Feedings: ${totalFeedings}`,
        `Average Feedings Per Day: ${avgFeedingsPerDay.toFixed(1)}`,
        `Total Sleep Sessions: ${totalSleeps}`,
        `Average Sleep Duration: ${avgSleepHours}h ${avgSleepMinutes}m`,
        `Total Diapers: ${totalDiapers}`,
        `Average Diapers Per Day: ${avgDiapersPerDay.toFixed(1)}`,
        ``,
        `FEEDING DETAILS`,
        `---------------------------`
      ];
      
      // Add feedings
      if (filteredFeedings.length === 0) {
        report.push(`No feeding records available for this period.`);
      } else {
        filteredFeedings.forEach((feeding, index) => {
          const time = formatDateTime(feeding.startTime);
          const duration = feeding.duration ? `${feeding.duration} min` : 'N/A';
          const amount = feeding.amount ? `${feeding.amount}` : 'N/A';
          const side = feeding.side ? `${feeding.side}` : 'N/A';
          report.push(`${index + 1}. ${time} - Type: ${feeding.type}, Duration: ${duration}, Amount: ${amount}, Side: ${side}`);
          if (feeding.notes) {
            report.push(`   Notes: ${feeding.notes}`);
          }
        });
      }
      
      report.push('');
      report.push('SLEEP DETAILS');
      report.push('---------------------------');
      
      // Add sleeps
      if (filteredSleeps.length === 0) {
        report.push(`No sleep records available for this period.`);
      } else {
        filteredSleeps.forEach((sleep, index) => {
          const startTime = formatDateTime(sleep.startTime);
          const endTime = sleep.endTime ? formatDateTime(sleep.endTime) : 'N/A';
          const duration = sleep.duration ? `${sleep.duration} min` : 'N/A';
          const quality = sleep.quality ? `${sleep.quality}` : 'N/A';
          report.push(`${index + 1}. ${startTime} to ${endTime} - Duration: ${duration}, Quality: ${quality}`);
          if (sleep.notes) {
            report.push(`   Notes: ${sleep.notes}`);
          }
        });
      }
      
      report.push('');
      report.push('DIAPER DETAILS');
      report.push('---------------------------');
      
      // Add diapers
      if (filteredDiapers.length === 0) {
        report.push(`No diaper records available for this period.`);
      } else {
        filteredDiapers.forEach((diaper, index) => {
          const time = formatDateTime(diaper.time);
          report.push(`${index + 1}. ${time} - Type: ${diaper.type}`);
          if (diaper.notes) {
            report.push(`   Notes: ${diaper.notes}`);
          }
        });
      }
      
      // Create a PDF document
      const doc = new jsPDF();
      
      // Set report filename
      const filename = `baby_report_${baby.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_${format(new Date(), 'yyyyMMdd')}.pdf`;
      
      // Add a title
      doc.setFontSize(20);
      doc.setTextColor(37, 99, 235); // Blue color to match the app
      doc.text("Baby Activity Report", 105, 20, { align: "center" });
      
      // Add report info
      doc.setFontSize(12);
      doc.setTextColor(0, 0, 0);
      doc.text(`Baby: ${baby.name}`, 20, 35);
      doc.text(`Report Period: ${dateRangeText}`, 20, 42);
      doc.text(`Generated on: ${format(new Date(), "MMMM d, yyyy h:mm a")}`, 20, 49);
      
      // Draw a line
      doc.setDrawColor(37, 99, 235);
      doc.line(20, 52, 190, 52);
      
      // Add summary section
      doc.setFontSize(16);
      doc.setTextColor(37, 99, 235);
      doc.text("Summary", 20, 60);
      
      // Summary boxes
      doc.setDrawColor(200, 200, 200);
      doc.setFillColor(240, 240, 240);
      doc.roundedRect(20, 65, 50, 30, 3, 3, 'FD');
      doc.roundedRect(80, 65, 50, 30, 3, 3, 'FD');
      doc.roundedRect(140, 65, 50, 30, 3, 3, 'FD');
      
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text("Total Feedings", 45, 72, { align: "center" });
      doc.text("Total Sleep Sessions", 105, 72, { align: "center" });
      doc.text("Total Diapers", 165, 72, { align: "center" });
      
      doc.setFontSize(14);
      doc.setTextColor(37, 99, 235);
      doc.text(`${totalFeedings}`, 45, 80, { align: "center" });
      doc.text(`${totalSleeps}`, 105, 80, { align: "center" });
      doc.text(`${totalDiapers}`, 165, 80, { align: "center" });
      
      doc.setFontSize(8);
      doc.setTextColor(100, 100, 100);
      doc.text(`Avg. ${avgFeedingsPerDay.toFixed(1)} per day`, 45, 88, { align: "center" });
      doc.text(`Avg. ${avgSleepHours}h ${avgSleepMinutes}m`, 105, 88, { align: "center" });
      doc.text(`Avg. ${avgDiapersPerDay.toFixed(1)} per day`, 165, 88, { align: "center" });
      
      let yPos = 105;
      
      // Add feeding details
      doc.setFontSize(16);
      doc.setTextColor(37, 99, 235);
      doc.text("Feeding Details", 20, yPos);
      yPos += 10;
      
      if (filteredFeedings.length === 0) {
        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        doc.text("No feeding records available for this period.", 20, yPos);
        yPos += 10;
      } else {
        doc.setFontSize(10);
        filteredFeedings.forEach((feeding, index) => {
          // Check if we need a new page
          if (yPos > 270) {
            doc.addPage();
            yPos = 20;
          }
          
          const time = formatDateTime(feeding.startTime);
          const duration = feeding.duration ? `${feeding.duration} min` : 'N/A';
          const amount = feeding.amount ? `${feeding.amount}` : 'N/A';
          const side = feeding.side ? `${feeding.side}` : 'N/A';
          
          doc.setTextColor(37, 99, 235);
          doc.setFont(undefined, 'bold');
          doc.text(`${index + 1}. ${time}`, 20, yPos);
          yPos += 6;
          
          doc.setTextColor(0, 0, 0);
          doc.setFont(undefined, 'normal');
          doc.text(`Type: ${feeding.type}, Duration: ${duration}, Amount: ${amount}, Side: ${side}`, 25, yPos);
          yPos += 6;
          
          if (feeding.notes) {
            doc.setFont(undefined, 'italic');
            doc.setTextColor(100, 100, 100);
            doc.text(`Notes: ${feeding.notes}`, 25, yPos);
            yPos += 6;
          }
          
          yPos += 2;
        });
      }
      
      // Add sleep details
      // Check if we need a new page
      if (yPos > 240) {
        doc.addPage();
        yPos = 20;
      }
      
      doc.setFontSize(16);
      doc.setTextColor(37, 99, 235);
      doc.text("Sleep Details", 20, yPos);
      yPos += 10;
      
      if (filteredSleeps.length === 0) {
        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        doc.text("No sleep records available for this period.", 20, yPos);
        yPos += 10;
      } else {
        doc.setFontSize(10);
        filteredSleeps.forEach((sleep, index) => {
          // Check if we need a new page
          if (yPos > 270) {
            doc.addPage();
            yPos = 20;
          }
          
          const startTime = formatDateTime(sleep.startTime);
          const endTime = sleep.endTime ? formatDateTime(sleep.endTime) : 'N/A';
          const duration = sleep.duration ? `${sleep.duration} min` : 'N/A';
          const quality = sleep.quality ? `${sleep.quality}` : 'N/A';
          
          doc.setTextColor(37, 99, 235);
          doc.setFont(undefined, 'bold');
          doc.text(`${index + 1}. ${startTime} to ${endTime}`, 20, yPos);
          yPos += 6;
          
          doc.setTextColor(0, 0, 0);
          doc.setFont(undefined, 'normal');
          doc.text(`Duration: ${duration}, Quality: ${quality}`, 25, yPos);
          yPos += 6;
          
          if (sleep.notes) {
            doc.setFont(undefined, 'italic');
            doc.setTextColor(100, 100, 100);
            doc.text(`Notes: ${sleep.notes}`, 25, yPos);
            yPos += 6;
          }
          
          yPos += 2;
        });
      }
      
      // Add diaper details
      // Check if we need a new page
      if (yPos > 240) {
        doc.addPage();
        yPos = 20;
      }
      
      doc.setFontSize(16);
      doc.setTextColor(37, 99, 235);
      doc.text("Diaper Details", 20, yPos);
      yPos += 10;
      
      if (filteredDiapers.length === 0) {
        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        doc.text("No diaper records available for this period.", 20, yPos);
        yPos += 10;
      } else {
        doc.setFontSize(10);
        filteredDiapers.forEach((diaper, index) => {
          // Check if we need a new page
          if (yPos > 270) {
            doc.addPage();
            yPos = 20;
          }
          
          const time = formatDateTime(diaper.time);
          
          doc.setTextColor(37, 99, 235);
          doc.setFont(undefined, 'bold');
          doc.text(`${index + 1}. ${time}`, 20, yPos);
          yPos += 6;
          
          doc.setTextColor(0, 0, 0);
          doc.setFont(undefined, 'normal');
          doc.text(`Type: ${diaper.type}`, 25, yPos);
          yPos += 6;
          
          if (diaper.notes) {
            doc.setFont(undefined, 'italic');
            doc.setTextColor(100, 100, 100);
            doc.text(`Notes: ${diaper.notes}`, 25, yPos);
            yPos += 6;
          }
          
          yPos += 2;
        });
      }
      
      // Add footer on each page
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text('Generated by Baby Tracker App', 105, 290, { align: 'center' });
        doc.text(`Page ${i} of ${pageCount}`, 190, 290, { align: 'right' });
      }
      
      // Set response headers for PDF download
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
      
      // Send the PDF as the response
      const pdfOutput = doc.output('arraybuffer');
      res.send(Buffer.from(pdfOutput));
      
    } catch (error) {
      console.error("Report generation error:", error);
      next(error);
    }
  });

  // Supply routes
  app.post("/api/supplies", isAuthenticated, async (req, res, next) => {
    try {
      const { name, category, status, quantity, unit, notes, onShoppingList, alertWhenLow } = req.body;
      if (!name || !category) {
        return res.status(400).json({ message: "Name and category are required" });
      }
      
      const supplyItem = await storage.createSupplyItem({
        userId: req.user!.id,
        name,
        category,
        status: status || 'in-stock',
        quantity: quantity || null,
        unit: unit || null,
        notes: notes || null,
        onShoppingList: onShoppingList || false,
        alertWhenLow: alertWhenLow || false,
      });
      
      res.status(201).json(supplyItem);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/supplies", isAuthenticated, async (req, res, next) => {
    try {
      const { status } = req.query;
      let supplies;
      
      if (status) {
        supplies = await storage.getSupplyItemsByStatus(req.user!.id, status as string);
      } else {
        supplies = await storage.getSupplyItemsByUser(req.user!.id);
      }
      
      res.json(supplies);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/supplies/shopping-list", isAuthenticated, async (req, res, next) => {
    try {
      const supplies = await storage.getShoppingList(req.user!.id);
      res.json(supplies);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/supplies/:supplyId", isAuthenticated, async (req, res, next) => {
    try {
      const supplyItem = await storage.getSupplyItem(parseInt(req.params.supplyId));
      
      if (!supplyItem) {
        return res.status(404).json({ message: "Supply item not found" });
      }
      
      // Check if the supply item belongs to the current user
      if (supplyItem.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(supplyItem);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/supplies/:supplyId", isAuthenticated, async (req, res, next) => {
    try {
      const { name, category, status, quantity, unit, notes, onShoppingList, alertWhenLow } = req.body;
      const supplyItem = await storage.getSupplyItem(parseInt(req.params.supplyId));
      
      if (!supplyItem) {
        return res.status(404).json({ message: "Supply item not found" });
      }
      
      // Check if the supply item belongs to the current user
      if (supplyItem.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updatedSupplyItem = await storage.updateSupplyItem(parseInt(req.params.supplyId), {
        name: name || supplyItem.name,
        category: category || supplyItem.category,
        status: status !== undefined ? status : supplyItem.status,
        quantity: quantity !== undefined ? quantity : supplyItem.quantity,
        unit: unit !== undefined ? unit : supplyItem.unit,
        notes: notes !== undefined ? notes : supplyItem.notes,
        onShoppingList: onShoppingList !== undefined ? onShoppingList : supplyItem.onShoppingList,
        alertWhenLow: alertWhenLow !== undefined ? alertWhenLow : supplyItem.alertWhenLow,
      });
      
      if (!updatedSupplyItem) {
        return res.status(404).json({ message: "Failed to update supply item" });
      }
      
      res.json(updatedSupplyItem);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/supplies/:supplyId", isAuthenticated, async (req, res, next) => {
    try {
      const supplyItem = await storage.getSupplyItem(parseInt(req.params.supplyId));
      
      if (!supplyItem) {
        return res.status(404).json({ message: "Supply item not found" });
      }
      
      // Check if the supply item belongs to the current user
      if (supplyItem.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const success = await storage.deleteSupplyItem(parseInt(req.params.supplyId));
      if (!success) {
        return res.status(404).json({ message: "Failed to delete supply item" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });
  
  // Baby update route (for gender and other fields)
  app.put("/api/babies/:babyId", isAuthenticated, hasBabyAccess, isAdmin, async (req, res, next) => {
    try {
      const { name, gender, dateOfBirth } = req.body;
      const baby = await storage.getBaby(parseInt(req.params.babyId));
      
      if (!baby) {
        return res.status(404).json({ message: "Baby not found" });
      }
      
      const updatedBaby = await storage.updateBaby(parseInt(req.params.babyId), {
        name: name || baby.name,
        gender: gender !== undefined ? gender : baby.gender,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : baby.dateOfBirth,
      });
      
      if (!updatedBaby) {
        return res.status(404).json({ message: "Failed to update baby" });
      }
      
      res.json(updatedBaby);
    } catch (error) {
      next(error);
    }
  });
  
  // For generating share codes with expiration
  app.get("/api/babies/:babyId/debug-generate-code", isAuthenticated, async (req, res, next) => {
    console.log("DEBUG: Direct generate code route accessed");
    
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Generate a new 12-digit code
      const shareCode = Math.floor(100000000000 + Math.random() * 900000000000).toString();
      console.log("DEBUG: Generated new share code:", shareCode);
      
      // Set expiration time - 5 minutes from now for testing by default
      const expiryMinutes = parseInt(req.query.expiryMinutes as string) || 5; // Default to 5 minutes
      const shareCodeExpiry = new Date();
      shareCodeExpiry.setMinutes(shareCodeExpiry.getMinutes() + expiryMinutes);
      
      console.log(`Setting share code expiry to: ${shareCodeExpiry} (${expiryMinutes} minutes from now)`);
      
      // Update the baby with the new share code and expiry
      const updatedBaby = await storage.updateBaby(babyId, { 
        shareCode,
        shareCodeExpiry
      });
      
      if (!updatedBaby) {
        return res.status(404).json({ message: "Failed to update baby" });
      }
      
      res.json({ 
        success: true,
        baby: updatedBaby, 
        shareCode,
        expiresAt: shareCodeExpiry
      });
    } catch (error) {
      console.error("DEBUG route error:", error);
      next(error);
    }
  });
  
  // Generate new share code for a baby with default permission
  app.post("/api/babies/:babyId/regenerate-code", isAuthenticated, hasBabyAccess, isAdmin, async (req, res, next) => {
    console.log("Regenerate code request received", {
      userId: req.user?.id,
      babyId: req.params.babyId,
      body: req.body
    });
    
    try {
      const babyId = parseInt(req.params.babyId);
      const { defaultRole } = req.body;
      
      console.log("Processing regenerate code", { babyId, defaultRole });
      
      // Validate role
      if (!defaultRole || !['admin', 'editor', 'viewer'].includes(defaultRole)) {
        console.log("Invalid role for regenerate code:", defaultRole);
        return res.status(400).json({ message: "Valid default role is required (admin, editor, or viewer)" });
      }
      
      const baby = await storage.getBaby(babyId);
      if (!baby) {
        console.log("Baby not found for regenerate code:", babyId);
        return res.status(404).json({ message: "Baby not found" });
      }
      
      console.log("Generating new share code for baby:", baby.name);
      
      // Generate a new 12-digit code
      const shareCode = Math.floor(100000000000 + Math.random() * 900000000000).toString();
      console.log("Generated new share code:", shareCode);
      
      // Set expiration time to 5 minutes from now
      const shareCodeExpiry = new Date();
      shareCodeExpiry.setMinutes(shareCodeExpiry.getMinutes() + 5);
      
      // Update the baby with the new share code and expiry
      const updatedBaby = await storage.updateBaby(babyId, { 
        shareCode,
        shareCodeExpiry
      });
      
      if (!updatedBaby) {
        console.log("Failed to update baby with new share code");
        return res.status(404).json({ message: "Failed to update baby" });
      }
      
      console.log("Successfully updated baby with new share code", {
        babyId: updatedBaby.id,
        shareCode: updatedBaby.shareCode
      });
      
      // Store the default role for this share code - in a real app this would go in a separate table
      // For now, we just return the information to the client
      res.json({ 
        baby: updatedBaby, 
        shareCode, 
        defaultRole 
      });
    } catch (error) {
      console.error("Error in regenerate-code endpoint:", error);
      next(error);
    }
  });
  
  // Growth Tracking routes
  app.post("/api/babies/:babyId/growth", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { weight, height, headCircumference, date, notes } = req.body;
      if (!date) {
        return res.status(400).json({ message: "Date is required" });
      }
      
      const growthRecord = await storage.createGrowthRecord({
        babyId: parseInt(req.params.babyId),
        weight: weight || null,
        height: height || null,
        headCircumference: headCircumference || null,
        date: new Date(date),
        notes: notes || null,
        createdBy: req.user!.id,
      });
      
      res.status(201).json(growthRecord);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/growth", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const records = await storage.getGrowthRecordsByBaby(parseInt(req.params.babyId));
      res.json(records);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/growth/:recordId", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const record = await storage.getGrowthRecord(parseInt(req.params.recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Growth record not found" });
      }
      
      // Make sure the record belongs to the specified baby
      if (record.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Growth record not found for this baby" });
      }
      
      res.json(record);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/babies/:babyId/growth/:recordId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { weight, height, headCircumference, date, notes } = req.body;
      const record = await storage.getGrowthRecord(parseInt(req.params.recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Growth record not found" });
      }
      
      // Make sure the record belongs to the specified baby
      if (record.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Growth record not found for this baby" });
      }
      
      const updatedRecord = await storage.updateGrowthRecord(parseInt(req.params.recordId), {
        weight: weight !== undefined ? weight : record.weight,
        height: height !== undefined ? height : record.height,
        headCircumference: headCircumference !== undefined ? headCircumference : record.headCircumference,
        date: date ? new Date(date) : record.date,
        notes: notes !== undefined ? notes : record.notes,
      });
      
      if (!updatedRecord) {
        return res.status(404).json({ message: "Failed to update growth record" });
      }
      
      res.json(updatedRecord);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/babies/:babyId/growth/:recordId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const record = await storage.getGrowthRecord(parseInt(req.params.recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Growth record not found" });
      }
      
      // Make sure the record belongs to the specified baby
      if (record.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Growth record not found for this baby" });
      }
      
      const success = await storage.deleteGrowthRecord(parseInt(req.params.recordId));
      if (!success) {
        return res.status(404).json({ message: "Failed to delete growth record" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });
  
  // Milestone Tracking routes
  app.post("/api/babies/:babyId/milestones", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { title, description, category, date, mediaUrl } = req.body;
      if (!title || !date) {
        return res.status(400).json({ message: "Title and date are required" });
      }
      
      const milestone = await storage.createMilestone({
        babyId: parseInt(req.params.babyId),
        title,
        description: description || null,
        category: category || null,
        date: new Date(date),
        mediaUrl: mediaUrl || null,
        createdBy: req.user!.id,
      });
      
      res.status(201).json(milestone);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/milestones", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { category } = req.query;
      let milestones;
      
      if (category) {
        milestones = await storage.getMilestonesByCategory(parseInt(req.params.babyId), category as string);
      } else {
        milestones = await storage.getMilestonesByBaby(parseInt(req.params.babyId));
      }
      
      res.json(milestones);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/milestones/:milestoneId", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const milestone = await storage.getMilestone(parseInt(req.params.milestoneId));
      
      if (!milestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }
      
      // Make sure the milestone belongs to the specified baby
      if (milestone.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Milestone not found for this baby" });
      }
      
      res.json(milestone);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/babies/:babyId/milestones/:milestoneId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { title, description, category, date, mediaUrl } = req.body;
      const milestone = await storage.getMilestone(parseInt(req.params.milestoneId));
      
      if (!milestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }
      
      // Make sure the milestone belongs to the specified baby
      if (milestone.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Milestone not found for this baby" });
      }
      
      const updatedMilestone = await storage.updateMilestone(parseInt(req.params.milestoneId), {
        title: title || milestone.title,
        description: description !== undefined ? description : milestone.description,
        category: category !== undefined ? category : milestone.category,
        date: date ? new Date(date) : milestone.date,
        mediaUrl: mediaUrl !== undefined ? mediaUrl : milestone.mediaUrl,
      });
      
      if (!updatedMilestone) {
        return res.status(404).json({ message: "Failed to update milestone" });
      }
      
      res.json(updatedMilestone);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/babies/:babyId/milestones/:milestoneId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const milestone = await storage.getMilestone(parseInt(req.params.milestoneId));
      
      if (!milestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }
      
      // Make sure the milestone belongs to the specified baby
      if (milestone.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Milestone not found for this baby" });
      }
      
      const success = await storage.deleteMilestone(parseInt(req.params.milestoneId));
      if (!success) {
        return res.status(404).json({ message: "Failed to delete milestone" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });
  
  // Health Tracking routes
  app.post("/api/babies/:babyId/health", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { recordType, date, temperature, medicationName, medicationDose, medicationSchedule, doctorNotes, notes } = req.body;
      if (!recordType || !date) {
        return res.status(400).json({ message: "Record type and date are required" });
      }
      
      const healthRecord = await storage.createHealthRecord({
        babyId: parseInt(req.params.babyId),
        recordType,
        date: new Date(date),
        temperature: temperature || null,
        medicationName: medicationName || null,
        medicationDose: medicationDose || null,
        medicationSchedule: medicationSchedule || null,
        doctorNotes: doctorNotes || null,
        notes: notes || null,
        createdBy: req.user!.id,
      });
      
      res.status(201).json(healthRecord);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/health", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const { recordType, startDate, endDate } = req.query;
      let healthRecords;
      
      if (recordType) {
        healthRecords = await storage.getHealthRecordsByType(parseInt(req.params.babyId), recordType as string);
      } else if (startDate && endDate) {
        healthRecords = await storage.getHealthRecordsByDate(
          parseInt(req.params.babyId), 
          new Date(startDate as string), 
          new Date(endDate as string)
        );
      } else {
        healthRecords = await storage.getHealthRecordsByBaby(parseInt(req.params.babyId));
      }
      
      res.json(healthRecords);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/babies/:babyId/health/:recordId", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const record = await storage.getHealthRecord(parseInt(req.params.recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Health record not found" });
      }
      
      // Make sure the record belongs to the specified baby
      if (record.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Health record not found for this baby" });
      }
      
      res.json(record);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/babies/:babyId/health/:recordId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const { recordType, date, temperature, medicationName, medicationDose, medicationSchedule, doctorNotes, notes } = req.body;
      const record = await storage.getHealthRecord(parseInt(req.params.recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Health record not found" });
      }
      
      // Make sure the record belongs to the specified baby
      if (record.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Health record not found for this baby" });
      }
      
      const updatedRecord = await storage.updateHealthRecord(parseInt(req.params.recordId), {
        recordType: recordType || record.recordType,
        date: date ? new Date(date) : record.date,
        temperature: temperature !== undefined ? temperature : record.temperature,
        medicationName: medicationName !== undefined ? medicationName : record.medicationName,
        medicationDose: medicationDose !== undefined ? medicationDose : record.medicationDose,
        medicationSchedule: medicationSchedule !== undefined ? medicationSchedule : record.medicationSchedule,
        doctorNotes: doctorNotes !== undefined ? doctorNotes : record.doctorNotes,
        notes: notes !== undefined ? notes : record.notes,
      });
      
      if (!updatedRecord) {
        return res.status(404).json({ message: "Failed to update health record" });
      }
      
      res.json(updatedRecord);
    } catch (error) {
      next(error);
    }
  });
  
  app.delete("/api/babies/:babyId/health/:recordId", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const record = await storage.getHealthRecord(parseInt(req.params.recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Health record not found" });
      }
      
      // Make sure the record belongs to the specified baby
      if (record.babyId !== parseInt(req.params.babyId)) {
        return res.status(404).json({ message: "Health record not found for this baby" });
      }
      
      const success = await storage.deleteHealthRecord(parseInt(req.params.recordId));
      if (!success) {
        return res.status(404).json({ message: "Failed to delete health record" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // Pumping & Milk Storage API Routes
  // ==================================
  
  // Pump Sessions
  // ------------
  
  // Get pump sessions for a baby
  app.get("/api/babies/:babyId/pump-sessions", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Get all pump sessions for this baby
      const sessions = await db.select().from(pumpSessions).where(eq(pumpSessions.babyId, babyId))
        .orderBy(desc(pumpSessions.startTime));
      
      res.json(sessions);
    } catch (error) {
      next(error);
    }
  });
  
  // Create a new pump session
  app.post("/api/babies/:babyId/pump-sessions", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Validate the request body
      const parsedBody = insertPumpSessionSchema.safeParse({
        ...req.body,
        babyId,
        userId: req.user.id,
      });
      
      if (!parsedBody.success) {
        return res.status(400).json({ errors: parsedBody.error.errors });
      }
      
      // Calculate total amount if not provided
      let data = parsedBody.data;
      
      if (!data.totalAmount && (data.amountLeftBreast || data.amountRightBreast)) {
        data.totalAmount = (data.amountLeftBreast || 0) + (data.amountRightBreast || 0);
      }
      
      // Calculate duration if not provided
      if (!data.duration && data.startTime && data.endTime) {
        const startTime = new Date(data.startTime);
        const endTime = new Date(data.endTime);
        data.duration = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60));
      }
      
      // Create the pump session
      const [newSession] = await db.insert(pumpSessions).values(data).returning();
      
      res.status(201).json(newSession);
    } catch (error) {
      next(error);
    }
  });
  
  // Get a specific pump session
  app.get("/api/pump-sessions/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the pump session
      const [session] = await db.select().from(pumpSessions).where(eq(pumpSessions.id, id));
      
      if (!session) {
        return res.status(404).json({ message: "Pump session not found" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, session.babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      res.json(session);
    } catch (error) {
      next(error);
    }
  });
  
  // Update a pump session
  app.put("/api/pump-sessions/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the pump session
      const [session] = await db.select().from(pumpSessions).where(eq(pumpSessions.id, id));
      
      if (!session) {
        return res.status(404).json({ message: "Pump session not found" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, session.babyId);
      if (!access || (access.role !== 'admin' && access.role !== 'editor')) {
        return res.status(403).json({ message: "No permission to edit" });
      }
      
      // Update the session
      const [updatedSession] = await db.update(pumpSessions)
        .set(req.body)
        .where(eq(pumpSessions.id, id))
        .returning();
      
      res.json(updatedSession);
    } catch (error) {
      next(error);
    }
  });
  
  // Delete a pump session
  app.delete("/api/pump-sessions/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the pump session
      const [session] = await db.select().from(pumpSessions).where(eq(pumpSessions.id, id));
      
      if (!session) {
        return res.status(404).json({ message: "Pump session not found" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, session.babyId);
      if (!access || (access.role !== 'admin' && access.role !== 'editor')) {
        return res.status(403).json({ message: "No permission to delete" });
      }
      
      // Delete the session
      await db.delete(pumpSessions).where(eq(pumpSessions.id, id));
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });
  
  // Milk Storage
  // -----------
  
  // Get milk storage entries for a baby
  app.get("/api/babies/:babyId/milk-storage", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const activeOnly = req.query.active === 'true';
      
      // Base query
      let query = db.select().from(milkStorage).where(eq(milkStorage.babyId, babyId));
      
      // Filter by active only if requested
      if (activeOnly) {
        query = query.where(eq(milkStorage.isFinished, false));
      }
      
      // Get all milk storage entries for this baby
      const milkEntries = await query.orderBy(desc(milkStorage.storedDate));
      
      res.json(milkEntries);
    } catch (error) {
      next(error);
    }
  });
  
  // Create a new milk storage entry
  app.post("/api/babies/:babyId/milk-storage", isAuthenticated, hasBabyAccess, canEdit, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Generate container ID if not provided
      const containerId = req.body.containerId || `MILK-${Date.now().toString(36).toUpperCase()}`;
      
      // Calculate expiry date based on storage type if not provided
      let expiryDate = req.body.expiryDate;
      if (!expiryDate && req.body.storageType && req.body.storedDate) {
        const storedDate = new Date(req.body.storedDate);
        
        // Default expiry times: 4 days for fridge, 6 months for freezer
        if (req.body.storageType === 'fridge') {
          expiryDate = new Date(storedDate);
          expiryDate.setDate(expiryDate.getDate() + 4);
        } else if (req.body.storageType === 'freezer') {
          expiryDate = new Date(storedDate);
          expiryDate.setMonth(expiryDate.getMonth() + 6);
        }
      }
      
      // Validate the request body
      const parsedBody = insertMilkStorageSchema.safeParse({
        ...req.body,
        babyId,
        userId: req.user.id,
        containerId,
        expiryDate,
        storedDate: req.body.storedDate || new Date(),
      });
      
      if (!parsedBody.success) {
        return res.status(400).json({ errors: parsedBody.error.errors });
      }
      
      // Create the milk storage entry
      const [newEntry] = await db.insert(milkStorage).values(parsedBody.data).returning();
      
      res.status(201).json(newEntry);
    } catch (error) {
      next(error);
    }
  });
  
  // Get a specific milk storage entry
  app.get("/api/milk-storage/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the milk storage entry
      const [entry] = await db.select().from(milkStorage).where(eq(milkStorage.id, id));
      
      if (!entry) {
        return res.status(404).json({ message: "Milk storage entry not found" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, entry.babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      res.json(entry);
    } catch (error) {
      next(error);
    }
  });
  
  // Update a milk storage entry (use or discard)
  app.put("/api/milk-storage/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the milk storage entry
      const [entry] = await db.select().from(milkStorage).where(eq(milkStorage.id, id));
      
      if (!entry) {
        return res.status(404).json({ message: "Milk storage entry not found" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, entry.babyId);
      if (!access || (access.role !== 'admin' && access.role !== 'editor')) {
        return res.status(403).json({ message: "No permission to edit" });
      }
      
      // Update fields
      const updateData = { ...req.body };
      
      // If used amount is updated, check if it equals total amount
      if (req.body.usedAmount !== undefined) {
        if (req.body.usedAmount >= entry.amount) {
          updateData.isFinished = true;
          updateData.usedAmount = entry.amount;
        }
      }
      
      // Mark as finished if explicit
      if (req.body.isFinished === true) {
        updateData.isFinished = true;
      }
      
      const [updatedEntry] = await db.update(milkStorage)
        .set(updateData)
        .where(eq(milkStorage.id, id))
        .returning();
      
      res.json(updatedEntry);
    } catch (error) {
      next(error);
    }
  });
  
  // Journal Entries API routes
  
  // Get all journal entries for a baby
  app.get("/api/journal/:babyId", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const entries = await storage.getJournalEntriesByBaby(babyId);
      res.json(entries);
    } catch (error) {
      next(error);
    }
  });

  // Get journal entries by date
  app.get("/api/journal/:babyId/date/:date", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const date = new Date(req.params.date);
      const entries = await storage.getJournalEntriesByDate(babyId, date);
      res.json(entries);
    } catch (error) {
      next(error);
    }
  });

  // Get journal entries by category
  app.get("/api/journal/:babyId/category/:category", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const { category } = req.params;
      const entries = await storage.getJournalEntriesByCategory(babyId, category);
      res.json(entries);
    } catch (error) {
      next(error);
    }
  });

  // Create a new journal entry
  app.post("/api/journal", isAuthenticated, async (req, res, next) => {
    try {
      const babyId = req.body.babyId;
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      // Ensure user has editor or admin role to create entries
      if (access.role === 'viewer') {
        return res.status(403).json({ message: "No permission to create journal entries" });
      }
      
      const journalData = {
        ...req.body,
        createdBy: req.user.id
      };
      
      const entry = await storage.createJournalEntry(journalData);
      res.status(201).json(entry);
    } catch (error) {
      next(error);
    }
  });

  // Get a single journal entry
  app.get("/api/journal/entry/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const entry = await storage.getJournalEntry(id);
      
      if (!entry) {
        return res.status(404).json({ message: "Journal entry not found" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, entry.babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      res.json(entry);
    } catch (error) {
      next(error);
    }
  });

  // Update a journal entry
  app.put("/api/journal/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the journal entry
      const entry = await storage.getJournalEntry(id);
      
      if (!entry) {
        return res.status(404).json({ message: "Journal entry not found" });
      }
      
      // Check if user has access to edit
      const access = await storage.getBabyAccess(req.user.id, entry.babyId);
      
      if (!access || (access.role !== 'admin' && access.role !== 'editor')) {
        return res.status(403).json({ message: "No permission to edit" });
      }
      
      // Only allow editing entries created by the user, unless admin
      if (entry.createdBy !== req.user.id && access.role !== 'admin') {
        return res.status(403).json({ message: "Can only edit your own entries" });
      }
      
      const updatedEntry = await storage.updateJournalEntry(id, req.body);
      res.json(updatedEntry);
    } catch (error) {
      next(error);
    }
  });

  // Delete a journal entry
  app.delete("/api/journal/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the journal entry
      const entry = await storage.getJournalEntry(id);
      
      if (!entry) {
        return res.status(404).json({ message: "Journal entry not found" });
      }
      
      // Check if user has access to delete
      const access = await storage.getBabyAccess(req.user.id, entry.babyId);
      
      if (!access || access.role !== 'admin') {
        // Only allow the owner to delete their own entries
        if (entry.createdBy !== req.user.id) {
          return res.status(403).json({ message: "No permission to delete" });
        }
      }
      
      const success = await storage.deleteJournalEntry(id);
      
      if (success) {
        res.status(200).json({ message: "Journal entry deleted" });
      } else {
        res.status(500).json({ message: "Failed to delete journal entry" });
      }
    } catch (error) {
      next(error);
    }
  });

  // Delete a milk storage entry
  app.delete("/api/milk-storage/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the milk storage entry
      const [entry] = await db.select().from(milkStorage).where(eq(milkStorage.id, id));
      
      if (!entry) {
        return res.status(404).json({ message: "Milk storage entry not found" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user.id, entry.babyId);
      if (!access || (access.role !== 'admin' && access.role !== 'editor')) {
        return res.status(403).json({ message: "No permission to delete" });
      }
      
      // Delete the entry
      await db.delete(milkStorage).where(eq(milkStorage.id, id));
      
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });
  
  // Get expiry summary for milk storage
  app.get("/api/babies/:babyId/milk-storage/summary", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Get all active milk storage entries
      const milkEntries = await db.select().from(milkStorage)
        .where(eq(milkStorage.babyId, babyId))
        .where(eq(milkStorage.isFinished, false));
      
      // Calculate summary
      const now = new Date();
      const summary = {
        totalMilk: 0,              // Total milk in storage (ml)
        totalFridgeMilk: 0,        // Total milk in fridge (ml)
        totalFreezerMilk: 0,       // Total milk in freezer (ml)
        expiringToday: 0,          // Count of items expiring today
        expiringThisWeek: 0,       // Count of items expiring this week
        expiredItems: 0,           // Count of expired items still in storage
        fridgeContainers: 0,       // Number of containers in fridge
        freezerContainers: 0,      // Number of containers in freezer
        oldestMilkDate: null,      // Date of oldest milk in storage
        newestMilkDate: null,      // Date of newest milk in storage
      };
      
      // Process each entry
      milkEntries.forEach(entry => {
        // Calculate available amount
        const availableAmount = entry.amount - (entry.usedAmount || 0);
        
        // Add to totals
        summary.totalMilk += availableAmount;
        
        if (entry.storageType === 'fridge') {
          summary.totalFridgeMilk += availableAmount;
          summary.fridgeContainers++;
        } else if (entry.storageType === 'freezer') {
          summary.totalFreezerMilk += availableAmount;
          summary.freezerContainers++;
        }
        
        // Check expiry
        const expiryDate = new Date(entry.expiryDate);
        
        if (expiryDate < now) {
          summary.expiredItems++;
        } else {
          // Check if expiring today
          const today = new Date(now);
          today.setHours(23, 59, 59, 999);
          
          if (expiryDate <= today) {
            summary.expiringToday++;
          } else {
            // Check if expiring this week
            const oneWeek = new Date(now);
            oneWeek.setDate(oneWeek.getDate() + 7);
            
            if (expiryDate <= oneWeek) {
              summary.expiringThisWeek++;
            }
          }
        }
        
        // Track oldest/newest milk
        const storedDate = new Date(entry.storedDate);
        
        if (!summary.oldestMilkDate || storedDate < new Date(summary.oldestMilkDate)) {
          summary.oldestMilkDate = entry.storedDate;
        }
        
        if (!summary.newestMilkDate || storedDate > new Date(summary.newestMilkDate)) {
          summary.newestMilkDate = entry.storedDate;
        }
      });
      
      res.json(summary);
    } catch (error) {
      next(error);
    }
  });

  // Appointment routes
  // Get all appointments for a baby
  app.get("/api/babies/:babyId/appointments", isAuthenticated, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Validate babyId
      if (isNaN(babyId)) {
        return res.status(400).json({ message: "Invalid baby ID" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user!.id, babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      const appointments = await storage.getAppointmentsByBaby(babyId);
      res.json(appointments);
    } catch (error) {
      next(error);
    }
  });

  // Get upcoming appointments for a baby
  app.get("/api/babies/:babyId/appointments/upcoming", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const appointments = await storage.getUpcomingAppointments(babyId);
      res.json(appointments);
    } catch (error) {
      next(error);
    }
  });

  // Get a specific appointment
  app.get("/api/appointments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Check if user has access to the baby related to this appointment
      const access = await storage.getBabyAccess(req.user!.id, appointment.babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this appointment" });
      }
      
      res.json(appointment);
    } catch (error) {
      next(error);
    }
  });

  // Create a new appointment
  app.post("/api/appointments", isAuthenticated, async (req, res, next) => {
    try {
      // Ensure babyId is valid
      const babyId = parseInt(req.body.babyId);
      
      if (isNaN(babyId)) {
        return res.status(400).json({ message: "Invalid baby ID" });
      }
      
      // Ensure user has access to the baby
      const access = await storage.getBabyAccess(req.user!.id, babyId);
      
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      // Create appointment
      const appointment = await storage.createAppointment({
        ...req.body,
        babyId: babyId, // Ensure babyId is explicitly set
        createdBy: req.user!.id
      });
      
      res.status(201).json(appointment);
    } catch (error) {
      next(error);
    }
  });

  // Update an appointment
  app.patch("/api/appointments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Check if user has access to the baby related to this appointment
      const access = await storage.getBabyAccess(req.user!.id, appointment.babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this appointment" });
      }
      
      // Only admin or the creator can update appointment
      if (access.role !== "admin" && appointment.createdBy !== req.user!.id) {
        return res.status(403).json({ message: "No permission to update this appointment" });
      }
      
      const updated = await storage.updateAppointment(id, req.body);
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  // Delete an appointment
  app.delete("/api/appointments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Check if user has access to the baby related to this appointment
      const access = await storage.getBabyAccess(req.user!.id, appointment.babyId);
      if (!access || access.role !== "admin") {
        return res.status(403).json({ message: "No permission to delete this appointment" });
      }
      
      await storage.deleteAppointment(id);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  // Vaccine routes
  // Get all vaccines for a baby
  app.get("/api/babies/:babyId/vaccines", isAuthenticated, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Validate babyId
      if (isNaN(babyId)) {
        return res.status(400).json({ message: "Invalid baby ID" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user!.id, babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      const vaccines = await storage.getVaccinesByBaby(babyId);
      res.json(vaccines);
    } catch (error) {
      next(error);
    }
  });

  // Get due vaccines for a baby
  app.get("/api/babies/:babyId/vaccines/due", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const vaccines = await storage.getDueVaccines(babyId);
      res.json(vaccines);
    } catch (error) {
      next(error);
    }
  });

  // Get a specific vaccine
  app.get("/api/vaccines/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const vaccine = await storage.getVaccine(id);
      
      if (!vaccine) {
        return res.status(404).json({ message: "Vaccine not found" });
      }
      
      // Check if user has access to the baby related to this vaccine
      const access = await storage.getBabyAccess(req.user!.id, vaccine.babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this vaccine" });
      }
      
      res.json(vaccine);
    } catch (error) {
      next(error);
    }
  });

  // Create a new vaccine
  app.post("/api/vaccines", isAuthenticated, async (req, res, next) => {
    try {
      // Ensure user has access to the baby
      const babyId = parseInt(req.body.babyId);
      const access = await storage.getBabyAccess(req.user!.id, babyId);
      
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      // Create vaccine
      const vaccine = await storage.createVaccine({
        ...req.body,
        createdBy: req.user!.id
      });
      
      res.status(201).json(vaccine);
    } catch (error) {
      next(error);
    }
  });
  
  // Create a new vaccine for a specific baby
  app.post("/api/babies/:babyId/vaccines", isAuthenticated, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      
      // Validate babyId
      if (isNaN(babyId)) {
        return res.status(400).json({ message: "Invalid baby ID" });
      }
      
      // Check if user has access to the baby
      const access = await storage.getBabyAccess(req.user!.id, babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this baby" });
      }
      
      // Check if user has edit permissions
      if (access.role !== "admin" && access.role !== "editor") {
        return res.status(403).json({ message: "No permission to create vaccine records" });
      }
      
      // Create vaccine with babyId from the URL
      console.log("Creating vaccine with data:", req.body);
      
      // Ensure dates are properly formatted
      const vaccineData = {
        ...req.body,
        babyId,
        createdBy: req.user!.id
      };
      
      const vaccine = await storage.createVaccine(vaccineData);
      
      res.status(201).json(vaccine);
    } catch (error) {
      next(error);
    }
  });

  // Update a vaccine
  app.patch("/api/babies/:babyId/vaccines/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const vaccine = await storage.getVaccine(id);
      
      if (!vaccine) {
        return res.status(404).json({ message: "Vaccine not found" });
      }
      
      // Check if user has access to the baby related to this vaccine
      const access = await storage.getBabyAccess(req.user!.id, vaccine.babyId);
      if (!access) {
        return res.status(403).json({ message: "No access to this vaccine" });
      }
      
      // Only admin or the creator can update vaccine
      if (access.role !== "admin" && vaccine.createdBy !== req.user!.id) {
        return res.status(403).json({ message: "No permission to update this vaccine" });
      }
      
      const updated = await storage.updateVaccine(id, req.body);
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });

  // Delete a vaccine
  app.delete("/api/babies/:babyId/vaccines/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const vaccine = await storage.getVaccine(id);
      
      if (!vaccine) {
        return res.status(404).json({ message: "Vaccine not found" });
      }
      
      // Check if user has access to the baby related to this vaccine
      const access = await storage.getBabyAccess(req.user!.id, vaccine.babyId);
      if (!access || access.role !== "admin") {
        return res.status(403).json({ message: "No permission to delete this vaccine" });
      }
      
      await storage.deleteVaccine(id);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  // Reminder System Endpoints
  
  // Get all upcoming reminders for the logged-in user
  app.get("/api/reminders", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      
      // Return custom reminders directly to avoid database errors
      const customReminders = await storage.getActiveCustomReminders(userId);
      
      console.log(`Found ${customReminders?.length || 0} custom reminders for user ${userId}`);
      
      // Using an empty array directly in case of error
      res.json(customReminders || []);
    } catch (error) {
      console.error("Error fetching reminders:", error);
      // Return empty array instead of error to keep the app working
      res.json([]);
    }
  });
  
  // Check if a baby has any reminders (used for UI indicators)
  app.get("/api/babies/:babyId/has-reminders", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const hasReminders = await hasBabyReminders(babyId);
      res.json({ hasReminders });
    } catch (error) {
      next(error);
    }
  });
  
  // Custom Reminders System Endpoints
  
  // Get all custom reminders for the current user
  app.get("/api/custom-reminders", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const reminders = await storage.getCustomRemindersByUser(userId);
      res.json(reminders);
    } catch (error) {
      next(error);
    }
  });
  
  // Get all active custom reminders for the current user
  app.get("/api/custom-reminders/active", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const reminders = await storage.getActiveCustomReminders(userId);
      res.json(reminders);
    } catch (error) {
      next(error);
    }
  });
  
  // Get all custom reminders for a specific baby
  app.get("/api/babies/:babyId/custom-reminders", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const reminders = await storage.getCustomRemindersByBaby(babyId);
      res.json(reminders);
    } catch (error) {
      next(error);
    }
  });
  
  // Get custom reminders of a specific type for a baby (feeding, sleep, medication)
  app.get("/api/babies/:babyId/custom-reminders/:type", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const type = req.params.type;
      
      // Validate reminder type
      const validTypes = ["feeding", "sleep", "medication"];
      if (!validTypes.includes(type)) {
        return res.status(400).json({ message: "Invalid reminder type. Must be one of: feeding, sleep, medication" });
      }
      
      const reminders = await storage.getCustomRemindersByType(babyId, type);
      res.json(reminders);
    } catch (error) {
      next(error);
    }
  });
  
  // Get a specific custom reminder by ID
  app.get("/api/custom-reminders/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const reminder = await storage.getCustomReminder(id);
      
      if (!reminder) {
        return res.status(404).json({ message: "Reminder not found" });
      }
      
      // Check if user has access to the reminder (either owner or has baby access)
      if (reminder.userId !== req.user!.id) {
        const access = await storage.getBabyAccess(req.user!.id, reminder.babyId);
        if (!access) {
          return res.status(403).json({ message: "No access to this reminder" });
        }
      }
      
      res.json(reminder);
    } catch (error) {
      next(error);
    }
  });
  
  // Create a new custom reminder
  app.post("/api/babies/:babyId/custom-reminders", isAuthenticated, hasBabyAccess, async (req, res, next) => {
    try {
      const babyId = parseInt(req.params.babyId);
      const userId = req.user!.id;
      
      // Validate reminder data
      if (!req.body.title || !req.body.type || !req.body.startDate || !req.body.time || !req.body.recurringType) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Create the reminder with proper date handling
      const reminderData = {
        ...req.body,
        startDate: req.body.startDate ? new Date(req.body.startDate) : null,
        endDate: req.body.endDate ? new Date(req.body.endDate) : null,
        babyId,
        userId,
      };
      
      const newReminder = await storage.createCustomReminder(reminderData);
      res.status(201).json(newReminder);
    } catch (error) {
      next(error);
    }
  });
  
  // Update a custom reminder
  app.patch("/api/custom-reminders/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const reminder = await storage.getCustomReminder(id);
      
      if (!reminder) {
        return res.status(404).json({ message: "Reminder not found" });
      }
      
      // Check if user has access to the reminder
      if (reminder.userId !== req.user!.id) {
        const access = await storage.getBabyAccess(req.user!.id, reminder.babyId);
        if (!access || access.role === "viewer") {
          return res.status(403).json({ message: "No permission to update this reminder" });
        }
      }
      
      const updated = await storage.updateCustomReminder(id, req.body);
      res.json(updated);
    } catch (error) {
      next(error);
    }
  });
  
  // Delete a custom reminder
  app.delete("/api/custom-reminders/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const reminder = await storage.getCustomReminder(id);
      
      if (!reminder) {
        return res.status(404).json({ message: "Reminder not found" });
      }
      
      // Check if user has access to delete this reminder
      if (reminder.userId !== req.user!.id) {
        const access = await storage.getBabyAccess(req.user!.id, reminder.babyId);
        if (!access || access.role !== "admin") {
          return res.status(403).json({ message: "No permission to delete this reminder" });
        }
      }
      
      await storage.deleteCustomReminder(id);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
