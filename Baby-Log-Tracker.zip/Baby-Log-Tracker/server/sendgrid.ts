import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
mailService.setApiKey(process.env.SENDGRID_API_KEY);

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text: string;
  html: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  try {
    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html,
    });
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

// Generate HTML for summary report
export function generateBabyReportHTML(babyName: string, dateRange: string, data: any): string {
  const { feedings, sleeps, diapers } = data;
  
  // Calculate summary statistics
  const totalFeedings = feedings.length;
  const breastFeedings = feedings.filter((f: any) => f.type === 'breast').length;
  const bottleFeedings = feedings.filter((f: any) => f.type === 'bottle').length;
  
  const totalSleeps = sleeps.length;
  let totalSleepMinutes = 0;
  sleeps.forEach((sleep: any) => {
    if (sleep.duration) {
      totalSleepMinutes += sleep.duration;
    }
  });
  const avgSleepDuration = totalSleeps > 0 ? Math.round(totalSleepMinutes / totalSleeps) : 0;
  const avgSleepHours = Math.floor(avgSleepDuration / 60);
  const avgSleepMinutes = avgSleepDuration % 60;
  
  const totalDiapers = diapers.length;
  const wetDiapers = diapers.filter((d: any) => d.type === 'wet').length;
  const dirtyDiapers = diapers.filter((d: any) => d.type === 'dirty').length;
  const mixedDiapers = diapers.filter((d: any) => d.type === 'mixed').length;
  
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Baby Report: ${babyName}</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
        h1 { color: #5B9BD5; }
        h2 { color: #5B9BD5; border-bottom: 1px solid #eee; padding-bottom: 5px; margin-top: 30px; }
        .summary-stats { display: flex; flex-wrap: wrap; margin: 20px 0; }
        .stat-box { width: 30%; margin-right: 3%; margin-bottom: 20px; background: #f7f7f7; padding: 15px; border-radius: 5px; }
        .stat-title { font-size: 14px; color: #666; }
        .stat-value { font-size: 24px; font-weight: bold; margin: 5px 0; }
        .stat-subtext { font-size: 12px; color: #999; }
        .feeding-box { background-color: rgba(91, 155, 213, 0.1); }
        .sleep-box { background-color: rgba(156, 123, 213, 0.1); }
        .diaper-box { background-color: rgba(246, 161, 146, 0.1); }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background: #f2f2f2; text-align: left; padding: 10px; }
        td { padding: 10px; border-bottom: 1px solid #eee; }
        .footer { margin-top: 30px; font-size: 12px; color: #999; text-align: center; }
      </style>
    </head>
    <body>
      <h1>Baby Activity Report: ${babyName}</h1>
      <p>Report Period: ${dateRange}</p>
      
      <h2>Summary</h2>
      <div class="summary-stats">
        <div class="stat-box feeding-box">
          <div class="stat-title">Feedings</div>
          <div class="stat-value">${totalFeedings}</div>
          <div class="stat-subtext">Breast: ${breastFeedings}, Bottle: ${bottleFeedings}</div>
        </div>
        
        <div class="stat-box sleep-box">
          <div class="stat-title">Sleep</div>
          <div class="stat-value">${avgSleepHours}h ${avgSleepMinutes}m</div>
          <div class="stat-subtext">Average sleep duration</div>
        </div>
        
        <div class="stat-box diaper-box">
          <div class="stat-title">Diapers</div>
          <div class="stat-value">${totalDiapers}</div>
          <div class="stat-subtext">Wet: ${wetDiapers}, Dirty: ${dirtyDiapers}, Mixed: ${mixedDiapers}</div>
        </div>
      </div>
      
      <h2>Feeding Details</h2>
      <table>
        <thead>
          <tr>
            <th>Date & Time</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Duration</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody>
          ${feedings.map((feeding: any) => `
            <tr>
              <td>${new Date(feeding.startTime).toLocaleString()}</td>
              <td>${feeding.type}${feeding.side ? ` (${feeding.side})` : ''}</td>
              <td>${feeding.amount || '-'}</td>
              <td>${feeding.duration ? `${feeding.duration} min` : '-'}</td>
              <td>${feeding.notes || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      
      <h2>Sleep Details</h2>
      <table>
        <thead>
          <tr>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Duration</th>
            <th>Quality</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody>
          ${sleeps.map((sleep: any) => `
            <tr>
              <td>${new Date(sleep.startTime).toLocaleString()}</td>
              <td>${sleep.endTime ? new Date(sleep.endTime).toLocaleString() : '-'}</td>
              <td>${sleep.duration ? `${sleep.duration} min` : '-'}</td>
              <td>${sleep.quality ? `${sleep.quality}/5` : '-'}</td>
              <td>${sleep.notes || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      
      <h2>Diaper Details</h2>
      <table>
        <thead>
          <tr>
            <th>Time</th>
            <th>Type</th>
            <th>Color</th>
            <th>Consistency</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody>
          ${diapers.map((diaper: any) => `
            <tr>
              <td>${new Date(diaper.time).toLocaleString()}</td>
              <td>${diaper.type}</td>
              <td>${diaper.color || '-'}</td>
              <td>${diaper.consistency || '-'}</td>
              <td>${diaper.notes || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      
      <div class="footer">
        <p>Generated by Baby Tracker App</p>
      </div>
    </body>
    </html>
  `;
}