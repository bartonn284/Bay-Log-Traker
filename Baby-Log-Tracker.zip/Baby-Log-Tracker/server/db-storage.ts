import { 
  User, InsertUser, 
  Baby, InsertBaby,
  FamilySharing, InsertFamilySharing, 
  Feeding, InsertFeeding,
  Sleep, InsertSleep,
  Diaper, InsertDiaper,
  SupplyItem, InsertSupplyItem,
  GrowthRecord, InsertGrowthRecord,
  Milestone, InsertMilestone,
  HealthRecord, InsertHealthRecord,
  Appointment, InsertAppointment,
  Vaccine, InsertVaccine,
  JournalEntry, InsertJournalEntry,
  CustomReminder, InsertCustomReminder
} from "@shared/schema";
import { 
  users, babies, familySharing, feedings, sleeps, diapers, supplyItems,
  growthRecords, milestones, healthRecords, appointments, vaccines, journalEntries,
  customReminders
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, notInArray, isNull, isNotNull } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is required");
    }
    
    this.sessionStore = new PostgresSessionStore({ 
      conObject: { connectionString: process.env.DATABASE_URL },
      createTableIfMissing: true 
    });
  }
  
  // Execute raw SQL query for complex data retrieval
  async executeRawQuery(query: string, params: any[] = []): Promise<any> {
    try {
      return await db.execute(query, params);
    } catch (error) {
      console.error("Error executing raw query:", error);
      throw error;
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, role: "admin" })
      .returning();
    return user;
  }

  // Baby methods
  async getBaby(id: number): Promise<Baby | undefined> {
    const [baby] = await db.select().from(babies).where(eq(babies.id, id));
    return baby;
  }
  
  async getBabyByShareCode(shareCode: string): Promise<Baby | undefined> {
    const [baby] = await db.select().from(babies).where(eq(babies.shareCode, shareCode));
    return baby;
  }

  async getBabiesByOwner(ownerId: number): Promise<Baby[]> {
    // Get babies directly owned by user
    const ownedBabies = await db
      .select()
      .from(babies)
      .where(eq(babies.ownerId, ownerId));
    
    if (ownedBabies.length === 0) {
      // If no owned babies, get shared babies
      const sharedBabies = await db
        .select({
          baby: babies,
        })
        .from(familySharing)
        .innerJoin(babies, eq(familySharing.babyId, babies.id))
        .where(eq(familySharing.userId, ownerId));
      
      return sharedBabies.map(row => row.baby);
    }
    
    // Get babies shared with the user that are not already owned
    const ownedBabyIds = ownedBabies.map(b => b.id);
    const notInClause = ownedBabyIds.length > 0 
      ? notInArray(babies.id, ownedBabyIds)
      : sql`1=1`; // Dummy true condition if no owned babies
    
    const sharedBabiesQuery = await db
      .select({
        baby: babies,
      })
      .from(familySharing)
      .innerJoin(babies, eq(familySharing.babyId, babies.id))
      .where(and(
        eq(familySharing.userId, ownerId),
        notInClause
      ));
    
    const sharedBabies = sharedBabiesQuery.map((row: { baby: Baby }) => row.baby);
    
    // Combine both sets
    return [...ownedBabies, ...sharedBabies];
  }

  async createBaby(insertBaby: InsertBaby): Promise<Baby> {
    // Generate a random 12-digit sharing code if not provided
    if (!insertBaby.shareCode) {
      const randomCode = Math.floor(100000000000 + Math.random() * 900000000000).toString();
      insertBaby.shareCode = randomCode;
    }
    
    // Ensure optional fields are either null or their correct type
    // Handle the camelCase to snake_case conversion for the photo URL field
    const { photoUrl, ...restOfBaby } = insertBaby;
    const babyData = {
      ...restOfBaby,
      photo_url: photoUrl || "",  // Map photoUrl to photo_url for database compatibility
      dateOfBirth: insertBaby.dateOfBirth || null,
      gender: insertBaby.gender || null,
      weight: insertBaby.weight || null,
      width: insertBaby.width || null,
      shareCode: insertBaby.shareCode,
      createdAt: new Date()
    };
    
    const [baby] = await db
      .insert(babies)
      .values(babyData)
      .returning();
    
    // Add owner as an admin in family sharing
    await this.createFamilySharing({
      babyId: baby.id,
      userId: insertBaby.ownerId,
      role: "admin"
    });
    
    return baby;
  }

  // Family sharing methods
  async getFamilyMembers(babyId: number): Promise<FamilySharing[]> {
    const familyMembers = await db
      .select({
        sharing: familySharing,
        user: {
          id: users.id,
          username: users.username,
          fullName: users.fullName
        }
      })
      .from(familySharing)
      .leftJoin(users, eq(familySharing.userId, users.id))
      .where(eq(familySharing.babyId, babyId));

    return familyMembers.map((row: { 
      sharing: FamilySharing, 
      user: { id: number; username: string; fullName: string; } | null 
    }) => ({
      ...row.sharing,
      user: row.user && row.user.id ? row.user : null
    }));
  }

  async getFamilySharing(id: number): Promise<FamilySharing | undefined> {
    const [sharing] = await db
      .select()
      .from(familySharing)
      .where(eq(familySharing.id, id));
    return sharing;
  }

  async createFamilySharing(insertSharing: InsertFamilySharing): Promise<FamilySharing> {
    // Ensure role is provided or use default 'viewer'
    const sharingData = {
      ...insertSharing,
      role: insertSharing.role || 'viewer',
      createdAt: new Date()
    };
    
    const [sharing] = await db
      .insert(familySharing)
      .values(sharingData)
      .returning();
    
    return sharing;
  }

  async updateFamilySharing(id: number, role: string): Promise<FamilySharing | undefined> {
    const [updated] = await db
      .update(familySharing)
      .set({ role })
      .where(eq(familySharing.id, id))
      .returning();
    return updated;
  }

  async deleteFamilySharing(id: number): Promise<boolean> {
    const result = await db
      .delete(familySharing)
      .where(eq(familySharing.id, id));
    return !!result;
  }

  async getBabyAccess(userId: number, babyId: number): Promise<FamilySharing | undefined> {
    const [sharing] = await db
      .select()
      .from(familySharing)
      .where(
        and(
          eq(familySharing.userId, userId),
          eq(familySharing.babyId, babyId)
        )
      );
    return sharing;
  }

  // Feeding methods
  async getFeeding(id: number): Promise<Feeding | undefined> {
    const [feeding] = await db
      .select()
      .from(feedings)
      .where(eq(feedings.id, id));
    return feeding;
  }

  async getFeedingsByBaby(babyId: number): Promise<Feeding[]> {
    return db
      .select()
      .from(feedings)
      .where(eq(feedings.babyId, babyId))
      .orderBy(desc(feedings.startTime));
  }

  async getFeedingsByDate(babyId: number, date: Date): Promise<Feeding[]> {
    const dateString = date.toISOString().split('T')[0];
    
    return db
      .select()
      .from(feedings)
      .where(
        and(
          eq(feedings.babyId, babyId),
          sql`DATE(${feedings.startTime}) = ${dateString}`
        )
      )
      .orderBy(desc(feedings.startTime));
  }

  async createFeeding(insertFeeding: InsertFeeding): Promise<Feeding> {
    // Ensure all optional fields are either null or their correct type
    const feedingData = {
      ...insertFeeding,
      amount: insertFeeding.amount || null,
      endTime: insertFeeding.endTime || null,
      duration: insertFeeding.duration || null,
      side: insertFeeding.side || null,
      notes: insertFeeding.notes || null,
      createdAt: new Date()
    };
    
    const [feeding] = await db
      .insert(feedings)
      .values(feedingData)
      .returning();
    
    return feeding;
  }

  async updateFeeding(id: number, feedingUpdate: Partial<InsertFeeding>): Promise<Feeding | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(feedingUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(feedings)
      .set(formattedUpdate)
      .where(eq(feedings.id, id))
      .returning();
    
    return updated;
  }

  async deleteFeeding(id: number): Promise<boolean> {
    const result = await db
      .delete(feedings)
      .where(eq(feedings.id, id));
    return !!result;
  }

  // Sleep methods
  async getSleep(id: number): Promise<Sleep | undefined> {
    const [sleep] = await db
      .select()
      .from(sleeps)
      .where(eq(sleeps.id, id));
    return sleep;
  }

  async getSleepsByBaby(babyId: number): Promise<Sleep[]> {
    return db
      .select()
      .from(sleeps)
      .where(eq(sleeps.babyId, babyId))
      .orderBy(desc(sleeps.startTime));
  }

  async getSleepsByDate(babyId: number, date: Date): Promise<Sleep[]> {
    const dateString = date.toISOString().split('T')[0];
    
    return db
      .select()
      .from(sleeps)
      .where(
        and(
          eq(sleeps.babyId, babyId),
          sql`DATE(${sleeps.startTime}) = ${dateString}`
        )
      )
      .orderBy(desc(sleeps.startTime));
  }

  async createSleep(insertSleep: InsertSleep): Promise<Sleep> {
    // Ensure all optional fields are either null or their correct type
    const sleepData = {
      ...insertSleep,
      endTime: insertSleep.endTime || null,
      duration: insertSleep.duration || null,
      quality: insertSleep.quality || null,
      notes: insertSleep.notes || null,
      createdAt: new Date()
    };
    
    const [sleep] = await db
      .insert(sleeps)
      .values(sleepData)
      .returning();
    
    return sleep;
  }

  async updateSleep(id: number, sleepUpdate: Partial<InsertSleep>): Promise<Sleep | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(sleepUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(sleeps)
      .set(formattedUpdate)
      .where(eq(sleeps.id, id))
      .returning();
    
    return updated;
  }

  async deleteSleep(id: number): Promise<boolean> {
    const result = await db
      .delete(sleeps)
      .where(eq(sleeps.id, id));
    return !!result;
  }

  // Diaper methods
  async getDiaper(id: number): Promise<Diaper | undefined> {
    const [diaper] = await db
      .select()
      .from(diapers)
      .where(eq(diapers.id, id));
    return diaper;
  }

  async getDiapersByBaby(babyId: number): Promise<Diaper[]> {
    return db
      .select()
      .from(diapers)
      .where(eq(diapers.babyId, babyId))
      .orderBy(desc(diapers.time));
  }

  async getDiapersByDate(babyId: number, date: Date): Promise<Diaper[]> {
    const dateString = date.toISOString().split('T')[0];
    
    return db
      .select()
      .from(diapers)
      .where(
        and(
          eq(diapers.babyId, babyId),
          sql`DATE(${diapers.time}) = ${dateString}`
        )
      )
      .orderBy(desc(diapers.time));
  }

  async createDiaper(insertDiaper: InsertDiaper): Promise<Diaper> {
    // Ensure all optional fields are either null or their correct type
    const diaperData = {
      ...insertDiaper,
      consistency: insertDiaper.consistency || null,
      color: insertDiaper.color || null,
      notes: insertDiaper.notes || null,
      createdAt: new Date()
    };
    
    const [diaper] = await db
      .insert(diapers)
      .values(diaperData)
      .returning();
    
    return diaper;
  }

  async updateDiaper(id: number, diaperUpdate: Partial<InsertDiaper>): Promise<Diaper | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(diaperUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(diapers)
      .set(formattedUpdate)
      .where(eq(diapers.id, id))
      .returning();
    
    return updated;
  }

  async deleteDiaper(id: number): Promise<boolean> {
    const result = await db
      .delete(diapers)
      .where(eq(diapers.id, id));
    return !!result;
  }
  
  // Supply methods
  async getSupplyItem(id: number): Promise<SupplyItem | undefined> {
    const [item] = await db
      .select()
      .from(supplyItems)
      .where(eq(supplyItems.id, id));
    return item;
  }
  
  async getSupplyItemsByUser(userId: number): Promise<SupplyItem[]> {
    return db
      .select()
      .from(supplyItems)
      .where(eq(supplyItems.userId, userId))
      .orderBy(supplyItems.name);
  }
  
  async getSupplyItemsByStatus(userId: number, status: string): Promise<SupplyItem[]> {
    return db
      .select()
      .from(supplyItems)
      .where(
        and(
          eq(supplyItems.userId, userId),
          eq(supplyItems.status, status)
        )
      )
      .orderBy(supplyItems.name);
  }
  
  async getShoppingList(userId: number): Promise<SupplyItem[]> {
    return db
      .select()
      .from(supplyItems)
      .where(
        and(
          eq(supplyItems.userId, userId),
          eq(supplyItems.onShoppingList, true)
        )
      )
      .orderBy(supplyItems.name);
  }
  
  async createSupplyItem(insertSupplyItem: InsertSupplyItem): Promise<SupplyItem> {
    // Ensure all optional fields are either null or their correct type
    const supplyItemData = {
      ...insertSupplyItem,
      status: insertSupplyItem.status || 'in-stock',
      quantity: insertSupplyItem.quantity || null,
      unit: insertSupplyItem.unit || null,
      notes: insertSupplyItem.notes || null,
      onShoppingList: insertSupplyItem.onShoppingList !== undefined ? insertSupplyItem.onShoppingList : false,
      alertWhenLow: insertSupplyItem.alertWhenLow !== undefined ? insertSupplyItem.alertWhenLow : false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const [supplyItem] = await db
      .insert(supplyItems)
      .values(supplyItemData)
      .returning();
    
    return supplyItem;
  }
  
  async updateSupplyItem(id: number, supplyItemUpdate: Partial<InsertSupplyItem>): Promise<SupplyItem | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {
      updatedAt: new Date()
    };
    
    // Only copy fields that are present in the update
    Object.entries(supplyItemUpdate).forEach(([key, value]) => {
      // For boolean fields, we want to keep false values
      if (key === 'onShoppingList' || key === 'alertWhenLow') {
        formattedUpdate[key] = value;
      } else {
        formattedUpdate[key] = value === undefined ? null : value;
      }
    });
    
    const [updated] = await db
      .update(supplyItems)
      .set(formattedUpdate)
      .where(eq(supplyItems.id, id))
      .returning();
    
    return updated;
  }
  
  async deleteSupplyItem(id: number): Promise<boolean> {
    const result = await db
      .delete(supplyItems)
      .where(eq(supplyItems.id, id));
    return !!result;
  }
  
  // Baby update method
  async updateBaby(id: number, babyUpdate: Partial<InsertBaby>): Promise<Baby | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Handle photoUrl separately to correctly map to photo_url in the database
    const { photoUrl, ...restOfUpdate } = babyUpdate;
    if (photoUrl !== undefined) {
      formattedUpdate.photo_url = photoUrl;
    }
    
    // Only copy fields that are present in the update
    Object.entries(restOfUpdate).forEach(([key, value]) => {
      try {
        // Special handling for date fields to ensure they are valid
        if (key === 'dateOfBirth') {
          if (value === null || value === undefined || value === '') {
            formattedUpdate[key] = null;
          } else if (typeof value === 'string') {
            // Validate the date string format (YYYY-MM-DD)
            const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (dateRegex.test(value)) {
              // It's a valid date string format, let SQL handle it
              formattedUpdate[key] = value;
            } else {
              // Try to parse it as a date
              try {
                const date = new Date(value);
                if (!isNaN(date.getTime())) {
                  // Format as YYYY-MM-DD
                  const year = date.getFullYear();
                  const month = String(date.getMonth() + 1).padStart(2, '0');
                  const day = String(date.getDate()).padStart(2, '0');
                  formattedUpdate[key] = `${year}-${month}-${day}`;
                } else {
                  formattedUpdate[key] = null;
                }
              } catch (e) {
                formattedUpdate[key] = null;
              }
            }
          } else if (value instanceof Date) {
            // Convert Date object to YYYY-MM-DD string
            const year = value.getFullYear();
            const month = String(value.getMonth() + 1).padStart(2, '0');
            const day = String(value.getDate()).padStart(2, '0');
            formattedUpdate[key] = `${year}-${month}-${day}`;
          } else {
            // Not a valid date format
            formattedUpdate[key] = null;
            console.log(`Invalid date format for ${key}:`, value);
          }
        } else {
          // Handle non-date fields
          formattedUpdate[key] = value === undefined ? null : value;
        }
      } catch (error) {
        console.error(`Error processing field ${key}:`, error);
        // Set to null if there's an error
        formattedUpdate[key] = null;
      }
    });
    
    console.log("Updating baby with formatted data:", formattedUpdate);
    
    const [updated] = await db
      .update(babies)
      .set(formattedUpdate)
      .where(eq(babies.id, id))
      .returning();
    
    return updated;
  }
  
  async deleteBaby(id: number): Promise<boolean> {
    try {
      // First delete all related records in tables that actually exist
      await db.delete(familySharing).where(eq(familySharing.babyId, id));
      await db.delete(feedings).where(eq(feedings.babyId, id));
      await db.delete(sleeps).where(eq(sleeps.babyId, id));
      await db.delete(diapers).where(eq(diapers.babyId, id));
      await db.delete(growthRecords).where(eq(growthRecords.babyId, id));
      await db.delete(milestones).where(eq(milestones.babyId, id));
      await db.delete(healthRecords).where(eq(healthRecords.babyId, id));
      
      // Tables that don't exist yet in the schema but are defined
      // We'll skip these for now:
      // - appointments
      // - vaccines
      // - journalEntries
      
      // Now delete the baby record
      const result = await db.delete(babies).where(eq(babies.id, id));
      return !!result;
    } catch (error) {
      console.error("Error deleting baby profile:", error);
      return false;
    }
  }
  
  // Growth Tracking methods
  async getGrowthRecord(id: number): Promise<GrowthRecord | undefined> {
    const [record] = await db
      .select()
      .from(growthRecords)
      .where(eq(growthRecords.id, id));
    return record;
  }

  async getGrowthRecordsByBaby(babyId: number): Promise<GrowthRecord[]> {
    return db
      .select()
      .from(growthRecords)
      .where(eq(growthRecords.babyId, babyId))
      .orderBy(desc(growthRecords.date));
  }

  async createGrowthRecord(insertRecord: InsertGrowthRecord): Promise<GrowthRecord> {
    // Ensure all optional fields are either null or their correct type
    const recordData = {
      ...insertRecord,
      weight: insertRecord.weight || null,
      height: insertRecord.height || null,
      headCircumference: insertRecord.headCircumference || null,
      notes: insertRecord.notes || null,
      createdAt: new Date()
    };
    
    const [record] = await db
      .insert(growthRecords)
      .values(recordData)
      .returning();
    
    return record;
  }

  async updateGrowthRecord(id: number, recordUpdate: Partial<InsertGrowthRecord>): Promise<GrowthRecord | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(recordUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(growthRecords)
      .set(formattedUpdate)
      .where(eq(growthRecords.id, id))
      .returning();
    
    return updated;
  }

  async deleteGrowthRecord(id: number): Promise<boolean> {
    const result = await db
      .delete(growthRecords)
      .where(eq(growthRecords.id, id));
    return !!result;
  }
  
  // Milestone Tracking methods
  async getMilestone(id: number): Promise<Milestone | undefined> {
    const [milestone] = await db
      .select()
      .from(milestones)
      .where(eq(milestones.id, id));
    return milestone;
  }

  async getMilestonesByBaby(babyId: number): Promise<Milestone[]> {
    return db
      .select()
      .from(milestones)
      .where(eq(milestones.babyId, babyId))
      .orderBy(desc(milestones.date));
  }

  async getMilestonesByCategory(babyId: number, category: string): Promise<Milestone[]> {
    return db
      .select()
      .from(milestones)
      .where(
        and(
          eq(milestones.babyId, babyId),
          eq(milestones.category, category)
        )
      )
      .orderBy(desc(milestones.date));
  }

  async createMilestone(insertMilestone: InsertMilestone): Promise<Milestone> {
    // Ensure all optional fields are either null or their correct type
    const milestoneData = {
      ...insertMilestone,
      category: insertMilestone.category || null,
      description: insertMilestone.description || null,
      mediaUrl: insertMilestone.mediaUrl || null,
      createdAt: new Date()
    };
    
    const [milestone] = await db
      .insert(milestones)
      .values(milestoneData)
      .returning();
    
    return milestone;
  }

  async updateMilestone(id: number, milestoneUpdate: Partial<InsertMilestone>): Promise<Milestone | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(milestoneUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(milestones)
      .set(formattedUpdate)
      .where(eq(milestones.id, id))
      .returning();
    
    return updated;
  }

  async deleteMilestone(id: number): Promise<boolean> {
    const result = await db
      .delete(milestones)
      .where(eq(milestones.id, id));
    return !!result;
  }
  
  // Health Tracking methods
  async getHealthRecord(id: number): Promise<HealthRecord | undefined> {
    const [record] = await db
      .select()
      .from(healthRecords)
      .where(eq(healthRecords.id, id));
    return record;
  }

  async getHealthRecordsByBaby(babyId: number): Promise<HealthRecord[]> {
    return db
      .select()
      .from(healthRecords)
      .where(eq(healthRecords.babyId, babyId))
      .orderBy(desc(healthRecords.date));
  }

  async getHealthRecordsByType(babyId: number, recordType: string): Promise<HealthRecord[]> {
    return db
      .select()
      .from(healthRecords)
      .where(
        and(
          eq(healthRecords.babyId, babyId),
          eq(healthRecords.recordType, recordType)
        )
      )
      .orderBy(desc(healthRecords.date));
  }

  async getHealthRecordsByDate(babyId: number, startDate: Date, endDate: Date): Promise<HealthRecord[]> {
    return db
      .select()
      .from(healthRecords)
      .where(
        and(
          eq(healthRecords.babyId, babyId),
          sql`${healthRecords.date} >= ${startDate}`,
          sql`${healthRecords.date} <= ${endDate}`
        )
      )
      .orderBy(desc(healthRecords.date));
  }

  async createHealthRecord(insertRecord: InsertHealthRecord): Promise<HealthRecord> {
    // Ensure all optional fields are either null or their correct type
    const recordData = {
      ...insertRecord,
      temperature: insertRecord.temperature || null,
      medicationName: insertRecord.medicationName || null,
      medicationDose: insertRecord.medicationDose || null,
      medicationSchedule: insertRecord.medicationSchedule || null,
      doctorNotes: insertRecord.doctorNotes || null,
      notes: insertRecord.notes || null,
      createdAt: new Date()
    };
    
    const [record] = await db
      .insert(healthRecords)
      .values(recordData)
      .returning();
    
    return record;
  }

  async updateHealthRecord(id: number, recordUpdate: Partial<InsertHealthRecord>): Promise<HealthRecord | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(recordUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(healthRecords)
      .set(formattedUpdate)
      .where(eq(healthRecords.id, id))
      .returning();
    
    return updated;
  }

  async deleteHealthRecord(id: number): Promise<boolean> {
    const result = await db
      .delete(healthRecords)
      .where(eq(healthRecords.id, id));
    return !!result;
  }
  
  // Daily Summary
  async getDailySummary(babyId: number, date: Date): Promise<{
    feedings: Feeding[];
    sleeps: Sleep[];
    diapers: Diaper[];
    healthRecords: HealthRecord[];
  }> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    const feedings = await this.getFeedingsByDate(babyId, date);
    const sleeps = await this.getSleepsByDate(babyId, date);
    const diapers = await this.getDiapersByDate(babyId, date);
    const healthRecords = await this.getHealthRecordsByDate(babyId, startOfDay, endOfDay);
    
    return {
      feedings,
      sleeps,
      diapers,
      healthRecords
    };
  }
  
  // Appointment methods
  async getAppointment(id: number): Promise<Appointment | undefined> {
    const [appointment] = await db
      .select()
      .from(appointments)
      .where(eq(appointments.id, id));
    return appointment;
  }
  
  async getAppointmentsByBaby(babyId: number): Promise<Appointment[]> {
    return db
      .select()
      .from(appointments)
      .where(eq(appointments.babyId, babyId))
      .orderBy(appointments.date); // Ascending by date
  }
  
  async getUpcomingAppointments(babyId: number): Promise<Appointment[]> {
    const now = new Date();
    const dateString = now.toISOString().split('T')[0]; // Today's date in YYYY-MM-DD format
    
    return db
      .select()
      .from(appointments)
      .where(
        and(
          eq(appointments.babyId, babyId),
          sql`DATE(${appointments.date}) >= ${dateString}`,
          eq(appointments.completed, false)
        )
      )
      .orderBy(appointments.date); // Ascending by date
  }
  
  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    // Ensure all optional fields are either null or their correct type
    const appointmentData = {
      ...insertAppointment,
      notes: insertAppointment.notes || null,
      time: insertAppointment.time || null,
      location: insertAppointment.location || null,
      doctorName: insertAppointment.doctorName || null,
      reminderSet: insertAppointment.reminderSet || false,
      reminderTime: insertAppointment.reminderTime || null,
      completed: insertAppointment.completed || false,
      createdAt: new Date()
    };
    
    const [appointment] = await db
      .insert(appointments)
      .values(appointmentData)
      .returning();
    
    return appointment;
  }
  
  async updateAppointment(id: number, appointmentUpdate: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(appointmentUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(appointments)
      .set(formattedUpdate)
      .where(eq(appointments.id, id))
      .returning();
    
    return updated;
  }
  
  async deleteAppointment(id: number): Promise<boolean> {
    const result = await db
      .delete(appointments)
      .where(eq(appointments.id, id));
    return !!result;
  }
  
  // Vaccine methods
  async getVaccine(id: number): Promise<Vaccine | undefined> {
    const [vaccine] = await db
      .select()
      .from(vaccines)
      .where(eq(vaccines.id, id));
    return vaccine;
  }
  
  async getVaccinesByBaby(babyId: number): Promise<Vaccine[]> {
    // Get all vaccines for a baby, sorted first by completion status then by due date/administered date
    return db
      .select()
      .from(vaccines)
      .where(eq(vaccines.babyId, babyId))
      .orderBy(
        vaccines.completed, // Sort by completion status
        vaccines.dueDate    // Then by due date
      );
  }
  
  async getDueVaccines(babyId: number): Promise<Vaccine[]> {
    const now = new Date();
    
    // Get date a week from now for showing upcoming vaccines
    const oneWeekFromNow = new Date();
    oneWeekFromNow.setDate(oneWeekFromNow.getDate() + 7);
    
    const todayString = now.toISOString().split('T')[0]; // Today's date in YYYY-MM-DD format
    const futureString = oneWeekFromNow.toISOString().split('T')[0]; // One week from now
    
    console.log(`Getting due vaccines for baby ${babyId}`);
    console.log(`Looking for vaccines due between ${todayString} and ${futureString}`);
    
    try {
      // First get all non-completed vaccines for the baby
      const allVaccines = await db
        .select()
        .from(vaccines)
        .where(
          and(
            eq(vaccines.babyId, babyId),
            eq(vaccines.completed, false)
          )
        )
        .orderBy(vaccines.dueDate); // Ascending by due date
      
      // Then filter for those with valid dates in the next 7 days
      const dueVaccines = allVaccines.filter(vaccine => {
        if (!vaccine.dueDate) return false;
        
        try {
          // Parse the date properly
          const dueDate = new Date(vaccine.dueDate);
          if (isNaN(dueDate.getTime())) {
            console.log(`Invalid date format for vaccine ${vaccine.name}: ${vaccine.dueDate}`);
            return false;
          }
          
          // Get just the date portion for comparison (no time)
          const dueDateDay = new Date(dueDate);
          dueDateDay.setHours(0, 0, 0, 0);
          
          const todayDay = new Date(now);
          todayDay.setHours(0, 0, 0, 0);
          
          const futureDay = new Date(oneWeekFromNow);
          futureDay.setHours(23, 59, 59, 999);
          
          // Due within the next 7 days (including today)
          return dueDateDay >= todayDay && dueDateDay <= futureDay;
        } catch (err) {
          console.error(`Error processing date for vaccine ${vaccine.name}:`, err);
          return false;
        }
      });
      
      console.log(`Found ${dueVaccines.length} due or upcoming vaccines after date filtering`);
      dueVaccines.forEach(vaccine => {
        const dueDate = vaccine.dueDate ? new Date(vaccine.dueDate) : null;
        const formattedDate = dueDate && !isNaN(dueDate.getTime()) 
          ? dueDate.toISOString().split('T')[0]
          : 'Invalid Date';
          
        console.log(`Vaccine: ${vaccine.name}, Due: ${formattedDate}, Reminder: ${vaccine.reminder}`);
      });
      
      return dueVaccines;
    } catch (error) {
      console.error("Error getting due vaccines:", error);
      return [];
    }
  }
  
  async createVaccine(insertVaccine: InsertVaccine): Promise<Vaccine> {
    // Ensure all optional fields are either null or their correct type
    console.log("Creating vaccine with raw data:", insertVaccine);
    
    // Process the due date ensuring it is a proper Date object with noon time
    let dueDateValue = null;
    if (insertVaccine.dueDate) {
      try {
        // Create a new Date object regardless of input type
        let dateObj;
        if (typeof insertVaccine.dueDate === 'string') {
          dateObj = new Date(insertVaccine.dueDate);
        } else {
          dateObj = new Date(insertVaccine.dueDate);
        }
        
        // Set the time to noon to avoid timezone issues
        dateObj.setHours(12, 0, 0, 0);
        
        console.log(`Processing due date: ${dateObj.toISOString()}`);
        
        if (isNaN(dateObj.getTime())) {
          console.error(`Invalid date: ${insertVaccine.dueDate}`);
          dueDateValue = null;
        } else {
          dueDateValue = dateObj;
          console.log(`Final due date value: ${dueDateValue.toISOString()}`);
        }
      } catch (err) {
        console.error(`Error processing due date: ${err}`);
        dueDateValue = null;
      }
    }
    
    // Process administered date the same way we process due date
    let administeredDateValue = null;
    if (insertVaccine.administeredDate) {
      try {
        let dateObj;
        if (typeof insertVaccine.administeredDate === 'string') {
          dateObj = new Date(insertVaccine.administeredDate);
        } else {
          dateObj = new Date(insertVaccine.administeredDate);
        }
        
        // Set the time to noon to avoid timezone issues
        dateObj.setHours(12, 0, 0, 0);
        
        console.log(`Processing administered date: ${dateObj.toISOString()}`);
        
        if (isNaN(dateObj.getTime())) {
          console.error(`Invalid administered date: ${insertVaccine.administeredDate}`);
          administeredDateValue = null;
        } else {
          administeredDateValue = dateObj;
        }
      } catch (err) {
        console.error(`Error processing administered date: ${err}`);
        administeredDateValue = null;
      }
    }

    // Create the vaccine data with our processed dates
    const vaccineData = {
      ...insertVaccine,
      notes: insertVaccine.notes || null,
      location: insertVaccine.location || null,
      dueDate: dueDateValue, // Use our processed date value
      administeredDate: administeredDateValue,
      lotNumber: insertVaccine.lotNumber || null,
      reminder: insertVaccine.reminder !== undefined ? insertVaccine.reminder : true,
      completed: insertVaccine.completed || false,
      createdBy: insertVaccine.createdBy,
      createdAt: new Date()
    };
    
    // Log the actual data being inserted into the database for debugging
    console.log("Inserting vaccine with processed data:", {
      ...vaccineData,
      dueDate: vaccineData.dueDate ? vaccineData.dueDate.toISOString() : null
    });
    
    try {
      const [vaccine] = await db
        .insert(vaccines)
        .values(vaccineData)
        .returning();
      
      // Log what was returned from the database
      console.log("Created vaccine:", vaccine);
      
      return vaccine;
    } catch (error) {
      console.error("Error creating vaccine:", error);
      throw error;
    }
  }
  
  async updateVaccine(id: number, vaccineUpdate: Partial<InsertVaccine>): Promise<Vaccine | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    console.log("Updating vaccine with raw data:", vaccineUpdate);
    
    // Process each field in the update
    Object.entries(vaccineUpdate).forEach(([key, value]) => {
      if (key === 'dueDate') {
        // Process due date
        if (value === null || value === undefined) {
          formattedUpdate[key] = null;
        } else {
          try {
            // Safely create a Date object
            let dateObj: Date | null = null;
            
            if (typeof value === 'string') {
              dateObj = new Date(value);
            } else if (value instanceof Date) {
              dateObj = new Date(value);
            }
            
            if (dateObj) {
              // Set to noon to avoid timezone issues
              dateObj.setHours(12, 0, 0, 0);
              
              if (isNaN(dateObj.getTime())) {
                console.error(`Invalid due date value: ${value}`);
                formattedUpdate[key] = null;
              } else {
                formattedUpdate[key] = dateObj;
                console.log(`Processed due date: ${dateObj.toISOString()}`);
              }
            } else {
              console.error(`Could not convert to date: ${value}`);
              formattedUpdate[key] = null;
            }
          } catch (err) {
            console.error(`Error processing due date: ${err}`);
            formattedUpdate[key] = null;
          }
        }
      } else if (key === 'administeredDate') {
        // Process administered date
        if (value === null || value === undefined) {
          formattedUpdate[key] = null;
        } else {
          try {
            // Safely create a Date object
            let dateObj: Date | null = null;
            
            if (typeof value === 'string') {
              dateObj = new Date(value);
            } else if (value instanceof Date) {
              dateObj = new Date(value);
            }
            
            if (dateObj) {
              // Set to noon to avoid timezone issues
              dateObj.setHours(12, 0, 0, 0);
              
              if (isNaN(dateObj.getTime())) {
                console.error(`Invalid administered date value: ${value}`);
                formattedUpdate[key] = null;
              } else {
                formattedUpdate[key] = dateObj;
                console.log(`Processed administered date: ${dateObj.toISOString()}`);
              }
            } else {
              console.error(`Could not convert to date: ${value}`);
              formattedUpdate[key] = null;
            }
          } catch (err) {
            console.error(`Error processing administered date: ${err}`);
            formattedUpdate[key] = null;
          }
        }
      } else {
        // Handle all other fields
        formattedUpdate[key] = value === undefined ? null : value;
      }
    });
    
    console.log("Formatted update data:", formattedUpdate);
    
    const [updated] = await db
      .update(vaccines)
      .set(formattedUpdate)
      .where(eq(vaccines.id, id))
      .returning();
    
    return updated;
  }
  
  async deleteVaccine(id: number): Promise<boolean> {
    const result = await db
      .delete(vaccines)
      .where(eq(vaccines.id, id));
    return !!result;
  }

  // Journal entries methods
  async getJournalEntry(id: number): Promise<JournalEntry | undefined> {
    const [entry] = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.id, id));
    return entry;
  }
  
  async getJournalEntriesByBaby(babyId: number): Promise<JournalEntry[]> {
    return db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.babyId, babyId))
      .orderBy(desc(journalEntries.date));
  }
  
  async getJournalEntriesByCategory(babyId: number, category: string): Promise<JournalEntry[]> {
    return db
      .select()
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.babyId, babyId),
          eq(journalEntries.category, category)
        )
      )
      .orderBy(desc(journalEntries.date));
  }
  
  async getJournalEntriesByDate(babyId: number, date: Date): Promise<JournalEntry[]> {
    const dateString = date.toISOString().split('T')[0]; // Format as YYYY-MM-DD
    
    return db
      .select()
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.babyId, babyId),
          sql`DATE(${journalEntries.date}) = ${dateString}`
        )
      )
      .orderBy(desc(journalEntries.date));
  }
  
  async createJournalEntry(insertEntry: InsertJournalEntry): Promise<JournalEntry> {
    // Ensure all optional fields are either null or their correct type
    const entryData = {
      ...insertEntry,
      mood: insertEntry.mood || null,
      category: insertEntry.category || null,
      createdAt: new Date()
    };
    
    const [entry] = await db
      .insert(journalEntries)
      .values(entryData)
      .returning();
    
    return entry;
  }
  
  async updateJournalEntry(id: number, entryUpdate: Partial<InsertJournalEntry>): Promise<JournalEntry | undefined> {
    // Handle possible undefined values to make sure they become null
    const formattedUpdate: Record<string, any> = {};
    
    // Only copy fields that are present in the update
    Object.entries(entryUpdate).forEach(([key, value]) => {
      formattedUpdate[key] = value === undefined ? null : value;
    });
    
    const [updated] = await db
      .update(journalEntries)
      .set(formattedUpdate)
      .where(eq(journalEntries.id, id))
      .returning();
    
    return updated;
  }
  
  async deleteJournalEntry(id: number): Promise<boolean> {
    const result = await db
      .delete(journalEntries)
      .where(eq(journalEntries.id, id));
    return !!result;
  }

  // Custom Reminders CRUD operations
  async getCustomReminder(id: number): Promise<CustomReminder | undefined> {
    try {
      const [reminder] = await db
        .select()
        .from(customReminders)
        .where(eq(customReminders.id, id));
      
      return reminder;
    } catch (error) {
      console.error("Error getting custom reminder:", error);
      throw error;
    }
  }

  async getCustomRemindersByBaby(babyId: number): Promise<CustomReminder[]> {
    try {
      const reminders = await db
        .select()
        .from(customReminders)
        .where(eq(customReminders.babyId, babyId))
        .orderBy(desc(customReminders.createdAt));
      
      return reminders;
    } catch (error) {
      console.error("Error getting custom reminders for baby:", error);
      throw error;
    }
  }

  async getCustomRemindersByUser(userId: number): Promise<CustomReminder[]> {
    try {
      const reminders = await db
        .select()
        .from(customReminders)
        .where(eq(customReminders.userId, userId))
        .orderBy(desc(customReminders.createdAt));
      
      return reminders;
    } catch (error) {
      console.error("Error getting custom reminders for user:", error);
      throw error;
    }
  }

  async getCustomRemindersByType(babyId: number, type: string): Promise<CustomReminder[]> {
    try {
      const reminders = await db
        .select()
        .from(customReminders)
        .where(and(
          eq(customReminders.babyId, babyId),
          eq(customReminders.type, type)
        ))
        .orderBy(desc(customReminders.createdAt));
      
      return reminders;
    } catch (error) {
      console.error(`Error getting ${type} reminders for baby:`, error);
      throw error;
    }
  }

  async createCustomReminder(insertReminder: InsertCustomReminder): Promise<CustomReminder> {
    try {
      const [reminder] = await db
        .insert(customReminders)
        .values(insertReminder)
        .returning();
      
      return reminder;
    } catch (error) {
      console.error("Error creating custom reminder:", error);
      throw error;
    }
  }

  async updateCustomReminder(id: number, reminderUpdate: Partial<InsertCustomReminder>): Promise<CustomReminder | undefined> {
    try {
      const [updated] = await db
        .update(customReminders)
        .set({
          ...reminderUpdate,
          updatedAt: new Date()
        })
        .where(eq(customReminders.id, id))
        .returning();
      
      return updated;
    } catch (error) {
      console.error("Error updating custom reminder:", error);
      throw error;
    }
  }

  async deleteCustomReminder(id: number): Promise<boolean> {
    try {
      const result = await db
        .delete(customReminders)
        .where(eq(customReminders.id, id))
        .returning({ id: customReminders.id });
      
      return result.length > 0;
    } catch (error) {
      console.error("Error deleting custom reminder:", error);
      throw error;
    }
  }

  async getActiveCustomReminders(userId: number): Promise<CustomReminder[]> {
    try {
      // Get current date for comparisons
      const now = new Date();
      
      const reminders = await db
        .select()
        .from(customReminders)
        .where(and(
          eq(customReminders.userId, userId),
          eq(customReminders.enabled, true),
          sql`(${customReminders.endDate} IS NULL OR ${customReminders.endDate} >= ${now})`
        ))
        .orderBy(customReminders.startDate);
      
      return reminders;
    } catch (error) {
      console.error("Error getting active custom reminders:", error);
      throw error;
    }
  }
}