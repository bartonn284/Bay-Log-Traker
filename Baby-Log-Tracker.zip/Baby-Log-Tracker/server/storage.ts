import { 
  users, User, InsertUser, 
  babies, Baby, InsertBaby,
  familySharing, FamilySharing, InsertFamilySharing,
  feedings, Feeding, InsertFeeding,
  sleeps, Sleep, InsertSleep,
  diapers, Diaper, InsertDiaper,
  supplyItems, SupplyItem, InsertSupplyItem,
  growthRecords, GrowthRecord, InsertGrowthRecord,
  milestones, Milestone, InsertMilestone,
  healthRecords, HealthRecord, InsertHealthRecord,
  appointments, Appointment, InsertAppointment,
  vaccines, Vaccine, InsertVaccine
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // Optional method for complex queries
  executeRawQuery?(query: string, params?: any[]): Promise<any>;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Baby methods
  getBaby(id: number): Promise<Baby | undefined>;
  getBabyByShareCode(shareCode: string): Promise<Baby | undefined>;
  getBabiesByOwner(ownerId: number): Promise<Baby[]>;
  createBaby(baby: InsertBaby): Promise<Baby>;
  updateBaby(id: number, baby: Partial<InsertBaby>): Promise<Baby | undefined>;
  deleteBaby(id: number): Promise<boolean>;
  
  // Family sharing methods
  getFamilyMembers(babyId: number): Promise<FamilySharing[]>;
  getFamilySharing(id: number): Promise<FamilySharing | undefined>;
  createFamilySharing(sharing: InsertFamilySharing): Promise<FamilySharing>;
  updateFamilySharing(id: number, role: string): Promise<FamilySharing | undefined>;
  deleteFamilySharing(id: number): Promise<boolean>;
  getBabyAccess(userId: number, babyId: number): Promise<FamilySharing | undefined>;
  
  // Feeding methods
  getFeeding(id: number): Promise<Feeding | undefined>;
  getFeedingsByBaby(babyId: number): Promise<Feeding[]>;
  getFeedingsByDate(babyId: number, date: Date): Promise<Feeding[]>;
  createFeeding(feeding: InsertFeeding): Promise<Feeding>;
  updateFeeding(id: number, feeding: Partial<InsertFeeding>): Promise<Feeding | undefined>;
  deleteFeeding(id: number): Promise<boolean>;
  
  // Sleep methods
  getSleep(id: number): Promise<Sleep | undefined>;
  getSleepsByBaby(babyId: number): Promise<Sleep[]>;
  getSleepsByDate(babyId: number, date: Date): Promise<Sleep[]>;
  createSleep(sleep: InsertSleep): Promise<Sleep>;
  updateSleep(id: number, sleep: Partial<InsertSleep>): Promise<Sleep | undefined>;
  deleteSleep(id: number): Promise<boolean>;
  
  // Diaper methods
  getDiaper(id: number): Promise<Diaper | undefined>;
  getDiapersByBaby(babyId: number): Promise<Diaper[]>;
  getDiapersByDate(babyId: number, date: Date): Promise<Diaper[]>;
  createDiaper(diaper: InsertDiaper): Promise<Diaper>;
  updateDiaper(id: number, diaper: Partial<InsertDiaper>): Promise<Diaper | undefined>;
  deleteDiaper(id: number): Promise<boolean>;
  
  // Supply methods
  getSupplyItem(id: number): Promise<SupplyItem | undefined>;
  getSupplyItemsByUser(userId: number): Promise<SupplyItem[]>;
  getSupplyItemsByStatus(userId: number, status: string): Promise<SupplyItem[]>;
  getShoppingList(userId: number): Promise<SupplyItem[]>;
  createSupplyItem(supplyItem: InsertSupplyItem): Promise<SupplyItem>;
  updateSupplyItem(id: number, supplyItem: Partial<InsertSupplyItem>): Promise<SupplyItem | undefined>;
  deleteSupplyItem(id: number): Promise<boolean>;
  
  // Growth Tracking methods
  getGrowthRecord(id: number): Promise<GrowthRecord | undefined>;
  getGrowthRecordsByBaby(babyId: number): Promise<GrowthRecord[]>;
  createGrowthRecord(record: InsertGrowthRecord): Promise<GrowthRecord>;
  updateGrowthRecord(id: number, record: Partial<InsertGrowthRecord>): Promise<GrowthRecord | undefined>;
  deleteGrowthRecord(id: number): Promise<boolean>;
  
  // Milestone Tracking methods
  getMilestone(id: number): Promise<Milestone | undefined>;
  getMilestonesByBaby(babyId: number): Promise<Milestone[]>;
  getMilestonesByCategory(babyId: number, category: string): Promise<Milestone[]>;
  createMilestone(milestone: InsertMilestone): Promise<Milestone>;
  updateMilestone(id: number, milestone: Partial<InsertMilestone>): Promise<Milestone | undefined>;
  deleteMilestone(id: number): Promise<boolean>;
  
  // Health Tracking methods
  getHealthRecord(id: number): Promise<HealthRecord | undefined>;
  getHealthRecordsByBaby(babyId: number): Promise<HealthRecord[]>;
  getHealthRecordsByType(babyId: number, recordType: string): Promise<HealthRecord[]>;
  getHealthRecordsByDate(babyId: number, startDate: Date, endDate: Date): Promise<HealthRecord[]>;
  createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord>;
  updateHealthRecord(id: number, record: Partial<InsertHealthRecord>): Promise<HealthRecord | undefined>;
  deleteHealthRecord(id: number): Promise<boolean>;
  
  // Daily Summary
  getDailySummary(babyId: number, date: Date): Promise<{
    feedings: Feeding[];
    sleeps: Sleep[];
    diapers: Diaper[];
    healthRecords: HealthRecord[];
  }>;
  
  // Appointment methods
  getAppointment(id: number): Promise<Appointment | undefined>;
  getAppointmentsByBaby(babyId: number): Promise<Appointment[]>;
  getUpcomingAppointments(babyId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;
  
  // Vaccine methods
  getVaccine(id: number): Promise<Vaccine | undefined>;
  getVaccinesByBaby(babyId: number): Promise<Vaccine[]>;
  getDueVaccines(babyId: number): Promise<Vaccine[]>;
  createVaccine(vaccine: InsertVaccine): Promise<Vaccine>;
  updateVaccine(id: number, vaccine: Partial<InsertVaccine>): Promise<Vaccine | undefined>;
  deleteVaccine(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private babies: Map<number, Baby>;
  private familySharing: Map<number, FamilySharing>;
  private feedings: Map<number, Feeding>;
  private sleeps: Map<number, Sleep>;
  private diapers: Map<number, Diaper>;
  private supplyItems: Map<number, SupplyItem>;
  private growthRecords: Map<number, GrowthRecord>;
  private milestones: Map<number, Milestone>;
  private healthRecords: Map<number, HealthRecord>;
  private appointments: Map<number, Appointment>;
  private vaccines: Map<number, Vaccine>;
  
  public sessionStore: session.Store;
  
  userCurrentId: number;
  babyCurrentId: number;
  familySharingCurrentId: number;
  feedingCurrentId: number;
  sleepCurrentId: number;
  diaperCurrentId: number;
  supplyItemCurrentId: number;
  growthRecordCurrentId: number;
  milestoneCurrentId: number;
  healthRecordCurrentId: number;
  appointmentCurrentId: number;
  vaccineCurrentId: number;

  constructor() {
    this.users = new Map();
    this.babies = new Map();
    this.familySharing = new Map();
    this.feedings = new Map();
    this.sleeps = new Map();
    this.diapers = new Map();
    this.supplyItems = new Map();
    this.growthRecords = new Map();
    this.milestones = new Map();
    this.healthRecords = new Map();
    this.appointments = new Map();
    this.vaccines = new Map();
    
    this.userCurrentId = 1;
    this.babyCurrentId = 1;
    this.familySharingCurrentId = 1;
    this.feedingCurrentId = 1;
    this.sleepCurrentId = 1;
    this.diaperCurrentId = 1;
    this.supplyItemCurrentId = 1;
    this.growthRecordCurrentId = 1;
    this.milestoneCurrentId = 1;
    this.healthRecordCurrentId = 1;
    this.appointmentCurrentId = 1;
    this.vaccineCurrentId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id, role: "admin" };
    this.users.set(id, user);
    return user;
  }
  
  // Baby methods
  async getBaby(id: number): Promise<Baby | undefined> {
    return this.babies.get(id);
  }
  
  async getBabyByShareCode(shareCode: string): Promise<Baby | undefined> {
    return Array.from(this.babies.values()).find(
      baby => baby.shareCode === shareCode
    );
  }
  
  async getBabiesByOwner(ownerId: number): Promise<Baby[]> {
    return Array.from(this.babies.values()).filter(
      (baby) => baby.ownerId === ownerId
    );
  }
  
  async createBaby(insertBaby: InsertBaby): Promise<Baby> {
    const id = this.babyCurrentId++;
    
    // Generate a 12-digit share code if none provided
    if (!insertBaby.shareCode) {
      insertBaby.shareCode = Math.floor(100000000000 + Math.random() * 900000000000).toString();
    }
    
    // Ensure all optional fields are properly set to null if undefined
    const baby: Baby = { 
      ...insertBaby, 
      id,
      gender: insertBaby.gender || null, 
      dateOfBirth: insertBaby.dateOfBirth || null,
      weight: insertBaby.weight || null,
      width: insertBaby.width || null,
      shareCode: insertBaby.shareCode,
      createdAt: new Date() 
    };
    
    this.babies.set(id, baby);
    
    // Auto-create family sharing for owner with admin role
    await this.createFamilySharing({
      babyId: baby.id,
      userId: baby.ownerId,
      role: "admin"
    });
    
    return baby;
  }
  
  // Family sharing methods
  async getFamilyMembers(babyId: number): Promise<FamilySharing[]> {
    return Array.from(this.familySharing.values()).filter(
      (sharing) => sharing.babyId === babyId
    );
  }
  
  async getFamilySharing(id: number): Promise<FamilySharing | undefined> {
    return this.familySharing.get(id);
  }
  
  async createFamilySharing(insertSharing: InsertFamilySharing): Promise<FamilySharing> {
    const id = this.familySharingCurrentId++;
    const sharing: FamilySharing = { 
      ...insertSharing,
      role: insertSharing.role || "viewer", 
      id, 
      createdAt: new Date() 
    };
    this.familySharing.set(id, sharing);
    return sharing;
  }
  
  async updateFamilySharing(id: number, role: string): Promise<FamilySharing | undefined> {
    const sharing = this.familySharing.get(id);
    if (sharing) {
      const updated = { ...sharing, role };
      this.familySharing.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteFamilySharing(id: number): Promise<boolean> {
    return this.familySharing.delete(id);
  }
  
  async getBabyAccess(userId: number, babyId: number): Promise<FamilySharing | undefined> {
    return Array.from(this.familySharing.values()).find(
      (sharing) => sharing.babyId === babyId && sharing.userId === userId
    );
  }
  
  // Feeding methods
  async getFeeding(id: number): Promise<Feeding | undefined> {
    return this.feedings.get(id);
  }
  
  async getFeedingsByBaby(babyId: number): Promise<Feeding[]> {
    return Array.from(this.feedings.values())
      .filter((feeding) => feeding.babyId === babyId)
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
  }
  
  async getFeedingsByDate(babyId: number, date: Date): Promise<Feeding[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return Array.from(this.feedings.values())
      .filter((feeding) => 
        feeding.babyId === babyId &&
        feeding.startTime >= startOfDay &&
        feeding.startTime <= endOfDay
      )
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
  }
  
  async createFeeding(insertFeeding: InsertFeeding): Promise<Feeding> {
    const id = this.feedingCurrentId++;
    const feeding: Feeding = { 
      ...insertFeeding, 
      id, 
      createdAt: new Date() 
    };
    this.feedings.set(id, feeding);
    return feeding;
  }
  
  async updateFeeding(id: number, feedingUpdate: Partial<InsertFeeding>): Promise<Feeding | undefined> {
    const feeding = this.feedings.get(id);
    if (feeding) {
      const updated = { ...feeding, ...feedingUpdate };
      this.feedings.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteFeeding(id: number): Promise<boolean> {
    return this.feedings.delete(id);
  }
  
  // Sleep methods
  async getSleep(id: number): Promise<Sleep | undefined> {
    return this.sleeps.get(id);
  }
  
  async getSleepsByBaby(babyId: number): Promise<Sleep[]> {
    return Array.from(this.sleeps.values())
      .filter((sleep) => sleep.babyId === babyId)
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
  }
  
  async getSleepsByDate(babyId: number, date: Date): Promise<Sleep[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return Array.from(this.sleeps.values())
      .filter((sleep) => 
        sleep.babyId === babyId &&
        sleep.startTime >= startOfDay &&
        sleep.startTime <= endOfDay
      )
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
  }
  
  async createSleep(insertSleep: InsertSleep): Promise<Sleep> {
    const id = this.sleepCurrentId++;
    const sleep: Sleep = { 
      ...insertSleep, 
      id, 
      createdAt: new Date() 
    };
    this.sleeps.set(id, sleep);
    return sleep;
  }
  
  async updateSleep(id: number, sleepUpdate: Partial<InsertSleep>): Promise<Sleep | undefined> {
    const sleep = this.sleeps.get(id);
    if (sleep) {
      const updated = { ...sleep, ...sleepUpdate };
      this.sleeps.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteSleep(id: number): Promise<boolean> {
    return this.sleeps.delete(id);
  }
  
  // Diaper methods
  async getDiaper(id: number): Promise<Diaper | undefined> {
    return this.diapers.get(id);
  }
  
  async getDiapersByBaby(babyId: number): Promise<Diaper[]> {
    return Array.from(this.diapers.values())
      .filter((diaper) => diaper.babyId === babyId)
      .sort((a, b) => b.time.getTime() - a.time.getTime());
  }
  
  async getDiapersByDate(babyId: number, date: Date): Promise<Diaper[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return Array.from(this.diapers.values())
      .filter((diaper) => 
        diaper.babyId === babyId &&
        diaper.time >= startOfDay &&
        diaper.time <= endOfDay
      )
      .sort((a, b) => b.time.getTime() - a.time.getTime());
  }
  
  async createDiaper(insertDiaper: InsertDiaper): Promise<Diaper> {
    const id = this.diaperCurrentId++;
    const diaper: Diaper = { 
      ...insertDiaper, 
      id, 
      createdAt: new Date() 
    };
    this.diapers.set(id, diaper);
    return diaper;
  }
  
  async updateDiaper(id: number, diaperUpdate: Partial<InsertDiaper>): Promise<Diaper | undefined> {
    const diaper = this.diapers.get(id);
    if (diaper) {
      const updated = { ...diaper, ...diaperUpdate };
      this.diapers.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteDiaper(id: number): Promise<boolean> {
    return this.diapers.delete(id);
  }
  
  // Supply methods
  async getSupplyItem(id: number): Promise<SupplyItem | undefined> {
    return this.supplyItems.get(id);
  }
  
  async getSupplyItemsByUser(userId: number): Promise<SupplyItem[]> {
    return Array.from(this.supplyItems.values())
      .filter((item) => item.userId === userId)
      .sort((a, b) => a.name.localeCompare(b.name));
  }
  
  async getSupplyItemsByStatus(userId: number, status: string): Promise<SupplyItem[]> {
    return Array.from(this.supplyItems.values())
      .filter((item) => item.userId === userId && item.status === status)
      .sort((a, b) => a.name.localeCompare(b.name));
  }
  
  async getShoppingList(userId: number): Promise<SupplyItem[]> {
    return Array.from(this.supplyItems.values())
      .filter((item) => item.userId === userId && item.onShoppingList === true)
      .sort((a, b) => a.name.localeCompare(b.name));
  }
  
  async createSupplyItem(insertSupplyItem: InsertSupplyItem): Promise<SupplyItem> {
    const id = this.supplyItemCurrentId++;
    const supplyItem: SupplyItem = {
      ...insertSupplyItem,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.supplyItems.set(id, supplyItem);
    return supplyItem;
  }
  
  async updateSupplyItem(id: number, supplyItemUpdate: Partial<InsertSupplyItem>): Promise<SupplyItem | undefined> {
    const supplyItem = this.supplyItems.get(id);
    if (supplyItem) {
      const updated = { 
        ...supplyItem, 
        ...supplyItemUpdate,
        updatedAt: new Date() 
      };
      this.supplyItems.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteSupplyItem(id: number): Promise<boolean> {
    return this.supplyItems.delete(id);
  }
  
  // Baby update method
  async updateBaby(id: number, babyUpdate: Partial<InsertBaby>): Promise<Baby | undefined> {
    const baby = this.babies.get(id);
    if (baby) {
      const updated = { ...baby, ...babyUpdate };
      this.babies.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteBaby(id: number): Promise<boolean> {
    try {
      // Delete associated data for this baby
      
      // Delete family sharing entries
      Array.from(this.familySharing.values())
        .filter(sharing => sharing.babyId === id)
        .forEach(sharing => this.familySharing.delete(sharing.id));
      
      // Delete feedings
      Array.from(this.feedings.values())
        .filter(feeding => feeding.babyId === id)
        .forEach(feeding => this.feedings.delete(feeding.id));
      
      // Delete sleeps
      Array.from(this.sleeps.values())
        .filter(sleep => sleep.babyId === id)
        .forEach(sleep => this.sleeps.delete(sleep.id));
      
      // Delete diapers
      Array.from(this.diapers.values())
        .filter(diaper => diaper.babyId === id)
        .forEach(diaper => this.diapers.delete(diaper.id));
      
      // Delete growth records
      Array.from(this.growthRecords.values())
        .filter(record => record.babyId === id)
        .forEach(record => this.growthRecords.delete(record.id));
      
      // Delete milestones
      Array.from(this.milestones.values())
        .filter(milestone => milestone.babyId === id)
        .forEach(milestone => this.milestones.delete(milestone.id));
      
      // Delete health records
      Array.from(this.healthRecords.values())
        .filter(record => record.babyId === id)
        .forEach(record => this.healthRecords.delete(record.id));
      
      // Delete appointments
      Array.from(this.appointments.values())
        .filter(appointment => appointment.babyId === id)
        .forEach(appointment => this.appointments.delete(appointment.id));
      
      // Delete vaccines
      Array.from(this.vaccines.values())
        .filter(vaccine => vaccine.babyId === id)
        .forEach(vaccine => this.vaccines.delete(vaccine.id));
      
      // Delete the baby itself
      return this.babies.delete(id);
    } catch (error) {
      console.error("Error deleting baby:", error);
      return false;
    }
  }
  
  // Growth Tracking methods
  async getGrowthRecord(id: number): Promise<GrowthRecord | undefined> {
    return this.growthRecords.get(id);
  }
  
  async getGrowthRecordsByBaby(babyId: number): Promise<GrowthRecord[]> {
    return Array.from(this.growthRecords.values())
      .filter((record) => record.babyId === babyId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async createGrowthRecord(insertRecord: InsertGrowthRecord): Promise<GrowthRecord> {
    const id = this.growthRecordCurrentId++;
    const record: GrowthRecord = {
      ...insertRecord,
      id,
      createdAt: new Date()
    };
    this.growthRecords.set(id, record);
    return record;
  }
  
  async updateGrowthRecord(id: number, recordUpdate: Partial<InsertGrowthRecord>): Promise<GrowthRecord | undefined> {
    const record = this.growthRecords.get(id);
    if (record) {
      const updated = { ...record, ...recordUpdate };
      this.growthRecords.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteGrowthRecord(id: number): Promise<boolean> {
    return this.growthRecords.delete(id);
  }
  
  // Milestone Tracking methods
  async getMilestone(id: number): Promise<Milestone | undefined> {
    return this.milestones.get(id);
  }
  
  async getMilestonesByBaby(babyId: number): Promise<Milestone[]> {
    return Array.from(this.milestones.values())
      .filter((milestone) => milestone.babyId === babyId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async getMilestonesByCategory(babyId: number, category: string): Promise<Milestone[]> {
    return Array.from(this.milestones.values())
      .filter((milestone) => milestone.babyId === babyId && milestone.category === category)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async createMilestone(insertMilestone: InsertMilestone): Promise<Milestone> {
    const id = this.milestoneCurrentId++;
    const milestone: Milestone = {
      ...insertMilestone,
      id,
      createdAt: new Date()
    };
    this.milestones.set(id, milestone);
    return milestone;
  }
  
  async updateMilestone(id: number, milestoneUpdate: Partial<InsertMilestone>): Promise<Milestone | undefined> {
    const milestone = this.milestones.get(id);
    if (milestone) {
      const updated = { ...milestone, ...milestoneUpdate };
      this.milestones.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteMilestone(id: number): Promise<boolean> {
    return this.milestones.delete(id);
  }
  
  // Health Tracking methods
  async getHealthRecord(id: number): Promise<HealthRecord | undefined> {
    return this.healthRecords.get(id);
  }
  
  async getHealthRecordsByBaby(babyId: number): Promise<HealthRecord[]> {
    return Array.from(this.healthRecords.values())
      .filter((record) => record.babyId === babyId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async getHealthRecordsByType(babyId: number, recordType: string): Promise<HealthRecord[]> {
    return Array.from(this.healthRecords.values())
      .filter((record) => record.babyId === babyId && record.recordType === recordType)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async getHealthRecordsByDate(babyId: number, startDate: Date, endDate: Date): Promise<HealthRecord[]> {
    return Array.from(this.healthRecords.values())
      .filter((record) => {
        const recordDate = new Date(record.date);
        return record.babyId === babyId && recordDate >= startDate && recordDate <= endDate;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async createHealthRecord(insertRecord: InsertHealthRecord): Promise<HealthRecord> {
    const id = this.healthRecordCurrentId++;
    const record: HealthRecord = {
      ...insertRecord,
      id,
      createdAt: new Date()
    };
    this.healthRecords.set(id, record);
    return record;
  }
  
  async updateHealthRecord(id: number, recordUpdate: Partial<InsertHealthRecord>): Promise<HealthRecord | undefined> {
    const record = this.healthRecords.get(id);
    if (record) {
      const updated = { ...record, ...recordUpdate };
      this.healthRecords.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteHealthRecord(id: number): Promise<boolean> {
    return this.healthRecords.delete(id);
  }
  
  // Daily Summary
  async getDailySummary(babyId: number, date: Date): Promise<{
    feedings: Feeding[];
    sleeps: Sleep[];
    diapers: Diaper[];
    healthRecords: HealthRecord[];
  }> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    const feedings = await this.getFeedingsByDate(babyId, date);
    const sleeps = await this.getSleepsByDate(babyId, date);
    const diapers = await this.getDiapersByDate(babyId, date);
    const healthRecords = await this.getHealthRecordsByDate(babyId, startOfDay, endOfDay);
    
    return {
      feedings,
      sleeps,
      diapers,
      healthRecords
    };
  }
  
  // Appointment methods
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }
  
  async getAppointmentsByBaby(babyId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values())
      .filter((appointment) => appointment.babyId === babyId)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()); // Ascending order by date
  }
  
  async getUpcomingAppointments(babyId: number): Promise<Appointment[]> {
    const now = new Date();
    return Array.from(this.appointments.values())
      .filter((appointment) => 
        appointment.babyId === babyId && 
        new Date(appointment.date) >= now &&
        !appointment.completed
      )
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()); // Ascending order by date
  }
  
  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentCurrentId++;
    const appointment: Appointment = {
      ...insertAppointment,
      id,
      reminderSet: insertAppointment.reminderSet || false,
      completed: insertAppointment.completed || false,
      createdAt: new Date()
    };
    this.appointments.set(id, appointment);
    return appointment;
  }
  
  async updateAppointment(id: number, appointmentUpdate: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (appointment) {
      const updated = { ...appointment, ...appointmentUpdate };
      this.appointments.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteAppointment(id: number): Promise<boolean> {
    return this.appointments.delete(id);
  }
  
  // Vaccine methods
  async getVaccine(id: number): Promise<Vaccine | undefined> {
    return this.vaccines.get(id);
  }
  
  async getVaccinesByBaby(babyId: number): Promise<Vaccine[]> {
    return Array.from(this.vaccines.values())
      .filter((vaccine) => vaccine.babyId === babyId)
      .sort((a, b) => {
        // First sort by completed status
        if (a.completed && !b.completed) return 1;
        if (!a.completed && b.completed) return -1;
        
        // Then sort by due date (if not completed) or administered date (if completed)
        const aDate = a.completed ? a.administeredDate : a.dueDate;
        const bDate = b.completed ? b.administeredDate : b.dueDate;
        
        if (aDate && bDate) return new Date(aDate).getTime() - new Date(bDate).getTime();
        if (aDate) return -1;
        if (bDate) return 1;
        
        return 0;
      });
  }
  
  async getDueVaccines(babyId: number): Promise<Vaccine[]> {
    const now = new Date();
    return Array.from(this.vaccines.values())
      .filter((vaccine) => 
        vaccine.babyId === babyId && 
        !vaccine.completed &&
        vaccine.dueDate && 
        new Date(vaccine.dueDate) <= now
      )
      .sort((a, b) => {
        if (a.dueDate && b.dueDate) {
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        }
        return 0;
      });
  }
  
  async createVaccine(insertVaccine: InsertVaccine): Promise<Vaccine> {
    const id = this.vaccineCurrentId++;
    const vaccine: Vaccine = {
      ...insertVaccine,
      id,
      reminder: insertVaccine.reminder !== undefined ? insertVaccine.reminder : true,
      completed: insertVaccine.completed || false,
      createdAt: new Date()
    };
    this.vaccines.set(id, vaccine);
    return vaccine;
  }
  
  async updateVaccine(id: number, vaccineUpdate: Partial<InsertVaccine>): Promise<Vaccine | undefined> {
    const vaccine = this.vaccines.get(id);
    if (vaccine) {
      const updated = { ...vaccine, ...vaccineUpdate };
      this.vaccines.set(id, updated);
      return updated;
    }
    return undefined;
  }
  
  async deleteVaccine(id: number): Promise<boolean> {
    return this.vaccines.delete(id);
  }
}

// Import the DatabaseStorage implementation
import { DatabaseStorage } from "./db-storage";

// Export a database storage instance
export const storage = new DatabaseStorage();
