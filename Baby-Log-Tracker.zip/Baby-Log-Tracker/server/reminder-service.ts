// Reminder Service for handling system reminders
import { storage } from "./storage";
import { add, isBefore, isAfter, parseISO, formatDistance, format, isValid } from "date-fns";
import { db } from "./db";

// Types of reminders we support
export enum ReminderType {
  VACCINE = "vaccine",
  APPOINTMENT = "appointment",
  MILESTONE = "milestone",
  GROWTH_CHECK = "growth_check",
  HEALTH_CHECK = "health_check",
}

// Structure for reminder object
export interface Reminder {
  id: number;
  type: ReminderType;
  babyId: number;
  babyName: string;
  userId: number;
  title: string;
  dueDate: Date;
  message: string;
  status: "pending" | "sent" | "dismissed";
}

// Simplified reminder interface that works with both system and custom reminders
export interface SimpleReminder {
  id: number;
  type: ReminderType | string;
  babyId: number;
  babyName: string;
  // For system reminders
  dueDate?: Date;
  name?: string;
  description?: string;
  // For custom reminders
  title?: string;
  startDate?: Date;
  time?: string;
  message?: string;
  notes?: string;
  enabled?: boolean;
}

// Get all upcoming reminders for a user
export async function getUpcomingReminders(userId: number): Promise<SimpleReminder[]> {
  const reminders: SimpleReminder[] = [];
  
  try {
    console.log(`Getting reminders for user ${userId}`);
    
    // 1. Get all babies this user has access to
    const babies = await storage.getBabiesByOwner(userId);
    
    if (!babies || babies.length === 0) {
      console.log("No babies found for this user");
      return []; // No babies, no reminders
    }
    
    console.log(`Found ${babies.length} babies to check for reminders`);
    
    // First collect the custom reminders (feeding, medication, etc.)
    const customReminders = await storage.getActiveCustomReminders(userId);
    
    if (customReminders && customReminders.length > 0) {
      console.log(`Found ${customReminders.length} custom reminders`);
      
      // Process each custom reminder
      for (const reminder of customReminders) {
        // Find baby details
        const baby = babies.find(b => b.id === reminder.babyId);
        if (!baby) continue; // Skip if baby not found
        
        reminders.push({
          id: reminder.id,
          type: reminder.type,
          babyId: reminder.babyId,
          babyName: baby.name,
          title: reminder.title,
          startDate: reminder.startDate,
          time: reminder.time,
          // Notes from custom reminders becomes the message for display
          message: reminder.notes || "",
          notes: reminder.notes || "",
          enabled: reminder.enabled
        });
      }
    }
    
    // Process each baby for system reminders
    for (const baby of babies) {
      // 2. Get vaccine reminders
      if (baby) {
        console.log(`Checking vaccines for baby: ${baby.name} (ID: ${baby.id})`);
        const vaccines = await storage.getDueVaccines(baby.id);
        
        for (const vaccine of vaccines || []) {
          if (vaccine.dueDate && vaccine.reminder && !vaccine.completed) {
            const dueDate = new Date(vaccine.dueDate);
            
            // Only add reminders if due date is valid and not in the future (next 7 days)
            if (!isNaN(dueDate.getTime())) {
              // Simple check - if the due date is in the future or today within next 7 days
              const today = new Date();
              today.setHours(0, 0, 0, 0);
              
              const oneWeekFromNow = new Date();
              oneWeekFromNow.setDate(oneWeekFromNow.getDate() + 7);
              oneWeekFromNow.setHours(23, 59, 59, 999);
              
              const dueDay = new Date(dueDate);
              
              if (dueDay >= today && dueDay <= oneWeekFromNow) {
                console.log(`Adding vaccine reminder: ${vaccine.name}, due: ${format(dueDate, 'yyyy-MM-dd')}`);
                
                reminders.push({
                  id: vaccine.id,
                  type: ReminderType.VACCINE,
                  babyId: baby.id,
                  babyName: baby.name,
                  name: vaccine.name,
                  dueDate: dueDate,
                  description: `${baby.name}'s ${vaccine.name} vaccine is due ${formatDistance(dueDate, new Date(), { addSuffix: true })}`
                });
              }
            }
          }
        }
        
        // 3. Get appointment reminders (similar structure)
        const appointments = await storage.getUpcomingAppointments(baby.id);
        
        for (const appointment of appointments || []) {
          if (appointment.date && appointment.reminderSet) {
            const appointmentDate = new Date(appointment.date);
            
            // Simple check for appointments within the next 7 days
            if (!isNaN(appointmentDate.getTime())) {
              const today = new Date();
              today.setHours(0, 0, 0, 0);
              
              const oneWeekFromNow = new Date();
              oneWeekFromNow.setDate(oneWeekFromNow.getDate() + 7);
              oneWeekFromNow.setHours(23, 59, 59, 999);
              
              const appointmentDay = new Date(appointmentDate);
              appointmentDay.setHours(0, 0, 0, 0);
              
              if (appointmentDay >= today && appointmentDay <= oneWeekFromNow) {
                console.log(`Adding appointment reminder: ${appointment.title}, due: ${format(appointmentDate, 'yyyy-MM-dd')}`);
                reminders.push({
                  id: appointment.id,
                  type: ReminderType.APPOINTMENT,
                  babyId: baby.id,
                  babyName: baby.name,
                  name: appointment.title || "Appointment",
                  dueDate: appointmentDate,
                  description: `${baby.name}'s appointment${appointment.title ? ` for ${appointment.title}` : ''} is scheduled ${formatDistance(appointmentDate, new Date(), { addSuffix: true })}`
                });
              }
            }
          }
        }
        
        // 4. Check for upcoming milestone reminders
        // Implementation depends on your milestone structure
        // Add similar checks for milestones, growth checks, etc.
      }
    }
    
    // Sort reminders by due date or start date (most urgent first)
    reminders.sort((a, b) => {
      const dateA = a.dueDate || a.startDate;
      const dateB = b.dueDate || b.startDate;
      
      if (!dateA) return 1;  // No date for A, put it later
      if (!dateB) return -1; // No date for B, put it later
      
      return dateA.getTime() - dateB.getTime();
    });
    
    return reminders;
  } catch (error) {
    console.error("Error getting reminders:", error);
    return [];
  }
}

// Check if a baby has any upcoming reminders
export async function hasBabyReminders(babyId: number): Promise<boolean> {
  try {
    // First check custom reminders from custom_reminders table directly
    console.log(`Checking if baby ${babyId} has reminders`);
    
    // Use the storage interface to check for custom reminders
    const customReminders = await storage.getCustomRemindersByBaby(babyId);
    
    if (customReminders && customReminders.length > 0) {
      // Check if any reminders are enabled
      const enabledReminders = customReminders.filter(reminder => reminder.enabled);
      if (enabledReminders.length > 0) {
        console.log(`Found ${enabledReminders.length} active custom reminders for baby ${babyId}`);
        return true;
      }
    }
    
    // Then check vaccines
    const vaccines = await storage.getDueVaccines(babyId);
    if (vaccines && vaccines.length > 0) {
      console.log(`Found ${vaccines.length} vaccines to check for reminders`);
      
      for (const vaccine of vaccines) {
        if (vaccine.dueDate && vaccine.reminder && !vaccine.completed) {
          // Ensure we have a proper date object
          const dueDate = new Date(vaccine.dueDate);
          
          console.log(`Checking vaccine: ${vaccine.name}, due date: ${vaccine.dueDate}, parsed date: ${dueDate}`);
          
          // Simple check - if the due date is in the future or today
          if (!isNaN(dueDate.getTime())) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const dueDay = new Date(dueDate);
            dueDay.setHours(0, 0, 0, 0);
            
            if (dueDay >= today) {
              console.log(`Found valid upcoming reminder for vaccine: ${vaccine.name}, due: ${dueDate.toISOString()}`);
              return true;
            }
          }
        }
      }
    }
    
    // Then check appointments
    const appointments = await storage.getUpcomingAppointments(babyId);
    if (appointments && appointments.length > 0) {
      for (const appointment of appointments) {
        if (appointment.date && appointment.reminderSet) {
          const appointmentDate = new Date(appointment.date);
          if (!isAfter(new Date(), add(appointmentDate, { days: 1 }))) {
            return true;
          }
        }
      }
    }
    
    // Return false if no reminders found
    return false;
  } catch (error) {
    console.error("Error checking reminders:", error);
    return false;
  }
}

// Format reminder for display
export function formatReminder(reminder: SimpleReminder): string {
  const dueDateFormatted = format(reminder.dueDate, "PPP");
  
  switch (reminder.type) {
    case ReminderType.VACCINE:
      return `${reminder.babyName}'s ${reminder.name} on ${dueDateFormatted}`;
      
    case ReminderType.APPOINTMENT:
      return `${reminder.babyName}'s appointment: ${reminder.name} on ${dueDateFormatted}`;
      
    case ReminderType.MILESTONE:
      return `${reminder.babyName} milestone check: ${reminder.name}`;
      
    case ReminderType.GROWTH_CHECK:
      return `${reminder.babyName}'s growth check due ${dueDateFormatted}`;
      
    case ReminderType.HEALTH_CHECK:
      return `${reminder.babyName}'s health check: ${reminder.name}`;
      
    default:
      return reminder.description;
  }
}