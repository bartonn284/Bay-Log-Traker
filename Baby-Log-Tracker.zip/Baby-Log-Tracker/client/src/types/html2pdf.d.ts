declare module 'html2pdf.js' {
  interface Options {
    margin?: number | [number, number, number, number];
    filename?: string;
    image?: {
      type?: string;
      quality?: number;
    };
    html2canvas?: {
      scale?: number;
      letterRendering?: boolean;
      useCORS?: boolean;
    };
    jsPDF?: {
      unit?: string;
      format?: string;
      orientation?: 'portrait' | 'landscape';
    };
  }

  interface HTML2PDF {
    from(element: HTMLElement | string): HTML2PDF;
    set(options: Options): HTML2PDF;
    save(): Promise<void>;
    toPdf(): HTML2PDF;
    toImg(): HTML2PDF;
    toCanvas(): HTML2PDF;
    output(type: string): string | ArrayBuffer;
  }

  function html2pdf(): HTML2PDF;
  export = html2pdf;
}