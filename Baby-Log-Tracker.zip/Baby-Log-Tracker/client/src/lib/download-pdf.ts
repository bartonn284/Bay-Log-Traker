/**
 * Helper function to download a PDF file generated from the PDF export
 * 
 * @param pdfBlob - The PDF blob to download
 * @param filename - The filename to use for the download
 */
export async function downloadPdf(pdfBlob: Blob, filename: string): Promise<void> {
  // Create a URL for the blob
  const url = URL.createObjectURL(pdfBlob);
  
  // Create a temporary link element
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  
  // Append to the document, click it, and remove it
  document.body.appendChild(link);
  link.click();
  
  // Clean up
  setTimeout(() => {
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, 100);
}