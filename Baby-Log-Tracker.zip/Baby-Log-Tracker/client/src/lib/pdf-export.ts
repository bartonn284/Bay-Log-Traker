import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { format, subDays, subWeeks, subMonths, differenceInMinutes, parseISO } from "date-fns";
import { Baby } from "@shared/schema";
import { apiRequest } from "./queryClient";

// Add any necessary modifications to jsPDF for TypeScript compatibility
declare module 'jspdf' {
  interface jsPDF {
    lastAutoTable: {
      finalY: number;
    };
    setFillColor(r: number, g: number, b: number): jsPDF;
    rect(x: number, y: number, w: number, h: number, style: string): jsPDF;
    circle(x: number, y: number, r: number, style: string): jsPDF;
    setDrawColor(r: number, g: number, b: number): jsPDF;
    setLineWidth(width: number): jsPDF;
    line(x1: number, y1: number, x2: number, y2: number): jsPDF;
  }
}

// Helper function to draw a bar chart in the PDF
function drawBarChart(
  doc: jsPDF, 
  data: { label: string; value: number; color?: [number, number, number] }[], 
  x: number, 
  y: number, 
  width: number, 
  height: number, 
  title: string
): number {
  const barWidth = width / data.length - 5;
  const maxValue = Math.max(...data.map(item => item.value));
  const scale = height / (maxValue || 1);
  
  // Draw title
  doc.setFontSize(12);
  doc.text(title, x, y - 5);
  
  // Draw axes
  doc.setDrawColor(100, 100, 100);
  doc.setLineWidth(0.5);
  doc.line(x, y, x, y + height);
  doc.line(x, y + height, x + width, y + height);
  
  // Draw bars
  data.forEach((item, index) => {
    const barHeight = item.value * scale;
    const barX = x + (barWidth + 5) * index + 5;
    const barY = y + height - barHeight;
    
    doc.setFillColor(...(item.color || [66, 135, 245]));
    doc.rect(barX, barY, barWidth, barHeight, 'F');
    
    // Draw label
    doc.setFontSize(8);
    doc.text(item.label, barX + barWidth / 2, y + height + 10, { align: 'center' });
    
    // Draw value
    doc.setFontSize(8);
    doc.text(item.value.toString(), barX + barWidth / 2, barY - 2, { align: 'center' });
  });
  
  return y + height + 20;
}

// Helper function to draw a pie chart
function drawPieChart(
  doc: jsPDF, 
  data: { label: string; value: number; color: [number, number, number] }[], 
  x: number, 
  y: number, 
  radius: number, 
  title: string
): number {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  let startAngle = 0;
  
  // Draw title
  doc.setFontSize(12);
  doc.text(title, x - radius, y - radius - 5);
  
  // Draw circle segments
  if (total > 0) {
    data.forEach((item) => {
      const angle = (item.value / total) * 2 * Math.PI;
      const endAngle = startAngle + angle;
      
      // Draw segment
      drawPieSegment(doc, x, y, radius, startAngle, endAngle, item.color);
      
      // Draw legend item
      const legendX = x + radius + 10;
      const legendY = y - radius + (data.indexOf(item) * 10);
      
      doc.setFillColor(...item.color);
      doc.rect(legendX, legendY - 4, 8, 8, 'F');
      doc.setFontSize(8);
      doc.text(`${item.label} (${Math.round((item.value / total) * 100)}%)`, legendX + 12, legendY);
      
      startAngle = endAngle;
    });
  } else {
    // Draw empty circle
    doc.setDrawColor(100, 100, 100);
    doc.circle(x, y, radius, 'S');
  }
  
  return y + radius + 10;
}

// Helper function to draw a pie segment
function drawPieSegment(
  doc: jsPDF, 
  centerX: number, 
  centerY: number, 
  radius: number, 
  startAngle: number, 
  endAngle: number, 
  color: [number, number, number]
) {
  const steps = Math.max(10, Math.floor((endAngle - startAngle) * 20 / Math.PI));
  
  doc.setFillColor(...color);
  doc.setLineWidth(0.1);
  
  // Start a path
  const x0 = centerX + radius * Math.cos(startAngle);
  const y0 = centerY + radius * Math.sin(startAngle);
  
  let path = `M ${centerX} ${centerY} L ${x0} ${y0}`;
  
  for (let i = 0; i <= steps; i++) {
    const angle = startAngle + (endAngle - startAngle) * (i / steps);
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    path += ` L ${x} ${y}`;
  }
  
  path += ` Z`;
  
  // Draw the path
  doc.internal.write(
    'q',
    `${color[0]/255} ${color[1]/255} ${color[2]/255} rg`,
    path,
    'f',
    'Q'
  );
}

// For analytics page - direct PDF generation
export async function generateDirectPDF(data: any, filename: string): Promise<void> {
  const doc = new jsPDF();
  
  // Add title
  doc.setFontSize(20);
  doc.text(`Baby Analytics Report: ${data.babyName}`, 14, 20);
  
  // Add date range
  doc.setFontSize(12);
  doc.text(`Report Period: ${data.dateRange}`, 14, 30);
  
  // Add charts data as tables
  let yPosition = 40;
  
  if (data.feedingStats) {
    doc.setFontSize(16);
    doc.text("Feeding Statistics", 14, yPosition);
    
    const feedingData = [
      ["Average feedings per day", data.feedingStats.avgPerDay?.toString() || "N/A"],
      ["Most common type", data.feedingStats.mostCommonType || "N/A"],
      ["Average duration", data.feedingStats.avgDuration ? `${data.feedingStats.avgDuration} mins` : "N/A"]
    ];
    
    autoTable(doc, {
      startY: yPosition + 5,
      head: [["Metric", "Value"]],
      body: feedingData,
      theme: 'grid',
      headStyles: { fillColor: [66, 135, 245], textColor: [255, 255, 255] }
    });
    
    yPosition = doc.lastAutoTable.finalY + 15;
  }
  
  if (data.sleepStats) {
    doc.setFontSize(16);
    doc.text("Sleep Statistics", 14, yPosition);
    
    const sleepData = [
      ["Average sleep per day", data.sleepStats.avgPerDay ? `${data.sleepStats.avgPerDay} hours` : "N/A"],
      ["Average sleep duration", data.sleepStats.avgDuration ? `${data.sleepStats.avgDuration} mins` : "N/A"],
      ["Quality average", data.sleepStats.avgQuality ? `${data.sleepStats.avgQuality}/5` : "N/A"]
    ];
    
    autoTable(doc, {
      startY: yPosition + 5,
      head: [["Metric", "Value"]],
      body: sleepData,
      theme: 'grid',
      headStyles: { fillColor: [155, 89, 182], textColor: [255, 255, 255] }
    });
    
    yPosition = doc.lastAutoTable.finalY + 15;
  }
  
  if (data.diaperStats) {
    doc.setFontSize(16);
    doc.text("Diaper Statistics", 14, yPosition);
    
    const diaperData = [
      ["Average changes per day", data.diaperStats.avgPerDay?.toString() || "N/A"],
      ["Most common type", data.diaperStats.mostCommonType || "N/A"]
    ];
    
    autoTable(doc, {
      startY: yPosition + 5,
      head: [["Metric", "Value"]],
      body: diaperData,
      theme: 'grid',
      headStyles: { fillColor: [46, 204, 113], textColor: [255, 255, 255] }
    });
    
    yPosition = doc.lastAutoTable.finalY + 15;
  }
  
  // Add charts if data is available
  if (data.feedingStats && data.feedingStats.types) {
    // Add a new page for charts
    doc.addPage();
    doc.setFontSize(18);
    doc.text('Visual Analytics', 14, 20);
    
    // Feeding Type Distribution - Pie Chart
    let chartY = 40;
    
    if (Object.keys(data.feedingStats.types).length > 0) {
      const typeData = Object.entries(data.feedingStats.types).map(([label, value], index) => {
        // Define different colors for each feeding type
        const colors: Record<string, [number, number, number]> = {
          'breastfeeding': [66, 135, 245],
          'bottle': [155, 89, 182],
          'formula': [46, 204, 113],
          'solids': [230, 126, 34],
          'other': [149, 165, 166]
        };
        
        return {
          label,
          value: value as number,
          color: colors[label.toLowerCase()] || [100, 100, 100] // default color
        };
      });
      
      chartY = drawPieChart(doc, typeData, 70, chartY + 35, 30, 'Feeding Type Distribution');
    }
    
    // Mood Distribution if available
    if (data.feedingStats.moods && Object.keys(data.feedingStats.moods).length > 0) {
      const moodData = Object.entries(data.feedingStats.moods).map(([label, value], index) => {
        // Define different colors for each mood
        const colors: Record<string, [number, number, number]> = {
          'happy': [46, 204, 113],
          'calm': [52, 152, 219],
          'fussy': [241, 196, 15],
          'crying': [231, 76, 60],
          'hungry': [230, 126, 34]
        };
        
        return {
          label,
          value: value as number,
          color: colors[label.toLowerCase()] || [100, 100, 100] // default color
        };
      });
      
      chartY = drawPieChart(doc, moodData, 70, chartY + 20, 30, 'Baby Mood Distribution');
    }
    
    // Feeding frequency by day (bar chart)
    if (data.feedingStats.byDay && Object.keys(data.feedingStats.byDay).length > 0) {
      // Convert to array of {label, value} for bar chart
      const dayData = Object.entries(data.feedingStats.byDay)
        .sort((a, b) => a[0].localeCompare(b[0])) // Sort by date
        .slice(-7) // Get last 7 days only
        .map(([day, count]) => ({
          label: day.slice(-2), // Just show the day part
          value: count as number,
          color: [66, 135, 245] as [number, number, number]
        }));
      
      if (dayData.length > 0) {
        chartY = drawBarChart(doc, dayData, 14, chartY + 20, 180, 60, 'Feeding Frequency by Day');
      }
    }
  }
  
  // Add footer
  doc.setFontSize(10);
  doc.text(`Generated on ${format(new Date(), 'MMM d, yyyy, h:mm a')}`, 
    doc.internal.pageSize.getWidth() / 2, 
    doc.internal.pageSize.getHeight() - 10, 
    { align: 'center' }
  );
  
  // Save and download the PDF
  doc.save(filename);
}

// Alias for compatibility
export const generatePDF = generateDirectPDF;

// For Reports page - returns a blob instead of saving directly
export async function generatePdf(baby: Baby, reportType: "full" | "summary", dateRange: "day" | "week" | "month"): Promise<Blob> {
  // Create a new PDF document
  const doc = new jsPDF();
  const today = new Date();
  
  // Add report header
  doc.setFontSize(20);
  doc.text(`Baby Activity Report: ${baby.name}`, 14, 20);
  
  let startDate: Date;
  switch (dateRange) {
    case "day":
      startDate = subDays(today, 1);
      break;
    case "week":
      startDate = subWeeks(today, 1);
      break;
    case "month":
      startDate = subMonths(today, 1);
      break;
  }
  
  doc.setFontSize(12);
  doc.text(`Report Period: ${format(startDate, 'MMM d, yyyy')} - ${format(today, 'MMM d, yyyy')}`, 14, 30);
  doc.text(`Report Type: ${reportType === "full" ? "Detailed" : "Summary"}`, 14, 40);
  
  // Add comprehensive baby info section
  doc.setFontSize(16);
  doc.text("Baby Information", 14, 55);
  
  doc.setFontSize(12);
  // Create full baby profile information array
  const babyInfo = [
    ["Name", baby.name],
    ["Gender", baby.gender || "Not specified"],
    ["Date of Birth", baby.dateOfBirth ? format(new Date(baby.dateOfBirth), 'MMM d, yyyy') : "Not specified"],
    ["Age", baby.dateOfBirth ? calculateAge(new Date(baby.dateOfBirth)) : "Not specified"],
    ["Weight", baby.weight || "Not specified"],
    ["Height", baby.height || "Not specified"],
    ["Hair Color", baby.hairColor || "Not specified"],
    ["Eye Color", baby.eyeColor || "Not specified"],
    ["Birth Location", baby.birthLocation || "Not specified"],
    ["Birth Weight", baby.birthWeight || "Not specified"],
    ["Birth Length", baby.birthLength || "Not specified"],
    ["Blood Type", baby.bloodType || "Not specified"],
    ["Allergies", baby.allergies || "None recorded"],
    ["Medical Conditions", baby.medicalConditions || "None recorded"],
    ["Pediatrician", baby.pediatrician || "Not specified"],
    ["Emergency Contact", baby.emergencyContact || "Not specified"],
    ["Insurance Info", baby.insuranceInfo || "Not specified"],
    ["Favorite Foods", baby.favoriteFood || "Not specified"],
    ["Favorite Activities", baby.favoriteActivities || "Not specified"],
    ["Likes", baby.likes || "Not specified"],
    ["Dislikes", baby.dislikes || "Not specified"],
    ["Birthmarks", baby.birthmarks || "None recorded"],
    ["Special Notes", baby.notes || "None recorded"]
  ];
  
  // Filter out fields that don't have values to save space
  const filteredBabyInfo = babyInfo.filter(info => 
    info[1] !== "Not specified" && info[1] !== "None recorded"
  );
  
  autoTable(doc, {
    startY: 60,
    head: [["Information", "Details"]],
    body: filteredBabyInfo.length > 0 ? filteredBabyInfo : babyInfo.slice(0, 4), // Use at least basic info
    theme: 'grid',
    headStyles: { fillColor: [100, 100, 255], textColor: [255, 255, 255] }
  });
  
  // Add activity sections
  let yPosition = doc.lastAutoTable.finalY + 15;
  
  try {
    // Fetch feeding data
    const feedingsRes = await apiRequest("GET", `/api/babies/${baby.id}/feedings`);
    const feedingsData = await feedingsRes.json();
    const feedings = Array.isArray(feedingsData) ? feedingsData : [];
    const filteredFeedings = feedings.filter((feeding: any) => 
      feeding && feeding.startTime && new Date(feeding.startTime) >= startDate
    );
    
    if (filteredFeedings.length > 0) {
      doc.setFontSize(16);
      doc.text("Feeding Activity", 14, yPosition);
      
      const feedingData = filteredFeedings.map((feeding: any) => [
        format(new Date(feeding.startTime), 'MMM d, h:mm a'),
        feeding.type,
        feeding.duration ? `${feeding.duration} mins` : "N/A",
        feeding.amount || "N/A",
        feeding.side || "N/A",
        feeding.mood || "N/A",
        reportType === "full" ? (feeding.notes || "None") : ""
      ]);
      
      autoTable(doc, {
        startY: yPosition + 5,
        head: [
          reportType === "full" 
            ? ["Time", "Type", "Duration", "Amount", "Side", "Mood", "Notes"]
            : ["Time", "Type", "Duration", "Amount", "Side", "Mood"]
        ],
        body: feedingData,
        theme: 'striped',
        headStyles: { fillColor: [66, 135, 245] }
      });
      
      yPosition = doc.lastAutoTable.finalY + 15;
      
      // Create feeding analytics and charts
      if (reportType === "full" && filteredFeedings.length > 0) {
        // Calculate feeding stats for charts
        const feedingTypes: Record<string, number> = {};
        const feedingMoods: Record<string, number> = {};
        const feedingDurationsByDay: Record<string, number[]> = {};
        
        filteredFeedings.forEach((feeding: any) => {
          // Count feeding types
          if (feeding.type) {
            feedingTypes[feeding.type] = (feedingTypes[feeding.type] || 0) + 1;
          }
          
          // Count moods if available
          if (feeding.mood) {
            feedingMoods[feeding.mood] = (feedingMoods[feeding.mood] || 0) + 1;
          }
          
          // Track durations by day
          if (feeding.startTime && feeding.duration) {
            const day = format(new Date(feeding.startTime), 'MM-dd');
            if (!feedingDurationsByDay[day]) {
              feedingDurationsByDay[day] = [];
            }
            feedingDurationsByDay[day].push(Number(feeding.duration));
          }
        });
        
        // Add new page for charts if there's not enough space
        if (yPosition > 180) {
          doc.addPage();
          yPosition = 20;
        }
        
        doc.setFontSize(16);
        doc.text("Feeding Analytics", 14, yPosition);
        yPosition += 10;
        
        // Draw feeding type distribution chart
        if (Object.keys(feedingTypes).length > 0) {
          const typeData = Object.entries(feedingTypes).map(([label, value]) => {
            // Define different colors for each feeding type
            const colors: Record<string, [number, number, number]> = {
              'breastfeeding': [66, 135, 245],
              'bottle': [155, 89, 182],
              'formula': [46, 204, 113],
              'solids': [230, 126, 34],
              'other': [149, 165, 166]
            };
            
            return {
              label,
              value,
              color: colors[label.toLowerCase()] || [100, 100, 100] // default color
            };
          });
          
          yPosition = drawPieChart(doc, typeData, 70, yPosition + 30, 30, 'Feeding Type Distribution');
        }
        
        // Draw mood distribution chart if available
        if (Object.keys(feedingMoods).length > 0) {
          // Add a new page if running out of space
          if (yPosition > 180) {
            doc.addPage();
            yPosition = 20;
          }
          
          const moodData = Object.entries(feedingMoods).map(([label, value]) => {
            // Define different colors for each mood
            const colors: Record<string, [number, number, number]> = {
              'happy': [46, 204, 113],
              'calm': [52, 152, 219],
              'fussy': [241, 196, 15],
              'crying': [231, 76, 60],
              'hungry': [230, 126, 34]
            };
            
            return {
              label,
              value,
              color: colors[label.toLowerCase()] || [100, 100, 100] // default color
            };
          });
          
          yPosition = drawPieChart(doc, moodData, 70, yPosition + 20, 30, 'Baby Mood Distribution');
        }
        
        // Calculate average durations by day for bar chart
        const avgDurationsByDay: Record<string, number> = {};
        Object.entries(feedingDurationsByDay).forEach(([day, durations]) => {
          const sum = durations.reduce((total, curr) => total + curr, 0);
          avgDurationsByDay[day] = Math.round(sum / durations.length);
        });
        
        // Draw average feeding duration by day chart
        if (Object.keys(avgDurationsByDay).length > 0) {
          // Add a new page if running out of space
          if (yPosition > 180) {
            doc.addPage();
            yPosition = 20;
          }
          
          // Convert to array of {label, value} for bar chart
          const durationData = Object.entries(avgDurationsByDay)
            .sort((a, b) => a[0].localeCompare(b[0])) // Sort by date
            .slice(-7) // Get last 7 days only
            .map(([day, avgDuration]) => ({
              label: day.slice(-2), // Just show the day part
              value: avgDuration,
              color: [66, 135, 245] as [number, number, number]
            }));
          
          if (durationData.length > 0) {
            yPosition = drawBarChart(doc, durationData, 14, yPosition + 20, 180, 60, 'Average Feeding Duration (mins) by Day');
          }
        }
      }
    }
    
    // Fetch sleep data
    const sleepRes = await apiRequest("GET", `/api/babies/${baby.id}/sleep`);
    const sleepsData = await sleepRes.json();
    const sleeps = Array.isArray(sleepsData) ? sleepsData : [];
    const filteredSleeps = sleeps.filter((sleep: any) => 
      sleep && sleep.startTime && new Date(sleep.startTime) >= startDate
    );
    
    if (filteredSleeps.length > 0) {
      doc.setFontSize(16);
      doc.text("Sleep Activity", 14, yPosition);
      
      const sleepData = filteredSleeps.map((sleep: any) => [
        format(new Date(sleep.startTime), 'MMM d, h:mm a'),
        sleep.endTime ? format(new Date(sleep.endTime), 'h:mm a') : "Ongoing",
        sleep.duration ? `${sleep.duration} mins` : "N/A",
        sleep.quality ? `${sleep.quality}/5` : "N/A",
        reportType === "full" ? (sleep.notes || "None") : ""
      ]);
      
      autoTable(doc, {
        startY: yPosition + 5,
        head: [
          reportType === "full" 
            ? ["Start Time", "End Time", "Duration", "Quality", "Notes"]
            : ["Start Time", "End Time", "Duration", "Quality"]
        ],
        body: sleepData,
        theme: 'striped',
        headStyles: { fillColor: [155, 89, 182] }
      });
      
      yPosition = doc.lastAutoTable.finalY + 15;
    }
    
    // Fetch diaper data
    const diaperRes = await apiRequest("GET", `/api/babies/${baby.id}/diapers`);
    const diapersData = await diaperRes.json();
    const diapers = Array.isArray(diapersData) ? diapersData : [];
    const filteredDiapers = diapers.filter((diaper: any) => 
      diaper && diaper.time && new Date(diaper.time) >= startDate
    );
    
    if (filteredDiapers.length > 0) {
      doc.setFontSize(16);
      doc.text("Diaper Activity", 14, yPosition);
      
      const diaperData = filteredDiapers.map((diaper: any) => [
        format(new Date(diaper.time), 'MMM d, h:mm a'),
        diaper.type,
        diaper.consistency || "N/A",
        diaper.color || "N/A",
        reportType === "full" ? (diaper.notes || "None") : ""
      ]);
      
      autoTable(doc, {
        startY: yPosition + 5,
        head: [
          reportType === "full" 
            ? ["Time", "Type", "Consistency", "Color", "Notes"]
            : ["Time", "Type", "Consistency", "Color"]
        ],
        body: diaperData,
        theme: 'striped',
        headStyles: { fillColor: [46, 204, 113] }
      });
      
      yPosition = doc.lastAutoTable.finalY + 15;
    }
    
    // If this is a full report, include health records and growth data
    if (reportType === "full") {
      // Fetch growth data
      const growthRes = await apiRequest("GET", `/api/babies/${baby.id}/growth`);
      const growthRecords = await growthRes.json();
      const filteredGrowth = growthRecords.filter((record: any) => 
        new Date(record.date) >= startDate
      );
      
      if (filteredGrowth.length > 0) {
        // Add a new page if we're running out of space
        if (yPosition > 230) {
          doc.addPage();
          yPosition = 20;
        }
        
        doc.setFontSize(16);
        doc.text("Growth Records", 14, yPosition);
        
        const growthData = filteredGrowth.map((record: any) => [
          format(new Date(record.date), 'MMM d, yyyy'),
          record.weight || "N/A",
          record.height || "N/A",
          record.headCircumference || "N/A",
          record.notes || "None"
        ]);
        
        autoTable(doc, {
          startY: yPosition + 5,
          head: [["Date", "Weight", "Height", "Head Circ.", "Notes"]],
          body: growthData,
          theme: 'striped',
          headStyles: { fillColor: [230, 126, 34] }
        });
        
        yPosition = doc.lastAutoTable.finalY + 15;
      }
      
      // Fetch health records
      const healthRes = await apiRequest("GET", `/api/babies/${baby.id}/health`);
      const healthRecords = await healthRes.json();
      const filteredHealth = healthRecords.filter((record: any) => 
        new Date(record.date) >= startDate
      );
      
      if (filteredHealth.length > 0) {
        // Add a new page if we're running out of space
        if (yPosition > 230) {
          doc.addPage();
          yPosition = 20;
        }
        
        doc.setFontSize(16);
        doc.text("Health Records", 14, yPosition);
        
        const healthData = filteredHealth.map((record: any) => [
          format(new Date(record.date), 'MMM d, yyyy'),
          record.recordType,
          record.temperature || "N/A",
          record.medicationName || "N/A",
          record.medicationDose || "N/A",
          record.notes || "None"
        ]);
        
        autoTable(doc, {
          startY: yPosition + 5,
          head: [["Date", "Type", "Temperature", "Medication", "Dose", "Notes"]],
          body: healthData,
          theme: 'striped',
          headStyles: { fillColor: [231, 76, 60] }
        });
        
        yPosition = doc.lastAutoTable.finalY + 15;
      }
    }
    
    // Add footer
    doc.setFontSize(10);
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.text(`Generated on ${format(new Date(), 'MMM d, yyyy, h:mm a')} - Page ${i} of ${pageCount}`, 
        doc.internal.pageSize.getWidth() / 2, 
        doc.internal.pageSize.getHeight() - 10, 
        { align: 'center' }
      );
    }
  } catch (error) {
    console.error("Error generating PDF:", error);
    // Add error message to the PDF
    doc.setTextColor(255, 0, 0);
    doc.text("An error occurred while generating the report. Some data may be missing.", 14, yPosition);
    doc.setTextColor(0, 0, 0);
  }
  
  return doc.output('blob');
}

function calculateAge(birthDate: Date): string {
  const today = new Date();
  let years = today.getFullYear() - birthDate.getFullYear();
  let months = today.getMonth() - birthDate.getMonth();
  
  if (months < 0 || (months === 0 && today.getDate() < birthDate.getDate())) {
    years--;
    months += 12;
  }
  
  const days = Math.floor((today.getTime() - new Date(today.getFullYear(), today.getMonth(), birthDate.getDate()).getTime()) / (1000 * 60 * 60 * 24));
  
  if (years > 0) {
    return `${years} year${years !== 1 ? 's' : ''}, ${months} month${months !== 1 ? 's' : ''}`;
  } else if (months > 0) {
    return `${months} month${months !== 1 ? 's' : ''}, ${days} day${days !== 1 ? 's' : ''}`;
  } else {
    return `${days} day${days !== 1 ? 's' : ''}`;
  }
}