import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, formatDistance, differenceInMonths, differenceInYears } from "date-fns"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date): string {
  return format(date, "MMM dd, yyyy")
}

export function calculateAge(dateOfBirth: Date): string {
  const now = new Date()
  const years = differenceInYears(now, dateOfBirth)
  const months = differenceInMonths(now, dateOfBirth) % 12
  
  if (years > 0) {
    return months > 0 
      ? `${years} ${years === 1 ? 'year' : 'years'}, ${months} ${months === 1 ? 'month' : 'months'}`
      : `${years} ${years === 1 ? 'year' : 'years'}`
  } else {
    return `${months} ${months === 1 ? 'month' : 'months'}`
  }
}
