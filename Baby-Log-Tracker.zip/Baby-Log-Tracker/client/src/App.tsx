import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/hooks/use-auth";
import { BabyProvider } from "@/hooks/use-baby-context";
import { ProtectedRoute } from "./lib/protected-route";
import { LogModal } from "@/components/log-modal";
import { useLogModal } from "@/hooks/use-log-modal";

import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import TimelinePage from "@/pages/timeline-page";
import SettingsPage from "@/pages/settings-page";
import ReportsPage from "@/pages/reports-page";
import SuppliesPage from "@/pages/supplies-page";
import AuthPage from "@/pages/auth-page";
import JoinBabyPage from "@/pages/join-baby-page";
import AnalyticsPage from "@/pages/analytics-page";
import DataPage from "@/pages/data-page";
import TipsPage from "@/pages/tips-page";

// Import health tracking pages 
import GrowthTrackingPage from "@/pages/growth-tracking-page";
import MilestonePage from "@/pages/milestone-page";
import HealthPage from "@/pages/health-page";
import DailySummaryPage from "@/pages/daily-summary-page";
import PumpingPage from "@/pages/pumping-page";
import AppointmentsPage from "@/pages/appointments-page";

// Application shell with global log modal
function AppShell({ children }: { children: React.ReactNode }) {
  const { isOpen, close } = useLogModal();
  
  return (
    <>
      {children}
      <LogModal isOpen={isOpen} onClose={close} />
    </>
  );
}

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={HomePage} />
      <ProtectedRoute path="/timeline" component={TimelinePage} />
      <ProtectedRoute path="/reports" component={ReportsPage} />
      <ProtectedRoute path="/supplies" component={SuppliesPage} />
      <ProtectedRoute path="/settings" component={SettingsPage} />
      <ProtectedRoute path="/join-baby" component={JoinBabyPage} />
      <ProtectedRoute path="/analytics" component={AnalyticsPage} />
      <ProtectedRoute path="/data" component={DataPage} />
      <ProtectedRoute path="/tips" component={TipsPage} />
      
      {/* Health tracking routes */}
      <ProtectedRoute path="/growth-tracking" component={GrowthTrackingPage} />
      <ProtectedRoute path="/milestones" component={MilestonePage} />
      <ProtectedRoute path="/health" component={HealthPage} />
      <ProtectedRoute path="/daily-summary" component={DailySummaryPage} />
      <ProtectedRoute path="/supplies/pumping" component={PumpingPage} />
      <ProtectedRoute path="/appointments" component={AppointmentsPage} />
      
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="baby-tracker-theme">
        <AuthProvider>
          <BabyProvider>
            <TooltipProvider>
              <AppShell>
                <Toaster />
                <Router />
              </AppShell>
            </TooltipProvider>
          </BabyProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
