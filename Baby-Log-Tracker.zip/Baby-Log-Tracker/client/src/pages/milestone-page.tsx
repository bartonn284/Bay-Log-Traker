import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";
import { Link } from "wouter";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, Star, Camera, Pencil, X, PlusCircle, ImagePlus, ChevronLeft } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Baby, Milestone as MilestoneType } from "@shared/schema";

type MilestoneFormData = {
  babyId: number;
  title: string;
  description: string;
  category: string;
  date: Date;
  mediaUrl: string;
};

const MILESTONE_CATEGORIES = [
  "Motor Skills",
  "Language",
  "Social",
  "Cognitive",
  "Emotional",
  "Other"
];

function MilestoneCard({ milestone, onEdit, onDelete }: { 
  milestone: MilestoneType, 
  onEdit: (milestone: MilestoneType) => void,
  onDelete: (id: number) => void
}) {
  return (
    <Card className="mb-4 border-l-4" style={{ borderLeftColor: getCategoryColor(milestone.category) }}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-base font-medium">
              {milestone.title}
            </CardTitle>
            <CardDescription>
              {format(new Date(milestone.date), "PPP")}
            </CardDescription>
          </div>
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8" 
              onClick={() => onEdit(milestone)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 text-destructive" 
              onClick={() => onDelete(milestone.id)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="flex items-center mb-3">
          <div className="w-8 h-8 rounded-full flex items-center justify-center mr-3" 
              style={{ backgroundColor: `${getCategoryColor(milestone.category)}20` }}>
            <Star className="h-4 w-4" style={{ color: getCategoryColor(milestone.category) }} />
          </div>
          <span className="text-sm font-medium" style={{ color: getCategoryColor(milestone.category) }}>
            {milestone.category}
          </span>
        </div>
        
        {milestone.description && (
          <p className="text-sm mb-3">{milestone.description}</p>
        )}
        
        {milestone.mediaUrl && (
          <div className="mt-3 pt-2 border-t">
            <p className="text-sm text-muted-foreground mb-2">Photo/Video:</p>
            <div className="relative rounded-md overflow-hidden bg-neutral-100 aspect-video flex items-center justify-center">
              <img 
                src={milestone.mediaUrl} 
                alt={milestone.title}
                className="object-cover w-full h-full"
                onError={(e) => {
                  e.currentTarget.src = "https://placehold.co/600x400?text=Media+Not+Available";
                }}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function getCategoryColor(category: string | null): string {
  switch (category) {
    case "Motor Skills":
      return "#0ea5e9"; // sky-500
    case "Language":
      return "#8b5cf6"; // violet-500
    case "Social":
      return "#ec4899"; // pink-500
    case "Cognitive": 
      return "#f59e0b"; // amber-500
    case "Emotional":
      return "#10b981"; // emerald-500
    default:
      return "#6b7280"; // gray-500
  }
}

export default function MilestonePage() {
  const { toast } = useToast();
  const [selectedBaby, setSelectedBaby] = useState<Baby | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [currentMilestone, setCurrentMilestone] = useState<MilestoneType | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [formData, setFormData] = useState<MilestoneFormData>({
    babyId: 0,
    title: "",
    description: "",
    category: "Other",
    date: new Date(),
    mediaUrl: "",
  });
  
  // Fetch babies
  const { data: babies } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Fetch milestones
  const { data: milestones, isLoading } = useQuery<MilestoneType[]>({
    queryKey: ["/api/babies", selectedBaby?.id, "milestones", selectedCategory],
    queryFn: async () => {
      if (!selectedBaby) throw new Error("No baby selected");
      const endpoint = selectedCategory === "all" 
        ? `/api/babies/${selectedBaby.id}/milestones` 
        : `/api/babies/${selectedBaby.id}/milestones/category/${selectedCategory}`;
      const response = await fetch(endpoint);
      if (!response.ok) {
        throw new Error("Failed to fetch milestones");
      }
      return response.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Create milestone
  const createMutation = useMutation({
    mutationFn: async (data: MilestoneFormData) => {
      const response = await apiRequest("POST", `/api/babies/${data.babyId}/milestones`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "milestones"] });
      setIsAddModalOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Milestone added successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add milestone: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Update milestone
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number } & MilestoneFormData) => {
      const response = await apiRequest("PATCH", `/api/babies/${data.babyId}/milestones/${data.id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "milestones"] });
      setIsEditModalOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Milestone updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update milestone: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Delete milestone
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/milestones/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "milestones"] });
      toast({
        title: "Success",
        description: "Milestone deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete milestone: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Set the first baby as selected when babies are loaded
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0]);
      setFormData(prev => ({ ...prev, babyId: babies[0].id }));
    }
  }, [babies, selectedBaby]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setFormData(prev => ({ ...prev, date }));
    }
  };
  
  const handleAddMilestone = () => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    
    // Make sure babyId is set correctly before submitting
    const dataToSubmit = {
      ...formData,
      babyId: selectedBaby.id
    };
    
    createMutation.mutate(dataToSubmit);
  };
  
  const handleUpdateMilestone = () => {
    if (!currentMilestone) return;
    
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    
    // Make sure babyId is set correctly before submitting
    const dataToSubmit = {
      ...formData,
      babyId: selectedBaby.id
    };
    
    updateMutation.mutate({ id: currentMilestone.id, ...dataToSubmit });
  };
  
  const handleEditClick = (milestone: MilestoneType) => {
    setCurrentMilestone(milestone);
    setFormData({
      babyId: milestone.babyId,
      title: milestone.title,
      description: milestone.description || "",
      category: milestone.category || "Other",
      date: new Date(milestone.date),
      mediaUrl: milestone.mediaUrl || "",
    });
    setIsEditModalOpen(true);
  };
  
  const handleDeleteClick = (id: number) => {
    if (confirm("Are you sure you want to delete this milestone?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const resetForm = () => {
    setFormData({
      babyId: selectedBaby?.id || 0,
      title: "",
      description: "",
      category: "Other",
      date: new Date(),
      mediaUrl: "",
    });
    setCurrentMilestone(null);
  };
  
  const filteredMilestones = milestones 
    ? selectedCategory 
      ? milestones.filter(m => m.category === selectedCategory)
      : milestones
    : [];
  
  return (
    <div className="container max-w-md mx-auto pb-20">
      <header className="py-6">
        <div className="flex items-center mb-2">
          <Button variant="ghost" size="sm" className="mr-2" asChild>
            <Link to="/reports">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Link>
          </Button>
        </div>
        <h1 className="text-2xl font-bold">Milestone Tracker</h1>
        <p className="text-muted-foreground">Record your baby's important development moments</p>
      </header>
      
      {babies && babies.length > 0 ? (
        <>
          {babies.length > 1 && (
            <Tabs defaultValue={String(selectedBaby?.id)} className="mb-6" onValueChange={(value) => {
              const baby = babies.find(b => b.id === Number(value));
              if (baby) {
                setSelectedBaby(baby);
                setFormData(prev => ({ ...prev, babyId: baby.id }));
              }
            }}>
              <TabsList className="grid grid-cols-3 w-full">
                {babies.map(baby => (
                  <TabsTrigger key={baby.id} value={String(baby.id)}>
                    {baby.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          )}
          
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Milestones</h2>
            <Button onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Milestone
            </Button>
          </div>
          
          <div className="mb-6">
            <Select 
              value={selectedCategory || ""} 
              onValueChange={(value) => setSelectedCategory(value || null)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {MILESTONE_CATEGORIES.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <ScrollArea className="h-[calc(100vh-320px)]">
            {isLoading ? (
              <div className="flex justify-center items-center h-40">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredMilestones.length > 0 ? (
              filteredMilestones
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map(milestone => (
                  <MilestoneCard 
                    key={milestone.id}
                    milestone={milestone}
                    onEdit={handleEditClick}
                    onDelete={handleDeleteClick}
                  />
                ))
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  {selectedCategory 
                    ? `No milestones in the "${selectedCategory}" category yet.`
                    : "No milestones recorded yet. Start tracking your baby's special moments!"}
                </p>
              </div>
            )}
          </ScrollArea>
          
          {/* Add Milestone Modal */}
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Milestone</DialogTitle>
                <DialogDescription>
                  Record a new development milestone for your baby
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Milestone Title</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    placeholder="e.g., First Steps, First Word"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {MILESTONE_CATEGORIES.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "PPP") : "Select a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={handleDateChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Add more details about this milestone..."
                    rows={3}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="mediaUrl">Photo/Video URL</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="mediaUrl"
                      name="mediaUrl"
                      value={formData.mediaUrl}
                      onChange={handleInputChange}
                      placeholder="Enter URL for photo or video"
                      className="flex-1"
                    />
                    <Button variant="outline" size="icon" type="button">
                      <ImagePlus className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Enter a URL to an image or video to capture this moment
                  </p>
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleAddMilestone}
                  disabled={createMutation.isPending || !formData.title}
                >
                  {createMutation.isPending && (
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                  )}
                  Save Milestone
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Edit Milestone Modal */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Milestone</DialogTitle>
                <DialogDescription>
                  Update the milestone details
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-title">Milestone Title</Label>
                  <Input
                    id="edit-title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    placeholder="e.g., First Steps, First Word"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger id="edit-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {MILESTONE_CATEGORIES.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-date">Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "PPP") : "Select a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={handleDateChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-description">Description</Label>
                  <Textarea
                    id="edit-description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Add more details about this milestone..."
                    rows={3}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-mediaUrl">Photo/Video URL</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="edit-mediaUrl"
                      name="mediaUrl"
                      value={formData.mediaUrl}
                      onChange={handleInputChange}
                      placeholder="Enter URL for photo or video"
                      className="flex-1"
                    />
                    <Button variant="outline" size="icon" type="button">
                      <ImagePlus className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Enter a URL to an image or video to capture this moment
                  </p>
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleUpdateMilestone}
                  disabled={updateMutation.isPending || !formData.title}
                >
                  {updateMutation.isPending && (
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                  )}
                  Update Milestone
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No babies added yet. Add a baby in the Home page first.</p>
        </div>
      )}
      
      <BottomNavigation currentTab="reports" />
    </div>
  );
}