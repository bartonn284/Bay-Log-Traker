import { JoinBabyForm } from "@/components/join-baby-form";
import { Layout } from "@/components/layout";

export default function JoinBabyPage() {
  return (
    <Layout title="Join Baby" currentTab="home">
      <div className="container max-w-md mx-auto py-6">
        <JoinBabyForm />
      </div>
    </Layout>
  );
}