import { useState, useEffect, lazy, Suspense } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, isToday, differenceInMinutes, formatDistanceToNow } from "date-fns";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { ActivityCard } from "@/components/activity-card";
import { LogModal } from "@/components/log-modal";
import { FeedingForm } from "@/components/feeding-form";
import { SleepForm } from "@/components/sleep-form";
import { DiaperForm } from "@/components/diaper-form";
import { BabySelector } from "@/components/baby-selector";
import { ReminderDashboard } from "@/components/dashboard/reminder-dashboard";
import { ReminderBadge } from "@/components/reminders/reminder-badge";
import { CustomReminderList } from "@/components/reminders/custom-reminder-list";
import { useAuth } from "@/hooks/use-auth";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Baby, Feeding, Sleep, Diaper, SupplyItem } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Activity,
  Calendar, 
  UserPlus, 
  Baby as BabyIcon,
  Clock,
  Plus,
  ArrowRight,
  AlertTriangle,
  Moon,
  Utensils,
  Scroll,
  Droplets,
  AlarmClock,
  Mic,
  Users,
  Milk,
  UserCircle,
  Scale,
  Ruler,
  Share2,
  QrCode
} from "lucide-react";

// Lazy load the voice input button to prevent issues with browser APIs
const VoiceInputButton = lazy(() => import('@/components/voice-input-button').then(
  module => ({ default: module.VoiceInputButton })
));
import { BabySpinner } from "@/components/baby-spinner";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function HomePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showLogModal, setShowLogModal] = useState<boolean>(false);
  const [selectedActivity, setSelectedActivity] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(
    format(new Date(), "yyyy-MM-dd")
  );
  const [selectedBaby, setSelectedBaby] = useState<number | null>(null);
  const [showAddBabyForm, setShowAddBabyForm] = useState<boolean>(false);
  const [newBabyName, setNewBabyName] = useState<string>("");
  const [newBabyGender, setNewBabyGender] = useState<string>("other");
  const [newBabyWeight, setNewBabyWeight] = useState<string>("");
  const [newBabyWidth, setNewBabyWidth] = useState<string>("");
  const [newBabyBirthDate, setNewBabyBirthDate] = useState<string>("");
  const [showShareDialog, setShowShareDialog] = useState<boolean>(false);
  const [shareCode, setShareCode] = useState<string>("");
  const [shareCodeExpiry, setShareCodeExpiry] = useState<string>("");

  // Fetch babies
  const {
    data: babies,
    isLoading: isLoadingBabies,
    error: babiesError,
  } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
  });

  // Create baby mutation
  const createBabyMutation = useMutation({
    mutationFn: async (babyData: { name: string; gender: string; weight: string; width: string; dateOfBirth: string }) => {
      const res = await apiRequest("POST", "/api/babies", babyData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies"] });
      setShowAddBabyForm(false);
      setNewBabyName("");
      setNewBabyGender("other");
      setNewBabyWeight("");
      setNewBabyWidth("");
      setNewBabyBirthDate("");
    },
  });

  // Generate share code mutation
  const generateShareCodeMutation = useMutation({
    mutationFn: async (babyId: number) => {
      const res = await apiRequest("POST", `/api/babies/${babyId}/share-code`, {});
      return await res.json();
    },
    onSuccess: (data) => {
      setShareCode(data.shareCode);
      setShareCodeExpiry(data.shareCodeExpiry);
    },
  });

  // Set first baby as selected if none selected
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0].id);
    }

    // For debugging
    console.log("Babies:", babies);
    console.log("Show Add Baby Form:", showAddBabyForm);
  }, [babies, selectedBaby, showAddBabyForm]);

  // Fetch daily activities for selected baby
  const {
    data: activities,
    isLoading: isLoadingActivities,
    error: activitiesError,
  } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "daily", selectedDate],
    queryFn: async () => {
      if (!selectedBaby) return null;
      const res = await fetch(`/api/babies/${selectedBaby}/daily?date=${selectedDate}`);
      if (!res.ok) throw new Error("Failed to load activities");
      return res.json();
    },
    enabled: !!selectedBaby,
  });

  // Fetch supplies for the current user
  const { 
    data: supplies,
    isLoading: isLoadingSupplies
  } = useQuery({
    queryKey: ["/api/supplies", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const res = await fetch(`/api/supplies`);
      if (!res.ok) throw new Error("Failed to load supplies");
      return res.json();
    },
    enabled: !!user,
  });

  // Calculate low supply items that need attention
  const lowSupplies = supplies?.filter(supply => supply.status === 'low' || supply.status === 'out');

  const handleLogButtonClick = () => {
    setShowLogModal(true);
  };

  const handleActivitySelect = (activity: string) => {
    setSelectedActivity(activity);
    setShowLogModal(false);
  };

  const handleFormBack = () => {
    setSelectedActivity(null);
  };

  const handleAddBaby = () => {
    if (newBabyName.trim()) {
      createBabyMutation.mutate({
        name: newBabyName,
        gender: newBabyGender,
        weight: newBabyWeight,
        width: newBabyWidth,
        dateOfBirth: newBabyBirthDate
      });
    }
  };

  // Calculate dashboard metrics
  const getDashboardMetrics = () => {
    if (!activities) return null;

    const { feedings, sleeps, diapers } = activities;

    // Get the last feeding
    const lastFeeding = feedings.length > 0 
      ? feedings.sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())[0]
      : null;

    // Get the current/last sleep
    const sortedSleeps = sleeps.sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
    const currentSleep = sortedSleeps.find(sleep => !sleep.endTime);
    const lastSleep = sortedSleeps[0] || null;

    // Get the last diaper
    const lastDiaper = diapers.length > 0
      ? diapers.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())[0]
      : null;

    // Calculate time since last feeding/diaper change
    const timeSinceLastFeeding = lastFeeding 
      ? formatDistanceToNow(new Date(lastFeeding.startTime), { addSuffix: true })
      : null;

    const timeSinceLastDiaper = lastDiaper
      ? formatDistanceToNow(new Date(lastDiaper.time), { addSuffix: true })
      : null;

    // Calculate daily totals
    const todayFeedings = feedings.filter(f => 
      isToday(new Date(f.startTime))).length;

    const todaySleeps = sleeps.filter(s => 
      isToday(new Date(s.startTime))).length;

    const todayDiapers = diapers.filter(d => 
      isToday(new Date(d.time))).length;

    // Calculate total sleep duration for today
    const todaySleepDuration = sleeps
      .filter(s => isToday(new Date(s.startTime)))
      .reduce((total, sleep) => {
        if (sleep.duration) {
          return total + sleep.duration;
        } else if (sleep.endTime) {
          return total + differenceInMinutes(new Date(sleep.endTime), new Date(sleep.startTime));
        }
        return total;
      }, 0);

    const sleepHours = Math.floor(todaySleepDuration / 60);
    const sleepMinutes = todaySleepDuration % 60;

    return {
      lastFeeding,
      timeSinceLastFeeding,
      currentSleep,
      lastSleep,
      lastDiaper,
      timeSinceLastDiaper,
      todayFeedings,
      todaySleeps,
      todayDiapers,
      todaySleepDuration,
      sleepHours,
      sleepMinutes
    };
  };

  const metrics = getDashboardMetrics();

  const renderContent = () => {
    if (selectedActivity === "feeding") {
      return (
        <FeedingForm
          babyId={selectedBaby!}
          onBack={handleFormBack}
          onSuccess={() => {
            queryClient.invalidateQueries({
              queryKey: ["/api/babies", selectedBaby, "daily", selectedDate],
            });
            setSelectedActivity(null);
          }}
        />
      );
    }

    if (selectedActivity === "sleep") {
      return (
        <SleepForm
          babyId={selectedBaby!}
          onBack={handleFormBack}
          onSuccess={() => {
            queryClient.invalidateQueries({
              queryKey: ["/api/babies", selectedBaby, "daily", selectedDate],
            });
            setSelectedActivity(null);
          }}
        />
      );
    }

    if (selectedActivity === "diaper") {
      return (
        <DiaperForm
          babyId={selectedBaby!}
          onBack={handleFormBack}
          onSuccess={() => {
            queryClient.invalidateQueries({
              queryKey: ["/api/babies", selectedBaby, "daily", selectedDate],
            });
            setSelectedActivity(null);
          }}
        />
      );
    }

    return (
      <div id="dashboard" className="px-4 py-2">
        {isLoadingBabies ? (
          <div className="flex justify-center my-8">
            <BabySpinner type="rattle" size="lg" showText />
          </div>
        ) : babies && babies.length > 0 ? (
          <>
            {/* Baby Select Header */}
            <div className="mb-4 space-y-2">
              <div className="glass-effect rounded-xl p-4 flex items-center justify-between border border-border/30 shadow-md">
                <div className="flex items-center">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-r from-[hsl(var(--gradient-start))] to-[hsl(var(--gradient-end))] flex items-center justify-center shadow-md overflow-hidden">
                    {selectedBaby && babies?.find((b) => b.id === selectedBaby)?.photoUrl ? (
                      <img 
                        src={babies.find((b) => b.id === selectedBaby)?.photoUrl || ''} 
                        alt={babies.find((b) => b.id === selectedBaby)?.name || ''} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-primary-foreground font-bold text-lg">
                        {selectedBaby
                          ? babies.find((b) => b.id === selectedBaby)?.name.substring(0, 2).toUpperCase()
                          : ""}
                      </span>
                    )}
                  </div>
                  <div className="ml-4">
                    <span className="font-bold text-foreground block text-lg text-gradient flex items-center">
                      {selectedBaby
                        ? babies.find((b) => b.id === selectedBaby)?.name
                        : "Select a baby"}
                      {selectedBaby && <ReminderBadge babyId={selectedBaby} />}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      Dashboard Overview
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center gap-1.5 rounded-lg border-primary/30 hover:bg-primary/10 hover:text-primary transition-colors"
                    onClick={() => setShowAddBabyForm(true)}
                  >
                    <BabyIcon className="h-3.5 w-3.5" />
                    <span className="text-xs font-medium">Add Baby</span>
                  </Button>
                  
                  <Select
                    value={selectedBaby?.toString()}
                    onValueChange={(value) => setSelectedBaby(parseInt(value))}
                  >
                    <SelectTrigger className="w-[140px] rounded-lg border-border/50 bg-card/50">
                      <SelectValue placeholder="Select Baby" />
                    </SelectTrigger>
                    <SelectContent className="rounded-lg">
                      {babies.map((baby) => (
                        <SelectItem key={baby.id} value={baby.id.toString()}>
                          {baby.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Reminder Dashboard - Consolidated all reminders in one place */}
            {selectedBaby && <ReminderDashboard />}
            
            {/* Note: The standalone ReminderList was removed to prevent duplicate reminder sections */}
            
            {/* Smart AI Baby Tips */}
            
            <Card className="glass-effect border border-border/30 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-500/10 to-indigo-500/10 pb-3">
                <CardTitle className="text-base flex items-center">
                  <div className="mr-2 text-blue-500">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20Z" fill="currentColor"/>
                      <path d="M12 17C12.5523 17 13 16.5523 13 16C13 15.4477 12.5523 15 12 15C11.4477 15 11 15.4477 11 16C11 16.5523 11.4477 17 12 17Z" fill="currentColor"/>
                      <path d="M12 7C10.9 7 10 7.9 10 9H12C12 8.45 12.45 8 13 8C13.55 8 14 8.45 14 9C14 10 12.5 9.75 12.5 12H14.5C14.5 10.75 16 10.5 16 9C16 7.9 15.1 7 14 7H12Z" fill="currentColor"/>
                    </svg>
                  </div>
                  <span className="bg-gradient-to-r from-blue-500 to-indigo-600 bg-clip-text text-transparent font-medium">
                    Smart AI Tips
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-3">
                <div className="py-2">
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-100 dark:border-blue-800/30">
                    <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                      Based on Jack's patterns, we recommend feeding every 3 hours during daytime.
                    </p>
                  </div>
                </div>
                <div className="flex justify-end mt-1">
                  <Button variant="ghost" size="sm" onClick={() => setLocation('/tips')} className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                    See all tips
                    <ArrowRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {isLoadingActivities ? (
              <div className="flex justify-center my-8">
                <div className="flex flex-col items-center">
                  <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary mb-2"></div>
                  <p className="text-sm text-muted-foreground">Loading baby activities...</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Quick Action Buttons */}
                <div className="space-y-2">
                  <div className="flex gap-2 justify-between">
                    <Button 
                      onClick={() => handleActivitySelect("feeding")}
                      className="flex-1 bg-gradient-to-r from-[hsl(var(--feeding))] to-[hsl(var(--feeding))_darkened_by_10%] hover:brightness-110 shadow-md text-white rounded-xl transition-all duration-200"
                    >
                      <Droplets className="h-4 w-4 mr-2" />
                      Feed
                    </Button>
                    <Button 
                      onClick={() => handleActivitySelect("sleep")} 
                      className="flex-1 bg-gradient-to-r from-[hsl(var(--sleep))] to-[hsl(var(--sleep))_darkened_by_10%] hover:brightness-110 shadow-md text-white rounded-xl transition-all duration-200"
                    >
                      <Moon className="h-4 w-4 mr-2" />
                      Sleep
                    </Button>
                    <Button 
                      onClick={() => handleActivitySelect("diaper")} 
                      className="flex-1 bg-gradient-to-r from-[hsl(var(--diaper))] to-[hsl(var(--diaper))_darkened_by_10%] hover:brightness-110 shadow-md text-white rounded-xl transition-all duration-200"
                    >
                      <Scroll className="h-4 w-4 mr-2" />
                      Diaper
                    </Button>
                  </div>

                  <div className="flex gap-2 justify-between">
                    <Button 
                      onClick={() => setLocation("/supplies")} 
                      className="flex-1 bg-gradient-to-r from-[hsl(var(--gradient-start))] to-[hsl(var(--gradient-end))] hover:brightness-110 shadow-md text-white rounded-xl transition-all duration-200"
                    >
                      <Milk className="h-4 w-4 mr-2" />
                      Pumping & Storage
                    </Button>
                  </div>

                  {/* Voice Input Button */}
                  <Suspense fallback={
                    <Button variant="secondary" className="w-full rounded-xl shadow-sm py-6">
                      <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-primary mx-auto"></div>
                    </Button>
                  }>
                    <VoiceInputButton 
                      className="w-full bg-gradient-to-r from-primary/10 to-primary/5 hover:from-primary/15 hover:to-primary/10 border border-primary/20 shadow-sm rounded-xl py-6 transition-all duration-300 hover:shadow-md" 
                      buttonText="Add by Voice"
                    />
                  </Suspense>
                </div>

                {/* Today's Stats Summary */}
                <Card className="glass-effect border border-border/30 overflow-hidden shadow-md">
                  <CardHeader className="bg-gradient-to-r from-[hsl(var(--gradient-start))/15%] to-[hsl(var(--gradient-end))/5%] pb-3">
                    <CardTitle className="text-base flex items-center text-gradient">
                      <Clock className="h-4 w-4 mr-2" />
                      Today's Overview
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="grid grid-cols-3 gap-3 text-center">
                      <div className="space-y-1 px-2 py-3 rounded-lg bg-feeding/5 border border-feeding/20">
                        <div className="text-2xl font-bold text-feeding">{metrics?.todayFeedings || 0}</div>
                        <div className="text-xs text-muted-foreground font-medium">Feedings</div>
                      </div>
                      <div className="space-y-1 px-2 py-3 rounded-lg bg-sleep/5 border border-sleep/20">
                        <div className="text-2xl font-bold text-sleep">
                          {metrics?.sleepHours || 0}h {metrics?.sleepMinutes || 0}m
                        </div>
                        <div className="text-xs text-muted-foreground font-medium">Sleep</div>
                      </div>
                      <div className="space-y-1 px-2 py-3 rounded-lg bg-diaper/5 border border-diaper/20">
                        <div className="text-2xl font-bold text-diaper">{metrics?.todayDiapers || 0}</div>
                        <div className="text-xs text-muted-foreground font-medium">Diapers</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Activities */}
                <Card className="glass-effect border border-border/30 overflow-hidden shadow-md">
                  <CardHeader className="bg-gradient-to-r from-[hsl(var(--gradient-start))/15%] to-[hsl(var(--gradient-end))/5%] pb-3">
                    <CardTitle className="text-base flex items-center text-gradient">
                      <Activity className="h-4 w-4 mr-2" />
                      Recent Activity
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 pt-3">
                    {/* Last Feeding */}
                    <div className="glass-effect rounded-xl p-4 relative overflow-hidden border border-feeding/30 shadow-sm transition-all duration-300 hover:shadow-md">
                      <div className="absolute top-0 bottom-0 left-0 w-1.5 bg-feeding"></div>
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-feeding/10 flex items-center justify-center">
                            <Droplets className="h-4 w-4 text-feeding" />
                          </div>
                          <span className="font-medium">Last Feeding</span>
                        </div>
                        <Badge variant="outline" className="text-xs rounded-lg border-feeding/30 text-feeding bg-feeding/5 font-medium">
                          {metrics?.timeSinceLastFeeding || 'No data'}
                        </Badge>
                      </div>
                      {metrics?.lastFeeding ? (
                        <div className="pl-6 text-sm">
                          <div>
                            <span className="text-muted-foreground">Type: </span>
                            <span className="font-medium capitalize">{metrics.lastFeeding.type}</span>
                          </div>
                          {metrics.lastFeeding.amount && (
                            <div>
                              <span className="text-muted-foreground">Amount: </span>
                              <span className="font-medium">{metrics.lastFeeding.amount}</span>
                            </div>
                          )}
                          <div>
                            <span className="text-muted-foreground">Time: </span>
                            <span className="font-medium">
                              {format(new Date(metrics.lastFeeding.startTime), "h:mm a")}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="pl-6 text-sm text-muted-foreground">
                          No recent feeding data
                        </div>
                      )}
                    </div>

                    {/* Current/Last Sleep */}
                    <div className="border border-border rounded-lg p-3 relative overflow-hidden">
                      <div className="absolute top-0 bottom-0 left-0 w-1 bg-purple-500"></div>
                      <div className="flex justify-between items-start mb-1">
                        <div className="flex items-center">
                          <Moon className="h-4 w-4 mr-2 text-purple-500" />
                          <span className="font-medium">
                            {metrics?.currentSleep ? 'Currently Sleeping' : 'Last Sleep'}
                          </span>
                        </div>
                        {metrics?.currentSleep && (
                          <Badge className="bg-purple-500 text-xs">
                            Active
                          </Badge>
                        )}
                      </div>
                      {(metrics?.currentSleep || metrics?.lastSleep) ? (
                        <div className="pl-6 text-sm">
                          {metrics?.currentSleep ? (
                            <>
                              <div>
                                <span className="text-muted-foreground">Started: </span>
                                <span className="font-medium">
                                  {format(new Date(metrics.currentSleep.startTime), "h:mm a")}
                                </span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Duration so far: </span>
                                <span className="font-medium">
                                  {formatDistanceToNow(new Date(metrics.currentSleep.startTime))}
                                </span>
                              </div>
                            </>
                          ) : metrics.lastSleep && (
                            <>
                              <div>
                                <span className="text-muted-foreground">Time: </span>
                                <span className="font-medium">
                                  {format(new Date(metrics.lastSleep.startTime), "h:mm a")}
                                  {metrics.lastSleep.endTime && 
                                    ` - ${format(new Date(metrics.lastSleep.endTime), "h:mm a")}`}
                                </span>
                              </div>
                              {metrics.lastSleep.duration && (
                                <div>
                                  <span className="text-muted-foreground">Duration: </span>
                                  <span className="font-medium">
                                    {Math.floor(metrics.lastSleep.duration / 60)}h {metrics.lastSleep.duration % 60}m
                                  </span>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      ) : (
                        <div className="pl-6 text-sm text-muted-foreground">
                          No recent sleep data
                        </div>
                      )}
                    </div>

                    {/* Last Diaper */}
                    <div className="border border-border rounded-lg p-3 relative overflow-hidden">
                      <div className="absolute top-0 bottom-0 left-0 w-1 bg-green-500"></div>
                      <div className="flex justify-between items-start mb-1">
                        <div className="flex items-center">
                          <Scroll className="h-4 w-4 mr-2 text-green-500" />
                          <span className="font-medium">Last Diaper Change</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {metrics?.timeSinceLastDiaper || 'No data'}
                        </Badge>
                      </div>
                      {metrics?.lastDiaper ? (
                        <div className="pl-6 text-sm">
                          <div>
                            <span className="text-muted-foreground">Type: </span>
                            <span className="font-medium capitalize">{metrics.lastDiaper.type}</span>
                          </div>
                          {metrics.lastDiaper.consistency && (
                            <div>
                              <span className="text-muted-foreground">Consistency: </span>
                              <span className="font-medium">{metrics.lastDiaper.consistency}</span>
                            </div>
                          )}
                          <div>
                            <span className="text-muted-foreground">Time: </span>
                            <span className="font-medium">
                              {format(new Date(metrics.lastDiaper.time), "h:mm a")}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="pl-6 text-sm text-muted-foreground">
                          No recent diaper data
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Supply Alerts */}
                {(lowSupplies && lowSupplies.length > 0) && (
                  <Card className="border-amber-500/50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2 text-amber-500" />
                        Supply Alerts
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-2">
                      <div className="space-y-2">
                        {lowSupplies.map(supply => (
                          <div key={supply.id} className="flex justify-between items-center">
                            <div className="flex items-center">
                              <span className={`w-2 h-2 rounded-full ${supply.status === 'out' ? 'bg-red-500' : 'bg-amber-500'} mr-2`}></span>
                              <span className="text-sm">{supply.name}</span>
                            </div>
                            <Badge variant={supply.status === 'out' ? 'destructive' : 'outline'} className="text-xs">
                              {supply.status === 'out' ? 'Out of Stock' : 'Low'}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="pt-0">
                      <Button variant="outline" className="w-full text-xs" size="sm" onClick={() => setLocation("/supplies")}>
                        Go to Supplies
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    </CardFooter>
                  </Card>
                )}

                
              </div>
            )}
          </>
        ) : (
          // No babies, show add baby form
          <div className="p-4 flex flex-col items-center justify-center space-y-4">
            {showAddBabyForm ? (
              <div className="w-full p-4 border border-border rounded-lg">
                <h3 className="text-lg font-semibold mb-4">Add Your Baby</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Baby's Name
                    </label>
                    <Input
                      value={newBabyName}
                      onChange={(e) => setNewBabyName(e.target.value)}
                      placeholder="e.g. Lily"
                      className="w-full"
                    />
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      onClick={handleAddBaby}
                      disabled={createBabyMutation.isPending}
                      className="flex-1"
                    >
                      {createBabyMutation.isPending ? (
                        <BabySpinner type="rattle" size="sm" className="mr-2" />
                      ) : null}
                      Add Baby
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setShowAddBabyForm(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <>
                <div className="text-center mb-4">
                  <h3 className="text-lg font-semibold mb-2">
                    Welcome to Baby To-Do List!
                  </h3>
                  <p className="text-muted-foreground">
                    Get started by adding your baby or joining one.
                  </p>
                </div>
                <div className="space-y-2">
                  <Button
                    onClick={() => setShowAddBabyForm(true)}
                    className="w-full"
                  >
                    Add Your Baby
                  </Button>
                  <div className="flex items-center justify-center gap-2 my-2">
                    <div className="h-px bg-border flex-1"></div>
                    <span className="text-sm text-muted-foreground">or</span>
                    <div className="h-px bg-border flex-1"></div>
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-center gap-2"
                    onClick={() => setLocation("/join-baby")}
                  >
                    <UserPlus size={16} />
                    <span>Join a Baby via Share Code</span>
                  </Button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <Layout
      title="Baby To-Do List"
      currentTab="home"
      onLogButtonClick={handleLogButtonClick}
    >
      {renderContent()}
      {showLogModal && (
        <LogModal
          onClose={() => setShowLogModal(false)}
          onSelectActivity={handleActivitySelect}
        />
      )}

      {/* Share Baby Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Share Baby Profile</DialogTitle>
            <DialogDescription>
              Generate a share code to let family members access this baby's data.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {shareCode ? (
              <div className="space-y-4">
                <div className="rounded-lg border p-4 text-center bg-muted/30">
                  <div className="text-xl font-bold tracking-wider mb-2">{shareCode}</div>
                  <div className="text-xs text-muted-foreground">
                    Code expires in 5 minutes
                  </div>
                </div>
                <div className="flex justify-center">
                  <QrCode className="w-32 h-32 text-primary" />
                </div>
                <div className="text-sm text-center">
                  Share this code with family members so they can join and track baby activities.
                </div>
              </div>
            ) : (
              <Button 
                onClick={() => generateShareCodeMutation.mutate(selectedBaby!)}
                disabled={generateShareCodeMutation.isPending}
                className="w-full"
              >
                {generateShareCodeMutation.isPending ? (
                  <BabySpinner type="rattle" size="sm" className="mr-2" />
                ) : (
                  <Share2 className="mr-2 h-4 w-4" />
                )}
                Generate Share Code
              </Button>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowShareDialog(false);
              setShareCode("");
            }}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Baby Dialog */}
      <Dialog open={showAddBabyForm} onOpenChange={setShowAddBabyForm}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Your Baby</DialogTitle>
            <DialogDescription>
              Enter your baby's details to get started tracking activities.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="baby-name" className="text-right font-medium">
                Name
              </label>
              <Input
                id="baby-name"
                value={newBabyName}
                onChange={(e) => setNewBabyName(e.target.value)}
                placeholder="e.g. Lily"
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="baby-gender" className="text-right font-medium flex items-center">
                <UserCircle className="h-4 w-4 mr-1" />
                Gender
              </label>
              <Select
                value={newBabyGender}
                onValueChange={setNewBabyGender}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="baby-birth-date" className="text-right font-medium flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                Birth Date
              </label>
              <Input
                id="baby-birth-date"
                type="date"
                value={newBabyBirthDate}
                onChange={(e) => setNewBabyBirthDate(e.target.value)}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="baby-weight" className="text-right font-medium flex items-center">
                <Scale className="h-4 w-4 mr-1" />
                Weight
              </label>
              <Input
                id="baby-weight"
                value={newBabyWeight}
                onChange={(e) => setNewBabyWeight(e.target.value)}
                placeholder="e.g. 7.5 lbs"
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="baby-width" className="text-right font-medium flex items-center">
                <Ruler className="h-4 w-4 mr-1" />
                Height
              </label>
              <Input
                id="baby-width"
                value={newBabyWidth}
                onChange={(e) => setNewBabyWidth(e.target.value)}
                placeholder="e.g. 21 inches"
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowAddBabyForm(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddBaby}
              disabled={createBabyMutation.isPending}
            >
              {createBabyMutation.isPending ? (
                <BabySpinner type="rattle" size="sm" className="mr-2" />
              ) : null}
              Add Baby
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}