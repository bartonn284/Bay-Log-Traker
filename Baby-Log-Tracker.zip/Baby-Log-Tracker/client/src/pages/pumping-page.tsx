import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BabySpinner } from "@/components/baby-spinner";
import { format, isToday, formatDistanceToNow } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useBabyContext } from "@/hooks/use-baby-context";
import { PumpForm } from "@/components/pump-form";
import { MilkStorageForm } from "@/components/milk-storage-form";
import { CalendarIcon, Milk, Refrigerator, Clock, Plus, Edit, Trash } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function PumpingPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const [tab, setTab] = useState<string>("pump");
  const [showPumpForm, setShowPumpForm] = useState<boolean>(false);
  const [showStorageForm, setShowStorageForm] = useState<boolean>(false);
  const [editPumpSession, setEditPumpSession] = useState<any>(null);
  const [editMilkStorage, setEditMilkStorage] = useState<any>(null);
  
  // Fetch pump sessions
  const { 
    data: pumpSessions,
    isLoading: isLoadingPumpSessions,
  } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "pump-sessions"],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await fetch(`/api/babies/${selectedBaby}/pump-sessions`);
      if (!res.ok) throw new Error("Failed to load pump sessions");
      return res.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Fetch milk storage entries
  const { 
    data: milkStorage,
    isLoading: isLoadingMilkStorage,
  } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "milk-storage"],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await fetch(`/api/babies/${selectedBaby}/milk-storage`);
      if (!res.ok) throw new Error("Failed to load milk storage");
      return res.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Fetch milk storage summary
  const { 
    data: milkSummary,
    isLoading: isLoadingSummary,
  } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "milk-storage", "summary"],
    queryFn: async () => {
      if (!selectedBaby) return null;
      const res = await fetch(`/api/babies/${selectedBaby}/milk-storage/summary`);
      if (!res.ok) throw new Error("Failed to load milk summary");
      return res.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Add milk as used from storage
  const useMilkMutation = useMutation({
    mutationFn: async ({ id, amount }: { id: number, amount: number }) => {
      const res = await apiRequest("PUT", `/api/milk-storage/${id}`, {
        usedAmount: amount
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", selectedBaby, "milk-storage"],
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", selectedBaby, "milk-storage", "summary"],
      });
      toast({
        title: "Milk used",
        description: "Successfully updated milk storage",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete milk storage entry
  const deleteMilkMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/milk-storage/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", selectedBaby, "milk-storage"],
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", selectedBaby, "milk-storage", "summary"],
      });
      toast({
        title: "Deleted",
        description: "Successfully removed milk storage entry",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete pump session
  const deletePumpMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/pump-sessions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", selectedBaby, "pump-sessions"],
      });
      toast({
        title: "Deleted",
        description: "Successfully removed pump session",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle forms
  const handlePumpSuccess = () => {
    setShowPumpForm(false);
    setEditPumpSession(null);
    queryClient.invalidateQueries({
      queryKey: ["/api/babies", selectedBaby, "pump-sessions"],
    });
  };
  
  const handleStorageSuccess = () => {
    setShowStorageForm(false);
    setEditMilkStorage(null);
    queryClient.invalidateQueries({
      queryKey: ["/api/babies", selectedBaby, "milk-storage"],
    });
    queryClient.invalidateQueries({
      queryKey: ["/api/babies", selectedBaby, "milk-storage", "summary"],
    });
  };
  
  const handleEditPumpSession = (session: any) => {
    setEditPumpSession(session);
    setShowPumpForm(true);
  };
  
  const handleEditMilkStorage = (storage: any) => {
    setEditMilkStorage(storage);
    setShowStorageForm(true);
  };
  
  // Render the pump sessions section
  const renderPumpSessions = () => {
    if (isLoadingPumpSessions) {
      return (
        <div className="flex justify-center my-8">
          <BabySpinner type="bottle" size="lg" showText />
        </div>
      );
    }
    
    if (!pumpSessions || pumpSessions.length === 0) {
      return (
        <div className="text-center py-8">
          <p className="text-muted-foreground mb-4">No pump sessions recorded yet</p>
          <Button onClick={() => setShowPumpForm(true)}>Record First Session</Button>
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        {pumpSessions.map((session: any) => (
          <Card key={session.id} className="overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-base flex items-center">
                  <Milk className="h-4 w-4 mr-2 text-blue-500" />
                  {format(new Date(session.startTime), "MMM d, yyyy")}
                  {isToday(new Date(session.startTime)) && (
                    <Badge className="ml-2 bg-green-500">Today</Badge>
                  )}
                </CardTitle>
                <div className="flex gap-1">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleEditPumpSession(session)}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      if (confirm("Are you sure you want to delete this session?")) {
                        deletePumpMutation.mutate(session.id);
                      }
                    }}
                  >
                    <Trash className="h-3 w-3" />
                  </Button>
                </div>
              </div>
              <CardDescription>
                {format(new Date(session.startTime), "h:mm a")}
                {session.endTime && ` - ${format(new Date(session.endTime), "h:mm a")}`}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Total Amount</p>
                  <p className="font-medium">{session.totalAmount} ml</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Duration</p>
                  <p className="font-medium">{session.duration || "-"} min</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Left/Right</p>
                  <p className="font-medium">
                    {session.amountLeftBreast || 0}/{session.amountRightBreast || 0} ml
                  </p>
                </div>
              </div>
              {session.notes && (
                <div className="mt-3 pt-3 border-t">
                  <p className="text-xs text-muted-foreground">Notes</p>
                  <p className="text-sm">{session.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };
  
  // Render the milk storage section
  const renderMilkStorage = () => {
    if (isLoadingMilkStorage) {
      return (
        <div className="flex justify-center my-8">
          <BabySpinner type="bottle" size="lg" showText />
        </div>
      );
    }
    
    if (!milkStorage || milkStorage.length === 0) {
      return (
        <div className="text-center py-8">
          <p className="text-muted-foreground mb-4">No milk storage recorded yet</p>
          <Button onClick={() => setShowStorageForm(true)}>Add First Storage</Button>
        </div>
      );
    }
    
    // Filter active (not finished) items
    const activeMilk = milkStorage.filter((item: any) => !item.isFinished);
    
    return (
      <div className="space-y-4">
        {activeMilk.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-muted-foreground mb-4">No active milk storage</p>
            <Button onClick={() => setShowStorageForm(true)}>Add Storage</Button>
          </div>
        ) : (
          <>
            {activeMilk.map((item: any) => {
              const availableAmount = item.amount - (item.usedAmount || 0);
              const percentUsed = ((item.usedAmount || 0) / item.amount) * 100;
              const isExpired = new Date(item.expiryDate) < new Date();
              const expiryTime = formatDistanceToNow(new Date(item.expiryDate), { 
                addSuffix: true 
              });
              
              return (
                <Card 
                  key={item.id} 
                  className={`overflow-hidden ${isExpired ? 'border-red-300' : ''}`}
                >
                  <CardHeader className={`pb-2 ${
                    item.storageType === 'fridge' 
                      ? 'bg-blue-500/10' 
                      : 'bg-purple-500/10'
                  }`}>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-base flex items-center">
                        {item.storageType === 'fridge' ? (
                          <Refrigerator className="h-4 w-4 mr-2 text-blue-500" />
                        ) : (
                          <Milk className="h-4 w-4 mr-2 text-purple-500" />
                        )}
                        {item.containerId}
                        {isExpired && (
                          <Badge variant="destructive" className="ml-2">Expired</Badge>
                        )}
                      </CardTitle>
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => handleEditMilkStorage(item)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this storage entry?")) {
                              deleteMilkMutation.mutate(item.id);
                            }
                          }}
                        >
                          <Trash className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="flex items-center justify-between">
                      <span>
                        {format(new Date(item.storedDate), "MMM d, yyyy")}
                      </span>
                      <span className={isExpired ? 'text-red-500 font-semibold' : ''}>
                        Expires: {expiryTime}
                      </span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="mb-4">
                      <div className="flex justify-between mb-1 text-sm">
                        <span>Used: {item.usedAmount || 0} ml</span>
                        <span>Available: {availableAmount} ml</span>
                      </div>
                      <Progress value={percentUsed} className="h-2" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <p className="text-xs text-muted-foreground">Total Amount</p>
                        <p className="font-medium">{item.amount} ml</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Storage</p>
                        <p className="font-medium capitalize">{item.storageType}</p>
                      </div>
                    </div>
                    
                    {item.notes && (
                      <div className="mt-3 pt-3 border-t">
                        <p className="text-xs text-muted-foreground">Notes</p>
                        <p className="text-sm">{item.notes}</p>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="bg-muted/30 pt-3 pb-3">
                    <div className="flex w-full justify-between">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">Use Milk</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Use Milk</DialogTitle>
                            <DialogDescription>
                              How much milk would you like to use from this container?
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-3 gap-4">
                              {[25, 50, 75, 100].map((amount) => (
                                <Button 
                                  key={amount}
                                  variant={amount > availableAmount ? "ghost" : "outline"}
                                  disabled={amount > availableAmount}
                                  className={amount > availableAmount ? "opacity-50" : ""}
                                  onClick={() => {
                                    useMilkMutation.mutate({
                                      id: item.id,
                                      amount: (item.usedAmount || 0) + amount
                                    });
                                  }}
                                >
                                  {amount} ml
                                </Button>
                              ))}
                              <Button 
                                variant="default"
                                onClick={() => {
                                  useMilkMutation.mutate({
                                    id: item.id,
                                    amount: item.amount // Use all
                                  });
                                }}
                              >
                                Use All
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          useMilkMutation.mutate({
                            id: item.id,
                            amount: item.amount // Mark as used/discarded
                          });
                        }}
                      >
                        Discard
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              );
            })}
          </>
        )}
        
        {/* Show finished items section */}
        {milkStorage.filter((item: any) => item.isFinished).length > 0 && (
          <details className="mt-6">
            <summary className="text-sm font-medium cursor-pointer">
              Show Finished/Used Milk ({milkStorage.filter((item: any) => item.isFinished).length})
            </summary>
            <div className="mt-2 space-y-2">
              {milkStorage
                .filter((item: any) => item.isFinished)
                .map((item: any) => (
                  <Card key={item.id} className="overflow-hidden opacity-60">
                    <CardHeader className="pb-2 bg-gray-100 dark:bg-gray-800">
                      <CardTitle className="text-base flex items-center">
                        {item.containerId}
                      </CardTitle>
                      <CardDescription>
                        {format(new Date(item.storedDate), "MMM d, yyyy")} - Used/Discarded
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-3 pb-3">
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <p className="text-xs text-muted-foreground">Amount</p>
                          <p className="font-medium">{item.amount} ml</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Storage</p>
                          <p className="font-medium capitalize">{item.storageType}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Used</p>
                          <p className="font-medium">{item.usedAmount || 0} ml</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </details>
        )}
      </div>
    );
  };
  
  // Summary section with metrics
  const renderSummary = () => {
    if (isLoadingSummary || !milkSummary) {
      return (
        <div className="flex justify-center py-4">
          <BabySpinner type="rattle" size="sm" />
        </div>
      );
    }
    
    return (
      <Card className="mb-4">
        <CardHeader>
          <CardTitle className="text-lg">Milk Storage Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Total Milk Available</p>
              <p className="text-2xl font-bold">{milkSummary.totalMilk} ml</p>
              <div className="flex gap-2 mt-1 text-sm">
                <span className="text-blue-500">{milkSummary.totalFridgeMilk} ml fridge</span>
                <span>|</span>
                <span className="text-purple-500">{milkSummary.totalFreezerMilk} ml freezer</span>
              </div>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Containers</p>
              <p className="text-2xl font-bold">
                {milkSummary.fridgeContainers + milkSummary.freezerContainers}
              </p>
              <div className="flex gap-2 mt-1 text-sm">
                <span className="text-blue-500">{milkSummary.fridgeContainers} fridge</span>
                <span>|</span>
                <span className="text-purple-500">{milkSummary.freezerContainers} freezer</span>
              </div>
            </div>
          </div>
          
          {/* Expired/Expiring Alerts */}
          <div className="mt-4 space-y-2">
            {milkSummary.expiredItems > 0 && (
              <Alert variant="destructive">
                <AlertTitle>Expired Milk</AlertTitle>
                <AlertDescription>
                  You have {milkSummary.expiredItems} expired milk container(s) that should be discarded.
                </AlertDescription>
              </Alert>
            )}
            
            {milkSummary.expiringToday > 0 && (
              <Alert>
                <AlertTitle>Expiring Today</AlertTitle>
                <AlertDescription>
                  {milkSummary.expiringToday} container(s) will expire today.
                </AlertDescription>
              </Alert>
            )}
            
            {milkSummary.expiringThisWeek > 0 && (
              <Alert>
                <AlertTitle>Expiring Soon</AlertTitle>
                <AlertDescription>
                  {milkSummary.expiringThisWeek} container(s) will expire within the next week.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };
  
  if (!selectedBaby) {
    return (
      <Layout title="Pumping & Milk Storage" currentTab="pumping">
        <div className="flex justify-center items-center h-[calc(100vh-200px)]">
          <div className="text-center">
            <p className="text-lg font-medium mb-4">Please select a baby first</p>
          </div>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout title="Pumping & Milk Storage" currentTab="pumping">
      <div className="container max-w-md mx-auto px-4 py-4">
        {/* Action Buttons */}
        <div className="flex justify-between gap-2 mb-6">
          <Button 
            onClick={() => {
              setEditPumpSession(null);
              setShowPumpForm(true);
            }}
            className="flex-1 bg-blue-500 hover:bg-blue-600"
          >
            <Plus className="h-4 w-4 mr-2" />
            Pump Session
          </Button>
          <Button 
            onClick={() => {
              setEditMilkStorage(null);
              setShowStorageForm(true);
            }}
            className="flex-1 bg-purple-500 hover:bg-purple-600"
          >
            <Plus className="h-4 w-4 mr-2" />
            Store Milk
          </Button>
        </div>
        
        {/* Summary */}
        {tab === "storage" && renderSummary()}
        
        {/* Tabs */}
        <Tabs defaultValue={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="pump">Pump Sessions</TabsTrigger>
            <TabsTrigger value="storage">Milk Storage</TabsTrigger>
          </TabsList>
          <TabsContent value="pump" className="mt-4">
            {renderPumpSessions()}
          </TabsContent>
          <TabsContent value="storage" className="mt-4">
            {renderMilkStorage()}
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Modal for Pump Form */}
      {showPumpForm && (
        <Dialog open={showPumpForm} onOpenChange={setShowPumpForm}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>
                {editPumpSession ? "Edit Pump Session" : "Record Pump Session"}
              </DialogTitle>
              <DialogDescription>
                Track your pumping sessions to monitor milk production.
              </DialogDescription>
            </DialogHeader>
            <PumpForm
              babyId={selectedBaby}
              pumpSession={editPumpSession}
              onSuccess={handlePumpSuccess}
              onCancel={() => {
                setShowPumpForm(false);
                setEditPumpSession(null);
              }}
            />
          </DialogContent>
        </Dialog>
      )}
      
      {/* Modal for Storage Form */}
      {showStorageForm && (
        <Dialog open={showStorageForm} onOpenChange={setShowStorageForm}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>
                {editMilkStorage ? "Edit Milk Storage" : "Store Milk"}
              </DialogTitle>
              <DialogDescription>
                Keep track of your stored breast milk and expiration dates.
              </DialogDescription>
            </DialogHeader>
            <MilkStorageForm
              babyId={selectedBaby}
              milkStorage={editMilkStorage}
              onSuccess={handleStorageSuccess}
              onCancel={() => {
                setShowStorageForm(false);
                setEditMilkStorage(null);
              }}
            />
          </DialogContent>
        </Dialog>
      )}
    </Layout>
  );
}