import { useState, useEffect } from "react";
import { Layout } from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { SupplyItem } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useLogModal } from "@/hooks/use-log-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  PackagePlus, 
  Pencil, 
  Trash2, 
  Package, 
  ShoppingBasket, 
  AlertTriangle,
  CheckCircle2,
  MinusCircle,
  AlertCircle
} from "lucide-react";

// Form schema
const supplyFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  category: z.string().min(1, "Category is required"),
  status: z.enum(["in-stock", "low", "out"]),
  quantity: z.string().nullable().optional(),
  unit: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
  onShoppingList: z.boolean().default(false),
  alertWhenLow: z.boolean().default(false),
});

type SupplyFormValues = z.infer<typeof supplyFormSchema>;

export default function SuppliesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedSupply, setSelectedSupply] = useState<SupplyItem | null>(null);
  
  // Use the global log modal hook
  const { open: openLogModal } = useLogModal();
  
  const handleLogButtonClick = () => {
    openLogModal();
  };

  // Get all supplies
  const { data: supplies, isLoading: isLoadingSupplies } = useQuery<SupplyItem[]>({
    queryKey: ['/api/supplies'],
    enabled: !!user,
  });

  // Get shopping list
  const { data: shoppingList, isLoading: isLoadingShoppingList } = useQuery<SupplyItem[]>({
    queryKey: ['/api/supplies/shopping-list'],
    enabled: !!user && activeTab === "shopping",
  });

  // Get by status
  const { data: inStockSupplies, isLoading: isLoadingInStock } = useQuery<SupplyItem[]>({
    queryKey: ['/api/supplies', { status: 'in-stock' }],
    queryFn: () => apiRequest('GET', '/api/supplies?status=in-stock').then(r => r.json()),
    enabled: !!user && activeTab === "in-stock",
  });

  const { data: lowSupplies, isLoading: isLoadingLow } = useQuery<SupplyItem[]>({
    queryKey: ['/api/supplies', { status: 'low' }],
    queryFn: () => apiRequest('GET', '/api/supplies?status=low').then(r => r.json()),
    enabled: !!user && activeTab === "low",
  });

  const { data: outOfStockSupplies, isLoading: isLoadingOut } = useQuery<SupplyItem[]>({
    queryKey: ['/api/supplies', { status: 'out' }],
    queryFn: () => apiRequest('GET', '/api/supplies?status=out').then(r => r.json()),
    enabled: !!user && activeTab === "out",
  });

  // Add supply mutation
  const addSupplyMutation = useMutation({
    mutationFn: async (data: SupplyFormValues) => {
      const res = await apiRequest('POST', '/api/supplies', data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Supply added",
        description: "The supply item has been added successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/supplies'] });
      form.reset();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add supply",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update supply mutation
  const updateSupplyMutation = useMutation({
    mutationFn: async (data: SupplyFormValues & { id: number }) => {
      const { id, ...rest } = data;
      const res = await apiRequest('PUT', `/api/supplies/${id}`, rest);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Supply updated",
        description: "The supply item has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/supplies'] });
      editForm.reset();
      setIsEditDialogOpen(false);
      setSelectedSupply(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update supply",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete supply mutation
  const deleteSupplyMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/supplies/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Supply deleted",
        description: "The supply item has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/supplies'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete supply",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Add supply form
  const form = useForm<SupplyFormValues>({
    resolver: zodResolver(supplyFormSchema),
    defaultValues: {
      name: "",
      category: "",
      status: "in-stock",
      quantity: "",
      unit: "",
      notes: "",
      onShoppingList: false,
      alertWhenLow: false,
    },
  });

  // Edit supply form
  const editForm = useForm<SupplyFormValues>({
    resolver: zodResolver(supplyFormSchema),
    defaultValues: {
      name: "",
      category: "",
      status: "in-stock",
      quantity: "",
      unit: "",
      notes: "",
      onShoppingList: false,
      alertWhenLow: false,
    },
  });

  // Update edit form when selectedSupply changes
  useEffect(() => {
    if (selectedSupply) {
      editForm.reset({
        name: selectedSupply.name,
        category: selectedSupply.category,
        status: selectedSupply.status as any,
        quantity: selectedSupply.quantity?.toString() || "",
        unit: selectedSupply.unit || "",
        notes: selectedSupply.notes || "",
        onShoppingList: selectedSupply.onShoppingList,
        alertWhenLow: selectedSupply.alertWhenLow,
      });
    }
  }, [selectedSupply, editForm]);

  function handleAddSubmit(data: SupplyFormValues) {
    // Keep quantity as string for the API - it will be parsed on the server
    addSupplyMutation.mutate(data);
  }

  function handleEditSubmit(data: SupplyFormValues) {
    if (!selectedSupply) return;

    // Keep the data as is, adding only the ID
    updateSupplyMutation.mutate({
      ...data,
      id: selectedSupply.id,
    });
  }

  function handleDelete(id: number) {
    if (window.confirm("Are you sure you want to delete this supply item?")) {
      deleteSupplyMutation.mutate(id);
    }
  }

  function handleEditClick(supply: SupplyItem) {
    setSelectedSupply(supply);
    setIsEditDialogOpen(true);
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'in-stock':
        return <CheckCircle2 className="w-5 h-5 text-green-500 drop-shadow-sm" />;
      case 'low':
        return <AlertCircle className="w-5 h-5 text-amber-500 drop-shadow-sm" />;
      case 'out':
        return <MinusCircle className="w-5 h-5 text-red-500 drop-shadow-sm" />;
      default:
        return null;
    }
  }

  // Determine which supplies to display based on active tab
  const displayedSupplies = () => {
    switch (activeTab) {
      case "in-stock":
        return inStockSupplies || [];
      case "low":
        return lowSupplies || [];
      case "out":
        return outOfStockSupplies || [];
      case "shopping":
        return shoppingList || [];
      case "checklist":
        // Checklist doesn't show existing supplies but rather the template items
        return [];
      default:
        return supplies || [];
    }
  };

  // Check if loading based on active tab
  const isTabLoading = () => {
    switch (activeTab) {
      case "in-stock":
        return isLoadingInStock;
      case "low":
        return isLoadingLow;
      case "out":
        return isLoadingOut;
      case "shopping":
        return isLoadingShoppingList;
      case "checklist":
        return false; // Checklist is never loading as it uses static data
      default:
        return isLoadingSupplies;
    }
  };
  
  // Handle adding a supply from the checklist
  const handleAddFromChecklist = (item: { name: string, category: string }) => {
    const newSupply = {
      name: item.name,
      category: item.category,
      status: "out" as const, // Start as out of stock to remind users to buy
      quantity: "0",
      unit: "unit",
      notes: "",
      onShoppingList: true, // Automatically add to shopping list
      alertWhenLow: false
    };
    
    addSupplyMutation.mutate(newSupply);
  };

  // Categories for selection
  const categories = [
    "Diapers",
    "Wipes",
    "Formula",
    "Food",
    "Clothing",
    "Toys",
    "Medicine",
    "Hygiene",
    "Other"
  ];
  
  // Top needed baby supplies for quick checklist
  const topNeededSupplies = [
    { name: "Diapers", category: "Diapers", icon: "📦" },
    { name: "Baby Wipes", category: "Wipes", icon: "🧻" },
    { name: "Formula", category: "Formula", icon: "🍼" },
    { name: "Baby Shampoo", category: "Hygiene", icon: "🧴" },
    { name: "Diaper Rash Cream", category: "Hygiene", icon: "🧴" },
    { name: "Burp Cloths", category: "Clothing", icon: "👕" },
    { name: "Pacifiers", category: "Other", icon: "🍭" },
    { name: "Baby Bottles", category: "Other", icon: "🍼" },
    { name: "Baby Lotion", category: "Hygiene", icon: "🧴" },
    { name: "Baby Wash", category: "Hygiene", icon: "🧼" }
  ];



  return (
    <Layout 
      title="Supply Tracker" 
      currentTab="supplies"
      onLogButtonClick={handleLogButtonClick}
    >
        <div className="px-4 py-6 md:px-6 md:py-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">Supply Tracker</h1>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <PackagePlus className="w-4 h-4 mr-2" />
                  Add Supply
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Supply</DialogTitle>
                  <DialogDescription>
                    Add a new item to your supply inventory.
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleAddSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Baby wipes" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories.map((category) => (
                                <SelectItem key={category} value={category}>
                                  {category}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="in-stock">In Stock</SelectItem>
                                <SelectItem value="low">Running Low</SelectItem>
                                <SelectItem value="out">Out of Stock</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <FormField
                          control={form.control}
                          name="quantity"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Quantity</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  placeholder="5"
                                  {...field}
                                  value={field.value || ""}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="unit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Unit</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="pack"
                                  {...field}
                                  value={field.value || ""}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Any additional notes"
                              {...field}
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="onShoppingList"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Add to Shopping List</FormLabel>
                              <FormDescription>
                                Include this item on your shopping list
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="alertWhenLow"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Alert When Low</FormLabel>
                              <FormDescription>
                                Get notified when supply is running low
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    <DialogFooter>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsAddDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button type="submit" disabled={addSupplyMutation.isPending}>
                        {addSupplyMutation.isPending ? "Adding..." : "Add Supply"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4 flex flex-wrap justify-start">
              <TabsTrigger value="checklist">Checklist</TabsTrigger>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="in-stock">In Stock</TabsTrigger>
              <TabsTrigger value="low">Running Low</TabsTrigger>
              <TabsTrigger value="out">Out of Stock</TabsTrigger>
              <TabsTrigger value="shopping">Shopping List</TabsTrigger>
              <TabsTrigger value="pumping">Pumping</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="space-y-4">
              {activeTab === "pumping" ? (
                <div className="bg-card p-4 rounded-lg shadow-sm">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold">Pumping & Milk Storage</h3>
                    <Button onClick={() => window.location.href = "/supplies/pumping"} variant="outline">
                      Go to Pumping Page
                    </Button>
                  </div>
                  <p className="text-muted-foreground mb-6">
                    Track your pumping sessions and manage your milk storage. View comprehensive data on your milk supply and set reminders for feeding times.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-md">Pumping Sessions</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          Log and monitor your pumping sessions to track your milk production over time.
                        </p>
                      </CardContent>
                      <CardFooter>
                        <Button onClick={() => window.location.href = "/supplies/pumping"} variant="secondary" className="w-full">
                          View Pumping Sessions
                        </Button>
                      </CardFooter>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-md">Milk Storage</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          Keep track of your stored breast milk, including fridge and freezer storage with expiration alerts.
                        </p>
                      </CardContent>
                      <CardFooter>
                        <Button onClick={() => window.location.href = "/supplies/pumping"} variant="secondary" className="w-full">
                          Manage Milk Storage
                        </Button>
                      </CardFooter>
                    </Card>
                  </div>
                </div>
              ) : activeTab === "checklist" ? (
                <div>
                  <p className="mb-4">These are essential items for your baby. Click to add them to your inventory:</p>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {topNeededSupplies.map((item, index) => (
                      <Card key={index} className="overflow-hidden border hover:shadow-md transition-shadow">
                        <CardHeader className="p-4 pb-2">
                          <div className="flex items-center">
                            <span className="text-2xl mr-2">{item.icon}</span>
                            <div>
                              <CardTitle className="text-base">{item.name}</CardTitle>
                              <CardDescription>{item.category}</CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="p-4 pt-0">
                          <p className="text-sm mb-2">Essential for your baby</p>
                        </CardContent>
                        <CardFooter className="p-4 pt-0 flex justify-end">
                          <Button 
                            size="sm" 
                            onClick={() => handleAddFromChecklist(item)}
                            className="w-full"
                          >
                            <PackagePlus className="h-4 w-4 mr-2" />
                            Add to Inventory
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </div>
              ) : isTabLoading() ? (
                <p>Loading supplies...</p>
              ) : displayedSupplies().length === 0 ? (
                <div className="text-center py-8">
                  <Package className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium">No supplies found</h3>
                  <p className="text-sm text-gray-500 mt-2">
                    {activeTab === "all"
                      ? "Add your first supply item to get started"
                      : activeTab === "shopping"
                      ? "Add items to your shopping list"
                      : `No items with status '${activeTab}'`}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
                  {displayedSupplies().map((supply) => (
                    <Card key={supply.id}>
                      <CardHeader className="pb-2 pt-4">
                        <div className="flex justify-between items-start">
                          <div className="max-w-[70%]">
                            <CardTitle className="flex items-center">
                              <div className="mr-2 flex-shrink-0">{getStatusIcon(supply.status)}</div>
                              <span className="font-bold truncate">{supply.name}</span>
                            </CardTitle>
                            <CardDescription className="text-sm mt-2 font-medium">{supply.category}</CardDescription>
                          </div>
                          <div className="flex space-x-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditClick(supply)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(supply.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm space-y-2">
                          {supply.quantity && supply.unit && (
                            <p className="font-medium">
                              Quantity: <span className="font-normal">{supply.quantity} {supply.unit}</span>
                            </p>
                          )}
                          {supply.notes && <p className="text-muted-foreground">{supply.notes}</p>}
                        </div>
                      </CardContent>
                      <CardFooter className="pt-2 pb-3 flex justify-between text-xs border-t border-border mt-1">
                        <div className="flex items-center space-x-3">
                          {supply.onShoppingList && (
                            <div className="flex items-center" title="On shopping list">
                              <ShoppingBasket className="h-3.5 w-3.5 mr-1.5 text-primary" />
                              <span className="font-medium">Shopping list</span>
                            </div>
                          )}
                          {supply.alertWhenLow && (
                            <div className="flex items-center" title="Alert when low">
                              <AlertTriangle className="h-3.5 w-3.5 mr-1.5 text-amber-500" />
                              <span className="font-medium">Alert</span>
                            </div>
                          )}
                        </div>
                        <div className="text-muted-foreground">
                          {new Date(supply.updatedAt).toLocaleDateString()}
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Edit Supply Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Supply</DialogTitle>
              <DialogDescription>
                Update the details of your supply item.
              </DialogDescription>
            </DialogHeader>
            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-4">
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Baby wipes" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="in-stock">In Stock</SelectItem>
                            <SelectItem value="low">Running Low</SelectItem>
                            <SelectItem value="out">Out of Stock</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <FormField
                      control={editForm.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Quantity</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="5"
                              {...field}
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editForm.control}
                      name="unit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Unit</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="pack"
                              {...field}
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                <FormField
                  control={editForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Any additional notes"
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="onShoppingList"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                        <div className="space-y-0.5">
                          <FormLabel>Add to Shopping List</FormLabel>
                          <FormDescription>
                            Include this item on your shopping list
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editForm.control}
                    name="alertWhenLow"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                        <div className="space-y-0.5">
                          <FormLabel>Alert When Low</FormLabel>
                          <FormDescription>
                            Get notified when supply is running low
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsEditDialogOpen(false);
                      setSelectedSupply(null);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={updateSupplyMutation.isPending}>
                    {updateSupplyMutation.isPending ? "Updating..." : "Update Supply"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </Layout>
  );
}