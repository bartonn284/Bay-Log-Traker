import React, { useState } from "react";
import { Layout } from "@/components/layout";
import { LoaderShowcase } from "@/components/loader-showcase";
import { BabySpinner } from "@/components/baby-spinner";
import { Button } from "@/components/ui/button";

export default function LoadersPage() {
  const [isLoading, setIsLoading] = useState(false);
  
  const simulateLoading = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 3000);
  };
  
  return (
    <Layout title="Baby Loading Spinners" currentTab="spinners">
      <div className="p-4 space-y-6">
        <div className="bg-white dark:bg-gray-950 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm p-6 mb-6">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            Animated Baby-Themed Loading Spinners
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Cute, playful loading indicators for a delightful user experience.
          </p>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h2 className="text-lg font-medium mb-3">Interactive Demo</h2>
              <div className="bg-gray-50 dark:bg-gray-900 p-8 rounded-lg flex flex-col items-center justify-center border border-gray-100 dark:border-gray-800">
                {isLoading ? (
                  <div className="min-h-[200px] flex items-center justify-center">
                    <BabySpinner type="bottle" size="xl" />
                  </div>
                ) : (
                  <div className="min-h-[200px] flex flex-col items-center justify-center">
                    <p className="text-gray-500 dark:text-gray-400 mb-4 text-center">
                      Click the button below to see the loading spinner in action!
                    </p>
                    <Button 
                      onClick={simulateLoading}
                      className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white"
                    >
                      Simulate Loading (3 seconds)
                    </Button>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <h2 className="text-lg font-medium mb-3">Use Cases</h2>
              <div className="bg-gray-50 dark:bg-gray-900 p-6 rounded-lg border border-gray-100 dark:border-gray-800">
                <ul className="space-y-3 text-gray-600 dark:text-gray-400">
                  <li className="flex items-start">
                    <span className="text-indigo-500 mr-2">•</span>
                    <span>Loading states for feeding data with the bottle spinner</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-indigo-500 mr-2">•</span>
                    <span>Diaper tracking loading states with the diaper spinner</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-indigo-500 mr-2">•</span>
                    <span>Sleep tracking with the cradle spinner</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-indigo-500 mr-2">•</span>
                    <span>General app loading with the rattle spinner</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-indigo-500 mr-2">•</span>
                    <span>Form submissions and API requests</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        
        <LoaderShowcase />
      </div>
    </Layout>
  );
}