import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarIcon, PlusCircle, Syringe, Stethoscope, Check, Clock, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { formatDistanceToNow, format, isAfter, isBefore, isToday } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Appointment, Vaccine, Baby } from "../../shared/schema";
import { useBabyContext } from "@/hooks/use-baby-context";
import { ScrollArea } from "@/components/ui/scroll-area";
import AppointmentForm from "@/components/appointment-form";
import VaccineForm from "@/components/vaccine-form";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useLocation } from "wouter";
import { BabySelector } from "@/components/baby-selector";
import { Separator } from "@/components/ui/separator";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function AppointmentsPage() {
  const { toast } = useToast();
  const { selectedBaby, setSelectedBaby } = useBabyContext();
  const [location, setLocation] = useLocation();
  
  // Query for all babies
  const { data: babies } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
  });
  const [activeTab, setActiveTab] = useState("appointments");
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);
  const [showVaccineForm, setShowVaccineForm] = useState(false);
  const [appointmentToEdit, setAppointmentToEdit] = useState<Appointment | null>(null);
  const [vaccineToEdit, setVaccineToEdit] = useState<Vaccine | null>(null);

  // Redirect to home if no baby is selected
  useEffect(() => {
    if (!selectedBaby) {
      setLocation("/");
    }
  }, [selectedBaby, setLocation]);

  // Queries
  const {
    data: appointments = [],
    isLoading: isLoadingAppointments,
    refetch: refetchAppointments,
  } = useQuery({
    queryKey: ["/api/babies", selectedBaby?.id, "appointments"],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await fetch(`/api/babies/${selectedBaby.id}/appointments`);
      if (!res.ok) throw new Error("Failed to fetch appointments");
      return res.json();
    },
    enabled: !!selectedBaby,
  });

  const {
    data: vaccines = [],
    isLoading: isLoadingVaccines,
    refetch: refetchVaccines,
  } = useQuery({
    queryKey: ["/api/babies", selectedBaby?.id, "vaccines"],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await fetch(`/api/babies/${selectedBaby.id}/vaccines`);
      if (!res.ok) throw new Error("Failed to fetch vaccines");
      return res.json();
    },
    enabled: !!selectedBaby,
  });

  // Mutations
  const deleteAppointmentMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/appointments/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error("Failed to delete appointment");
      }
    },
    onSuccess: () => {
      toast({
        title: "Appointment deleted",
        description: "The appointment has been deleted successfully.",
      });
      refetchAppointments();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete appointment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteVaccineMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/vaccines/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error("Failed to delete vaccine");
      }
    },
    onSuccess: () => {
      toast({
        title: "Vaccine deleted",
        description: "The vaccine has been deleted successfully.",
      });
      refetchVaccines();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete vaccine",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateAppointmentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: { completed: boolean } }) => {
      const response = await fetch(`/api/appointments/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error("Failed to update appointment");
      }
      return response.json();
    },
    onSuccess: () => {
      refetchAppointments();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update appointment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateVaccineMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: { completed: boolean; administeredDate?: Date } }) => {
      const response = await fetch(`/api/vaccines/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error("Failed to update vaccine");
      }
      return response.json();
    },
    onSuccess: () => {
      refetchVaccines();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update vaccine",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handlers
  const handleAddAppointment = () => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    setAppointmentToEdit(null);
    setShowAppointmentForm(true);
  };

  const handleEditAppointment = (appointment: Appointment) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    setAppointmentToEdit(appointment);
    setShowAppointmentForm(true);
  };

  const handleAddVaccine = () => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    setVaccineToEdit(null);
    setShowVaccineForm(true);
  };

  const handleEditVaccine = (vaccine: Vaccine) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    setVaccineToEdit(vaccine);
    setShowVaccineForm(true);
  };

  const handleCompleteAppointment = (appointment: Appointment) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    updateAppointmentMutation.mutate({
      id: appointment.id,
      data: { completed: true },
    });
  };

  const handleUncompleteAppointment = (appointment: Appointment) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    updateAppointmentMutation.mutate({
      id: appointment.id,
      data: { completed: false },
    });
  };

  const handleCompleteVaccine = (vaccine: Vaccine) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    updateVaccineMutation.mutate({
      id: vaccine.id,
      data: { completed: true, administeredDate: new Date() },
    });
  };

  const handleUncompleteVaccine = (vaccine: Vaccine) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    updateVaccineMutation.mutate({
      id: vaccine.id,
      data: { completed: false, administeredDate: null },
    });
  };

  const deleteAppointment = (id: number) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    
    if (window.confirm("Are you sure you want to delete this appointment?")) {
      deleteAppointmentMutation.mutate(id);
    }
  };

  const deleteVaccine = (id: number) => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    
    if (window.confirm("Are you sure you want to delete this vaccine?")) {
      deleteVaccineMutation.mutate(id);
    }
  };

  // Filter and sort appointments
  const upcomingAppointments = appointments
    .filter((apt: Appointment) => !apt.completed && isAfter(new Date(apt.date), new Date()))
    .sort((a: Appointment, b: Appointment) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  const pastAppointments = appointments
    .filter((apt: Appointment) => apt.completed || isBefore(new Date(apt.date), new Date()))
    .sort((a: Appointment, b: Appointment) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Filter and sort vaccines
  const upcomingVaccines = vaccines
    .filter((vac: Vaccine) => !vac.completed)
    .sort((a: Vaccine, b: Vaccine) => {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });
  
  const completedVaccines = vaccines
    .filter((vac: Vaccine) => vac.completed)
    .sort((a: Vaccine, b: Vaccine) => {
      if (!a.administeredDate) return 1;
      if (!b.administeredDate) return -1;
      return new Date(b.administeredDate).getTime() - new Date(a.administeredDate).getTime();
    });

  if (!selectedBaby) {
    return null;
  }

  return (
    <div className="container max-w-md mx-auto pb-16">
      <div className="py-4">
        <BabySelector 
          selectedBaby={selectedBaby?.id || null}
          onSelectBaby={(babyId) => {
            const baby = babies?.find(b => b.id === babyId);
            if (baby) {
              setSelectedBaby(baby);
            }
          }}
          showDetails
        />
      </div>
      
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Health Schedule</h1>
        
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="appointments" className="flex items-center gap-2">
              <Stethoscope className="h-4 w-4" />
              <span>Appointments</span>
            </TabsTrigger>
            <TabsTrigger value="vaccines" className="flex items-center gap-2">
              <Syringe className="h-4 w-4" />
              <span>Vaccines</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Appointments Tab */}
          <TabsContent value="appointments" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Appointments</h2>
              <Button onClick={handleAddAppointment} size="sm" className="flex items-center gap-1">
                <PlusCircle className="h-4 w-4" />
                <span>Add</span>
              </Button>
            </div>
            
            {isLoadingAppointments ? (
              <div className="space-y-3">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
            ) : (
              <div className="space-y-4">
                {upcomingAppointments.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Upcoming</h3>
                    <ScrollArea className="h-[50vh]">
                      {upcomingAppointments.map((appointment: Appointment) => (
                        <AppointmentCard
                          key={appointment.id}
                          appointment={appointment}
                          onEdit={() => handleEditAppointment(appointment)}
                          onDelete={() => deleteAppointment(appointment.id)}
                          onComplete={() => handleCompleteAppointment(appointment)}
                          onUncomplete={() => handleUncompleteAppointment(appointment)}
                        />
                      ))}
                    </ScrollArea>
                  </div>
                )}
                
                {upcomingAppointments.length === 0 && (
                  <div className="text-center p-6 bg-muted/50 rounded-lg">
                    <Stethoscope className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">No upcoming appointments scheduled</p>
                    <Button onClick={handleAddAppointment} variant="link" className="mt-2">
                      Schedule an appointment
                    </Button>
                  </div>
                )}
                
                {pastAppointments.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Past</h3>
                    <ScrollArea className="h-[30vh]">
                      {pastAppointments.map((appointment: Appointment) => (
                        <AppointmentCard
                          key={appointment.id}
                          appointment={appointment}
                          onEdit={() => handleEditAppointment(appointment)}
                          onDelete={() => deleteAppointment(appointment.id)}
                          onComplete={() => handleCompleteAppointment(appointment)}
                          onUncomplete={() => handleUncompleteAppointment(appointment)}
                        />
                      ))}
                    </ScrollArea>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
          
          {/* Vaccines Tab */}
          <TabsContent value="vaccines" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Vaccines</h2>
              <Button onClick={handleAddVaccine} size="sm" className="flex items-center gap-1">
                <PlusCircle className="h-4 w-4" />
                <span>Add</span>
              </Button>
            </div>
            
            {isLoadingVaccines ? (
              <div className="space-y-3">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
            ) : (
              <div className="space-y-4">
                {upcomingVaccines.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Upcoming</h3>
                    <ScrollArea className="h-[50vh]">
                      {upcomingVaccines.map((vaccine: Vaccine) => (
                        <VaccineCard
                          key={vaccine.id}
                          vaccine={vaccine}
                          onEdit={() => handleEditVaccine(vaccine)}
                          onDelete={() => deleteVaccine(vaccine.id)}
                          onComplete={() => handleCompleteVaccine(vaccine)}
                          onUncomplete={() => handleUncompleteVaccine(vaccine)}
                        />
                      ))}
                    </ScrollArea>
                  </div>
                )}
                
                {upcomingVaccines.length === 0 && (
                  <div className="text-center p-6 bg-muted/50 rounded-lg">
                    <Syringe className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">No upcoming vaccines scheduled</p>
                    <Button onClick={handleAddVaccine} variant="link" className="mt-2">
                      Add a vaccine
                    </Button>
                  </div>
                )}
                
                {completedVaccines.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Completed</h3>
                    <ScrollArea className="h-[30vh]">
                      {completedVaccines.map((vaccine: Vaccine) => (
                        <VaccineCard
                          key={vaccine.id}
                          vaccine={vaccine}
                          onEdit={() => handleEditVaccine(vaccine)}
                          onDelete={() => deleteVaccine(vaccine.id)}
                          onComplete={() => handleCompleteVaccine(vaccine)}
                          onUncomplete={() => handleUncompleteVaccine(vaccine)}
                        />
                      ))}
                    </ScrollArea>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Appointment Form Dialog */}
      <Dialog open={showAppointmentForm} onOpenChange={setShowAppointmentForm}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogTitle>
            {appointmentToEdit ? "Edit Appointment" : "Add New Appointment"}
          </DialogTitle>
          <AppointmentForm
            appointment={appointmentToEdit}
            babyId={selectedBaby.id}
            onSuccess={() => {
              setShowAppointmentForm(false);
              refetchAppointments();
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Vaccine Form Dialog */}
      <Dialog open={showVaccineForm} onOpenChange={setShowVaccineForm}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogTitle>
            {vaccineToEdit ? "Edit Vaccine" : "Add New Vaccine"}
          </DialogTitle>
          <VaccineForm
            vaccine={vaccineToEdit}
            babyId={selectedBaby.id}
            onSuccess={() => {
              setShowVaccineForm(false);
              refetchVaccines();
            }}
          />
        </DialogContent>
      </Dialog>

      <BottomNavigation currentTab="health" />
    </div>
  );
}

// AppointmentCard component
function AppointmentCard({
  appointment,
  onEdit,
  onDelete,
  onComplete,
  onUncomplete,
}: {
  appointment: Appointment;
  onEdit: () => void;
  onDelete: () => void;
  onComplete: () => void;
  onUncomplete: () => void;
}) {
  const appointmentDate = new Date(appointment.date);
  const isPast = isBefore(appointmentDate, new Date()) && !isToday(appointmentDate);
  const isTodays = isToday(appointmentDate);

  return (
    <Card className={`mb-3 ${appointment.completed ? "bg-muted/30" : ""}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              {appointment.title}
              {appointment.completed && <Check className="h-4 w-4 text-green-500" />}
            </CardTitle>
            <CardDescription className="flex items-center gap-1 mt-1">
              <CalendarIcon className="h-3 w-3" />
              {format(appointmentDate, "MMM d, yyyy")}
              {appointment.time && ` at ${appointment.time}`}
            </CardDescription>
          </div>
          <div>
            {isPast && !appointment.completed && (
              <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
                Missed
              </Badge>
            )}
            {isTodays && !appointment.completed && (
              <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                Today
              </Badge>
            )}
            {!isPast && !isTodays && !appointment.completed && (
              <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                {formatDistanceToNow(appointmentDate, { addSuffix: true })}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-3">
        <div className="text-sm text-muted-foreground mb-2">
          {appointment.appointmentType && (
            <div className="mb-1">
              <span className="font-semibold">Type:</span> {appointment.appointmentType}
            </div>
          )}
          {appointment.doctorName && (
            <div className="mb-1">
              <span className="font-semibold">Doctor:</span> {appointment.doctorName}
            </div>
          )}
          {appointment.location && (
            <div className="mb-1">
              <span className="font-semibold">Location:</span> {appointment.location}
            </div>
          )}
          {appointment.notes && (
            <div className="mb-1">
              <span className="font-semibold">Notes:</span> {appointment.notes}
            </div>
          )}
        </div>
        <div className="flex gap-2 justify-end">
          {appointment.completed ? (
            <Button onClick={onUncomplete} size="sm" variant="outline">
              Mark as Incomplete
            </Button>
          ) : (
            <Button onClick={onComplete} size="sm" variant="outline">
              Mark as Complete
            </Button>
          )}
          <Button onClick={onEdit} size="sm" variant="outline">
            Edit
          </Button>
          <Button onClick={onDelete} size="sm" variant="destructive">
            Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// VaccineCard component
function VaccineCard({
  vaccine,
  onEdit,
  onDelete,
  onComplete,
  onUncomplete,
}: {
  vaccine: Vaccine;
  onEdit: () => void;
  onDelete: () => void;
  onComplete: () => void;
  onUncomplete: () => void;
}) {
  const now = new Date();
  const dueDate = vaccine.dueDate ? new Date(vaccine.dueDate) : null;
  const isPastDue = dueDate && isBefore(dueDate, now) && !isToday(dueDate) && !vaccine.completed;
  const isDueToday = dueDate && isToday(dueDate) && !vaccine.completed;

  return (
    <Card className={`mb-3 ${vaccine.completed ? "bg-muted/30" : ""}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              {vaccine.name}
              {vaccine.completed && <Check className="h-4 w-4 text-green-500" />}
            </CardTitle>
            {dueDate && (
              <CardDescription className="flex items-center gap-1 mt-1">
                <CalendarIcon className="h-3 w-3" />
                {vaccine.completed && vaccine.administeredDate
                  ? `Administered on ${format(new Date(vaccine.administeredDate), "MMM d, yyyy")}`
                  : `Due on ${format(dueDate, "MMM d, yyyy")}`}
              </CardDescription>
            )}
          </div>
          <div>
            {isPastDue && (
              <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
                Overdue
              </Badge>
            )}
            {isDueToday && (
              <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                Due Today
              </Badge>
            )}
            {dueDate && !isPastDue && !isDueToday && !vaccine.completed && (
              <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                Due {formatDistanceToNow(dueDate, { addSuffix: true })}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-3">
        <div className="text-sm text-muted-foreground mb-2">
          {vaccine.location && (
            <div className="mb-1">
              <span className="font-semibold">Location:</span> {vaccine.location}
            </div>
          )}
          {vaccine.lotNumber && (
            <div className="mb-1">
              <span className="font-semibold">Lot Number:</span> {vaccine.lotNumber}
            </div>
          )}
          {vaccine.notes && (
            <div className="mb-1">
              <span className="font-semibold">Notes:</span> {vaccine.notes}
            </div>
          )}
        </div>
        <div className="flex gap-2 justify-end">
          {vaccine.completed ? (
            <Button onClick={onUncomplete} size="sm" variant="outline">
              Mark as Incomplete
            </Button>
          ) : (
            <Button onClick={onComplete} size="sm" variant="outline">
              Mark as Complete
            </Button>
          )}
          <Button onClick={onEdit} size="sm" variant="outline">
            Edit
          </Button>
          <Button onClick={onDelete} size="sm" variant="destructive">
            Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}