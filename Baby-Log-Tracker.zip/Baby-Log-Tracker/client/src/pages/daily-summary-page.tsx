import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, parseISO, isToday } from "date-fns";
import { Link } from "wouter";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Baby } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Baby as BabyIcon, BarChart4, ChevronLeft } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

type DailySummary = {
  date: string;
  feedings: any[];
  sleeps: any[];
  diapers: any[];
  healthRecords: any[];
};

// Helper function to format time
const formatTime = (dateStr: string) => {
  return format(parseISO(dateStr), "h:mm a");
};

// Helper function to calculate duration in hours and minutes
const calculateDuration = (start: string, end: string) => {
  const startTime = parseISO(start);
  const endTime = parseISO(end);
  const diffMs = endTime.getTime() - startTime.getTime();
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}m`;
};

export default function DailySummaryPage() {
  const [selectedBaby, setSelectedBaby] = useState<Baby | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  
  // Fetch babies
  const { data: babies } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Fetch daily summary
  const { data: dailySummary, isLoading } = useQuery<DailySummary>({
    queryKey: ["/api/babies", selectedBaby?.id, "daily", format(selectedDate, "yyyy-MM-dd")],
    queryFn: async () => {
      if (!selectedBaby) throw new Error("No baby selected");
      const response = await fetch(`/api/babies/${selectedBaby.id}/daily?date=${format(selectedDate, "yyyy-MM-dd")}`);
      if (!response.ok) {
        throw new Error("Failed to fetch daily summary");
      }
      return response.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Set the first baby as selected when babies are loaded
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0]);
    }
  }, [babies, selectedBaby]);
  
  // Calculate statistics
  const calculateStats = () => {
    if (!dailySummary) return null;
    
    const feedingsCount = dailySummary.feedings.length;
    let totalFeedingAmount = 0;
    dailySummary.feedings.forEach(feeding => {
      if (feeding.type === "bottle" && feeding.amount) {
        totalFeedingAmount += parseFloat(feeding.amount);
      }
    });
    
    const sleepsCount = dailySummary.sleeps.length;
    let totalSleepMinutes = 0;
    dailySummary.sleeps.forEach(sleep => {
      if (sleep.endTime) {
        const start = parseISO(sleep.startTime);
        const end = parseISO(sleep.endTime);
        totalSleepMinutes += (end.getTime() - start.getTime()) / (1000 * 60);
      }
    });
    
    const diapersCount = dailySummary.diapers.length;
    const wetCount = dailySummary.diapers.filter(diaper => diaper.type === "wet" || diaper.type === "both").length;
    const dirtyCount = dailySummary.diapers.filter(diaper => diaper.type === "dirty" || diaper.type === "both").length;
    
    const healthCount = dailySummary.healthRecords.length;
    
    return {
      feedingsCount,
      totalFeedingAmount: totalFeedingAmount.toFixed(1),
      sleepsCount,
      totalSleepHours: (totalSleepMinutes / 60).toFixed(1),
      diapersCount,
      wetCount,
      dirtyCount,
      healthCount
    };
  };
  
  const stats = calculateStats();
  
  return (
    <div className="container max-w-md mx-auto pb-20">
      <header className="py-6">
        <div className="flex items-center mb-2">
          <Button variant="ghost" size="sm" className="mr-2" asChild>
            <Link to="/reports">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Link>
          </Button>
        </div>
        <h1 className="text-2xl font-bold">Daily Summary</h1>
        <p className="text-muted-foreground">Review your baby's day at a glance</p>
      </header>
      
      {babies && babies.length > 0 ? (
        <>
          {babies.length > 1 && (
            <Tabs defaultValue={String(selectedBaby?.id)} className="mb-6" onValueChange={(value) => {
              const baby = babies.find(b => b.id === Number(value));
              if (baby) {
                setSelectedBaby(baby);
              }
            }}>
              <TabsList className="grid grid-cols-3 w-full">
                {babies.map(baby => (
                  <TabsTrigger key={baby.id} value={String(baby.id)}>
                    {baby.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          )}
          
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">
              {isToday(selectedDate) ? "Today's Summary" : `Summary: ${format(selectedDate, "MMM d, yyyy")}`}
            </h2>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-auto">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {format(selectedDate, "PP")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : dailySummary ? (
            <>
              {stats && (
                <Card className="mb-6 bg-gradient-to-br from-primary/5 to-primary/10 border-none shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <BarChart4 className="w-5 h-5 mr-2" />
                      Daily Stats
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Feedings</p>
                        <p className="text-xl font-semibold">{stats.feedingsCount}</p>
                        {stats.totalFeedingAmount && parseFloat(stats.totalFeedingAmount) > 0 && (
                          <p className="text-sm">{stats.totalFeedingAmount} oz total</p>
                        )}
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Sleep</p>
                        <p className="text-xl font-semibold">{stats.sleepsCount} naps</p>
                        <p className="text-sm">{stats.totalSleepHours} hours total</p>
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Diapers</p>
                        <p className="text-xl font-semibold">{stats.diapersCount} changes</p>
                        <p className="text-sm">{stats.wetCount} wet, {stats.dirtyCount} dirty</p>
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Health</p>
                        <p className="text-xl font-semibold">{stats.healthCount} records</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              <ScrollArea className="h-[calc(100vh-320px)]">
                {dailySummary.feedings.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-3">Feedings</h3>
                    {dailySummary.feedings
                      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
                      .map((feeding) => (
                        <Card key={feeding.id} className="mb-3 border-l-4 border-l-blue-400">
                          <CardContent className="p-4">
                            <div className="flex justify-between">
                              <div>
                                <p className="font-medium capitalize">
                                  {feeding.type} {feeding.type === "bottle" && feeding.amount && `(${feeding.amount} oz)`}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {formatTime(feeding.startTime)}
                                  {feeding.endTime && ` - ${formatTime(feeding.endTime)}`}
                                </p>
                              </div>
                              {feeding.startTime && feeding.endTime && (
                                <div className="text-right">
                                  <p className="text-sm font-medium">Duration</p>
                                  <p className="text-sm">{calculateDuration(feeding.startTime, feeding.endTime)}</p>
                                </div>
                              )}
                            </div>
                            {feeding.notes && (
                              <p className="text-sm mt-2 pt-2 border-t">{feeding.notes}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                )}
                
                {dailySummary.sleeps.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-3">Sleep</h3>
                    {dailySummary.sleeps
                      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
                      .map((sleep) => (
                        <Card key={sleep.id} className="mb-3 border-l-4 border-l-purple-400">
                          <CardContent className="p-4">
                            <div className="flex justify-between">
                              <div>
                                <p className="font-medium">Sleep</p>
                                <p className="text-sm text-muted-foreground">
                                  {formatTime(sleep.startTime)}
                                  {sleep.endTime && ` - ${formatTime(sleep.endTime)}`}
                                </p>
                              </div>
                              {sleep.startTime && sleep.endTime && (
                                <div className="text-right">
                                  <p className="text-sm font-medium">Duration</p>
                                  <p className="text-sm">{calculateDuration(sleep.startTime, sleep.endTime)}</p>
                                </div>
                              )}
                            </div>
                            {sleep.notes && (
                              <p className="text-sm mt-2 pt-2 border-t">{sleep.notes}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                )}
                
                {dailySummary.diapers.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-3">Diapers</h3>
                    {dailySummary.diapers
                      .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())
                      .map((diaper) => (
                        <Card key={diaper.id} className="mb-3 border-l-4 border-l-yellow-400">
                          <CardContent className="p-4">
                            <div className="flex justify-between">
                              <div>
                                <p className="font-medium capitalize">{diaper.type} Diaper</p>
                                <p className="text-sm text-muted-foreground">{formatTime(diaper.time)}</p>
                              </div>
                              {diaper.consistency && (
                                <div className="text-right">
                                  <p className="text-sm font-medium">Consistency</p>
                                  <p className="text-sm capitalize">{diaper.consistency}</p>
                                </div>
                              )}
                            </div>
                            {diaper.notes && (
                              <p className="text-sm mt-2 pt-2 border-t">{diaper.notes}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                )}
                
                {dailySummary.healthRecords.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-3">Health</h3>
                    {dailySummary.healthRecords
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((record) => (
                        <Card key={record.id} className="mb-3 border-l-4 border-l-green-400">
                          <CardContent className="p-4">
                            <div>
                              <p className="font-medium">{record.recordType}</p>
                              <p className="text-sm text-muted-foreground">{formatTime(record.date)}</p>
                              
                              {record.recordType === "Temperature" && record.temperature && (
                                <p className="mt-1">Temperature: {record.temperature}</p>
                              )}
                              
                              {record.recordType === "Medication" && record.medicationName && (
                                <div className="mt-1">
                                  <p>{record.medicationName} {record.medicationDose && `(${record.medicationDose})`}</p>
                                  {record.medicationSchedule && (
                                    <p className="text-sm text-muted-foreground">{record.medicationSchedule}</p>
                                  )}
                                </div>
                              )}
                              
                              {record.recordType === "Doctor Visit" && record.doctorNotes && (
                                <p className="mt-1">{record.doctorNotes}</p>
                              )}
                            </div>
                            
                            {record.notes && (
                              <p className="text-sm mt-2 pt-2 border-t">{record.notes}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                )}
                
                {dailySummary.feedings.length === 0 && 
                 dailySummary.sleeps.length === 0 && 
                 dailySummary.diapers.length === 0 &&
                 dailySummary.healthRecords.length === 0 && (
                  <Alert className="mt-6">
                    <BabyIcon className="h-4 w-4" />
                    <AlertTitle>No activities recorded</AlertTitle>
                    <AlertDescription>
                      There are no activities recorded for this day. Use the Log button to add feedings, sleep, diapers, or health records.
                    </AlertDescription>
                  </Alert>
                )}
              </ScrollArea>
            </>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Failed to load daily summary. Please try again.</p>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No babies added yet. Add a baby in the Home page first.</p>
        </div>
      )}
      
      <BottomNavigation currentTab="reports" />
    </div>
  );
}