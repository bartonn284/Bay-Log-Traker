import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, parseISO } from "date-fns";
import { Layout } from "@/components/layout";
import { Baby, JournalEntry } from "@shared/schema";
import { useLogModal } from "@/hooks/use-log-modal";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { BabySelector } from "@/components/baby-selector";
import { BabyDetailsModal } from "@/components/baby-details-modal";
import { FeedingForm } from "@/components/feeding-form";
import { SleepForm } from "@/components/sleep-form";
import { DiaperForm } from "@/components/diaper-form";
import { JournalForm } from "@/components/journal-form";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectGroup,
  SelectLabel,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, BookOpen, BarChart2, Clock } from "lucide-react";

type TimelineItem = {
  id: number;
  type: "feeding" | "sleep" | "diaper" | "mood" | "milestone" | "journal";
  time: string;
  title: string;
  subtitle?: string;
  color: string;
  content?: string;
};

export default function TimelinePage() {
  const [selectedBaby, setSelectedBaby] = useState<number | null>(null);
  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);
  const [activeTab, setActiveTab] = useState<"timeline" | "journal">("timeline");
  const [showJournalForm, setShowJournalForm] = useState<boolean>(false);
  const [showBabyDetailsModal, setShowBabyDetailsModal] = useState<boolean>(false);
  const [babyToEdit, setBabyToEdit] = useState<Baby | null>(null);
  
  // Use the global log modal
  const { open: openLogModal } = useLogModal();
  const { toast } = useToast();
  
  // Fetch babies
  const {
    data: babies,
    isLoading: isLoadingBabies,
  } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
  });
  
  // Set first baby as selected if none selected
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0].id);
    }
  }, [babies, selectedBaby]);
  
  // Fetch feedings
  const { data: feedings, isLoading: isLoadingFeedings } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "feedings"],
    enabled: !!selectedBaby,
  });
  
  // Fetch sleeps
  const { data: sleeps, isLoading: isLoadingSleeps } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "sleeps"],
    enabled: !!selectedBaby,
  });
  
  // Fetch diapers
  const { data: diapers, isLoading: isLoadingDiapers } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "diapers"],
    enabled: !!selectedBaby,
  });
  
  // Fetch moods
  const { data: moods, isLoading: isLoadingMoods } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "moods"],
    enabled: !!selectedBaby,
  });
  
  // Fetch milestones
  const { data: milestones, isLoading: isLoadingMilestones } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "milestones"],
    enabled: !!selectedBaby,
  });
  
  // Fetch journal entries
  const { data: journalEntries, isLoading: isLoadingJournal } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal", selectedBaby],
    enabled: !!selectedBaby,
  });
  
  // Combine and sort timeline items
  useEffect(() => {
    const items: TimelineItem[] = [];
    
    if (feedings && Array.isArray(feedings)) {
      feedings.forEach((feeding: any) => {
        items.push({
          id: feeding.id,
          type: "feeding",
          time: feeding.startTime,
          title: `Feeding: ${feeding.type}`,
          subtitle: feeding.amount ? `${feeding.amount}` : "",
          color: "bg-feeding",
        });
      });
    }
    
    if (sleeps && Array.isArray(sleeps)) {
      sleeps.forEach((sleep: any) => {
        items.push({
          id: sleep.id,
          type: "sleep",
          time: sleep.startTime,
          title: `Sleep: ${sleep.type === "nap" ? "Nap" : "Night Sleep"}`,
          subtitle: sleep.duration ? `${Math.floor(sleep.duration / 60)}h ${sleep.duration % 60}m` : "",
          color: "bg-sleep",
        });
      });
    }
    
    if (diapers && Array.isArray(diapers)) {
      diapers.forEach((diaper: any) => {
        items.push({
          id: diaper.id,
          type: "diaper",
          time: diaper.time,
          title: `Diaper: ${diaper.type}`,
          subtitle: diaper.consistency ? `${diaper.consistency}` : "",
          color: "bg-diaper",
        });
      });
    }
    
    if (moods && Array.isArray(moods)) {
      moods.forEach((mood: any) => {
        let subtitle = mood.mood;
        if (mood.crying) {
          subtitle += `, crying${mood.cryDuration ? ` for ${mood.cryDuration} min` : ''}`;
          if (mood.cryReason) {
            subtitle += `, reason: ${mood.cryReason}`;
          }
        }
        
        items.push({
          id: mood.id,
          type: "mood",
          time: mood.time,
          title: "Mood",
          subtitle: subtitle,
          color: "bg-mood",
        });
      });
    }
    
    if (milestones && Array.isArray(milestones)) {
      milestones.forEach((milestone: any) => {
        const milestoneTitle = milestone.type ? milestone.type.replace(/_/g, ' ') : 'unspecified';
        
        items.push({
          id: milestone.id,
          type: "milestone",
          time: milestone.time,
          title: `Milestone: ${milestoneTitle}`,
          subtitle: milestone.category ? `Category: ${milestone.category}` : '',
          color: "bg-milestone",
        });
      });
    }
    
    // Add journal entries to timeline if available
    if (journalEntries && Array.isArray(journalEntries)) {
      journalEntries.forEach((entry: JournalEntry) => {
        let subtitle = entry.category || "General";
        if (entry.mood) {
          subtitle += ` • Mood: ${entry.mood}`;
        }
        
        items.push({
          id: entry.id,
          type: "journal",
          time: entry.date.toString(),
          title: `Journal: ${entry.title}`,
          subtitle: subtitle,
          color: "bg-journal",
          content: entry.entry
        });
      });
    }
    
    // Sort by time descending (newest first)
    items.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
    
    setTimelineItems(items);
  }, [feedings, sleeps, diapers, moods, milestones, journalEntries]);
  
  const handleLogButtonClick = () => {
    openLogModal();
  };
  
  // Function to handle opening the baby details modal
  const handleEditBabyDetails = () => {
    // Find selected baby from babies array
    const currentBaby = babies?.find(b => b.id === selectedBaby) || null;
    setBabyToEdit(currentBaby);
    setShowBabyDetailsModal(true);
  };
  
  // Since we're using the global log modal now, remove the local log modal state
  // Function to close the journal form
  const handleCloseJournalForm = () => {
    setShowJournalForm(false);
  };
  
  const isLoading = isLoadingBabies || isLoadingFeedings || isLoadingSleeps || isLoadingDiapers;
  
  const renderContent = () => {
    // Using the global log modal for feeding, sleep, and diaper activities
    
    if (showJournalForm) {
      return (
        <JournalForm
          babyId={selectedBaby!}
          onBack={() => {
            setShowJournalForm(false);
          }}
          onSuccess={() => {
            queryClient.invalidateQueries({
              queryKey: ["/api/journal", selectedBaby],
            });
            setShowJournalForm(false);
          }}
        />
      );
    }
    
    return (
      <div className="p-4">
        <div className="flex flex-col space-y-4 mb-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Data Center</h2>
            
            {babies && babies.length > 0 && (
              <Select
                value={selectedBaby?.toString()}
                onValueChange={(value) => setSelectedBaby(parseInt(value))}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Select Baby" />
                </SelectTrigger>
                <SelectContent>
                  {babies.map((baby) => (
                    <SelectItem key={baby.id} value={baby.id.toString()}>
                      {baby.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          
          {/* Baby Information Card */}
          {babies && selectedBaby && (
            <div className="bg-card rounded-lg shadow-sm border border-border p-4">
              {(() => {
                const baby = babies.find(b => b.id === selectedBaby);
                if (!baby) return null;
                
                // Calculate age if dateOfBirth is available
                let ageDisplay = '';
                if (baby.dateOfBirth) {
                  const birthDate = new Date(baby.dateOfBirth);
                  const now = new Date();
                  const diffTime = Math.abs(now.getTime() - birthDate.getTime());
                  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                  
                  if (diffDays < 30) {
                    ageDisplay = `${diffDays} days old`;
                  } else if (diffDays < 365) {
                    const months = Math.floor(diffDays / 30);
                    ageDisplay = `${months} months old`;
                  } else {
                    const years = Math.floor(diffDays / 365);
                    const remainingMonths = Math.floor((diffDays % 365) / 30);
                    ageDisplay = `${years} year${years > 1 ? 's' : ''} ${remainingMonths > 0 ? `${remainingMonths} months` : ''} old`;
                  }
                }
                
                return (
                  <div className="flex items-start md:items-center flex-col md:flex-row space-y-2 md:space-y-0">
                    <div className="rounded-full bg-primary/10 p-3 mr-3">
                      {baby.gender === 'male' ? (
                        <span className="text-blue-500 text-2xl">♂</span>
                      ) : baby.gender === 'female' ? (
                        <span className="text-pink-500 text-2xl">♀</span>
                      ) : (
                        <span className="text-purple-500 text-2xl">⚥</span>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold bg-gradient-to-r from-primary to-blue-400 text-transparent bg-clip-text">{baby.name}</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 mt-1">
                        {baby.dateOfBirth && (
                          <div className="flex items-center">
                            <span className="text-sm text-muted-foreground mr-1">Birthday:</span> 
                            <span className="text-sm font-medium">{format(new Date(baby.dateOfBirth), "MMM dd, yyyy")}</span>
                          </div>
                        )}
                        {ageDisplay && (
                          <div className="flex items-center">
                            <span className="text-sm text-muted-foreground mr-1">Age:</span> 
                            <span className="text-sm font-medium">{ageDisplay}</span>
                          </div>
                        )}
                        {baby.weight && (
                          <div className="flex items-center">
                            <span className="text-sm text-muted-foreground mr-1">Weight:</span> 
                            <span className="text-sm font-medium">{baby.weight} lbs</span>
                          </div>
                        )}
                        {baby.width && (
                          <div className="flex items-center">
                            <span className="text-sm text-muted-foreground mr-1">Height:</span> 
                            <span className="text-sm font-medium">{baby.width} in</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
          
          {/* Tabs for Timeline and Journal */}
          <Tabs 
            defaultValue="timeline" 
            value={activeTab}
            onValueChange={(value) => setActiveTab(value as "timeline" | "journal")}
            className="w-full"
          >
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="timeline" className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>Timeline</span>
                </TabsTrigger>
                <TabsTrigger value="journal" className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4" />
                  <span>Journal</span>
                </TabsTrigger>
              </TabsList>
              
              {activeTab === "journal" && (
                <Button 
                  size="sm" 
                  className="flex items-center gap-1"
                  onClick={() => setShowJournalForm(true)}
                >
                  <span>New Entry</span>
                </Button>
              )}
            </div>
            
            <TabsContent value="timeline" className="mt-0">
              {isLoading ? (
                <div className="flex justify-center my-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : timelineItems.filter(item => item.type !== "journal").length > 0 ? (
                <div className="space-y-2">
                  {timelineItems
                    .filter(item => item.type !== "journal")
                    .map((item) => (
                    <div key={`${item.type}-${item.id}`} className="bg-card rounded-lg shadow-sm border border-border p-3 flex items-start">
                      <div className={`w-3 h-3 rounded-full ${item.color} mt-1.5 mr-3 flex-shrink-0`}></div>
                      <div className="flex-1">
                        <div className="font-semibold text-card-foreground">{item.title}</div>
                        {item.subtitle && <div className="text-sm text-muted-foreground">{item.subtitle}</div>}
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {item.time && format(parseISO(item.time), "h:mm a")}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {item.time && format(parseISO(item.time), "MMM d")}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No activities recorded yet. Start by logging some activities!
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="journal" className="mt-0">
              {isLoadingJournal ? (
                <div className="flex justify-center my-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : journalEntries && journalEntries.length > 0 ? (
                <div className="space-y-3">
                  {journalEntries.map((entry) => (
                    <div key={`journal-${entry.id}`} className="bg-card rounded-lg shadow-sm border border-border p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-lg">{entry.title}</h3>
                          <div className="flex items-center gap-2 mb-2">
                            <div className="text-xs text-muted-foreground">
                              {format(new Date(entry.date), "MMMM d, yyyy")}
                            </div>
                            {entry.category && (
                              <div className="inline-flex px-2 py-0.5 rounded-full text-xs bg-journal text-white">
                                {entry.category}
                              </div>
                            )}
                            {entry.mood && (
                              <div className="inline-flex px-2 py-0.5 rounded-full text-xs bg-mood text-white">
                                Mood: {entry.mood}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <p className="text-sm whitespace-pre-line">{entry.entry}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 space-y-4">
                  <BookOpen className="h-12 w-12 text-muted-foreground/40" />
                  <div className="text-center">
                    <p className="text-muted-foreground">No journal entries yet.</p>
                    <p className="text-sm text-muted-foreground/80">
                      Record your thoughts, feelings, and milestones about your baby's journey.
                    </p>
                  </div>
                  <Button 
                    onClick={() => setShowJournalForm(true)}
                    className="mt-2"
                  >
                    Create Your First Entry
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    );
  };
  
  const handleDeleteBaby = async () => {
    if (!selectedBaby) return;
    
    if (!confirm("Are you sure you want to delete this baby? This action cannot be undone.")) {
      return;
    }

    try {
      const response = await fetch(`/api/babies/${selectedBaby}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Refresh babies data
        queryClient.invalidateQueries({ queryKey: ["/api/babies"] });
        // Select first available baby if any
        if (babies && babies.length > 1) {
          const nextBaby = babies.find(b => b.id !== selectedBaby);
          if (nextBaby) {
            setSelectedBaby(nextBaby.id);
          }
        }
      } else {
        throw new Error("Failed to delete baby");
      }
    } catch (error) {
      console.error("Error deleting baby:", error);
    }
  };

  return (
    <Layout
      title="Data"
      currentTab="timeline"
      onLogButtonClick={handleLogButtonClick}
    >
      {showJournalForm ? (
        renderContent()
      ) : (
        <>
          <div className="p-4">
            <div className="flex flex-col space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <BabySelector
                  selectedBaby={selectedBaby}
                  onSelectBaby={setSelectedBaby}
                  showDetails={true}
                  className="flex-1 min-w-[200px]"
                />
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleEditBabyDetails}
                >
                  Edit More Baby Info
                </Button>
              </div>
            </div>
          </div>
          {renderContent()}
        </>
      )}

      {/* Baby Details Modal */}
      {showBabyDetailsModal && (
        <BabyDetailsModal
          isOpen={showBabyDetailsModal}
          onClose={() => setShowBabyDetailsModal(false)}
          baby={babyToEdit}
        />
      )}
    </Layout>
  );
}
