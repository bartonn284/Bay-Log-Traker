import { useState } from "react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Lightbulb, ThumbsUp, ThumbsDown } from "lucide-react";
import { useBabyContext } from "@/hooks/use-baby-context";

export default function TipsPage() {
  const { selectedBaby } = useBabyContext();
  const [feedbackGiven, setFeedbackGiven] = useState<Record<number, 'like' | 'dislike' | null>>({});
  
  // Mock data for tips (would be replaced with real data from backend)
  const tipData = {
    daily: [
      {
        id: 1,
        title: "Consistent Feeding Schedule",
        content: "Based on Jack's patterns, we recommend feeding every 3 hours during daytime. This regular schedule can help establish healthy eating habits.",
        category: "feeding"
      },
      {
        id: 2,
        title: "Sleep Environment",
        content: "Jack seems to sleep better in darker environments. Consider room-darkening curtains to extend nap durations.",
        category: "sleep"
      }
    ],
    weekly: [
      {
        id: 3,
        title: "Diaper Changes Trend",
        content: "We've noticed fewer wet diapers in the morning. Consider checking for proper hydration, especially after long sleep periods.",
        category: "diaper"
      },
      {
        id: 4,
        title: "Weekly Sleep Analysis",
        content: "Jack averages 14 hours of sleep daily - this is normal for his age! His longest sleep stretches are improving week over week.",
        category: "sleep"
      }
    ],
    monthly: [
      {
        id: 5,
        title: "Growth Pattern Insight",
        content: "Jack's growth is following the expected curve for his age. His weight gain has been consistent with recommended guidelines.",
        category: "growth"
      },
      {
        id: 6,
        title: "Feeding Development",
        content: "We've observed increased feeding duration over the past month, which is normal as babies become more efficient at eating.",
        category: "feeding"
      }
    ]
  };

  const handleFeedback = (tipId: number, type: 'like' | 'dislike') => {
    setFeedbackGiven(prev => ({
      ...prev,
      [tipId]: type
    }));
    
    // Here you would send feedback to the server
    console.log(`Feedback for tip ${tipId}: ${type}`);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'feeding':
        return 'text-feeding bg-feeding/10 border-feeding/30';
      case 'sleep':
        return 'text-sleep bg-sleep/10 border-sleep/30';
      case 'diaper':
        return 'text-diaper bg-diaper/10 border-diaper/30';
      case 'growth':
        return 'text-green-600 bg-green-50 border-green-200 dark:text-green-400 dark:bg-green-900/20 dark:border-green-800/30';
      default:
        return 'text-primary bg-primary/10 border-primary/30';
    }
  };

  return (
    <Layout currentTab="tips" title="Smart AI Baby Tips">
      <div className="container max-w-md mx-auto pb-20 px-4">
        <div className="flex items-center justify-between my-4">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-indigo-600 bg-clip-text text-transparent">
            Smart AI Baby Tips
          </h1>
          <div className="bg-blue-100 dark:bg-blue-900/30 p-1.5 rounded-full">
            <Lightbulb className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          </div>
        </div>
        
        <p className="text-muted-foreground mb-6">
          Personalized insights based on your baby's data patterns to help you provide the best care possible.
        </p>
        
        <Tabs defaultValue="daily" className="space-y-4">
          <TabsList className="grid grid-cols-3 h-auto p-1 w-full">
            <TabsTrigger value="daily" className="py-2">Daily</TabsTrigger>
            <TabsTrigger value="weekly" className="py-2">Weekly</TabsTrigger>
            <TabsTrigger value="monthly" className="py-2">Monthly</TabsTrigger>
          </TabsList>
          
          <TabsContent value="daily" className="space-y-4">
            {tipData.daily.map(tip => (
              <TipCard 
                key={tip.id}
                tip={tip}
                feedbackStatus={feedbackGiven[tip.id]}
                onFeedback={handleFeedback}
                categoryColorClass={getCategoryColor(tip.category)}
              />
            ))}
          </TabsContent>
          
          <TabsContent value="weekly" className="space-y-4">
            {tipData.weekly.map(tip => (
              <TipCard 
                key={tip.id}
                tip={tip}
                feedbackStatus={feedbackGiven[tip.id]}
                onFeedback={handleFeedback}
                categoryColorClass={getCategoryColor(tip.category)}
              />
            ))}
          </TabsContent>
          
          <TabsContent value="monthly" className="space-y-4">
            {tipData.monthly.map(tip => (
              <TipCard 
                key={tip.id}
                tip={tip}
                feedbackStatus={feedbackGiven[tip.id]}
                onFeedback={handleFeedback}
                categoryColorClass={getCategoryColor(tip.category)}
              />
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

interface TipCardProps {
  tip: {
    id: number;
    title: string;
    content: string;
    category: string;
  };
  feedbackStatus: 'like' | 'dislike' | null | undefined;
  onFeedback: (tipId: number, type: 'like' | 'dislike') => void;
  categoryColorClass: string;
}

function TipCard({ tip, feedbackStatus, onFeedback, categoryColorClass }: TipCardProps) {
  return (
    <Card className="glass-effect border border-border/30 overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <Badge variant="outline" className={`mb-2 font-normal text-xs ${categoryColorClass}`}>
              {tip.category.charAt(0).toUpperCase() + tip.category.slice(1)}
            </Badge>
            <CardTitle className="text-base">{tip.title}</CardTitle>
          </div>
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-200 to-indigo-200 dark:from-blue-900 dark:to-indigo-900 flex items-center justify-center">
            <Lightbulb className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">{tip.content}</p>
        
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">Was this helpful?</p>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant={feedbackStatus === 'like' ? 'default' : 'outline'} 
              className={`px-3 ${feedbackStatus === 'like' ? 'bg-blue-600 hover:bg-blue-700' : 'hover:bg-blue-50 dark:hover:bg-blue-900/20'}`}
              onClick={() => onFeedback(tip.id, 'like')}
            >
              <ThumbsUp className="h-3.5 w-3.5 mr-1" />
              <span className="text-xs">Yes</span>
            </Button>
            <Button 
              size="sm" 
              variant={feedbackStatus === 'dislike' ? 'default' : 'outline'} 
              className={`px-3 ${feedbackStatus === 'dislike' ? 'bg-rose-600 hover:bg-rose-700' : 'hover:bg-rose-50 dark:hover:bg-rose-900/20'}`}
              onClick={() => onFeedback(tip.id, 'dislike')}
            >
              <ThumbsDown className="h-3.5 w-3.5 mr-1" />
              <span className="text-xs">No</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}