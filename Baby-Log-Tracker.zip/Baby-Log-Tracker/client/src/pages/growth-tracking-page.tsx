import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";
import { Link } from "wouter";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, Ruler, Weight, Circle, Pencil, X, PlusCircle, ChevronLeft } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Baby, GrowthRecord as GrowthRecordType } from "@shared/schema";

type GrowthFormData = {
  babyId: number;
  weight: string;
  height: string;
  headCircumference: string;
  date: Date;
  notes: string;
};

function GrowthRecordCard({ record, onEdit, onDelete }: { 
  record: GrowthRecordType, 
  onEdit: (record: GrowthRecordType) => void,
  onDelete: (id: number) => void
}) {
  return (
    <Card className="mb-4 border-l-4 border-l-primary">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-base font-medium">
            {format(new Date(record.date), "PPP")}
          </CardTitle>
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8" 
              onClick={() => onEdit(record)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 text-destructive" 
              onClick={() => onDelete(record.id)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="flex flex-col space-y-2">
          {record.weight && (
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <Weight className="h-4 w-4 text-primary" />
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Weight:</span>
                <p className="font-medium">{record.weight}</p>
              </div>
            </div>
          )}
          
          {record.height && (
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <Ruler className="h-4 w-4 text-primary" />
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Height:</span>
                <p className="font-medium">{record.height}</p>
              </div>
            </div>
          )}
          
          {record.headCircumference && (
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <Circle className="h-4 w-4 text-primary" />
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Head Circumference:</span>
                <p className="font-medium">{record.headCircumference}</p>
              </div>
            </div>
          )}
        </div>
        
        {record.notes && (
          <div className="mt-3 pt-3 border-t">
            <p className="text-sm text-muted-foreground">Notes:</p>
            <p className="text-sm mt-1">{record.notes}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function GrowthTrackingPage() {
  const { toast } = useToast();
  const [selectedBaby, setSelectedBaby] = useState<Baby | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [currentRecord, setCurrentRecord] = useState<GrowthRecordType | null>(null);
  const [formData, setFormData] = useState<GrowthFormData>({
    babyId: 0,
    weight: "",
    height: "",
    headCircumference: "",
    date: new Date(),
    notes: "",
  });
  
  // Fetch babies
  const { data: babies } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Fetch growth records
  const { data: growthRecords, isLoading } = useQuery<GrowthRecordType[]>({
    queryKey: ["/api/babies", selectedBaby?.id, "growth"],
    queryFn: async () => {
      if (!selectedBaby) throw new Error("No baby selected");
      const response = await fetch(`/api/babies/${selectedBaby.id}/growth`);
      if (!response.ok) {
        throw new Error("Failed to fetch growth records");
      }
      return response.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Create growth record
  const createMutation = useMutation({
    mutationFn: async (data: GrowthFormData) => {
      const response = await apiRequest("POST", `/api/babies/${data.babyId}/growth`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "growth"] });
      setIsAddModalOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Growth record added successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add growth record: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Update growth record
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number } & GrowthFormData) => {
      const response = await apiRequest("PATCH", `/api/babies/${data.babyId}/growth/${data.id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "growth"] });
      setIsEditModalOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Growth record updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update growth record: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Delete growth record
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/growth/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "growth"] });
      toast({
        title: "Success",
        description: "Growth record deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete growth record: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Set the first baby as selected when babies are loaded
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0]);
      setFormData(prev => ({ ...prev, babyId: babies[0].id }));
    }
  }, [babies, selectedBaby]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setFormData(prev => ({ ...prev, date }));
    }
  };
  
  const handleAddRecord = () => {
    createMutation.mutate(formData);
  };
  
  const handleUpdateRecord = () => {
    if (!currentRecord) return;
    updateMutation.mutate({ id: currentRecord.id, ...formData });
  };
  
  const handleEditClick = (record: GrowthRecordType) => {
    setCurrentRecord(record);
    setFormData({
      babyId: record.babyId,
      weight: record.weight || "",
      height: record.height || "",
      headCircumference: record.headCircumference || "",
      date: new Date(record.date),
      notes: record.notes || "",
    });
    setIsEditModalOpen(true);
  };
  
  const handleDeleteClick = (id: number) => {
    if (confirm("Are you sure you want to delete this growth record?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const resetForm = () => {
    setFormData({
      babyId: selectedBaby?.id || 0,
      weight: "",
      height: "",
      headCircumference: "",
      date: new Date(),
      notes: "",
    });
    setCurrentRecord(null);
  };
  
  return (
    <div className="container max-w-md mx-auto pb-20">
      <header className="py-6">
        <div className="flex items-center mb-2">
          <Button variant="ghost" size="sm" className="mr-2" asChild>
            <Link to="/reports">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Link>
          </Button>
        </div>
        <h1 className="text-2xl font-bold">Growth Tracking</h1>
        <p className="text-muted-foreground">Monitor your baby's growth over time</p>
      </header>
      
      {babies && babies.length > 0 ? (
        <>
          {babies.length > 1 && (
            <Tabs defaultValue={String(selectedBaby?.id)} className="mb-6" onValueChange={(value) => {
              const baby = babies.find(b => b.id === Number(value));
              if (baby) {
                setSelectedBaby(baby);
                setFormData(prev => ({ ...prev, babyId: baby.id }));
              }
            }}>
              <TabsList className="grid grid-cols-3 w-full">
                {babies.map(baby => (
                  <TabsTrigger key={baby.id} value={String(baby.id)}>
                    {baby.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          )}
          
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Growth Records</h2>
            <Button onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Record
            </Button>
          </div>
          
          <ScrollArea className="h-[calc(100vh-270px)]">
            {isLoading ? (
              <div className="flex justify-center items-center h-40">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : growthRecords && growthRecords.length > 0 ? (
              growthRecords
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map(record => (
                  <GrowthRecordCard 
                    key={record.id}
                    record={record}
                    onEdit={handleEditClick}
                    onDelete={handleDeleteClick}
                  />
                ))
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No growth records yet. Add your first record!</p>
              </div>
            )}
          </ScrollArea>
          
          {/* Add Record Modal */}
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Growth Record</DialogTitle>
                <DialogDescription>
                  Record your baby's measurements and track their growth
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "PPP") : "Select a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={handleDateChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (e.g., 7.5 lbs)</Label>
                  <Input
                    id="weight"
                    name="weight"
                    value={formData.weight}
                    onChange={handleInputChange}
                    placeholder="Enter weight"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="height">Height (e.g., 21 inches)</Label>
                  <Input
                    id="height"
                    name="height"
                    value={formData.height}
                    onChange={handleInputChange}
                    placeholder="Enter height"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="headCircumference">Head Circumference (e.g., 14 inches)</Label>
                  <Input
                    id="headCircumference"
                    name="headCircumference"
                    value={formData.headCircumference}
                    onChange={handleInputChange}
                    placeholder="Enter head circumference"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Add any additional notes..."
                    rows={3}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleAddRecord}
                  disabled={createMutation.isPending || (!formData.weight && !formData.height && !formData.headCircumference)}
                >
                  {createMutation.isPending && (
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                  )}
                  Save Record
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Edit Record Modal */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Growth Record</DialogTitle>
                <DialogDescription>
                  Update your baby's growth measurements
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "PPP") : "Select a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={handleDateChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (e.g., 7.5 lbs)</Label>
                  <Input
                    id="weight"
                    name="weight"
                    value={formData.weight}
                    onChange={handleInputChange}
                    placeholder="Enter weight"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="height">Height (e.g., 21 inches)</Label>
                  <Input
                    id="height"
                    name="height"
                    value={formData.height}
                    onChange={handleInputChange}
                    placeholder="Enter height"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="headCircumference">Head Circumference (e.g., 14 inches)</Label>
                  <Input
                    id="headCircumference"
                    name="headCircumference"
                    value={formData.headCircumference}
                    onChange={handleInputChange}
                    placeholder="Enter head circumference"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Add any additional notes..."
                    rows={3}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleUpdateRecord}
                  disabled={updateMutation.isPending || (!formData.weight && !formData.height && !formData.headCircumference)}
                >
                  {updateMutation.isPending && (
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                  )}
                  Update Record
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No babies added yet. Add a baby in the Home page first.</p>
        </div>
      )}
      
      <BottomNavigation currentTab="reports" />
    </div>
  );
}