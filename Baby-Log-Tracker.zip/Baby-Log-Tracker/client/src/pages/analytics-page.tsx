import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, subDays, addDays, startOfWeek, endOfWeek, parseISO, isValid, isAfter, isBefore, differenceInMinutes } from "date-fns";
import { Layout } from "@/components/layout";
import { Baby, Feeding, Sleep, Diaper } from "@shared/schema";
import { generatePDF, generateDirectPDF } from "@/lib/pdf-export";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2, ChevronLeft, ChevronRight, Download, FileText } from "lucide-react";
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts";
// removed jsPDF import
import { useToast } from "@/hooks/use-toast";

// Define date range options
const DATE_RANGES = {
  DAY: "day",
  WEEK: "week",
  MONTH: "month"
};

const COLORS = ['#5B9BD5', '#9C7BD5', '#F6A192', '#6BBE8A', '#F7C545'];

export default function AnalyticsPage() {
  const [selectedBaby, setSelectedBaby] = useState<number | null>(null);
  const [dateRange, setDateRange] = useState(DATE_RANGES.WEEK);
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Calculate start and end dates based on date range
  const getDateRange = () => {
    let startDate, endDate;
    
    if (dateRange === DATE_RANGES.DAY) {
      startDate = new Date(currentDate);
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date(currentDate);
      endDate.setHours(23, 59, 59, 999);
    } else if (dateRange === DATE_RANGES.WEEK) {
      startDate = startOfWeek(currentDate);
      endDate = endOfWeek(currentDate);
    } else { // MONTH
      startDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      endDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    }
    
    return { startDate, endDate };
  };
  
  // Navigate to previous or next time period
  const navigateDate = (direction: 'prev' | 'next') => {
    const amount = direction === 'prev' ? -1 : 1;
    
    if (dateRange === DATE_RANGES.DAY) {
      setCurrentDate(addDays(currentDate, amount));
    } else if (dateRange === DATE_RANGES.WEEK) {
      setCurrentDate(addDays(currentDate, amount * 7));
    } else { // MONTH
      setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + amount, 1));
    }
  };
  
  // Format date range for display
  const formatDateRange = () => {
    const { startDate, endDate } = getDateRange();
    
    if (dateRange === DATE_RANGES.DAY) {
      return format(startDate, "MMMM d, yyyy");
    } else if (dateRange === DATE_RANGES.WEEK) {
      return `${format(startDate, "MMM d")} - ${format(endDate, "MMM d, yyyy")}`;
    } else { // MONTH
      return format(startDate, "MMMM yyyy");
    }
  };

  // Fetch babies data
  const { data: babies, isLoading: isBabiesLoading } = useQuery<Baby[], Error>({
    queryKey: ["/api/babies"],
  });
  
  // Set the first baby as selected if none is selected and data is loaded
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0].id);
    }
  }, [babies, selectedBaby]);
  
  // Get date range for API calls
  const { startDate, endDate } = getDateRange();
  
  // Format dates for API calls
  const startDateString = format(startDate, "yyyy-MM-dd");
  const endDateString = format(endDate, "yyyy-MM-dd");
  
  // Fetch all activities for the selected baby within the date range using the combined analytics endpoint
  const { data: analyticsData, isLoading: isAnalyticsLoading } = useQuery<{
    dateRange: { startDate: string, endDate: string };
    feedings: Feeding[];
    sleeps: Sleep[];
    diapers: Diaper[];
    moods: any[]; // Add mood type once defined in schema.ts
    milestones: any[]; // Add milestone type once defined in schema.ts
  }, Error>({
    queryKey: ["/api/babies", selectedBaby, "analytics", startDateString, endDateString],
    queryFn: async () => {
      const response = await fetch(`/api/babies/${selectedBaby}/analytics?startDate=${startDateString}&endDate=${endDateString}`);
      if (!response.ok) {
        throw new Error("Failed to fetch analytics data");
      }
      return response.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Extract the data from the combined endpoint
  const feedings = analyticsData?.feedings;
  const sleeps = analyticsData?.sleeps;
  const diapers = analyticsData?.diapers;
  const moods = analyticsData?.moods;
  const milestones = analyticsData?.milestones;
  
  // Fetch moods and milestones data for PDF export
  const { isLoading: isLoadingMoods } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "moods"],
    enabled: !!selectedBaby,
  });
  
  const { isLoading: isLoadingMilestones } = useQuery({
    queryKey: ["/api/babies", selectedBaby, "milestones"],
    enabled: !!selectedBaby,
  });
  
  const isLoading = isBabiesLoading || isAnalyticsLoading || isLoadingMoods || isLoadingMilestones;
  
  // Prepare data for charts
  const prepareFeedingData = () => {
    if (!feedings) return [];
    
    const feedingsByDate: Record<string, { date: string; count: number; breast: number; bottle: number; }> = {};
    
    // Initialize dates
    let currentDateCopy = new Date(startDate);
    while (currentDateCopy <= endDate) {
      const dateKey = format(currentDateCopy, "yyyy-MM-dd");
      feedingsByDate[dateKey] = { 
        date: format(currentDateCopy, "MMM dd"), 
        count: 0,
        breast: 0,
        bottle: 0
      };
      currentDateCopy = addDays(currentDateCopy, 1);
    }
    
    // Count feedings
    feedings.forEach(feeding => {
      const feedingDate = new Date(feeding.startTime);
      if (isValid(feedingDate) && isAfter(feedingDate, startDate) && isBefore(feedingDate, endDate)) {
        const dateKey = format(feedingDate, "yyyy-MM-dd");
        if (feedingsByDate[dateKey]) {
          feedingsByDate[dateKey].count++;
          
          if (feeding.type === 'breast') {
            feedingsByDate[dateKey].breast++;
          } else if (feeding.type === 'bottle') {
            feedingsByDate[dateKey].bottle++;
          }
        }
      }
    });
    
    return Object.values(feedingsByDate);
  };
  
  const prepareSleepData = () => {
    if (!sleeps) return [];
    
    const sleepsByDate: Record<string, { date: string; totalMinutes: number; count: number; avgDuration: number }> = {};
    
    // Initialize dates
    let currentDateCopy = new Date(startDate);
    while (currentDateCopy <= endDate) {
      const dateKey = format(currentDateCopy, "yyyy-MM-dd");
      sleepsByDate[dateKey] = { 
        date: format(currentDateCopy, "MMM dd"), 
        totalMinutes: 0,
        count: 0,
        avgDuration: 0
      };
      currentDateCopy = addDays(currentDateCopy, 1);
    }
    
    // Calculate sleep durations
    sleeps.forEach(sleep => {
      const sleepDate = new Date(sleep.startTime);
      if (isValid(sleepDate) && isAfter(sleepDate, startDate) && isBefore(sleepDate, endDate)) {
        const dateKey = format(sleepDate, "yyyy-MM-dd");
        if (sleepsByDate[dateKey]) {
          sleepsByDate[dateKey].count++;
          
          // Calculate duration in minutes
          if (sleep.duration) {
            sleepsByDate[dateKey].totalMinutes += sleep.duration;
          } else if (sleep.endTime) {
            const duration = differenceInMinutes(new Date(sleep.endTime), sleepDate);
            sleepsByDate[dateKey].totalMinutes += duration;
          }
        }
      }
    });
    
    // Calculate average duration
    Object.keys(sleepsByDate).forEach(date => {
      if (sleepsByDate[date].count > 0) {
        sleepsByDate[date].avgDuration = Math.round(sleepsByDate[date].totalMinutes / sleepsByDate[date].count);
      }
    });
    
    return Object.values(sleepsByDate);
  };
  
  const prepareDiaperData = () => {
    if (!diapers) return [];
    
    const diapersByDate: Record<string, { date: string; count: number; wet: number; dirty: number; mixed: number }> = {};
    
    // Initialize dates
    let currentDateCopy = new Date(startDate);
    while (currentDateCopy <= endDate) {
      const dateKey = format(currentDateCopy, "yyyy-MM-dd");
      diapersByDate[dateKey] = { 
        date: format(currentDateCopy, "MMM dd"), 
        count: 0,
        wet: 0,
        dirty: 0,
        mixed: 0
      };
      currentDateCopy = addDays(currentDateCopy, 1);
    }
    
    // Count diapers
    diapers.forEach(diaper => {
      const diaperDate = new Date(diaper.time);
      if (isValid(diaperDate) && isAfter(diaperDate, startDate) && isBefore(diaperDate, endDate)) {
        const dateKey = format(diaperDate, "yyyy-MM-dd");
        if (diapersByDate[dateKey]) {
          diapersByDate[dateKey].count++;
          
          if (diaper.type === 'wet') {
            diapersByDate[dateKey].wet++;
          } else if (diaper.type === 'dirty') {
            diapersByDate[dateKey].dirty++;
          } else if (diaper.type === 'mixed') {
            diapersByDate[dateKey].mixed++;
          }
        }
      }
    });
    
    return Object.values(diapersByDate);
  };

  // Calculate summary statistics
  const calculateSummaryStats = () => {
    if (!feedings || !sleeps || !diapers) return null;
    
    const totalFeedings = feedings.length;
    const avgFeedingsPerDay = totalFeedings / (dateRange === DATE_RANGES.DAY ? 1 : dateRange === DATE_RANGES.WEEK ? 7 : 30);
    
    const totalSleeps = sleeps.length;
    let totalSleepMinutes = 0;
    
    sleeps.forEach(sleep => {
      if (sleep.duration) {
        totalSleepMinutes += sleep.duration;
      } else if (sleep.endTime && sleep.startTime) {
        const duration = differenceInMinutes(new Date(sleep.endTime), new Date(sleep.startTime));
        totalSleepMinutes += duration;
      }
    });
    
    const avgSleepDuration = totalSleeps > 0 ? Math.round(totalSleepMinutes / totalSleeps) : 0;
    const avgSleepHours = Math.floor(avgSleepDuration / 60);
    const avgSleepMinutes = avgSleepDuration % 60;
    
    const totalDiapers = diapers.length;
    const avgDiapersPerDay = totalDiapers / (dateRange === DATE_RANGES.DAY ? 1 : dateRange === DATE_RANGES.WEEK ? 7 : 30);
    
    const wetDiapers = diapers.filter(d => d.type === 'wet').length;
    const dirtyDiapers = diapers.filter(d => d.type === 'dirty').length;
    const mixedDiapers = diapers.filter(d => d.type === 'mixed').length;
    
    const diaperTypeData = [
      { name: 'Wet', value: wetDiapers },
      { name: 'Dirty', value: dirtyDiapers },
      { name: 'Mixed', value: mixedDiapers }
    ].filter(item => item.value > 0);
    
    return {
      totalFeedings,
      avgFeedingsPerDay: avgFeedingsPerDay.toFixed(1),
      totalSleeps,
      avgSleepDuration: `${avgSleepHours}h ${avgSleepMinutes}m`,
      totalSleepMinutes,
      totalDiapers,
      avgDiapersPerDay: avgDiapersPerDay.toFixed(1),
      diaperTypeData
    };
  };
  
  const feedingData = prepareFeedingData();
  const sleepData = prepareSleepData();
  const diaperData = prepareDiaperData();
  const summaryStats = calculateSummaryStats();
  
  const { toast, dismiss } = useToast();
  
  // Generate PDF using jsPDF
  const handleExportPDF = async () => {
    if (!selectedBaby || !babies) {
      toast({
        title: "Cannot generate report",
        description: "Please select a baby first.",
        variant: "destructive",
      });
      return;
    }
    
    // Show processing toast
    const loadingToastId = toast({
      title: "Generating PDF...",
      description: "Please wait while we prepare your PDF.",
    }).id;
    
    try {
      // Get the selected baby name
      const selectedBabyData = babies.find(b => b.id === selectedBaby);
      const babyName = selectedBabyData?.name || "Baby";
      
      // Get the date range
      const { startDate, endDate } = getDateRange();
      
      console.log("PDF Generation: Preparing data for", babyName, "from", format(startDate, 'yyyy-MM-dd'), "to", format(endDate, 'yyyy-MM-dd'));
      
      // Validate and prepare all data
      const cleanFeedings = Array.isArray(feedings) ? feedings : [];
      const cleanSleeps = Array.isArray(sleeps) ? sleeps : [];
      const cleanDiapers = Array.isArray(diapers) ? diapers : [];
      const cleanMoods = Array.isArray(moods) ? moods : [];
      const cleanMilestones = Array.isArray(milestones) ? milestones : [];
      
      // Log some statistics to help with debugging
      console.log("PDF Data Stats:", {
        feedingsCount: cleanFeedings.length,
        sleepsCount: cleanSleeps.length,
        diapersCount: cleanDiapers.length,
        moodsCount: cleanMoods.length,
        milestonesCount: cleanMilestones.length,
        dateRange: `${format(startDate, 'yyyy-MM-dd')} to ${format(endDate, 'yyyy-MM-dd')}`
      });
      
      // Create the data for the PDF with clean arrays
      const pdfData = {
        babyName,
        dateRange: {
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString()
        },
        feedings: cleanFeedings,
        sleeps: cleanSleeps,
        diapers: cleanDiapers,
        moods: cleanMoods,
        milestones: cleanMilestones
      };
      
      // Generate the filename
      const filename = `baby_report_${babyName.replace(/[^a-z0-9]/gi, '_')}_${format(new Date(), 'yyyyMMdd')}.pdf`;
      
      console.log("PDF Generation: Calling generateDirectPDF with valid data");
      
      // Generate the PDF using our direct PDF generation method
      await generateDirectPDF(pdfData, filename);
      
      // Clear the loading toast
      dismiss(loadingToastId);
      
      // Show success toast
      toast({
        title: "PDF Generated",
        description: "Your report has been successfully downloaded.",
      });
    } catch (error: any) {
      // Clear the loading toast
      dismiss(loadingToastId);
      
      console.error("PDF generation error:", error);
      
      // Provide a more specific error message to the user if possible
      let errorMessage = "There was a problem generating your PDF. Please try again.";
      
      // Try to extract meaningful error message
      if (error instanceof Error) {
        // Check for common error patterns
        if (error.message.includes("blob")) {
          errorMessage = "Failed to create the PDF file. Please try again with a different date range.";
        } else if (error.message.includes("download")) {
          errorMessage = "Could not download the PDF. Please check your browser settings and try again.";
        } else if (error.message.includes("Invalid")) {
          errorMessage = "Invalid data format. Please try selecting a different date range.";
        } else {
          // Provide a sanitized version of the error message
          errorMessage = `Error: ${error.message.replace(/[^\w\s.-]/gi, '').substring(0, 100)}`;
        }
      }
      
      // Show error toast
      toast({
        title: "PDF Generation Failed",
        description: errorMessage,
        variant: "destructive",
      });
      
      // Check if we're dealing with too much data
      try {
        const { startDate, endDate } = getDateRange();
        const dayDiff = differenceInMinutes(endDate, startDate) / (60 * 24);
        
        // Suggest a smaller range if the date range is large (more than 2 weeks)
        if (dayDiff > 14) {
          console.log("Date range too large, suggesting smaller range");
          // If there were many days selected, suggest a smaller date range
          toast({
            title: "Try a smaller date range",
            description: "The report may be too large. Try selecting a shorter period."
          });
        }
      } catch (fallbackError) {
        console.error("Error handling PDF generation failure:", fallbackError);
      }
    }
  };
  
  // No email functionality needed
  
  // Check if data is loading - using the isLoading flag we defined above
  if (isLoading) {
    return (
      <Layout title="Analytics" currentTab="analytics">
        <div className="flex justify-center my-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Analytics" currentTab="analytics">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Activity Analytics</h2>
          
          {babies && babies.length > 0 && (
            <Select
              value={selectedBaby?.toString()}
              onValueChange={(value) => setSelectedBaby(parseInt(value))}
            >
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Select Baby" />
              </SelectTrigger>
              <SelectContent>
                {babies.map((baby) => (
                  <SelectItem key={baby.id} value={baby.id.toString()}>
                    {baby.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
        
        {!babies || babies.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No babies added yet. Add a baby to see analytics.
          </div>
        ) : (
          <div className="space-y-4">
            {/* Date Navigation */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col space-y-4 mb-4">
                  <div className="flex items-center justify-between">
                    <Select
                      value={dateRange}
                      onValueChange={(value) => setDateRange(value as typeof dateRange)}
                    >
                      <SelectTrigger className="w-[100px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={DATE_RANGES.DAY}>Day</SelectItem>
                        <SelectItem value={DATE_RANGES.WEEK}>Week</SelectItem>
                        <SelectItem value={DATE_RANGES.MONTH}>Month</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => navigateDate('prev')}>
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <div className="text-sm font-medium min-w-32 text-center">
                        {formatDateRange()}
                      </div>
                      <Button variant="outline" size="icon" onClick={() => navigateDate('next')}>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 justify-end">
                    <Button variant="outline" size="sm" onClick={handleExportPDF}>
                      <FileText className="h-4 w-4 mr-1" />
                      <Download className="h-4 w-4 mr-1" />
                      Export PDF
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Summary Card */}
            {summaryStats && (
              <Card>
                <CardHeader>
                  <CardTitle>Summary</CardTitle>
                  <CardDescription>
                    Overview for {formatDateRange()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <Label className="text-muted-foreground">Feedings</Label>
                      <div className="text-2xl font-bold">{summaryStats.totalFeedings}</div>
                      <div className="text-sm text-muted-foreground">
                        Avg {summaryStats.avgFeedingsPerDay} per day
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <Label className="text-muted-foreground">Sleep</Label>
                      <div className="text-2xl font-bold">{summaryStats.avgSleepDuration}</div>
                      <div className="text-sm text-muted-foreground">
                        Avg duration per sleep
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <Label className="text-muted-foreground">Diapers</Label>
                      <div className="text-2xl font-bold">{summaryStats.totalDiapers}</div>
                      <div className="text-sm text-muted-foreground">
                        Avg {summaryStats.avgDiapersPerDay} per day
                      </div>
                    </div>
                  </div>
                  
                  {/* Diaper Types Pie Chart */}
                  {summaryStats.diaperTypeData.length > 0 && (
                    <div className="mt-6">
                      <Label className="text-muted-foreground mb-2 block">Diaper Types</Label>
                      <div className="h-[200px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={summaryStats.diaperTypeData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {summaryStats.diaperTypeData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
            
            {/* Detailed Charts */}
            <Tabs defaultValue="feeding" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="feeding">Feeding</TabsTrigger>
                <TabsTrigger value="sleep">Sleep</TabsTrigger>
                <TabsTrigger value="diaper">Diaper</TabsTrigger>
              </TabsList>
              
              <TabsContent value="feeding">
                <Card>
                  <CardHeader>
                    <CardTitle>Feeding Frequency</CardTitle>
                    <CardDescription>
                      Number of feedings per day
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={feedingData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar name="Breast" dataKey="breast" fill="#5B9BD5" />
                          <Bar name="Bottle" dataKey="bottle" fill="#6BBE8A" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="sleep">
                <Card>
                  <CardHeader>
                    <CardTitle>Sleep Duration</CardTitle>
                    <CardDescription>
                      Average sleep duration in minutes per day
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={sleepData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip formatter={(value) => [`${value} min`, 'Avg Duration']} />
                          <Legend />
                          <Line 
                            type="monotone" 
                            name="Avg Duration (min)" 
                            dataKey="avgDuration" 
                            stroke="#9C7BD5" 
                            activeDot={{ r: 8 }} 
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="diaper">
                <Card>
                  <CardHeader>
                    <CardTitle>Diaper Changes</CardTitle>
                    <CardDescription>
                      Number of diaper changes per day
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={diaperData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar name="Wet" dataKey="wet" fill="#5B9BD5" />
                          <Bar name="Dirty" dataKey="dirty" fill="#F6A192" />
                          <Bar name="Mixed" dataKey="mixed" fill="#F7C545" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </Layout>
  );
}