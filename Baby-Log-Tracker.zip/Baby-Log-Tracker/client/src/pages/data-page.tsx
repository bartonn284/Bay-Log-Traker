import { useState } from "react";
import { Layout } from "@/components/layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLogModal } from "@/hooks/use-log-modal";
import GrowthTrackingTab from "@/components/data/growth-tracking-tab";
import HealthRecordsTab from "@/components/data/health-records-tab";
import AppointmentsTab from "@/components/data/appointments-tab";
import MilestonesTab from "@/components/data/milestones-tab";
import VaccinationsTab from "@/components/data/vaccinations-tab";
import FeedingTab from "@/components/tracking/feeding-tab";
import SleepTab from "@/components/tracking/sleep-tab";
import DiaperTab from "@/components/tracking/diaper-tab";
import JournalTab from "@/components/data/journal-tab";
import BabyInfoTab from "@/components/data/baby-info-tab";
import { useBabyContext } from "@/hooks/use-baby-context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Activity, 
  Thermometer, 
  Ruler, 
  Calendar, 
  Award, 
  Syringe,
  Utensils,
  Moon,
  Baby,
  BookOpen,
  User
} from "lucide-react";

export default function DataPage() {
  const { open: openLogModal } = useLogModal();
  const { selectedBaby } = useBabyContext();
  const [activeTab, setActiveTab] = useState("feeding");
  
  const handleLogButtonClick = () => {
    openLogModal();
  };
  
  return (
    <Layout 
      title="Baby Data" 
      currentTab="data"
      onLogButtonClick={handleLogButtonClick}
    >
      <div className="p-4">
        <h1 className="text-gradient text-2xl font-bold mb-2">Baby Tracker</h1>
        <p className="text-muted-foreground text-sm mb-4">Track your baby's activities, health, and development</p>
        
        {selectedBaby ? (
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="mb-6 w-full grid grid-cols-2 lg:grid-cols-10 md:grid-cols-5 sm:grid-cols-4 h-auto glass-effect rounded-xl p-1">
              <div className="col-span-2 lg:col-span-10 md:col-span-5 sm:col-span-4 font-medium text-sm px-2 py-1.5 bg-primary/10 text-primary rounded-lg mb-2 backdrop-blur-sm">
                <span className="text-gradient">Core Tracking</span>
              </div>
              <TabsTrigger 
                value="feeding" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Utensils className="h-4 w-4" />
                <span className="text-xs font-medium">Feeding</span>
              </TabsTrigger>
              <TabsTrigger 
                value="sleep" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Moon className="h-4 w-4" />
                <span className="text-xs font-medium">Sleep</span>
              </TabsTrigger>
              <TabsTrigger 
                value="diaper" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Baby className="h-4 w-4" />
                <span className="text-xs font-medium">Diaper</span>
              </TabsTrigger>
              <TabsTrigger 
                value="journal" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <BookOpen className="h-4 w-4" />
                <span className="text-xs font-medium">Journal</span>
              </TabsTrigger>
              <TabsTrigger 
                value="babyinfo" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <User className="h-4 w-4" />
                <span className="text-xs font-medium">Baby Info</span>
              </TabsTrigger>
              
              <div className="col-span-2 lg:col-span-10 md:col-span-5 sm:col-span-4 font-medium text-sm px-2 py-1.5 bg-primary/10 text-primary rounded-lg mb-2 mt-3 backdrop-blur-sm">
                <span className="text-gradient">Health Monitoring</span>
              </div>
              <TabsTrigger 
                value="growth" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Ruler className="h-4 w-4" />
                <span className="text-xs font-medium">Growth</span>
              </TabsTrigger>
              <TabsTrigger 
                value="health" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Thermometer className="h-4 w-4" />
                <span className="text-xs font-medium">Health</span>
              </TabsTrigger>
              <TabsTrigger 
                value="appointments" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Calendar className="h-4 w-4" />
                <span className="text-xs font-medium">Appointments</span>
              </TabsTrigger>
              <TabsTrigger 
                value="vaccinations" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Syringe className="h-4 w-4" />
                <span className="text-xs font-medium">Vaccinations</span>
              </TabsTrigger>
              
              <div className="col-span-2 lg:col-span-10 md:col-span-5 sm:col-span-4 font-medium text-sm px-2 py-1.5 bg-primary/10 text-primary rounded-lg mb-2 mt-3 backdrop-blur-sm">
                <span className="text-gradient">Development Tracking</span>
              </div>
              <TabsTrigger 
                value="milestones" 
                className="flex flex-col py-2.5 px-1 items-center gap-1.5 rounded-lg data-[state=active]:bg-primary !data-[state=active]:text-primary-foreground data-[state=active]:font-extrabold data-[state=active]:shadow-lg border-[1.5px] border-transparent data-[state=active]:border-white/30"
              >
                <Award className="h-4 w-4" />
                <span className="text-xs font-medium">Milestones</span>
              </TabsTrigger>
            </TabsList>
            
            <div className="bg-card rounded-xl shadow-lg p-4 card-hover">
              {/* Core tracking content */}
              <TabsContent value="feeding" className="mt-0">
                <FeedingTab />
              </TabsContent>
              
              <TabsContent value="sleep" className="mt-0">
                <SleepTab />
              </TabsContent>
              
              <TabsContent value="diaper" className="mt-0">
                <DiaperTab />
              </TabsContent>
              
              <TabsContent value="journal" className="mt-0">
                <JournalTab />
              </TabsContent>
              
              <TabsContent value="babyinfo" className="mt-0">
                <BabyInfoTab />
              </TabsContent>
              
              {/* Health monitoring content */}
              <TabsContent value="growth" className="mt-0">
                <GrowthTrackingTab />
              </TabsContent>
              
              <TabsContent value="health" className="mt-0">
                <HealthRecordsTab />
              </TabsContent>
              
              <TabsContent value="appointments" className="mt-0">
                <AppointmentsTab />
              </TabsContent>
              
              <TabsContent value="vaccinations" className="mt-0">
                <VaccinationsTab />
              </TabsContent>
              
              {/* Development tracking content */}
              <TabsContent value="milestones" className="mt-0">
                <MilestonesTab />
              </TabsContent>
            </div>
          </Tabs>
        ) : (
          <Card className="glass-effect overflow-hidden border">
            <CardHeader className="bg-gradient-to-r from-primary/30 to-primary/10 pb-6">
              <CardTitle className="text-xl text-gradient">No Baby Selected</CardTitle>
              <CardDescription className="text-sm">
                Please select a baby to view health and development data.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center py-10">
              <div className="float-effect">
                <Activity className="h-20 w-20 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}