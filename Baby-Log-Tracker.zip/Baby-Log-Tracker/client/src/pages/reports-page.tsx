import { useState, useEffect } from "react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { useLogModal } from "@/hooks/use-log-modal";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { generatePdf } from "@/lib/pdf-export";
import { downloadPdf } from "@/lib/download-pdf";
import { FileText, Download, RefreshCw, Calendar } from "lucide-react";
import { EmergencyProfileCard } from "@/components/emergency-profile-card";
import { format, subDays } from "date-fns";

export default function ReportsPage() {
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const { open: openLogModal } = useLogModal();
  const [reportType, setReportType] = useState<"full" | "summary">("summary");
  const [dateRange, setDateRange] = useState<"day" | "week" | "month">("week");
  const [isGenerating, setIsGenerating] = useState(false);
  const [activitySummary, setActivitySummary] = useState({
    feedings: 0,
    sleep: 0,
    diapers: 0,
    growth: { weight: "", date: "" }
  });

  // Fetch baby data for profile info
  const { data: babyData } = useQuery({
    queryKey: ['/api/babies', selectedBaby],
    queryFn: async () => {
      if (!selectedBaby) return null;
      const res = await apiRequest("GET", `/api/babies/${selectedBaby}`);
      return res.json();
    },
    enabled: !!selectedBaby
  });

  // Fetch feedings data
  const { data: feedingsData } = useQuery({
    queryKey: ['/api/babies', selectedBaby, 'feedings'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby}/feedings`);
      return res.json();
    },
    enabled: !!selectedBaby
  });

  // Fetch sleep data
  const { data: sleepData } = useQuery({
    queryKey: ['/api/babies', selectedBaby, 'sleep'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby}/sleep`);
      return res.json();
    },
    enabled: !!selectedBaby
  });

  // Fetch diaper data
  const { data: diaperData } = useQuery({
    queryKey: ['/api/babies', selectedBaby, 'diapers'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby}/diapers`);
      return res.json();
    },
    enabled: !!selectedBaby
  });

  // Fetch growth data
  const { data: growthData } = useQuery({
    queryKey: ['/api/babies', selectedBaby, 'growth'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby}/growth`);
      return res.json();
    },
    enabled: !!selectedBaby
  });

  // Calculate summary data when data changes
  useEffect(() => {
    if (!selectedBaby) return;

    // Get yesterday's date for 24 hour calculation
    const yesterday = subDays(new Date(), 1);

    // Process feedings
    const recentFeedings = Array.isArray(feedingsData) ? 
      feedingsData.filter((feeding: any) => 
        new Date(feeding.startTime) >= yesterday
      ) : [];

    // Process sleep
    const recentSleep = Array.isArray(sleepData) ? 
      sleepData.filter((sleep: any) => 
        new Date(sleep.startTime) >= yesterday
      ) : [];
    
    // Calculate total sleep hours
    const totalSleepMinutes = recentSleep.reduce((total: number, sleep: any) => {
      return total + (sleep.duration || 0);
    }, 0);
    const sleepHours = (totalSleepMinutes / 60).toFixed(1);

    // Process diapers
    const recentDiapers = Array.isArray(diaperData) ? 
      diaperData.filter((diaper: any) => 
        new Date(diaper.time) >= yesterday
      ) : [];

    // Get latest growth record
    let latestGrowth = { weight: "", date: "" };
    if (Array.isArray(growthData) && growthData.length > 0) {
      const sortedGrowth = [...growthData].sort((a: any, b: any) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      if (sortedGrowth[0]) {
        latestGrowth = {
          weight: sortedGrowth[0].weight || "",
          date: format(new Date(sortedGrowth[0].date), 'MMM d, yyyy')
        };
      }
    }

    setActivitySummary({
      feedings: recentFeedings.length,
      sleep: parseFloat(sleepHours),
      diapers: recentDiapers.length,
      growth: latestGrowth
    });
  }, [selectedBaby, feedingsData, sleepData, diaperData, growthData]);

  const handleLogButtonClick = () => {
    openLogModal();
  };

  const refreshData = () => {
    if (!selectedBaby) return;
    
    queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby, 'feedings'] });
    queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby, 'sleep'] });
    queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby, 'diapers'] });
    queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby, 'growth'] });
    
    toast({
      title: "Data refreshed",
      description: "The activity summary has been updated.",
    });
  };

  const handleGenerateReport = async () => {
    if (!selectedBaby) {
      toast({
        title: "Baby not selected",
        description: "Please select a baby to generate reports for.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    try {
      // Generate and download the PDF using the already fetched data
      const pdfBlob = await generatePdf(babyData, reportType, dateRange);
      await downloadPdf(pdfBlob, `${babyData.name}_report_${new Date().toISOString().split('T')[0]}.pdf`);
      
      toast({
        title: "Report generated",
        description: "Your report has been generated and downloaded.",
      });
    } catch (error) {
      console.error("Error generating report:", error);
      toast({
        title: "Failed to generate report",
        description: "There was an error generating your report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Print functionality removed
  
  return (
    <Layout 
      title="Reports" 
      currentTab="reports"
      onLogButtonClick={handleLogButtonClick}
    >
        <div className="p-4">
          <h1 className="text-2xl font-bold mb-6">Reports & Analytics</h1>
          
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Emergency Profile Info</h2>
            </div>
            
            {selectedBaby && babyData ? (
              <EmergencyProfileCard 
                baby={babyData} 
                onExportPdf={handleGenerateReport}
              />
            ) : (
              <Card className="p-6 text-center">
                <p className="text-muted-foreground">Select a baby to view emergency profile</p>
              </Card>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Activity Summary</CardTitle>
                <CardDescription>Generate a summary of recent activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Time Range:</span>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        variant={dateRange === "day" ? "default" : "outline"}
                        onClick={() => setDateRange("day")}
                      >
                        Day
                      </Button>
                      <Button 
                        size="sm" 
                        variant={dateRange === "week" ? "default" : "outline"}
                        onClick={() => setDateRange("week")}
                      >
                        Week
                      </Button>
                      <Button 
                        size="sm" 
                        variant={dateRange === "month" ? "default" : "outline"}
                        onClick={() => setDateRange("month")}
                      >
                        Month
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Report Type:</span>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        variant={reportType === "summary" ? "default" : "outline"}
                        onClick={() => setReportType("summary")}
                      >
                        Summary
                      </Button>
                      <Button 
                        size="sm" 
                        variant={reportType === "full" ? "default" : "outline"}
                        onClick={() => setReportType("full")}
                      >
                        Detailed
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={handleGenerateReport}
                  disabled={isGenerating || !selectedBaby}
                  className="w-full"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Health Reports</CardTitle>
                <CardDescription>Generate health-focused reports</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Generate comprehensive reports on your baby's growth, health records, 
                  vaccinations, and appointments. These reports can be shared with healthcare providers.
                </p>
                
                {babyData && (
                  <div className="mt-4 bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                    <h3 className="font-medium text-blue-700 dark:text-blue-400">
                      Profile Summary
                    </h3>
                    <div className="grid grid-cols-2 gap-x-2 mt-2 text-sm">
                      <p className="text-muted-foreground">Name:</p>
                      <p className="font-medium">{babyData.name}</p>
                      
                      {babyData.dateOfBirth && (
                        <>
                          <p className="text-muted-foreground">Date of birth:</p>
                          <p className="font-medium">{format(new Date(babyData.dateOfBirth), 'MMM d, yyyy')}</p>
                        </>
                      )}
                      
                      {babyData.gender && (
                        <>
                          <p className="text-muted-foreground">Gender:</p>
                          <p className="font-medium">{babyData.gender}</p>
                        </>
                      )}
                      
                      {babyData.weight && (
                        <>
                          <p className="text-muted-foreground">Birth weight:</p>
                          <p className="font-medium">{babyData.weight}</p>
                        </>
                      )}
                      
                      {babyData.height && (
                        <>
                          <p className="text-muted-foreground">Birth height:</p>
                          <p className="font-medium">{babyData.height}</p>
                        </>
                      )}
                      
                      {babyData.bloodType && (
                        <>
                          <p className="text-muted-foreground">Blood type:</p>
                          <p className="font-medium">{babyData.bloodType}</p>
                        </>
                      )}
                      
                      {babyData.allergies && (
                        <>
                          <p className="text-muted-foreground">Allergies:</p>
                          <p className="font-medium">{babyData.allergies}</p>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full" 
                  variant="secondary"
                  disabled={!selectedBaby}
                  onClick={() => {
                    setReportType("full");
                    setDateRange("month");
                    setTimeout(handleGenerateReport, 100);
                  }}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Health Report
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <Card className="mb-4">
            <CardHeader className="pb-2 flex flex-row items-center justify-between">
              <div>
                <CardTitle>Recent Activity Overview</CardTitle>
                <CardDescription>Summary of recent tracking data</CardDescription>
              </div>
              
              <Button 
                size="sm" 
                variant="ghost" 
                onClick={refreshData}
                disabled={!selectedBaby}
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent>
              {selectedBaby ? (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground mb-4">
                    <Calendar className="h-4 w-4 inline-block mr-1" />
                    Data for the past 24 hours ({format(subDays(new Date(), 1), 'MMM d')} - {format(new Date(), 'MMM d')})
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                      <h3 className="font-medium text-blue-700 dark:text-blue-400">Feedings</h3>
                      <p className="text-2xl font-bold mt-1">{activitySummary.feedings}</p>
                      <p className="text-xs text-muted-foreground">Past 24 hours</p>
                    </div>
                    <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                      <h3 className="font-medium text-purple-700 dark:text-purple-400">Sleep</h3>
                      <p className="text-2xl font-bold mt-1">{activitySummary.sleep} hrs</p>
                      <p className="text-xs text-muted-foreground">Hours in past day</p>
                    </div>
                    <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                      <h3 className="font-medium text-green-700 dark:text-green-400">Diapers</h3>
                      <p className="text-2xl font-bold mt-1">{activitySummary.diapers}</p>
                      <p className="text-xs text-muted-foreground">Past 24 hours</p>
                    </div>
                    <div className="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg">
                      <h3 className="font-medium text-amber-700 dark:text-amber-400">Growth</h3>
                      <p className="text-2xl font-bold mt-1">
                        {activitySummary.growth.weight || "-"}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {activitySummary.growth.date || "No records"}
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-6 text-muted-foreground">
                  Please select a baby to view activity data.
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </Layout>
  );
}