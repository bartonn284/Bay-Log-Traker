import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { FamilySharing } from "@/components/family-sharing";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/components/theme-provider";
import { Baby } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LogOut, User, Users, ArrowRight, Moon, Sun, Trash2, Upload, Bell } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DeleteAllReminders } from "@/components/reminders/delete-all-reminders";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SettingsPage() {
  const { user, logoutMutation } = useAuth();
  const { theme, colorTheme, setTheme, setColorTheme } = useTheme();
  const [selectedBaby, setSelectedBaby] = useState<number | null>(null);
  const [selectedSection, setSelectedSection] = useState<string>("profile");
  const [enableGenderTheme, setEnableGenderTheme] = useState<boolean>(true);
  const [deleteConfirmation, setDeleteConfirmation] = useState<string>("");
  const { toast } = useToast();
  const { setSelectedBaby: setContextBaby } = useBabyContext();
  
  // Fetch babies
  const {
    data: babies,
    isLoading: isLoadingBabies,
  } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
  });
  
  // Set first baby as selected if none selected
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0].id);
    }
  }, [babies, selectedBaby]);
  
  // Theme preferences stored in localStorage
  useEffect(() => {
    const savedPreference = localStorage.getItem('enableGenderTheme');
    if (savedPreference !== null) {
      setEnableGenderTheme(savedPreference === 'true');
    }
  }, []);

  // Delete baby mutation
  const deleteBabyMutation = useMutation({
    mutationFn: async (babyId: number) => {
      const res = await apiRequest('DELETE', `/api/babies/${babyId}`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Baby profile deleted",
        description: "The baby profile has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/babies"] });
      setDeleteConfirmation("");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete baby profile: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleGenderThemeToggle = (checked: boolean) => {
    setEnableGenderTheme(checked);
    localStorage.setItem('enableGenderTheme', String(checked));
    
    // Apply theme immediately
    if (checked && babies && selectedBaby) {
      const currentBaby = babies.find(baby => baby.id === selectedBaby);
      if (currentBaby?.gender) {
        document.documentElement.setAttribute('data-baby-gender', currentBaby.gender);
      }
    } else {
      document.documentElement.removeAttribute('data-baby-gender');
    }
    
    // Keep the class toggle for backward compatibility
    document.documentElement.classList.toggle('gender-theme-enabled', checked);
    
    // Show confirmation toast
    toast({
      title: checked ? "Gender theme enabled" : "Gender theme disabled",
      description: checked ? 
        "Colors will now reflect your baby's gender in the app." : 
        "Standard color theme will be used for all babies.",
    });
  };
  
  const handleDeleteBaby = () => {
    if (!selectedBaby) return;
    
    const selectedBabyData = babies?.find(b => b.id === selectedBaby);
    if (!selectedBabyData) return;
    
    const name = selectedBabyData.name;
    if (deleteConfirmation === name) {
      deleteBabyMutation.mutate(selectedBaby);
    }
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const renderContent = () => {
    if (selectedSection === "family") {
      return (
        <FamilySharing babyId={selectedBaby!} />
      );
    }
    
    // Profile section
    return (
      <div className="space-y-5">
        <div className="bg-card dark:bg-card rounded-lg shadow-sm border border-border p-4">
          <h3 className="font-semibold mb-4">Your Profile</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">
                Full Name
              </label>
              <Input
                value={user?.fullName || ""}
                disabled
                className="bg-muted"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">
                Email
              </label>
              <Input
                value={user?.username || ""}
                disabled
                className="bg-muted"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">
                Role
              </label>
              <Input
                value={user?.role || "Admin"}
                disabled
                className="bg-muted"
              />
            </div>
          </div>
        </div>
        
        <div className="bg-card dark:bg-card rounded-lg shadow-sm border border-border p-4">
          <h3 className="font-semibold mb-4">Display Settings</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Dark Mode</h4>
                <p className="text-sm text-muted-foreground">
                  Toggle dark mode for nighttime use
                </p>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="rounded-full"
              >
                {theme === "dark" ? (
                  <Moon className="h-[1.2rem] w-[1.2rem]" />
                ) : (
                  <Sun className="h-[1.2rem] w-[1.2rem]" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
            </div>
            
            <div className="pt-2 border-t border-border space-y-2">
              <div>
                <h4 className="font-medium">Color Theme</h4>
                <p className="text-sm text-muted-foreground mb-2">
                  Select your preferred color palette for the app
                </p>
              </div>
              
              <div className="grid grid-cols-1 gap-3">
                <Button
                  variant={colorTheme === "default" ? "default" : "outline"}
                  className={`flex items-center justify-start h-14 transition-all px-4 ${
                    colorTheme === "default" 
                      ? "bg-gradient-to-r from-[hsl(var(--primary))] to-[hsl(var(--primary-foreground))]" 
                      : "hover:bg-accent"
                  }`}
                  onClick={() => setColorTheme("default")}
                >
                  <div className="w-6 h-6 rounded-full bg-primary mr-3 flex-shrink-0 border border-white/20"></div>
                  <span className={`text-base font-medium ${colorTheme === "default" ? "text-white" : ""}`}>Default Theme</span>
                </Button>
                
                <Button
                  variant={colorTheme === "vibrant" ? "default" : "outline"}
                  className={`flex items-center justify-start h-14 transition-all px-4 ${
                    colorTheme === "vibrant" 
                      ? "bg-gradient-to-r from-purple-600 to-pink-600" 
                      : "hover:bg-accent"
                  }`}
                  onClick={() => setColorTheme("vibrant")}
                >
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 mr-3 flex-shrink-0 border border-white/20"></div>
                  <span className={`text-base font-medium ${colorTheme === "vibrant" ? "text-white" : ""}`}>Vibrant Theme</span>
                </Button>
                
                <Button
                  variant={colorTheme === "pastel" ? "default" : "outline"}
                  className={`flex items-center justify-start h-14 transition-all px-4 ${
                    colorTheme === "pastel" 
                      ? "bg-gradient-to-r from-teal-500 to-emerald-500" 
                      : "hover:bg-accent"
                  }`}
                  onClick={() => setColorTheme("pastel")}
                >
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-teal-400 to-emerald-400 mr-3 flex-shrink-0 border border-white/20"></div>
                  <span className={`text-base font-medium ${colorTheme === "pastel" ? "text-white" : ""}`}>Pastel Theme</span>
                </Button>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <div>
                <h4 className="font-medium">Gender-Based Theme</h4>
                <p className="text-sm text-muted-foreground">
                  Apply colors based on baby gender throughout the app
                </p>
              </div>
              <Switch
                checked={enableGenderTheme}
                onCheckedChange={handleGenderThemeToggle}
                aria-label="Toggle gender-based colors"
              />
            </div>
          </div>
        </div>
        
        {babies && babies.length > 0 && (
          <div className="bg-card dark:bg-card rounded-lg shadow-sm border border-border p-4">
            <h3 className="font-semibold mb-4">Baby Information</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Select Baby
                </label>
                <Select
                  value={selectedBaby?.toString()}
                  onValueChange={(value) => setSelectedBaby(parseInt(value))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select Baby" />
                  </SelectTrigger>
                  <SelectContent>
                    {babies.map((baby) => (
                      <SelectItem key={baby.id} value={baby.id.toString()}>
                        {baby.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button
                variant="outline"
                className="w-full flex justify-between items-center"
                onClick={() => setSelectedSection("family")}
              >
                <span>Family Sharing</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
              
              <div className="pt-4 border-t border-border mt-4">
                <h4 className="font-medium text-red-500 mb-2">Danger Zone</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Permanently delete this baby profile and all associated data.
                  This action cannot be undone.
                </p>
                
                <div className="flex flex-col space-y-2">
                  <Input 
                    placeholder={`Type "${babies?.find(b => b.id === selectedBaby)?.name}" to confirm`} 
                    value={deleteConfirmation}
                    onChange={(e) => setDeleteConfirmation(e.target.value)}
                    className="border-red-200"
                  />
                  
                  <Button
                    variant="destructive"
                    className="w-full"
                    onClick={handleDeleteBaby}
                    disabled={deleteConfirmation !== babies?.find(b => b.id === selectedBaby)?.name || deleteBabyMutation.isPending}
                  >
                    {deleteBabyMutation.isPending ? (
                      <>Deleting...</>
                    ) : (
                      <>
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete Baby Profile
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div className="bg-card dark:bg-card rounded-lg shadow-sm border border-border p-4 mb-4">
          <h3 className="font-semibold mb-4 flex items-center">
            <Bell className="h-4 w-4 mr-2 text-primary" />
            Reminder Management
          </h3>
          <DeleteAllReminders />
        </div>
        
        <Button
          variant="destructive"
          className="w-full"
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Log Out
        </Button>
      </div>
    );
  };
  
  return (
    <Layout title="Settings" currentTab="settings">
      <div className="p-4">
        {selectedSection === "family" && (
          <div className="mb-4">
            <Button
              variant="ghost"
              className="px-0"
              onClick={() => setSelectedSection("profile")}
            >
              ← Back to Settings
            </Button>
          </div>
        )}
        
        {renderContent()}
      </div>
    </Layout>
  );
}
