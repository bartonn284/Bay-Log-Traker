import { useState, useEffect, lazy, Suspense } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format, subDays } from "date-fns";
import { Link } from "wouter";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Thermometer, 
  PillIcon, 
  Stethoscope, 
  Pencil, 
  X, 
  PlusCircle, 
  Clock, 
  ChevronLeft,
  AlertTriangle
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Baby, HealthRecord as HealthRecordType } from "@shared/schema";
import { EmergencyInfoCard } from "@/components/emergency-info-card";

// Lazy load the temperature form component
const TemperatureForm = lazy(() => import("@/components/temperature-form").then(mod => ({ 
  default: mod.TemperatureForm 
})));

type HealthFormData = {
  babyId: number;
  recordType: string;
  date: Date;
  temperature: string;
  medicationName: string;
  medicationDose: string;
  medicationSchedule: string;
  doctorNotes: string;
  symptoms: string;
  illnessName: string;
  isSickDay: boolean;
  notes: string;
};

const RECORD_TYPES = [
  "Temperature",
  "Illness",
  "Medication",
  "Doctor Visit"
];

function HealthRecordCard({ record, onEdit, onDelete }: { 
  record: HealthRecordType, 
  onEdit: (record: HealthRecordType) => void,
  onDelete: (id: number) => void
}) {
  const recordIcon = () => {
    switch (record.recordType) {
      case "Temperature":
        return <Thermometer className="h-5 w-5 text-orange-500" />;
      case "Illness":
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case "Medication":
        return <PillIcon className="h-5 w-5 text-indigo-500" />;
      case "Doctor Visit":
        return <Stethoscope className="h-5 w-5 text-emerald-500" />;
      default:
        return <Thermometer className="h-5 w-5 text-primary" />;
    }
  };
  
  const recordColor = () => {
    switch (record.recordType) {
      case "Temperature":
        return "border-orange-500";
      case "Illness":
        return "border-red-500";
      case "Medication":
        return "border-indigo-500";
      case "Doctor Visit":
        return "border-emerald-500";
      default:
        return "border-primary";
    }
  };
  
  return (
    <Card className={`mb-4 border-l-4 ${recordColor()}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
              {recordIcon()}
            </div>
            <div>
              <CardTitle className="text-base font-medium">
                {record.recordType}
              </CardTitle>
              <CardDescription>
                {format(new Date(record.date), "PPP p")}
              </CardDescription>
            </div>
          </div>
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8" 
              onClick={() => onEdit(record)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 text-destructive" 
              onClick={() => onDelete(record.id)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        {record.recordType === "Temperature" && record.temperature && (
          <div className="mb-3">
            <span className="text-sm text-muted-foreground">Temperature:</span>
            <p className="font-medium">{record.temperature}</p>
          </div>
        )}
        
        {record.recordType === "Illness" && (
          <>
            {record.temperature && (
              <div className="mb-2">
                <span className="text-sm text-muted-foreground">Temperature:</span>
                <p className="font-medium">{record.temperature}</p>
              </div>
            )}
            
            {/* Extract and display symptoms from notes */}
            {record.notes && record.notes.includes("Symptoms:") && (
              <div className="mb-2">
                <span className="text-sm text-muted-foreground">Symptoms:</span>
                <p className="font-medium">
                  {record.notes.match(/Symptoms: (.*?)(\n\n|$)/)?.[1] || ""}
                </p>
              </div>
            )}
            
            {/* Extract and display illness from notes */}
            {record.notes && record.notes.includes("Illness:") && (
              <div className="mb-2">
                <span className="text-sm text-muted-foreground">Diagnosis:</span>
                <p className="font-medium">
                  {record.notes.match(/Illness: (.*?)(\n\n|$)/)?.[1] || ""}
                </p>
              </div>
            )}
            
            {/* Check if marked as sick day */}
            {record.notes && record.notes.includes("Marked as sick day") && (
              <div className="mb-2">
                <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                  Marked as sick day
                </Badge>
              </div>
            )}
          </>
        )}
        
        {record.recordType === "Medication" && (
          <>
            {record.medicationName && (
              <div className="mb-2">
                <span className="text-sm text-muted-foreground">Medication:</span>
                <p className="font-medium">{record.medicationName}</p>
              </div>
            )}
            {record.medicationDose && (
              <div className="mb-2">
                <span className="text-sm text-muted-foreground">Dose:</span>
                <p className="font-medium">{record.medicationDose}</p>
              </div>
            )}
            {record.medicationSchedule && (
              <div className="mb-2">
                <span className="text-sm text-muted-foreground">Schedule:</span>
                <p className="font-medium">{record.medicationSchedule}</p>
              </div>
            )}
          </>
        )}
        
        {record.recordType === "Doctor Visit" && record.doctorNotes && (
          <div className="mb-3">
            <span className="text-sm text-muted-foreground">Doctor Notes:</span>
            <p className="font-medium">{record.doctorNotes}</p>
          </div>
        )}
        
        {record.notes && (
          <div className="mt-3 pt-3 border-t">
            <p className="text-sm text-muted-foreground">Notes:</p>
            <p className="text-sm mt-1">
              {record.recordType === "Illness" 
                ? record.notes
                    .replace(/Symptoms: .*?(\n\n|$)/g, "")
                    .replace(/Illness: .*?(\n\n|$)/g, "")
                    .replace(/Marked as sick day/g, "")
                    .replace(/\n{3,}/g, "\n\n")
                    .trim()
                : record.notes}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function HealthPage() {
  const { toast } = useToast();
  const [selectedBaby, setSelectedBaby] = useState<Baby | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [currentRecord, setCurrentRecord] = useState<HealthRecordType | null>(null);
  const [filter, setFilter] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState<string>("all");
  const [formData, setFormData] = useState<HealthFormData>({
    babyId: 0,
    recordType: "Temperature",
    date: new Date(),
    temperature: "",
    medicationName: "",
    medicationDose: "",
    medicationSchedule: "",
    doctorNotes: "",
    symptoms: "",
    illnessName: "",
    isSickDay: false,
    notes: "",
  });
  
  // Fetch babies
  const { data: babies } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Calculate date range for filtering
  const getDateRange = () => {
    const today = new Date();
    switch (timeRange) {
      case "week":
        return subDays(today, 7);
      case "month":
        return subDays(today, 30);
      case "3months":
        return subDays(today, 90);
      default:
        return null; // all time
    }
  };
  
  // Fetch health records
  const { data: healthRecords, isLoading } = useQuery<HealthRecordType[]>({
    queryKey: ["/api/babies", selectedBaby?.id, "health"],
    queryFn: async () => {
      if (!selectedBaby) throw new Error("No baby selected");
      const response = await fetch(`/api/babies/${selectedBaby.id}/health`);
      if (!response.ok) {
        throw new Error("Failed to fetch health records");
      }
      return response.json();
    },
    enabled: !!selectedBaby,
  });
  
  // Create health record
  const createMutation = useMutation({
    mutationFn: async (data: HealthFormData) => {
      const response = await apiRequest("POST", `/api/babies/${data.babyId}/health`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "health"] });
      setIsAddModalOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Health record added successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add health record: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Update health record
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number } & HealthFormData) => {
      const response = await apiRequest("PATCH", `/api/babies/${data.babyId}/health/${data.id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "health"] });
      setIsEditModalOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Health record updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update health record: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Delete health record
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/health/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies", selectedBaby?.id, "health"] });
      toast({
        title: "Success",
        description: "Health record deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete health record: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Set the first baby as selected when babies are loaded
  useEffect(() => {
    if (babies && babies.length > 0 && !selectedBaby) {
      setSelectedBaby(babies[0]);
      setFormData(prev => ({ ...prev, babyId: babies[0].id }));
    }
  }, [babies, selectedBaby]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setFormData(prev => ({ ...prev, date }));
    }
  };
  
  const handleAddRecord = () => {
    // Check if a baby is selected
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    
    // Make sure babyId is set correctly
    const modifiedData = { 
      ...formData,
      babyId: selectedBaby.id 
    };
    
    if (formData.recordType === "Illness") {
      let notesWithMetadata = formData.notes || "";
      
      if (formData.symptoms) {
        notesWithMetadata += `\n\nSymptoms: ${formData.symptoms}`;
      }
      
      if (formData.illnessName) {
        notesWithMetadata += `\n\nIllness: ${formData.illnessName}`;
      }
      
      if (formData.isSickDay) {
        notesWithMetadata += `\n\nMarked as sick day`;
      }
      
      modifiedData.notes = notesWithMetadata.trim();
    }
    
    createMutation.mutate(modifiedData);
  };
  
  const handleUpdateRecord = () => {
    if (!currentRecord) return;
    
    // Check if a baby is selected
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "Please select a baby first",
        variant: "destructive",
      });
      return;
    }
    
    // Format data to store metadata in notes field until database schema is updated
    const modifiedData = { 
      ...formData,
      babyId: selectedBaby.id 
    };
    
    if (formData.recordType === "Illness") {
      let notesWithMetadata = formData.notes || "";
      
      if (formData.symptoms) {
        notesWithMetadata += `\n\nSymptoms: ${formData.symptoms}`;
      }
      
      if (formData.illnessName) {
        notesWithMetadata += `\n\nIllness: ${formData.illnessName}`;
      }
      
      if (formData.isSickDay) {
        notesWithMetadata += `\n\nMarked as sick day`;
      }
      
      modifiedData.notes = notesWithMetadata.trim();
    }
    
    updateMutation.mutate({ id: currentRecord.id, ...modifiedData });
  };
  
  const handleEditClick = (record: HealthRecordType) => {
    setCurrentRecord(record);
    
    // Extract illness data from notes field if this is an illness record
    let symptoms = "";
    let illnessName = "";
    let isSickDay = false;
    let notesContent = record.notes || "";
    
    if (record.recordType === "Illness" && record.notes) {
      // Extract symptoms
      const symptomsMatch = record.notes.match(/Symptoms: (.*?)(\n\n|$)/);
      if (symptomsMatch) {
        symptoms = symptomsMatch[1];
        notesContent = notesContent.replace(symptomsMatch[0], "");
      }
      
      // Extract illness name
      const illnessMatch = record.notes.match(/Illness: (.*?)(\n\n|$)/);
      if (illnessMatch) {
        illnessName = illnessMatch[1];
        notesContent = notesContent.replace(illnessMatch[0], "");
      }
      
      // Check if marked as sick day
      isSickDay = record.notes.includes("Marked as sick day");
      if (isSickDay) {
        notesContent = notesContent.replace("Marked as sick day", "").trim();
      }
      
      // Clean up leftover newlines
      notesContent = notesContent.replace(/\n{3,}/g, "\n\n").trim();
    }
    
    setFormData({
      babyId: record.babyId,
      recordType: record.recordType,
      date: new Date(record.date),
      temperature: record.temperature || "",
      medicationName: record.medicationName || "",
      medicationDose: record.medicationDose || "",
      medicationSchedule: record.medicationSchedule || "",
      doctorNotes: record.doctorNotes || "",
      symptoms: symptoms,
      illnessName: illnessName,
      isSickDay: isSickDay,
      notes: notesContent,
    });
    
    setIsEditModalOpen(true);
  };
  
  const handleDeleteClick = (id: number) => {
    if (confirm("Are you sure you want to delete this health record?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const resetForm = () => {
    setFormData({
      babyId: selectedBaby?.id || 0,
      recordType: "Temperature",
      date: new Date(),
      temperature: "",
      medicationName: "",
      medicationDose: "",
      medicationSchedule: "",
      doctorNotes: "",
      symptoms: "",
      illnessName: "",
      isSickDay: false,
      notes: "",
    });
    setCurrentRecord(null);
  };
  
  // Filter records based on type and time range
  const filteredRecords = healthRecords 
    ? healthRecords
        .filter(record => !filter || record.recordType === filter)
        .filter(record => {
          const startDate = getDateRange();
          return !startDate || new Date(record.date) >= startDate;
        })
    : [];
  
  return (
    <div className="container max-w-md mx-auto pb-20">
      <header className="py-6">
        <div className="flex items-center mb-2">
          <Button variant="ghost" size="sm" className="mr-2" asChild>
            <Link to="/reports">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Link>
          </Button>
        </div>
        <h1 className="text-2xl font-bold">Health Tracker</h1>
        <p className="text-muted-foreground">Monitor your baby's health records</p>
      </header>
      
      {/* Emergency Profile Info Card - Only show when baby data is fully loaded */}
      {selectedBaby && selectedBaby.id && (
        <div className="mb-6">
          <EmergencyInfoCard baby={selectedBaby} />
        </div>
      )}
      
      {babies && babies.length > 0 ? (
        <>
          {babies.length > 1 && (
            <Tabs defaultValue={String(selectedBaby?.id)} className="mb-6" onValueChange={(value) => {
              const baby = babies.find(b => b.id === Number(value));
              if (baby) {
                setSelectedBaby(baby);
                setFormData(prev => ({ ...prev, babyId: baby.id }));
              }
            }}>
              <TabsList className="grid grid-cols-3 w-full">
                {babies.map(baby => (
                  <TabsTrigger key={baby.id} value={String(baby.id)}>
                    {baby.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          )}
          
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Health Records</h2>
            <Button onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Record
            </Button>
          </div>
          
          <div className="flex flex-col gap-4 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="type-filter" className="text-sm">Record Type</Label>
                <Select 
                  value={filter || ""} 
                  onValueChange={(value) => setFilter(value || null)}
                >
                  <SelectTrigger id="type-filter">
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    {RECORD_TYPES.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="time-filter" className="text-sm">Time Period</Label>
                <Select 
                  value={timeRange} 
                  onValueChange={setTimeRange}
                >
                  <SelectTrigger id="time-filter">
                    <SelectValue placeholder="All Time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="week">Last Week</SelectItem>
                    <SelectItem value="month">Last Month</SelectItem>
                    <SelectItem value="3months">Last 3 Months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <ScrollArea className="h-[calc(100vh-360px)]">
            {isLoading ? (
              <div className="flex justify-center items-center h-40">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredRecords.length > 0 ? (
              filteredRecords
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map(record => (
                  <HealthRecordCard 
                    key={record.id}
                    record={record}
                    onEdit={handleEditClick}
                    onDelete={handleDeleteClick}
                  />
                ))
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  {filter 
                    ? `No ${filter.toLowerCase()} records found for the selected time period.`
                    : "No health records yet. Start tracking your baby's health!"}
                </p>
              </div>
            )}
          </ScrollArea>
          
          {/* Add Record Modal */}
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Health Record</DialogTitle>
                <DialogDescription>
                  Record a new health entry for your baby
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="recordType">Record Type</Label>
                  <Select
                    value={formData.recordType}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, recordType: value }))}
                  >
                    <SelectTrigger id="recordType">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {RECORD_TYPES.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="date">Date & Time</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "PPP p") : "Select date and time"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={handleDateChange}
                        initialFocus
                      />
                      <div className="p-3 border-t border-border">
                        <Label htmlFor="time" className="text-sm">Time</Label>
                        <Input
                          type="time"
                          id="time"
                          className="mt-1"
                          value={format(formData.date, "HH:mm")}
                          onChange={(e) => {
                            const [hours, minutes] = e.target.value.split(':').map(Number);
                            const newDate = new Date(formData.date);
                            newDate.setHours(hours);
                            newDate.setMinutes(minutes);
                            setFormData(prev => ({ ...prev, date: newDate }));
                          }}
                        />
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>
                
                {formData.recordType === "Temperature" && (
                  <div className="space-y-2">
                    <Label htmlFor="temperature">Temperature</Label>
                    <Input
                      id="temperature"
                      name="temperature"
                      value={formData.temperature}
                      onChange={handleInputChange}
                      placeholder="e.g., 98.6°F"
                    />
                  </div>
                )}
                
                {formData.recordType === "Illness" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="temperature">Temperature (if taken)</Label>
                      <Input
                        id="temperature"
                        name="temperature"
                        value={formData.temperature}
                        onChange={handleInputChange}
                        placeholder="e.g., 98.6°F"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="symptoms">Symptoms</Label>
                      <Input
                        id="symptoms"
                        name="symptoms"
                        value={formData.symptoms}
                        onChange={handleInputChange}
                        placeholder="e.g., cough, runny nose, fever"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="illnessName">Illness</Label>
                      <Input
                        id="illnessName"
                        name="illnessName"
                        value={formData.illnessName}
                        onChange={handleInputChange}
                        placeholder="e.g., Cold, Flu, Ear infection"
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2 py-2">
                      <Checkbox 
                        id="isSickDay" 
                        checked={formData.isSickDay}
                        onCheckedChange={(checked) => {
                          setFormData(prev => ({
                            ...prev,
                            isSickDay: checked === true
                          }));
                        }}
                      />
                      <Label htmlFor="isSickDay" className="text-sm font-normal">
                        Mark as sick day
                      </Label>
                    </div>
                  </>
                )}
                
                {formData.recordType === "Medication" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="medicationName">Medication Name</Label>
                      <Input
                        id="medicationName"
                        name="medicationName"
                        value={formData.medicationName}
                        onChange={handleInputChange}
                        placeholder="e.g., Tylenol"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="medicationDose">Dose</Label>
                      <Input
                        id="medicationDose"
                        name="medicationDose"
                        value={formData.medicationDose}
                        onChange={handleInputChange}
                        placeholder="e.g., 2.5ml"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="medicationSchedule">Schedule</Label>
                      <Input
                        id="medicationSchedule"
                        name="medicationSchedule"
                        value={formData.medicationSchedule}
                        onChange={handleInputChange}
                        placeholder="e.g., Every 6 hours for 3 days"
                      />
                    </div>
                  </>
                )}
                
                {formData.recordType === "Doctor Visit" && (
                  <div className="space-y-2">
                    <Label htmlFor="doctorNotes">Doctor Notes</Label>
                    <Textarea
                      id="doctorNotes"
                      name="doctorNotes"
                      value={formData.doctorNotes}
                      onChange={handleInputChange}
                      placeholder="Add notes from the doctor's visit..."
                      rows={3}
                    />
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Add any additional notes..."
                    rows={3}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleAddRecord}
                  disabled={createMutation.isPending || (
                    formData.recordType === "Temperature" && !formData.temperature ||
                    formData.recordType === "Medication" && !formData.medicationName ||
                    formData.recordType === "Doctor Visit" && !formData.doctorNotes
                  )}
                >
                  {createMutation.isPending && (
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                  )}
                  Save Record
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Edit Record Modal */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Health Record</DialogTitle>
                <DialogDescription>
                  Update the health record details
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-recordType">Record Type</Label>
                  <Select
                    value={formData.recordType}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, recordType: value }))}
                  >
                    <SelectTrigger id="edit-recordType">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {RECORD_TYPES.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-date">Date & Time</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "PPP p") : "Select date and time"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={handleDateChange}
                        initialFocus
                      />
                      <div className="p-3 border-t border-border">
                        <Label htmlFor="edit-time" className="text-sm">Time</Label>
                        <Input
                          type="time"
                          id="edit-time"
                          className="mt-1"
                          value={format(formData.date, "HH:mm")}
                          onChange={(e) => {
                            const [hours, minutes] = e.target.value.split(':').map(Number);
                            const newDate = new Date(formData.date);
                            newDate.setHours(hours);
                            newDate.setMinutes(minutes);
                            setFormData(prev => ({ ...prev, date: newDate }));
                          }}
                        />
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>
                
                {formData.recordType === "Temperature" && (
                  <div className="space-y-2">
                    <Label htmlFor="edit-temperature">Temperature</Label>
                    <Input
                      id="edit-temperature"
                      name="temperature"
                      value={formData.temperature}
                      onChange={handleInputChange}
                      placeholder="e.g., 98.6°F"
                    />
                  </div>
                )}
                
                {formData.recordType === "Illness" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="edit-temperature">Temperature (if taken)</Label>
                      <Input
                        id="edit-temperature"
                        name="temperature"
                        value={formData.temperature}
                        onChange={handleInputChange}
                        placeholder="e.g., 98.6°F"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="edit-symptoms">Symptoms</Label>
                      <Input
                        id="edit-symptoms"
                        name="symptoms"
                        value={formData.symptoms}
                        onChange={handleInputChange}
                        placeholder="e.g., cough, runny nose, fever"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="edit-illnessName">Illness</Label>
                      <Input
                        id="edit-illnessName"
                        name="illnessName"
                        value={formData.illnessName}
                        onChange={handleInputChange}
                        placeholder="e.g., Cold, Flu, Ear infection"
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2 py-2">
                      <Checkbox 
                        id="edit-isSickDay" 
                        checked={formData.isSickDay}
                        onCheckedChange={(checked) => {
                          setFormData(prev => ({
                            ...prev,
                            isSickDay: checked === true
                          }));
                        }}
                      />
                      <Label htmlFor="edit-isSickDay" className="text-sm font-normal">
                        Mark as sick day
                      </Label>
                    </div>
                  </>
                )}
                
                {formData.recordType === "Medication" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="edit-medicationName">Medication Name</Label>
                      <Input
                        id="edit-medicationName"
                        name="medicationName"
                        value={formData.medicationName}
                        onChange={handleInputChange}
                        placeholder="e.g., Tylenol"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="edit-medicationDose">Dose</Label>
                      <Input
                        id="edit-medicationDose"
                        name="medicationDose"
                        value={formData.medicationDose}
                        onChange={handleInputChange}
                        placeholder="e.g., 2.5ml"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="edit-medicationSchedule">Schedule</Label>
                      <Input
                        id="edit-medicationSchedule"
                        name="medicationSchedule"
                        value={formData.medicationSchedule}
                        onChange={handleInputChange}
                        placeholder="e.g., Every 6 hours for 3 days"
                      />
                    </div>
                  </>
                )}
                
                {formData.recordType === "Doctor Visit" && (
                  <div className="space-y-2">
                    <Label htmlFor="edit-doctorNotes">Doctor Notes</Label>
                    <Textarea
                      id="edit-doctorNotes"
                      name="doctorNotes"
                      value={formData.doctorNotes}
                      onChange={handleInputChange}
                      placeholder="Add notes from the doctor's visit..."
                      rows={3}
                    />
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="edit-notes">Additional Notes</Label>
                  <Textarea
                    id="edit-notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Add any additional notes..."
                    rows={3}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleUpdateRecord}
                  disabled={updateMutation.isPending || (
                    formData.recordType === "Temperature" && !formData.temperature ||
                    formData.recordType === "Medication" && !formData.medicationName ||
                    formData.recordType === "Doctor Visit" && !formData.doctorNotes
                  )}
                >
                  {updateMutation.isPending && (
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                  )}
                  Update Record
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">No babies added yet. Add a baby in the Home page first.</p>
        </div>
      )}
      
      <BottomNavigation currentTab="reports" />
    </div>
  );
}