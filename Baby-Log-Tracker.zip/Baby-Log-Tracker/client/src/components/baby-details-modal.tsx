import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Baby } from "@shared/schema";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Define schema for baby details form
const babyDetailsSchema = z.object({
  allergies: z.string().optional().nullable(),
  likes: z.string().optional().nullable(),
  dislikes: z.string().optional().nullable(),
  hairColor: z.string().optional().nullable(),
  eyeColor: z.string().optional().nullable(),
  height: z.string().optional().nullable(),
  weight: z.string().optional().nullable(),
  birthmarks: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

type BabyDetailsFormValues = z.infer<typeof babyDetailsSchema>;

interface BabyDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  baby: Baby | null;
}

export function BabyDetailsModal({ isOpen, onClose, baby }: BabyDetailsModalProps) {
  const { toast } = useToast();
  
  const form = useForm<BabyDetailsFormValues>({
    resolver: zodResolver(babyDetailsSchema),
    defaultValues: {
      allergies: baby?.allergies || "",
      likes: baby?.likes || "",
      dislikes: baby?.dislikes || "",
      hairColor: baby?.hairColor || "",
      eyeColor: baby?.eyeColor || "",
      height: baby?.height || "",
      weight: baby?.weight || "",
      birthmarks: baby?.birthmarks || "",
      notes: baby?.notes || "",
    }
  });
  
  // Update form when baby changes
  useEffect(() => {
    if (baby) {
      form.reset({
        allergies: baby.allergies || "",
        likes: baby.likes || "",
        dislikes: baby.dislikes || "",
        hairColor: baby.hairColor || "",
        eyeColor: baby.eyeColor || "",
        height: baby.height || "",
        weight: baby.weight || "",
        birthmarks: baby.birthmarks || "",
        notes: baby.notes || "",
      });
    }
  }, [baby, form]);
  
  const updateBabyMutation = useMutation({
    mutationFn: async (data: BabyDetailsFormValues) => {
      if (!baby) return null;
      
      const response = await apiRequest(
        "PATCH",
        `/api/babies/${baby.id}`,
        data
      );
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/babies"] });
      toast({
        title: "Success",
        description: "Baby details updated successfully",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update baby details",
        variant: "destructive",
      });
    }
  });
  
  function handleSubmit(data: BabyDetailsFormValues) {
    updateBabyMutation.mutate(data);
  }
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Baby Details</DialogTitle>
          <DialogDescription>
            Add more details about {baby?.name} to personalize your baby tracking experience.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="hairColor"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Hair Color</FormLabel>
                    <FormControl>
                      <Input placeholder="Hair Color" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="eyeColor"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Eye Color</FormLabel>
                    <FormControl>
                      <Input placeholder="Eye Color" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="height"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Height</FormLabel>
                    <FormControl>
                      <Input placeholder="Height" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="weight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Weight</FormLabel>
                    <FormControl>
                      <Input placeholder="Weight" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="birthmarks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Birthmarks</FormLabel>
                    <FormControl>
                      <Input placeholder="Birthmarks" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="allergies"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Allergies</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="List any allergies here" 
                      className="resize-none" 
                      {...field} 
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="likes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Likes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Things your baby likes" 
                        className="resize-none" 
                        {...field} 
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="dislikes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Dislikes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Things your baby dislikes" 
                        className="resize-none" 
                        {...field} 
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any other information you want to record" 
                      className="resize-none" 
                      {...field} 
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={updateBabyMutation.isPending}>
                {updateBabyMutation.isPending ? "Saving..." : "Save Details"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}