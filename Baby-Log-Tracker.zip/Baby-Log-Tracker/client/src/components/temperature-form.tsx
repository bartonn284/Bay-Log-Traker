import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Thermometer, 
  ArrowLeft, 
  AlertTriangle,
  ThermometerSnowflake,
  ThermometerSun
} from "lucide-react";
import { insertHealthRecordSchema } from "@shared/schema";

// Define temperature form schema
const temperatureFormSchema = insertHealthRecordSchema
  .pick({
    babyId: true,
    recordType: true,
    date: true,
    temperature: true,
    symptoms: true,
    illnessName: true,
    notes: true,
  })
  .extend({
    date: z.string().min(1, { message: "Date is required" }),
    temperature: z.string().min(1, { message: "Temperature is required" }),
    unit: z.enum(["F", "C"]),
    isSickDay: z.boolean().default(false),
  });

type TemperatureFormValues = z.infer<typeof temperatureFormSchema>;

interface TemperatureFormProps {
  babyId: number;
  onBack: () => void;
  onSuccess: () => void;
}

export function TemperatureForm({ babyId, onBack, onSuccess }: TemperatureFormProps) {
  const { toast } = useToast();
  const [isManualTemp, setIsManualTemp] = useState(true);
  
  // Define form with default values
  const form = useForm<TemperatureFormValues>({
    resolver: zodResolver(temperatureFormSchema),
    defaultValues: {
      babyId,
      recordType: "temperature",
      date: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      temperature: "",
      unit: "F",
      symptoms: "",
      illnessName: "",
      isSickDay: false,
      notes: "",
    },
  });
  
  // Create mutation for submitting temperature record
  const createTemperatureMutation = useMutation({
    mutationFn: async (data: any) => {
      // Format temperature with unit
      const formattedTemp = `${data.temperature}°${data.unit}`;
      
      // Prepare data for API
      // Store symptoms and illness data in notes field until database schema is updated
      let notesWithMetadata = data.notes || "";
      
      if (data.symptoms) {
        notesWithMetadata += `\n\nSymptoms: ${data.symptoms}`;
      }
      
      if (data.illnessName) {
        notesWithMetadata += `\n\nIllness: ${data.illnessName}`;
      }
      
      if (data.isSickDay) {
        notesWithMetadata += `\n\nMarked as sick day`;
      }
      
      const payload = {
        babyId: data.babyId,
        recordType: data.recordType,
        date: new Date(data.date).toISOString(),
        temperature: formattedTemp,
        notes: notesWithMetadata.trim(),
        createdBy: 1, // This should be the current user ID
      };
      
      const res = await apiRequest("POST", "/api/health-records", payload);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to save temperature record");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/health-records"] });
      toast({
        title: "Temperature recorded",
        description: "The temperature has been successfully recorded.",
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to record temperature",
        variant: "destructive",
      });
    },
  });
  
  function onSubmit(data: TemperatureFormValues) {
    createTemperatureMutation.mutate(data);
  }
  
  const watchTemperature = form.watch("temperature");
  const watchUnit = form.watch("unit");
  
  // Determine if temperature is concerning
  const isFever = () => {
    const temp = parseFloat(watchTemperature);
    if (isNaN(temp)) return false;
    
    if (watchUnit === "F") {
      return temp >= 100.4; // 100.4°F is considered a fever
    } else {
      return temp >= 38; // 38°C is considered a fever
    }
  };
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl flex items-center">
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-0 mr-2 h-8 w-8" 
            onClick={onBack}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Thermometer className="mr-2 h-6 w-6 text-red-500" />
          Record Temperature
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Temperature Input */}
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <FormLabel className="text-base">Temperature Reading</FormLabel>
                
                <div className="mb-3 flex items-center space-x-2">
                  <Button 
                    type="button" 
                    variant={isManualTemp ? "default" : "outline"} 
                    size="sm"
                    onClick={() => setIsManualTemp(true)}
                  >
                    Manual Input
                  </Button>
                  <Button 
                    type="button" 
                    variant={!isManualTemp ? "default" : "outline"} 
                    size="sm"
                    onClick={() => setIsManualTemp(false)}
                    disabled
                  >
                    Smart Thermometer
                  </Button>
                </div>
              </div>
              
              <FormField
                control={form.control}
                name="temperature"
                render={({ field }) => (
                  <FormItem className="flex-grow">
                    <FormControl>
                      <Input
                        type="number"
                        placeholder={form.getValues("unit") === "F" ? "98.6" : "37.0"}
                        step="0.1"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="unit"
                render={({ field }) => (
                  <FormItem>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Unit" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="F">°F (Fahrenheit)</SelectItem>
                        <SelectItem value="C">°C (Celsius)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Display warning if fever detected */}
            {isFever() && (
              <div className="rounded-lg bg-red-100 border border-red-200 p-3 flex items-start space-x-2">
                <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                <div>
                  <p className="font-medium text-red-800">
                    Possible fever detected
                  </p>
                  <p className="text-sm text-red-600">
                    This temperature reading indicates a fever. Consider consulting a healthcare provider if other symptoms are present.
                  </p>
                </div>
              </div>
            )}
            
            {/* Temperature visualization */}
            <div className="py-2">
              <div className="flex items-center justify-center">
                <ThermometerSnowflake className="h-5 w-5 text-blue-500" />
                <div className="h-2 w-full bg-gradient-to-r from-blue-500 via-green-400 to-red-500 rounded-full mx-2" />
                <ThermometerSun className="h-5 w-5 text-red-500" />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>{watchUnit === "F" ? "95°F" : "35°C"}</span>
                <span>{watchUnit === "F" ? "98.6°F" : "37°C"}</span>
                <span>{watchUnit === "F" ? "102°F" : "39°C"}</span>
              </div>
            </div>
            
            {/* Date and Time */}
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date & Time</FormLabel>
                  <FormControl>
                    <Input type="datetime-local" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Symptoms */}
            <FormField
              control={form.control}
              name="symptoms"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Symptoms (if any)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g., cough, rash, runny nose" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Separate multiple symptoms with commas
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Illness Name */}
            <FormField
              control={form.control}
              name="illnessName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Illness Name (if known)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g., cold, flu, ear infection" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Sick Day Flag */}
            <FormField
              control={form.control}
              name="isSickDay"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>
                      Mark as a sick day
                    </FormLabel>
                    <FormDescription>
                      This will help track illness patterns
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
            
            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Add any additional details" 
                      className="resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <CardFooter className="px-0 pt-4 flex justify-between">
              <Button variant="outline" onClick={onBack}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createTemperatureMutation.isPending}
              >
                {createTemperatureMutation.isPending ? "Saving..." : "Save Record"}
              </Button>
            </CardFooter>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}