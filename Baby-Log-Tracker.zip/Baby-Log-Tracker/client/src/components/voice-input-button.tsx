import React, { useState } from 'react';
import { VoiceRecognition } from './voice-recognition';
import { VoiceInputConfirmation } from './voice-input-confirmation';
import { toast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useBabyContext } from '@/hooks/use-baby-context';

interface VoiceInputButtonProps {
  className?: string;
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  buttonText?: string;
  onClose?: () => void;
}

export function VoiceInputButton({
  className = "",
  variant = "outline",
  size = "default",
  buttonText = "Voice Input",
  onClose
}: VoiceInputButtonProps) {
  const [voiceText, setVoiceText] = useState("");
  const [parsedData, setParsedData] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  // Get the selected baby from the context
  const { selectedBaby } = useBabyContext();

  const handleVoiceResult = (text: string) => {
    setVoiceText(text);
    toast({
      title: "Voice input received",
      description: text,
    });
  };

  const handleParsedData = (data: any) => {
    setParsedData(data);
    setIsDialogOpen(true);
  };

  const handleConfirm = async (confirmedData: any) => {
    if (!selectedBaby?.id) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }

    try {
      // Format the data for the API based on activity type
      let apiEndpoint = '';
      let requestData = {};

      switch (confirmedData.type) {
        case 'bottle':
        case 'breast':
          apiEndpoint = `/api/babies/${selectedBaby.id}/feedings`;
          requestData = {
            babyId: selectedBaby.id,
            type: confirmedData.type,
            startTime: confirmedData.time,
            ...(confirmedData.type === 'bottle' && { amount: confirmedData.amount }),
            ...(confirmedData.type === 'breast' && { 
              side: confirmedData.side,
              duration: confirmedData.duration 
            }),
            notes: confirmedData.notes
          };
          break;
          
        case 'feeding':
          apiEndpoint = `/api/babies/${selectedBaby.id}/feedings`;
          // Determine if it's a bottle or breast feeding
          const feedingType = confirmedData.feedingType || 'bottle';
          requestData = {
            babyId: selectedBaby.id,
            type: feedingType,
            startTime: confirmedData.time,
            ...(feedingType === 'bottle' && { amount: confirmedData.amount }),
            ...(feedingType === 'breast' && { 
              side: confirmedData.side,
              duration: confirmedData.duration 
            }),
            notes: confirmedData.notes
          };
          break;
          
        case 'completed_sleep':
          // This is a special case for past tense expressions like "baby slept for 2 hours"
          // We create a completed sleep entry with start and end times calculated from duration
          apiEndpoint = `/api/babies/${selectedBaby.id}/sleeps`;
          
          // If we have duration, calculate a start time that would end at current time
          const endTime = new Date(confirmedData.time);
          const startTime = new Date(endTime);
          
          if (confirmedData.duration) {
            // Subtract the duration (in minutes) from the end time to get start time
            startTime.setMinutes(startTime.getMinutes() - confirmedData.duration);
          } else {
            // Default to 1 hour if no duration specified
            startTime.setHours(startTime.getHours() - 1);
          }
          
          requestData = {
            babyId: selectedBaby.id,
            type: 'nap',
            startTime: startTime.toISOString(),
            endTime: endTime.toISOString(),
            notes: confirmedData.notes || 'Logged via voice input (past tense)'
          };
          
          console.log('Completed sleep entry:', requestData);
          break;
          
        case 'sleep':
          apiEndpoint = `/api/babies/${selectedBaby.id}/sleeps`;
          
          if (confirmedData.sleepStatus === 'end') {
            // Find the most recent active sleep to end it
            const sleepsResponse = await apiRequest('GET', `/api/babies/${selectedBaby.id}/sleeps`);
            const sleeps = await sleepsResponse.json();
            const activeSleep = sleeps.find((s: any) => s.endTime === null);
            
            if (activeSleep) {
              apiEndpoint = `/api/babies/${selectedBaby.id}/sleeps/${activeSleep.id}`;
              requestData = {
                endTime: confirmedData.time,
                notes: confirmedData.notes || activeSleep.notes
              };
            } else {
              toast({
                title: "No active sleep session",
                description: "Could not find an active sleep session to end",
                variant: "destructive",
              });
              return;
            }
          } else {
            // Start a new sleep session
            requestData = {
              babyId: selectedBaby.id,
              type: 'nap',  // Add required field 'type' with default value
              startTime: confirmedData.time || new Date().toISOString(), // Ensure startTime is present
              ...(confirmedData.duration && { duration: confirmedData.duration }),
              notes: confirmedData.notes || ''
            };
            
            // Add validation logging
            console.log('Sleep request data:', requestData);
          }
          break;
          
        case 'diaper':
          apiEndpoint = `/api/babies/${selectedBaby.id}/diapers`;
          
          // Validate diaper type and convert mixed/both to 'both'
          let diaperType = confirmedData.diaperType || 'wet';
          if (diaperType === 'mixed') {
            diaperType = 'both'; // API expects 'both', not 'mixed'
          }
          
          // Make sure we have a valid time
          const time = confirmedData.time || new Date().toISOString();
          
          // Log what we're submitting for debugging
          console.log('Saving diaper entry:', {
            type: diaperType,
            time,
            consistency: confirmedData.consistency
          });
          
          requestData = {
            babyId: selectedBaby.id,
            time: time,
            type: diaperType,
            ...(confirmedData.consistency && { consistency: confirmedData.consistency }),
            notes: confirmedData.notes || ''
          };
          break;
          
        case 'medication':
          // Medication might use a different endpoint based on your app structure
          // Here we'll assume it's handled as a health record
          apiEndpoint = `/api/babies/${selectedBaby.id}/health`;
          requestData = {
            babyId: selectedBaby.id,
            time: confirmedData.time,
            type: 'medication',
            details: {
              medication: confirmedData.medicationType,
              dose: confirmedData.dose
            },
            notes: confirmedData.notes
          };
          break;
        
        case 'mood':
          apiEndpoint = `/api/babies/${selectedBaby.id}/moods`;
          requestData = {
            babyId: selectedBaby.id,
            time: confirmedData.time,
            mood: confirmedData.mood || 'happy',
            crying: !!confirmedData.crying,
            cryDuration: confirmedData.cryDuration || 0,
            cryReason: confirmedData.cryReason || '',
            notes: confirmedData.notes || ''
          };
          break;
          
        case 'supply':
          apiEndpoint = `/api/supplies`;
          requestData = {
            userId: selectedBaby.ownerId, // Supplies are tracked by user, not by baby
            name: confirmedData.supplyName || 'Unspecified item',
            category: confirmedData.supplyCategory || 'other',
            status: 'needed',
            priority: confirmedData.supplyPriority || 'medium',
            notes: confirmedData.notes || ''
          };
          break;
          
        case 'milestone':
          apiEndpoint = `/api/babies/${selectedBaby.id}/milestones`;
          requestData = {
            babyId: selectedBaby.id,
            time: confirmedData.time,
            type: confirmedData.milestoneType || 'other',
            category: confirmedData.milestoneCategory || 'other',
            notes: confirmedData.notes || ''
          };
          break;
          
        default:
          toast({
            title: "Unknown activity type",
            description: "Could not determine what type of activity to log",
            variant: "destructive",
          });
          return;
      }

      // Make the API request
      const requestMethod = confirmedData.sleepStatus === 'end' && confirmedData.type === 'sleep' ? 'PATCH' : 'POST';
      await apiRequest(requestMethod, apiEndpoint, requestData);
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby.id}/feedings`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby.id}/sleeps`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby.id}/diapers`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby.id}/health`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby.id}/moods`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby.id}/milestones`] });
      queryClient.invalidateQueries({ queryKey: [`/api/supplies`] });
      
      // Invalidate date-specific queries with any date parameter to ensure all views refresh
      const currentDate = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
      queryClient.invalidateQueries({ 
        queryKey: [`/api/babies/${selectedBaby.id}/daily`]
      });
      queryClient.invalidateQueries({ 
        queryKey: [`/api/babies/${selectedBaby.id}/daily`, currentDate]
      });
      
      // Invalidate analytics data
      queryClient.invalidateQueries({ 
        queryKey: [`/api/babies/${selectedBaby.id}/analytics`]
      });
      
      // Invalidate metrics for dashboard
      queryClient.invalidateQueries({ 
        queryKey: [`/api/babies/${selectedBaby.id}/metrics`]
      });
      
      // Invalidate the general babies list query which might contain summary stats
      queryClient.invalidateQueries({
        queryKey: ['/api/babies']
      });

      // Show success message
      toast({
        title: "Entry saved successfully",
        description: `Your ${confirmedData.type} entry has been saved.`,
      });
      
      // Close the voice input dialog if onClose callback is provided
      if (onClose) {
        onClose();
      }
      
    } catch (error: any) {
      console.error('Error saving voice entry:', error);
      
      // Enhanced error logging for debugging
      if (error.response) {
        console.error('Response data:', error.response.data);
        console.error('Response status:', error.response.status);
      }
      
      // Provide more specific error message if available
      let errorMessage = "There was an error saving your entry. Please try again.";
      
      if (error.message) {
        // Check for common validation errors
        if (error.message.includes("required")) {
          errorMessage = "Missing required fields. Make sure to include all necessary information.";
        } else if (error.message.includes("format")) {
          errorMessage = "Data format error. Please check your input.";
        } else if (error.message.includes("401") || error.message.includes("unauthorized")) {
          errorMessage = "Session expired. Please refresh the page and try again.";
        } else {
          errorMessage = `Error: ${error.message}`;
        }
      }
      
      toast({
        title: "Failed to save entry",
        description: errorMessage,
        variant: "destructive",
      });
      
      // Also close the dialog on error if onClose is provided
      if (onClose) {
        onClose();
      }
    }
  };

  return (
    <>
      <VoiceRecognition
        onResult={handleVoiceResult}
        onParsed={handleParsedData}
        className={className}
        variant={variant}
        size={size}
        buttonText={buttonText}
        parseCommand={true}
      />
      
      {parsedData && (
        <VoiceInputConfirmation
          isOpen={isDialogOpen}
          onClose={() => setIsDialogOpen(false)}
          parsedData={parsedData}
          rawText={voiceText}
          onConfirm={handleConfirm}
        />
      )}
    </>
  );
}