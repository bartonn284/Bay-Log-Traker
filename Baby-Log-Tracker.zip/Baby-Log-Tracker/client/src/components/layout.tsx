import { ReactNode, useEffect, useState } from "react";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Bell, Plus, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BabySelector } from "@/components/baby-selector-new";
import { useBabyContext } from "@/hooks/use-baby-context";
import { useQuery } from "@tanstack/react-query";
import { Baby } from "@shared/schema";

type LayoutProps = {
  children: ReactNode;
  title: string;
  currentTab: string;
  onLogButtonClick?: () => void;
  showBabySelector?: boolean;
};

export function Layout({ 
  children, 
  title, 
  currentTab, 
  onLogButtonClick,
  showBabySelector = true 
}: LayoutProps) {
  const { selectedBaby, setSelectedBaby } = useBabyContext();
  
  // Fetch all babies
  const { data: babies } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
  });
  
  return (
    <div className="app-container">
      <header className="bg-background px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-primary">{title}</h1>
          </div>
          
          <div className="flex space-x-2">
          </div>
        </div>
        
        {showBabySelector && (
          <div className="flex items-center py-1">
            <div className="flex-1">
              {selectedBaby !== null && (
                <BabySelector 
                  selectedBaby={selectedBaby} 
                  onSelectBaby={setSelectedBaby}
                  showQuickNav={true}
                />
              )}
            </div>
          </div>
        )}
      </header>
      
      <main className="flex-1 overflow-y-auto pb-16">
        {children}
      </main>
      
      <BottomNavigation currentTab={currentTab} onLogButtonClick={onLogButtonClick} />
    </div>
  );
}
