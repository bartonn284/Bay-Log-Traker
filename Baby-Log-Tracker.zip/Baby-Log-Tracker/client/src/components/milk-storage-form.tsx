import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { BabySpinner } from "@/components/baby-spinner";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format, addDays, addMonths } from "date-fns";

// Form schema with validation
const milkStorageFormSchema = z.object({
  containerId: z.string().optional(),
  storageType: z.enum(["fridge", "freezer"]),
  amount: z.coerce.number().min(10, "Amount must be at least 10ml"),
  pumpSessionId: z.coerce.number().optional(),
  storedDate: z.string().nonempty("Storage date is required"),
  expiryDate: z.string().optional(),
  notes: z.string().optional(),
});

type MilkStorageFormValues = z.infer<typeof milkStorageFormSchema>;

interface MilkStorageFormProps {
  babyId: number;
  milkStorage?: any;
  onSuccess: () => void;
  onCancel: () => void;
}

export function MilkStorageForm({ babyId, milkStorage, onSuccess, onCancel }: MilkStorageFormProps) {
  const { toast } = useToast();
  const [autoContainerId, setAutoContainerId] = useState<string>("");
  
  // Generate a unique container ID if not editing
  useEffect(() => {
    if (!milkStorage) {
      const timestamp = Date.now().toString(36).toUpperCase();
      const randomChars = Math.random().toString(36).substring(2, 5).toUpperCase();
      setAutoContainerId(`MILK-${timestamp.slice(-4)}-${randomChars}`);
    }
  }, [milkStorage]);
  
  // Fetch pump sessions for dropdown
  const { data: pumpSessions } = useQuery({
    queryKey: ["/api/babies", babyId, "pump-sessions"],
    queryFn: async () => {
      const res = await fetch(`/api/babies/${babyId}/pump-sessions`);
      if (!res.ok) throw new Error("Failed to fetch pump sessions");
      return res.json();
    },
    enabled: !!babyId,
  });
  
  // Default values
  const defaultValues: MilkStorageFormValues = {
    containerId: milkStorage?.containerId || autoContainerId,
    storageType: milkStorage?.storageType || "fridge",
    amount: milkStorage?.amount || 0,
    pumpSessionId: milkStorage?.pumpSessionId || undefined,
    storedDate: milkStorage?.storedDate 
      ? format(new Date(milkStorage.storedDate), "yyyy-MM-dd'T'HH:mm") 
      : format(new Date(), "yyyy-MM-dd'T'HH:mm"),
    expiryDate: milkStorage?.expiryDate 
      ? format(new Date(milkStorage.expiryDate), "yyyy-MM-dd'T'HH:mm") 
      : undefined,
    notes: milkStorage?.notes || "",
  };
  
  // Initialize form
  const form = useForm<MilkStorageFormValues>({
    resolver: zodResolver(milkStorageFormSchema),
    defaultValues,
  });
  
  // Create/update mutation
  const mutation = useMutation({
    mutationFn: async (values: MilkStorageFormValues) => {
      if (milkStorage) {
        // Update existing entry
        const res = await apiRequest("PUT", `/api/milk-storage/${milkStorage.id}`, values);
        return await res.json();
      } else {
        // Create new entry
        const res = await apiRequest("POST", `/api/babies/${babyId}/milk-storage`, values);
        return await res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: milkStorage ? "Updated milk storage" : "Added milk storage",
        description: "Your milk storage information has been saved.",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Auto-calculate expiry date when storage type or date changes
  useEffect(() => {
    const subscription = form.watch(({ storageType, storedDate }) => {
      if (storageType && storedDate) {
        const storedDateTime = new Date(storedDate);
        let expiryDateTime: Date;
        
        if (storageType === 'fridge') {
          // 4 days for fridge
          expiryDateTime = addDays(storedDateTime, 4);
        } else {
          // 6 months for freezer
          expiryDateTime = addMonths(storedDateTime, 6);
        }
        
        form.setValue("expiryDate", format(expiryDateTime, "yyyy-MM-dd'T'HH:mm"));
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form]);
  
  // Handle form submission
  const onSubmit = async (values: MilkStorageFormValues) => {
    mutation.mutate(values);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-4">
        <FormField
          control={form.control}
          name="containerId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Container ID</FormLabel>
              <FormControl>
                <Input 
                  placeholder="e.g., MILK-2A3B" 
                  {...field} 
                  value={field.value || autoContainerId}
                />
              </FormControl>
              <FormDescription>
                A unique identifier for this container of milk
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="storageType"
          render={({ field }) => (
            <FormItem className="space-y-3">
              <FormLabel>Storage Type</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex space-x-4"
                >
                  <FormItem className="flex items-center space-x-2 space-y-0">
                    <FormControl>
                      <RadioGroupItem value="fridge" />
                    </FormControl>
                    <FormLabel className="font-normal">
                      Fridge (4 days)
                    </FormLabel>
                  </FormItem>
                  <FormItem className="flex items-center space-x-2 space-y-0">
                    <FormControl>
                      <RadioGroupItem value="freezer" />
                    </FormControl>
                    <FormLabel className="font-normal">
                      Freezer (6 months)
                    </FormLabel>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Amount (ml)</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  {...field}
                  onChange={(e) => {
                    field.onChange(e.target.valueAsNumber || 0);
                  }}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="storedDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Storage Date</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="expiryDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Expiry Date</FormLabel>
                <FormControl>
                  <Input 
                    type="datetime-local" 
                    {...field} 
                    value={field.value || ""} 
                  />
                </FormControl>
                <FormDescription>
                  Auto-calculated based on storage type
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="pumpSessionId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Related Pump Session (Optional)</FormLabel>
              <FormControl>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  {...field}
                  onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                  value={field.value || ""}
                >
                  <option value="">-- None --</option>
                  {pumpSessions && pumpSessions.map((session: any) => (
                    <option key={session.id} value={session.id}>
                      {format(new Date(session.startTime), "MMM d, yyyy h:mm a")} - {session.totalAmount}ml
                    </option>
                  ))}
                </select>
              </FormControl>
              <FormDescription>
                Link this storage to a specific pumping session
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Add any additional details about this milk storage..."
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? (
              <>
                <BabySpinner type="bottle" size="sm" className="mr-2" />
                Saving...
              </>
            ) : milkStorage ? (
              "Update Storage"
            ) : (
              "Save Storage"
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}