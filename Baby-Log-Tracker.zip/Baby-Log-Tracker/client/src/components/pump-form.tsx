import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { BabySpinner } from "@/components/baby-spinner";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";

// Form schema with validation
const pumpFormSchema = z.object({
  startTime: z.string().nonempty("Start time is required"),
  endTime: z.string().optional(),
  amountLeftBreast: z.coerce.number().min(0, "Amount cannot be negative").optional(),
  amountRightBreast: z.coerce.number().min(0, "Amount cannot be negative").optional(),
  totalAmount: z.coerce.number().min(0, "Amount cannot be negative").optional(),
  duration: z.coerce.number().min(0, "Duration cannot be negative").optional(),
  notes: z.string().optional(),
});

type PumpFormValues = z.infer<typeof pumpFormSchema>;

interface PumpFormProps {
  babyId: number;
  pumpSession?: any;
  onSuccess: () => void;
  onCancel: () => void;
}

export function PumpForm({ babyId, pumpSession, onSuccess, onCancel }: PumpFormProps) {
  const { toast } = useToast();
  const [isCalculating, setIsCalculating] = useState<boolean>(false);
  
  // Default values
  const defaultValues: PumpFormValues = {
    startTime: pumpSession ? format(new Date(pumpSession.startTime), "yyyy-MM-dd'T'HH:mm") : format(new Date(), "yyyy-MM-dd'T'HH:mm"),
    endTime: pumpSession?.endTime ? format(new Date(pumpSession.endTime), "yyyy-MM-dd'T'HH:mm") : undefined,
    amountLeftBreast: pumpSession?.amountLeftBreast || 0,
    amountRightBreast: pumpSession?.amountRightBreast || 0,
    totalAmount: pumpSession?.totalAmount || 0,
    duration: pumpSession?.duration || 0,
    notes: pumpSession?.notes || "",
  };
  
  // Initialize form
  const form = useForm<PumpFormValues>({
    resolver: zodResolver(pumpFormSchema),
    defaultValues,
  });
  
  // Create/update mutation
  const mutation = useMutation({
    mutationFn: async (values: PumpFormValues) => {
      if (pumpSession) {
        // Update existing session
        const res = await apiRequest("PUT", `/api/pump-sessions/${pumpSession.id}`, values);
        return await res.json();
      } else {
        // Create new session
        const res = await apiRequest("POST", `/api/babies/${babyId}/pump-sessions`, values);
        return await res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: pumpSession ? "Updated pump session" : "Recorded pump session",
        description: "Your pumping data has been saved.",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Auto-calculate total amount when breast amounts change
  useEffect(() => {
    const subscription = form.watch(({ amountLeftBreast, amountRightBreast }) => {
      if (typeof amountLeftBreast === 'number' || typeof amountRightBreast === 'number') {
        const left = typeof amountLeftBreast === 'number' ? amountLeftBreast : 0;
        const right = typeof amountRightBreast === 'number' ? amountRightBreast : 0;
        form.setValue("totalAmount", left + right);
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form]);
  
  // Auto-calculate duration when times change
  useEffect(() => {
    const subscription = form.watch(({ startTime, endTime }) => {
      if (startTime && endTime) {
        const start = new Date(startTime);
        const end = new Date(endTime);
        
        if (start && end && end > start) {
          // Calculate duration in minutes
          const durationMinutes = Math.round((end.getTime() - start.getTime()) / (1000 * 60));
          form.setValue("duration", durationMinutes);
        }
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form]);
  
  // Handle form submission
  const onSubmit = async (values: PumpFormValues) => {
    mutation.mutate(values);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="startTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Start Time</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="endTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>End Time</FormLabel>
                <FormControl>
                  <Input 
                    type="datetime-local" 
                    {...field} 
                    value={field.value || ""} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="duration"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Duration (minutes)</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  {...field}
                  onChange={(e) => {
                    field.onChange(e.target.valueAsNumber);
                  }}
                />
              </FormControl>
              <FormDescription>
                Auto-calculated if both start and end times are provided
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Card className="p-4">
          <Label>Milk Amount (ml)</Label>
          <div className="grid grid-cols-3 gap-4 mt-2">
            <FormField
              control={form.control}
              name="amountLeftBreast"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <div className="flex flex-col">
                      <Label className="mb-1 text-xs">Left Breast</Label>
                      <Input 
                        type="number" 
                        placeholder="0"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e.target.valueAsNumber || 0);
                        }}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="amountRightBreast"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <div className="flex flex-col">
                      <Label className="mb-1 text-xs">Right Breast</Label>
                      <Input 
                        type="number" 
                        placeholder="0"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e.target.valueAsNumber || 0);
                        }}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="totalAmount"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <div className="flex flex-col">
                      <Label className="mb-1 text-xs">Total (ml)</Label>
                      <Input 
                        type="number" 
                        placeholder="0"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e.target.valueAsNumber || 0);
                        }}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <FormDescription className="mt-2 text-xs">
            Total is auto-calculated from left and right amounts
          </FormDescription>
        </Card>
        
        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Add any additional details about this pumping session..."
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? (
              <>
                <BabySpinner type="bottle" size="sm" className="mr-2" />
                Saving...
              </>
            ) : pumpSession ? (
              "Update Pump Session"
            ) : (
              "Save Pump Session"
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}