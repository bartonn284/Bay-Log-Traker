import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Vaccine } from "../../shared/schema";
import { Switch } from "@/components/ui/switch";

// Schema for the form
const vaccineSchema = z.object({
  name: z.string().min(1, { message: "Vaccine name is required" }),
  dueDate: z.date().optional().nullable(),
  location: z.string().optional(),
  notes: z.string().optional(),
  lotNumber: z.string().optional(),
  reminder: z.boolean().default(true),
  completed: z.boolean().default(false),
  administeredDate: z.date().optional().nullable(),
});

type FormValues = z.infer<typeof vaccineSchema>;

type VaccineFormProps = {
  vaccine: Vaccine | null;
  babyId: number;
  onSuccess: () => void;
};

export default function VaccineForm({ vaccine, babyId, onSuccess }: VaccineFormProps) {
  const { toast } = useToast();
  const [showAdministeredDatePicker, setShowAdministeredDatePicker] = useState(false);

  // Default values
  const defaultValues: Partial<FormValues> = vaccine
    ? {
        ...vaccine,
        dueDate: vaccine.dueDate ? new Date(vaccine.dueDate) : null,
        administeredDate: vaccine.administeredDate ? new Date(vaccine.administeredDate) : null,
      }
    : {
        name: "",
        dueDate: new Date(),
        location: "",
        notes: "",
        lotNumber: "",
        reminder: true,
        completed: false,
        administeredDate: null,
      };

  // Create form
  const form = useForm<FormValues>({
    resolver: zodResolver(vaccineSchema),
    defaultValues,
  });

  // Watch the completed field to toggle visibility of administered date
  const completed = form.watch("completed");

  // Create mutation for saving the vaccine
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      // Check if babyId is valid before making the request
      if (!babyId) {
        throw new Error("No baby selected. Please select a baby first.");
      }
      
      const response = await fetch(`/api/babies/${babyId}/vaccines`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        throw new Error("Failed to create vaccine record");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Vaccine record created",
        description: "The vaccine record has been successfully created.",
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create vaccine record",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!vaccine) return null;
      
      // Check if babyId is valid before making the request
      if (!babyId) {
        throw new Error("No baby selected. Please select a baby first.");
      }

      const response = await fetch(`/api/babies/${babyId}/vaccines/${vaccine.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        throw new Error("Failed to update vaccine record");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Vaccine record updated",
        description: "The vaccine record has been successfully updated.",
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update vaccine record",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Automatically set administered date when marking as completed
  const handleCompletedChange = (checked: boolean) => {
    form.setValue("completed", checked);
    
    // If marking as completed and no administered date is set, set it to today
    if (checked && !form.getValues("administeredDate")) {
      form.setValue("administeredDate", new Date());
    }
  };

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    // Check if babyId is valid
    if (!babyId || isNaN(babyId)) {
      toast({
        title: "Error",
        description: "No baby selected. Please select a baby first.",
        variant: "destructive",
      });
      return;
    }
    
    if (vaccine) {
      updateMutation.mutate(values);
    } else {
      createMutation.mutate(values);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-2">
        {/* Name */}
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Vaccine Name*</FormLabel>
              <FormControl>
                <Input placeholder="Enter vaccine name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Due Date */}
        <FormField
          control={form.control}
          name="dueDate"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel>Due Date</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full pl-3 text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "PPP")
                      ) : (
                        <span>Pick a date</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value || undefined}
                    onSelect={field.onChange}
                    disabled={(date) => date < new Date("1900-01-01")}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Location */}
        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location</FormLabel>
              <FormControl>
                <Input placeholder="Where the vaccine will be administered" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Lot Number */}
        <FormField
          control={form.control}
          name="lotNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Lot Number</FormLabel>
              <FormControl>
                <Input placeholder="Vaccine lot number" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Notes */}
        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Any additional notes about this vaccine" 
                  {...field} 
                  value={field.value || ""} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Reminder */}
        <FormField
          control={form.control}
          name="reminder"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
              <div className="space-y-0.5">
                <FormLabel>Set Reminder</FormLabel>
                <div className="text-sm text-muted-foreground">
                  Get notified when this vaccine is due
                </div>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        {/* Completed Status */}
        <FormField
          control={form.control}
          name="completed"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
              <div className="space-y-0.5">
                <FormLabel>Mark as Administered</FormLabel>
                <div className="text-sm text-muted-foreground">
                  Vaccine has been administered
                </div>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={handleCompletedChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        {/* Administered Date (conditional) */}
        {completed && (
          <FormField
            control={form.control}
            name="administeredDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Date Administered</FormLabel>
                <Popover open={showAdministeredDatePicker} onOpenChange={setShowAdministeredDatePicker}>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value || undefined}
                      onSelect={(date) => {
                        field.onChange(date);
                        setShowAdministeredDatePicker(false);
                      }}
                      disabled={(date) => date < new Date("1900-01-01")}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        {/* Submit Button */}
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Saving..." : vaccine ? "Update Vaccine" : "Add Vaccine"}
        </Button>
      </form>
    </Form>
  );
}