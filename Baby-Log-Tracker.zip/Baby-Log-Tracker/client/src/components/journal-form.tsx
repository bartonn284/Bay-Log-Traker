import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CalendarIcon, Save } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Journal entry form schema
const journalFormSchema = z.object({
  date: z.date(),
  title: z.string().min(2, "Title must be at least 2 characters"),
  entry: z.string().min(5, "Journal entry must be at least 5 characters"),
  mood: z.string().optional(),
  category: z.string().optional(),
});

type JournalFormValues = z.infer<typeof journalFormSchema>;

interface JournalFormProps {
  babyId: number;
  onSuccess?: () => void;
  onBack?: () => void;
  initialValues?: Partial<JournalFormValues>;
}

export function JournalForm({ babyId, onSuccess, onBack, initialValues }: JournalFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Setup form with default values
  const form = useForm<JournalFormValues>({
    resolver: zodResolver(journalFormSchema),
    defaultValues: initialValues || {
      date: new Date(),
      title: "",
      entry: "",
      mood: "happy",
      category: "general",
    },
  });

  // Update form when initialValues changes (for editing)
  useEffect(() => {
    if (initialValues) {
      form.reset({
        ...initialValues,
        date: initialValues.date || new Date(),
      });
    }
  }, [initialValues, form]);

  // Journal creation mutation
  const createJournalMutation = useMutation({
    mutationFn: async (values: JournalFormValues) => {
      const data = {
        ...values,
        babyId,
      };

      const res = await apiRequest("POST", "/api/journal", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Journal entry saved",
        description: "Your journal entry has been saved successfully.",
      });
      form.reset({
        date: new Date(),
        title: "",
        entry: "",
        mood: "happy",
        category: "general",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/journal", babyId] });
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save journal entry",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submit handler
  function onSubmit(values: JournalFormValues) {
    setIsSubmitting(true);
    createJournalMutation.mutate(values, {
      onSettled: () => setIsSubmitting(false),
    });
  }

  // Available moods for selection
  const moods = [
    { value: "happy", label: "Happy 😊" },
    { value: "excited", label: "Excited 🎉" },
    { value: "tired", label: "Tired 😴" },
    { value: "frustrated", label: "Frustrated 😤" },
    { value: "worried", label: "Worried 😟" },
    { value: "sad", label: "Sad 😢" },
    { value: "anxious", label: "Anxious 😰" },
    { value: "proud", label: "Proud 🥰" },
    { value: "amazed", label: "Amazed 😲" },
    { value: "grateful", label: "Grateful 🙏" },
  ];

  // Available categories for selection
  const categories = [
    { value: "general", label: "General" },
    { value: "milestone", label: "Milestone" },
    { value: "feeling", label: "Feeling/Emotion" },
    { value: "memory", label: "Memory" },
    { value: "sleep", label: "Sleep" },
    { value: "feeding", label: "Feeding" },
    { value: "health", label: "Health" },
    { value: "development", label: "Development" },
    { value: "family", label: "Family" },
    { value: "other", label: "Other" },
  ];

  return (
    <Form {...form}>
      <div className="mb-4 flex items-center">
        <Button 
          type="button" 
          variant="ghost"
          onClick={onBack}
          className="px-0 hover:bg-transparent"
        >
          ← Back
        </Button>
        <h2 className="text-xl font-semibold ml-2">Journal Entry</h2>
      </div>
      
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="mood"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Your Mood</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your mood" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {moods.map((mood) => (
                      <SelectItem key={mood.value} value={mood.value}>
                        {mood.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Title</FormLabel>
              <FormControl>
                <Input
                  placeholder="Title of your journal entry"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="category"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Category</FormLabel>
              <Select
                onValueChange={field.onChange}
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="entry"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Journal Entry</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Write about your thoughts, feelings, or any special moments with your baby..."
                  className="min-h-[150px]"
                  {...field}
                />
              </FormControl>
              <FormDescription>
                This is a space for your personal reflections and memories.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button
          type="submit"
          className="w-full"
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>Saving...</>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Journal Entry
            </>
          )}
        </Button>
      </form>
    </Form>
  );
}