import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, ArrowLeft } from "lucide-react";

const joinSchema = z.object({
  shareCode: z.string().min(12, "Share code must be 12 characters").max(12, "Share code must be 12 characters"),
});

type JoinFormValues = z.infer<typeof joinSchema>;

export function JoinBabyForm() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const form = useForm<JoinFormValues>({
    resolver: zodResolver(joinSchema),
    defaultValues: {
      shareCode: "",
    },
  });

  const joinMutation = useMutation({
    mutationFn: async (data: JoinFormValues) => {
      const res = await apiRequest("POST", "/api/babies/join", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Successfully joined baby!",
        description: "You can now view and track this baby's activities.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/babies"] });
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to join",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: JoinFormValues) => {
    joinMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <div>
        <Button
          variant="ghost"
          className="mb-2 p-0 h-auto"
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Button>
        <h2 className="text-2xl font-semibold mb-2">Join a Baby</h2>
        <p className="text-neutral-600 text-sm">
          Enter the 12-digit share code provided by the baby's admin to join and get access.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="shareCode"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Share Code</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Enter 12-digit code"
                    {...field}
                    className="font-mono tracking-wider text-center"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button
            type="submit"
            className="w-full"
            disabled={joinMutation.isPending}
          >
            {joinMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            Join Baby
          </Button>
        </form>
      </Form>
    </div>
  );
}