import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Clock, 
  MapPin, 
  UserRound, 
  Plus, 
  Trash2, 
  Edit,
  Bell 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Appointment {
  id: number;
  babyId: number;
  createdAt: Date;
  date: Date;
  time: string | null;
  title: string;
  appointmentType: string;
  location: string | null;
  doctorName: string | null;
  notes: string | null;
  reminderSet: boolean | null;
  reminderTime: Date | null;
  completed: boolean | null;
  createdBy: number;
}

export default function AppointmentsTab() {
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentAppointment, setCurrentAppointment] = useState<Appointment | null>(null);
  const [date, setDate] = useState<Date>(new Date());
  const [time, setTime] = useState("");
  const [title, setTitle] = useState("");
  const [appointmentType, setAppointmentType] = useState("Check-up");
  const [location, setLocation] = useState("");
  const [doctorName, setDoctorName] = useState("");
  const [notes, setNotes] = useState("");
  const [reminderSet, setReminderSet] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [filter, setFilter] = useState<"upcoming" | "past" | "all">("upcoming");
  
  // Fetch appointments
  const { data: appointments, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby?.id, 'appointments'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby.id}/appointments`);
      return res.json();
    },
    enabled: !!selectedBaby
  });
  
  // Create appointment
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      date: Date;
      time: string;
      title: string;
      appointmentType: string;
      location: string;
      doctorName: string;
      notes: string;
      reminderSet: boolean;
      completed: boolean;
    }) => {
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/appointments`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'appointments'] });
      toast({
        title: "Success",
        description: "Appointment added successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add appointment: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update appointment
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      date: Date;
      time: string;
      title: string;
      appointmentType: string;
      location: string;
      doctorName: string;
      notes: string;
      reminderSet: boolean;
      completed: boolean;
    }) => {
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/appointments/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'appointments'] });
      toast({
        title: "Success",
        description: "Appointment updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update appointment: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete appointment
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/appointments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'appointments'] });
      toast({
        title: "Success",
        description: "Appointment deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete appointment: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setDate(new Date());
    setTime("");
    setTitle("");
    setAppointmentType("Check-up");
    setLocation("");
    setDoctorName("");
    setNotes("");
    setReminderSet(false);
    setCompleted(false);
    setCurrentAppointment(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!title) {
      toast({
        title: "Error",
        description: "Please enter a title for the appointment",
        variant: "destructive",
      });
      return;
    }
    
    createMutation.mutate({
      babyId: selectedBaby.id,
      date,
      time,
      title,
      appointmentType,
      location,
      doctorName,
      notes,
      reminderSet,
      completed
    });
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !currentAppointment) {
      toast({
        title: "Error",
        description: "No baby or appointment selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!title) {
      toast({
        title: "Error",
        description: "Please enter a title for the appointment",
        variant: "destructive",
      });
      return;
    }
    
    updateMutation.mutate({
      id: currentAppointment.id,
      babyId: selectedBaby.id,
      date,
      time,
      title,
      appointmentType,
      location,
      doctorName,
      notes,
      reminderSet,
      completed
    });
  };
  
  const handleEdit = (appointment: Appointment) => {
    setCurrentAppointment(appointment);
    setDate(new Date(appointment.date));
    setTime(appointment.time || "");
    setTitle(appointment.title);
    setAppointmentType(appointment.appointmentType);
    setLocation(appointment.location || "");
    setDoctorName(appointment.doctorName || "");
    setNotes(appointment.notes || "");
    setReminderSet(appointment.reminderSet || false);
    setCompleted(appointment.completed || false);
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this appointment?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const toggleCompleted = (appointment: Appointment) => {
    updateMutation.mutate({
      id: appointment.id,
      babyId: selectedBaby!.id,
      date: new Date(appointment.date),
      time: appointment.time || "",
      title: appointment.title,
      appointmentType: appointment.appointmentType,
      location: appointment.location || "",
      doctorName: appointment.doctorName || "",
      notes: appointment.notes || "",
      reminderSet: appointment.reminderSet || false,
      completed: !(appointment.completed || false)
    });
  };
  
  // Filter and sort appointments
  const filteredAppointments = (() => {
    if (!appointments) return [];
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    let filtered = [...appointments];
    
    if (filter === "upcoming") {
      filtered = filtered.filter((appointment: Appointment) => 
        new Date(appointment.date) >= today && !(appointment.completed || false)
      );
    } else if (filter === "past") {
      filtered = filtered.filter((appointment: Appointment) => 
        new Date(appointment.date) < today || (appointment.completed || false)
      );
    }
    
    // Sort by date (upcoming first)
    return filtered.sort((a: Appointment, b: Appointment) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
  })();
  
  const renderAppointmentForm = () => {
    return (
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="title">Appointment Title*</Label>
          <Input
            id="title"
            placeholder="e.g., Well Baby Check-up"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="appointmentType">Appointment Type</Label>
          <Select
            value={appointmentType}
            onValueChange={setAppointmentType}
          >
            <SelectTrigger id="appointmentType">
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Check-up">Check-up</SelectItem>
              <SelectItem value="Vaccination">Vaccination</SelectItem>
              <SelectItem value="Specialist">Specialist</SelectItem>
              <SelectItem value="Emergency">Emergency</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="date">Date*</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                id="date"
                variant="outline"
                className="w-full justify-start text-left font-normal"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={date}
                onSelect={(date) => date && setDate(date)}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="time">Time</Label>
          <Input
            id="time"
            placeholder="e.g., 10:30 AM"
            value={time}
            onChange={(e) => setTime(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            placeholder="e.g., Children's Hospital"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="doctorName">Doctor/Provider Name</Label>
          <Input
            id="doctorName"
            placeholder="e.g., Dr. Smith"
            value={doctorName}
            onChange={(e) => setDoctorName(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="notes">Notes</Label>
          <Textarea
            id="notes"
            placeholder="Any additional notes about the appointment"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>
        
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="reminder" 
            checked={reminderSet}
            onCheckedChange={(checked) => setReminderSet(checked as boolean)}
          />
          <Label htmlFor="reminder">Set reminder</Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="completed" 
            checked={completed}
            onCheckedChange={(checked) => setCompleted(checked as boolean)}
          />
          <Label htmlFor="completed">Mark as completed</Label>
        </div>
      </div>
    );
  };
  
  const getAppointmentStatus = (appointment: Appointment) => {
    if (appointment.completed) {
      return {
        label: "Completed",
        bg: "bg-green-100",
        text: "text-green-800",
        border: "border-green-200",
      };
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const apptDate = new Date(appointment.date);
    apptDate.setHours(0, 0, 0, 0);
    
    if (apptDate < today) {
      return {
        label: "Missed",
        bg: "bg-red-100",
        text: "text-red-800",
        border: "border-red-200",
      };
    } else if (apptDate.getTime() === today.getTime()) {
      return {
        label: "Today",
        bg: "bg-blue-100",
        text: "text-blue-800",
        border: "border-blue-200",
      };
    } else {
      return {
        label: "Upcoming",
        bg: "bg-purple-100",
        text: "text-purple-800",
        border: "border-purple-200",
      };
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Appointments</h2>
          <p className="text-sm text-muted-foreground">
            Track doctor visits, check-ups and other appointments
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Appointment
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Appointment</DialogTitle>
              <DialogDescription>
                Schedule a new appointment for your baby
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {renderAppointmentForm()}
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Save Appointment</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Appointment</DialogTitle>
              <DialogDescription>
                Update appointment details
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleUpdate} className="space-y-4">
              {renderAppointmentForm()}
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Update Appointment</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Filter Buttons */}
      <div className="flex space-x-2">
        <Button 
          variant={filter === "upcoming" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("upcoming")}
        >
          Upcoming
        </Button>
        <Button 
          variant={filter === "past" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("past")}
        >
          Past/Completed
        </Button>
        <Button 
          variant={filter === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("all")}
        >
          All
        </Button>
      </div>
      
      {/* Appointments List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center p-4">Loading...</div>
        ) : filteredAppointments.length > 0 ? (
          filteredAppointments.map((appointment: Appointment) => {
            const status = getAppointmentStatus(appointment);
            
            return (
              <Card key={appointment.id} className="mb-4">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-base font-medium">
                          {appointment.title}
                        </CardTitle>
                        <Badge 
                          variant="outline" 
                          className={`${status.bg} ${status.text} ${status.border}`}
                        >
                          {status.label}
                        </Badge>
                      </div>
                      <CardDescription>
                        {format(new Date(appointment.date), "PPP")}
                        {appointment.time ? ` at ${appointment.time}` : ""}
                      </CardDescription>
                    </div>
                    <div className="flex space-x-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => handleEdit(appointment)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive" 
                        onClick={() => handleDelete(appointment.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-4 space-y-2">
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                    <div className="flex items-center">
                      <UserRound className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{appointment.doctorName || "No provider specified"}</span>
                    </div>
                    
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{appointment.location || "No location specified"}</span>
                    </div>
                    
                    {appointment.appointmentType && (
                      <div className="flex items-center col-span-2">
                        <span className="text-muted-foreground mr-2">Type:</span>
                        <span>{appointment.appointmentType}</span>
                      </div>
                    )}
                    
                    {appointment.reminderSet && (
                      <div className="flex items-center col-span-2">
                        <Bell className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>Reminder set</span>
                      </div>
                    )}
                  </div>
                  
                  {appointment.notes && (
                    <div className="mt-3 pt-3 border-t">
                      <p className="text-sm text-muted-foreground">Notes:</p>
                      <p className="text-sm mt-1">{appointment.notes}</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="ml-auto"
                    onClick={() => toggleCompleted(appointment)}
                  >
                    {appointment.completed 
                      ? "Mark as not completed" 
                      : "Mark as completed"}
                  </Button>
                </CardFooter>
              </Card>
            );
          })
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            No appointments found. Click 'Add Appointment' to schedule one.
          </div>
        )}
      </div>
    </div>
  );
}