import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  BookOpen, 
  Plus, 
  Trash2, 
  Edit,
  Image,
  FileText
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface JournalEntry {
  id: number;
  babyId: number;
  title: string;
  date: Date;
  category: string | null;
  description: string | null;
  mediaUrl: string | null;
  createdAt: Date;
  createdBy: number;
}

export default function JournalTab() {
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentEntry, setCurrentEntry] = useState<JournalEntry | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string>("");
  const [mediaUrl, setMediaUrl] = useState("");
  const [date, setDate] = useState<Date>(new Date());
  const [filter, setFilter] = useState<"all" | "milestone" | "story" | "memory" | "other">("all");
  
  // Fetch journal entries
  const { data: entries, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby?.id, 'journal'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby.id}/journal`);
      return res.json();
    },
    enabled: !!selectedBaby
  });
  
  // Create journal entry
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      title: string;
      date: Date;
      category?: string;
      description?: string;
      mediaUrl?: string;
    }) => {
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/journal`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'journal'] });
      toast({
        title: "Success",
        description: "Journal entry created successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create journal entry: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update journal entry
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      title: string;
      date: Date;
      category?: string;
      description?: string;
      mediaUrl?: string;
    }) => {
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/journal/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'journal'] });
      toast({
        title: "Success",
        description: "Journal entry updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update journal entry: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete journal entry
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/journal/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'journal'] });
      toast({
        title: "Success",
        description: "Journal entry deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete journal entry: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setTitle("");
    setDescription("");
    setCategory("");
    setMediaUrl("");
    setDate(new Date());
    setCurrentEntry(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!title) {
      toast({
        title: "Error",
        description: "Title is required",
        variant: "destructive",
      });
      return;
    }
    
    createMutation.mutate({
      babyId: selectedBaby.id,
      title,
      date,
      category: category || undefined,
      description: description || undefined,
      mediaUrl: mediaUrl || undefined
    });
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !currentEntry) {
      toast({
        title: "Error",
        description: "No baby or entry selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!title) {
      toast({
        title: "Error",
        description: "Title is required",
        variant: "destructive",
      });
      return;
    }
    
    updateMutation.mutate({
      id: currentEntry.id,
      babyId: selectedBaby.id,
      title,
      date,
      category: category || undefined,
      description: description || undefined,
      mediaUrl: mediaUrl || undefined
    });
  };
  
  const handleEdit = (entry: JournalEntry) => {
    setCurrentEntry(entry);
    setTitle(entry.title);
    setDescription(entry.description || "");
    setCategory(entry.category || "");
    setMediaUrl(entry.mediaUrl || "");
    setDate(new Date(entry.date));
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this journal entry?")) {
      deleteMutation.mutate(id);
    }
  };
  
  // Filter journal entries
  const filteredEntries = (() => {
    if (!entries) return [];
    
    if (filter === "all") {
      return entries;
    }
    
    return entries.filter((entry: JournalEntry) => entry.category === filter);
  })();
  
  // Sort journal entries by date (newest first)
  const sortedEntries = filteredEntries.sort((a: JournalEntry, b: JournalEntry) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  // Get color for category
  const getCategoryColor = (category: string | null) => {
    switch (category) {
      case "milestone":
        return "bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400";
      case "story":
        return "bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400";
      case "memory":
        return "bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400";
      case "other":
        return "bg-purple-50 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400";
      default:
        return "bg-gray-50 text-gray-600 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Baby Journal</h2>
          <p className="text-sm text-muted-foreground">
            Record special moments, stories, and memories
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Select value={filter} onValueChange={(value: "all" | "milestone" | "story" | "memory" | "other") => setFilter(value)}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Filter by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All entries</SelectItem>
              <SelectItem value="milestone">Milestones</SelectItem>
              <SelectItem value="story">Stories</SelectItem>
              <SelectItem value="memory">Memories</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Entry
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create Journal Entry</DialogTitle>
                <DialogDescription>
                  Add a new memory, story, or milestone to your baby's journal
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g., First smile"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="milestone">Milestone</SelectItem>
                      <SelectItem value="story">Story</SelectItem>
                      <SelectItem value="memory">Memory</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(date) => date && setDate(date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Write the details here..."
                    className="min-h-[100px]"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="mediaUrl">Media URL (optional)</Label>
                  <Input
                    id="mediaUrl"
                    value={mediaUrl}
                    onChange={(e) => setMediaUrl(e.target.value)}
                    placeholder="Add image URL"
                  />
                </div>
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Save Entry</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Journal Entry</DialogTitle>
            <DialogDescription>
              Update your baby's journal entry
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleUpdate} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">Title</Label>
              <Input
                id="edit-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., First smile"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="milestone">Milestone</SelectItem>
                  <SelectItem value="story">Story</SelectItem>
                  <SelectItem value="memory">Memory</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(date) => date && setDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Write the details here..."
                className="min-h-[100px]"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-mediaUrl">Media URL (optional)</Label>
              <Input
                id="edit-mediaUrl"
                value={mediaUrl}
                onChange={(e) => setMediaUrl(e.target.value)}
                placeholder="Add image URL"
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">Update Entry</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Journal Entries List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center p-4">Loading journal entries...</div>
        ) : sortedEntries.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sortedEntries.map((entry: JournalEntry) => (
              <Card key={entry.id} className="overflow-hidden">
                <CardHeader className="pb-0">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg font-medium">{entry.title}</CardTitle>
                      <CardDescription>
                        {format(new Date(entry.date), "PPP")}
                      </CardDescription>
                    </div>
                    <div className="flex space-x-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => handleEdit(entry)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive" 
                        onClick={() => handleDelete(entry.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                {entry.mediaUrl && (
                  <div className="p-4 pb-0">
                    <div className="relative h-48 w-full rounded-md overflow-hidden">
                      <img 
                        src={entry.mediaUrl} 
                        alt={entry.title} 
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
                
                <CardContent className="pt-4">
                  {entry.category && (
                    <Badge 
                      variant="outline" 
                      className={`${getCategoryColor(entry.category)} mb-2`}
                    >
                      {entry.category.charAt(0).toUpperCase() + entry.category.slice(1)}
                    </Badge>
                  )}
                  
                  {entry.description && (
                    <p className="text-sm mt-2">
                      {entry.description.length > 150 
                        ? `${entry.description.substring(0, 150)}...` 
                        : entry.description}
                    </p>
                  )}
                </CardContent>
                {entry.description && entry.description.length > 150 && (
                  <CardFooter className="pt-0">
                    <Button variant="link" size="sm" className="p-0" onClick={() => handleEdit(entry)}>
                      Read more
                    </Button>
                  </CardFooter>
                )}
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            <BookOpen className="h-12 w-12 mx-auto mb-3 text-muted-foreground/60" />
            <h3 className="font-medium mb-1">Your journal is empty</h3>
            <p className="text-sm mb-4">Start capturing special moments by adding your first entry.</p>
            <Button 
              variant="outline"
              onClick={() => setIsAddDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Create First Entry
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}