import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Award, 
  Plus, 
  Trash2, 
  Edit, 
  Image, 
  Brain,
  ActivityIcon,
  MessageCircle,
  HeartHandshake
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { BabySelector } from "@/components/baby-selector";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Milestone {
  id: number;
  babyId: number;
  createdAt: Date;
  date: Date;
  title: string;
  category: string | null;
  description: string | null;
  mediaUrl: string | null;
  createdBy: number;
}

export default function MilestonesTab() {
  const { toast } = useToast();
  const { selectedBaby, setSelectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentMilestone, setCurrentMilestone] = useState<Milestone | null>(null);
  const [date, setDate] = useState<Date>(new Date());
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("motor");
  const [description, setDescription] = useState("");
  const [mediaUrl, setMediaUrl] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  
  // Query for all babies for baby selection
  const { data: babies } = useQuery({
    queryKey: ['/api/babies'],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Milestone categories
  const categories = [
    { id: "motor", label: "Motor Skills", icon: <ActivityIcon className="h-4 w-4" /> },
    { id: "social", label: "Social", icon: <HeartHandshake className="h-4 w-4" /> },
    { id: "language", label: "Language", icon: <MessageCircle className="h-4 w-4" /> },
    { id: "cognitive", label: "Cognitive", icon: <Brain className="h-4 w-4" /> },
    { id: "other", label: "Other", icon: <Award className="h-4 w-4" /> }
  ];
  
  // Fetch milestones
  const { data: milestones, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby?.id, 'milestones'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby.id}/milestones`);
      return res.json();
    },
    enabled: !!selectedBaby
  });
  
  // Create milestone
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      date: Date;
      title: string;
      category: string;
      description: string;
      mediaUrl: string;
    }) => {
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/milestones`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'milestones'] });
      toast({
        title: "Success",
        description: "Milestone added successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add milestone: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update milestone
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      date: Date;
      title: string;
      category: string;
      description: string;
      mediaUrl: string;
    }) => {
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/milestones/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'milestones'] });
      toast({
        title: "Success",
        description: "Milestone updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update milestone: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete milestone
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/milestones/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'milestones'] });
      toast({
        title: "Success",
        description: "Milestone deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete milestone: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setDate(new Date());
    setTitle("");
    setCategory("motor");
    setDescription("");
    setMediaUrl("");
    setCurrentMilestone(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!title) {
      toast({
        title: "Error",
        description: "Please enter a title for the milestone",
        variant: "destructive",
      });
      return;
    }
    
    createMutation.mutate({
      babyId: selectedBaby.id,
      date,
      title,
      category,
      description,
      mediaUrl
    });
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !currentMilestone) {
      toast({
        title: "Error",
        description: "No baby or milestone selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!title) {
      toast({
        title: "Error",
        description: "Please enter a title for the milestone",
        variant: "destructive",
      });
      return;
    }
    
    updateMutation.mutate({
      id: currentMilestone.id,
      babyId: selectedBaby.id,
      date,
      title,
      category,
      description,
      mediaUrl
    });
  };
  
  const handleEdit = (milestone: Milestone) => {
    setCurrentMilestone(milestone);
    setDate(new Date(milestone.date));
    setTitle(milestone.title);
    setCategory(milestone.category || "other");
    setDescription(milestone.description || "");
    setMediaUrl(milestone.mediaUrl || "");
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this milestone?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const getCategoryDetails = (categoryId: string | null) => {
    const category = categories.find(c => c.id === categoryId) || categories[4]; // Default to "Other"
    return {
      icon: category.icon,
      label: category.label,
      color: getCategoryColor(categoryId)
    };
  };
  
  const getCategoryColor = (categoryId: string | null) => {
    switch(categoryId) {
      case "motor":
        return "text-blue-500 bg-blue-50 border-blue-200";
      case "social":
        return "text-pink-500 bg-pink-50 border-pink-200";
      case "language":
        return "text-purple-500 bg-purple-50 border-purple-200";
      case "cognitive":
        return "text-amber-500 bg-amber-50 border-amber-200";
      default:
        return "text-emerald-500 bg-emerald-50 border-emerald-200";
    }
  };
  
  // Filter and sort milestones
  const filteredMilestones = (() => {
    let filtered = milestones || [];
    
    // Filter by category if one is selected
    if (activeCategory) {
      filtered = filtered.filter((milestone: Milestone) => milestone.category === activeCategory);
    }
    
    // Sort by date (newest first)
    return [...filtered].sort((a: Milestone, b: Milestone) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  })();
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Milestone Tracking</h2>
          <p className="text-sm text-muted-foreground">
            Record and celebrate your baby's developmental milestones
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Milestone
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Milestone</DialogTitle>
              <DialogDescription>
                Record a new developmental milestone
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Milestone Title*</Label>
                <Input
                  id="title"
                  placeholder="e.g., First Steps, First Word"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={category}
                  onValueChange={setCategory}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.id}>
                        <div className="flex items-center">
                          {cat.icon}
                          <span className="ml-2">{cat.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="date">Date Achieved*</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="date"
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => date && setDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Add details about this milestone"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="mediaUrl">Photo/Video URL</Label>
                <div className="flex space-x-2">
                  <Input
                    id="mediaUrl"
                    placeholder="Add a link to a photo or video"
                    value={mediaUrl}
                    onChange={(e) => setMediaUrl(e.target.value)}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Save Milestone</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Milestone</DialogTitle>
              <DialogDescription>
                Update milestone details
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleUpdate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-title">Milestone Title*</Label>
                <Input
                  id="edit-title"
                  placeholder="e.g., First Steps, First Word"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-category">Category</Label>
                <Select
                  value={category}
                  onValueChange={setCategory}
                >
                  <SelectTrigger id="edit-category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.id}>
                        <div className="flex items-center">
                          {cat.icon}
                          <span className="ml-2">{cat.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-date">Date Achieved*</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="edit-date"
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => date && setDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  placeholder="Add details about this milestone"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-mediaUrl">Photo/Video URL</Label>
                <div className="flex space-x-2">
                  <Input
                    id="edit-mediaUrl"
                    placeholder="Add a link to a photo or video"
                    value={mediaUrl}
                    onChange={(e) => setMediaUrl(e.target.value)}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Update Milestone</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Category Filters */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        <Button 
          variant={activeCategory === null ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveCategory(null)}
        >
          All Categories
        </Button>
        {categories.map(cat => (
          <Button 
            key={cat.id}
            variant={activeCategory === cat.id ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveCategory(cat.id)}
            className="flex items-center whitespace-nowrap"
          >
            {cat.icon}
            <span className="ml-1">{cat.label}</span>
          </Button>
        ))}
      </div>
      
      {/* Milestones List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center p-4">Loading...</div>
        ) : filteredMilestones.length > 0 ? (
          filteredMilestones.map((milestone: Milestone) => {
            const categoryInfo = getCategoryDetails(milestone.category);
            
            return (
              <Card key={milestone.id} className="mb-4">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-base font-medium">
                          {milestone.title}
                        </CardTitle>
                        <Badge 
                          variant="outline" 
                          className={categoryInfo.color}
                        >
                          <div className="flex items-center">
                            {categoryInfo.icon}
                            <span className="ml-1">{categoryInfo.label}</span>
                          </div>
                        </Badge>
                      </div>
                      <CardDescription>
                        Achieved on {format(new Date(milestone.date), "PPP")}
                      </CardDescription>
                    </div>
                    <div className="flex space-x-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => handleEdit(milestone)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive" 
                        onClick={() => handleDelete(milestone.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  {milestone.description && (
                    <div className="mb-3">
                      <p className="text-sm">{milestone.description}</p>
                    </div>
                  )}
                  
                  {milestone.mediaUrl && (
                    <div className="mt-3 flex items-center text-sm text-blue-600">
                      <Image className="h-4 w-4 mr-1" />
                      <a 
                        href={milestone.mediaUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="hover:underline"
                      >
                        View photo/video
                      </a>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            No milestones found. Click 'Add Milestone' to record a new achievement.
          </div>
        )}
      </div>
    </div>
  );
}