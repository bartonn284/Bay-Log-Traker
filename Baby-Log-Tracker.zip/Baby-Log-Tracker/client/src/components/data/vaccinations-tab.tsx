import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, isAfter, isBefore, parseISO } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { BabySelector } from "@/components/baby-selector";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Syringe, 
  Plus, 
  Trash2, 
  Edit,
  Bell,
  MapPin,
  Check,
  AlertCircle 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Vaccine {
  id: number;
  babyId: number;
  createdAt: Date;
  name: string;
  dueDate: Date | null;
  administeredDate: Date | null;
  location: string | null;
  lotNumber: string | null;
  notes: string | null;
  completed: boolean | null;
  reminder: boolean | null;
  createdBy: number;
}

export default function VaccinationsTab() {
  const { toast } = useToast();
  const { selectedBaby, setSelectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentVaccine, setCurrentVaccine] = useState<Vaccine | null>(null);
  const [name, setName] = useState("");
  const [dueDate, setDueDate] = useState<Date | null>(new Date());
  const [administeredDate, setAdministeredDate] = useState<Date | null>(null);
  const [location, setLocation] = useState("");
  const [lotNumber, setLotNumber] = useState("");
  const [notes, setNotes] = useState("");
  const [completed, setCompleted] = useState(false);
  const [reminder, setReminder] = useState(false);
  const [filter, setFilter] = useState<"upcoming" | "completed" | "all">("all");
  
  // Query for all babies for baby selection
  const { data: babies } = useQuery({
    queryKey: ['/api/babies'],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Fetch vaccines
  const { data: vaccines, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby, 'vaccines'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby}/vaccines`);
      return res.json();
    },
    enabled: selectedBaby !== null
  });
  
  // Ensure baby is selected before submitting
  const validateBabySelection = () => {
    if (selectedBaby === null) {
      toast({
        title: "No baby selected",
        description: "Please select a baby before adding a vaccination record",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  // Create vaccine
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      name: string;
      dueDate: string | null;  // Changed from Date to string
      administeredDate: string | null;  // Changed from Date to string
      location: string;
      lotNumber: string;
      notes: string;
      completed: boolean;
      reminder: boolean;
    }) => {
      console.log("Creating vaccine with data:", data);
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/vaccines`, data);
      return res.json();
    },
    onSuccess: () => {
      // Invalidate both vaccines and reminders queries to update UI
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby, 'vaccines'] });
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/has-reminders`] });
      
      toast({
        title: "Success",
        description: "Vaccination record added successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add vaccination record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update vaccine
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      name: string;
      dueDate: string | null;  // Changed from Date to string
      administeredDate: string | null;  // Changed from Date to string
      location: string;
      lotNumber: string;
      notes: string;
      completed: boolean;
      reminder: boolean;
    }) => {
      console.log("Updating vaccine with data:", data);
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/vaccines/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      // Invalidate both vaccines and reminders queries to update UI
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby, 'vaccines'] });
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/has-reminders`] });
      
      toast({
        title: "Success",
        description: "Vaccination record updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update vaccination record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete vaccine
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby}/vaccines/${id}`);
    },
    onSuccess: () => {
      // Invalidate both vaccines and reminders queries to update UI
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby, 'vaccines'] });
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/has-reminders`] });
      
      toast({
        title: "Success",
        description: "Vaccination record deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete vaccination record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setName("");
    setDueDate(new Date());
    setLocation("");
    setLotNumber("");
    setNotes("");
    setCompleted(false);
    setReminder(false);
    setCurrentVaccine(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!name) {
      toast({
        title: "Error",
        description: "Please enter a name for the vaccine",
        variant: "destructive",
      });
      return;
    }
    
    // Make a copy of the date object to avoid modifying the state directly
    const formDate = dueDate ? new Date(dueDate.getTime()) : null;
    
    // Set the time portion to noon to avoid timezone issues
    if (formDate) {
      formDate.setHours(12, 0, 0, 0);
    }
    
    // Use the date as either due date or administered date based on the completed status
    const vaccineData = {
      babyId: selectedBaby,
      name,
      dueDate: completed ? null : formDate ? formDate.toISOString() : null,
      administeredDate: completed ? (formDate ? formDate.toISOString() : null) : null,
      location,
      lotNumber,
      notes,
      completed,
      reminder
    };
    
    // Log what we're sending to the server
    console.log("Creating vaccine with data:", vaccineData);
    
    // Submit the form
    createMutation.mutate(vaccineData);
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !currentVaccine) {
      toast({
        title: "Error",
        description: "No baby or vaccination record selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!name) {
      toast({
        title: "Error",
        description: "Please enter a name for the vaccine",
        variant: "destructive",
      });
      return;
    }
    
    // Log the data we're submitting for update
    console.log("Updating vaccine with ID:", currentVaccine.id);
    
    // Make a copy of the date object to avoid modifying the state directly
    const formDate = dueDate ? new Date(dueDate.getTime()) : null;
    
    // Set the time portion to noon to avoid timezone issues
    if (formDate) {
      formDate.setHours(12, 0, 0, 0);
    }
    
    // Use the date as either due date or administered date based on the completed status
    const updateData = {
      id: currentVaccine.id,
      babyId: selectedBaby,
      name,
      dueDate: completed ? null : formDate ? formDate.toISOString() : null,
      administeredDate: completed ? (formDate ? formDate.toISOString() : null) : null,
      location,
      lotNumber,
      notes,
      completed,
      reminder
    };
    
    console.log("Updating with data:", updateData);
    updateMutation.mutate(updateData);
  };
  
  const handleEdit = (vaccine: Vaccine) => {
    setCurrentVaccine(vaccine);
    setName(vaccine.name);
    
    // Set the appropriate date based on completed status
    if (vaccine.completed && vaccine.administeredDate) {
      setDueDate(new Date(vaccine.administeredDate));
      setCompleted(true);
    } else if (vaccine.dueDate) {
      setDueDate(new Date(vaccine.dueDate));
      setCompleted(false);
    } else {
      setDueDate(new Date());
      setCompleted(false);
    }
    
    setLocation(vaccine.location || "");
    setLotNumber(vaccine.lotNumber || "");
    setNotes(vaccine.notes || "");
    setReminder(vaccine.reminder || false);
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this vaccination record?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const markAsCompleted = (vaccine: Vaccine) => {
    console.log("Marking vaccine as completed:", vaccine);
    // Format the vaccine due date correctly
    const dueDate = vaccine.dueDate ? 
      (typeof vaccine.dueDate === 'string' ? vaccine.dueDate : vaccine.dueDate.toISOString().split('T')[0]) 
      : null;
      
    updateMutation.mutate({
      id: vaccine.id,
      babyId: selectedBaby,
      name: vaccine.name,
      dueDate: dueDate, // Format the due date correctly
      administeredDate: new Date().toISOString().split('T')[0], // Set to current date (YYYY-MM-DD format)
      location: vaccine.location || "",
      lotNumber: vaccine.lotNumber || "",
      notes: vaccine.notes || "",
      completed: true,
      reminder: vaccine.reminder || false
    });
  };
  
  // Filter and sort vaccines
  const filteredVaccines = (() => {
    if (!vaccines) return [];
    
    let filtered = [...vaccines];
    
    if (filter === "upcoming") {
      filtered = filtered.filter((vaccine: Vaccine) => 
        !(vaccine.completed || false)
      );
    } else if (filter === "completed") {
      filtered = filtered.filter((vaccine: Vaccine) => 
        (vaccine.completed || false)
      );
    }
    
    // Sort by due date (soonest first)
    return filtered.sort((a: Vaccine, b: Vaccine) => {
      // Put ones without due dates at the end
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });
  })();
  
  const getVaccineStatus = (vaccine: Vaccine) => {
    if (vaccine.completed) {
      return {
        label: "Completed",
        bg: "bg-green-100",
        text: "text-green-800",
        border: "border-green-200",
        icon: <Check className="h-3 w-3 mr-1" />
      };
    }
    
    if (!vaccine.dueDate) {
      return {
        label: "No Due Date",
        bg: "bg-gray-100",
        text: "text-gray-800",
        border: "border-gray-200",
        icon: <CalendarIcon className="h-3 w-3 mr-1" />
      };
    }
    
    const now = new Date();
    const dueDate = new Date(vaccine.dueDate);
    
    if (isBefore(dueDate, now)) {
      return {
        label: "Overdue",
        bg: "bg-red-100",
        text: "text-red-800",
        border: "border-red-200",
        icon: <AlertCircle className="h-3 w-3 mr-1" />
      };
    } else {
      return {
        label: "Upcoming",
        bg: "bg-blue-100",
        text: "text-blue-800",
        border: "border-blue-200",
        icon: <CalendarIcon className="h-3 w-3 mr-1" />
      };
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Vaccinations</h2>
          <p className="text-sm text-muted-foreground">
            Track vaccinations and immunization records
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Vaccine
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Vaccination Record</DialogTitle>
              <DialogDescription>
                Record a new vaccination for your baby
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Vaccine Name*</Label>
                <Input
                  id="name"
                  placeholder="e.g., DTaP, MMR"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="vaccineDate">Vaccine Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        id="vaccineDate"
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dueDate ? format(dueDate, "PP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={dueDate}
                        onSelect={setDueDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label>Date Type</Label>
                  <div className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="dueDateType" 
                        name="dateType"
                        checked={!completed}
                        onChange={() => setCompleted(false)}
                        className="w-4 h-4"
                      />
                      <Label htmlFor="dueDateType" className="font-normal cursor-pointer" onClick={() => setCompleted(false)}>
                        Due Date
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="administeredDateType" 
                        name="dateType"
                        checked={completed}
                        onChange={() => setCompleted(true)}
                        className="w-4 h-4"
                      />
                      <Label htmlFor="administeredDateType" className="font-normal cursor-pointer" onClick={() => setCompleted(true)}>
                        Administered Date
                      </Label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  placeholder="e.g., Pediatrician's Office"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="lotNumber">Lot Number <span className="text-xs text-muted-foreground">(Optional)</span></Label>
                <Input
                  id="lotNumber"
                  placeholder="e.g., AB123456"
                  value={lotNumber}
                  onChange={(e) => setLotNumber(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional notes about the vaccination"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="reminder" 
                  checked={reminder}
                  onCheckedChange={(checked) => setReminder(checked as boolean)}
                />
                <Label htmlFor="reminder">Set reminder</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="completed" 
                  checked={completed}
                  onCheckedChange={(checked) => {
                    setCompleted(checked as boolean);
                    if (checked && !administeredDate) {
                      setAdministeredDate(new Date());
                    }
                  }}
                />
                <Label htmlFor="completed">
                  {administeredDate 
                    ? `Mark as completed (administered on ${format(administeredDate, "PP")})`
                    : "Mark as completed (today)"}
                </Label>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Save Record</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Vaccination Record</DialogTitle>
              <DialogDescription>
                Update vaccination details
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleUpdate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Vaccine Name*</Label>
                <Input
                  id="edit-name"
                  placeholder="e.g., DTaP, MMR"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-vaccineDate">Vaccine Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        id="edit-vaccineDate"
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dueDate ? format(dueDate, "PP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={dueDate}
                        onSelect={setDueDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label>Date Type</Label>
                  <div className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="edit-dueDateType" 
                        checked={!completed}
                        onChange={() => setCompleted(false)}
                      />
                      <Label htmlFor="edit-dueDateType" className="font-normal">Due Date</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="edit-administeredDateType" 
                        checked={completed}
                        onChange={() => setCompleted(true)}
                      />
                      <Label htmlFor="edit-administeredDateType" className="font-normal">Administered Date</Label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-location">Location</Label>
                <Input
                  id="edit-location"
                  placeholder="e.g., Pediatrician's Office"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-lotNumber">Lot Number <span className="text-xs text-muted-foreground">(Optional)</span></Label>
                <Input
                  id="edit-lotNumber"
                  placeholder="e.g., AB123456"
                  value={lotNumber}
                  onChange={(e) => setLotNumber(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-notes">Notes</Label>
                <Textarea
                  id="edit-notes"
                  placeholder="Any additional notes about the vaccination"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="edit-reminder" 
                  checked={reminder}
                  onCheckedChange={(checked) => setReminder(checked as boolean)}
                />
                <Label htmlFor="edit-reminder">Set reminder</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="edit-completed" 
                  checked={completed}
                  onCheckedChange={(checked) => {
                    setCompleted(checked as boolean);
                    if (checked && !administeredDate) {
                      setAdministeredDate(new Date());
                    }
                  }}
                />
                <Label htmlFor="edit-completed">
                  {administeredDate 
                    ? `Mark as completed (administered on ${format(administeredDate, "PP")})`
                    : "Mark as completed (today)"}
                </Label>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Update Record</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Filter Buttons */}
      <div className="flex space-x-2">
        <Button 
          variant={filter === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("all")}
        >
          All Vaccines
        </Button>
        <Button 
          variant={filter === "upcoming" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("upcoming")}
        >
          Upcoming
        </Button>
        <Button 
          variant={filter === "completed" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("completed")}
        >
          Completed
        </Button>
      </div>
      
      {/* Vaccines Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center">
            <Syringe className="h-5 w-5 mr-2" />
            Vaccination Records
          </CardTitle>
          <CardDescription>
            Track your baby's immunization schedule
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center p-4">Loading...</div>
          ) : filteredVaccines.length > 0 ? (
            <Table>
              <TableCaption>Vaccination record for {selectedBaby?.name}</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead>Vaccine</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Administered</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVaccines.map((vaccine: Vaccine) => {
                  const status = getVaccineStatus(vaccine);
                  
                  return (
                    <TableRow key={vaccine.id}>
                      <TableCell className="font-medium">
                        {vaccine.name}
                      </TableCell>
                      <TableCell>
                        {vaccine.dueDate
                          ? format(new Date(vaccine.dueDate), "MMM d, yyyy")
                          : "-"}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={`${status.bg} ${status.text} ${status.border} flex items-center w-fit`}
                        >
                          {status.icon}
                          {status.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {vaccine.administeredDate
                          ? format(new Date(vaccine.administeredDate), "MMM d, yyyy")
                          : "-"}
                      </TableCell>
                      <TableCell>
                        {vaccine.location || "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-1">
                          {!vaccine.completed && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => markAsCompleted(vaccine)}
                              className="text-green-700"
                            >
                              <Check className="h-4 w-4 mr-1" />
                              <span className="hidden sm:inline">Complete</span>
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleEdit(vaccine)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-destructive"
                            onClick={() => handleDelete(vaccine.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center p-6 text-muted-foreground">
              No vaccination records found. Click 'Add Vaccine' to start tracking vaccinations.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}