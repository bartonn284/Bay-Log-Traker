import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, LineChart, Plus, Ruler, Scale, Trash2, Edit } from "lucide-react";
import { cn } from "@/lib/utils";
import { BabySelector } from "@/components/baby-selector";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface GrowthRecord {
  id: number;
  babyId: number;
  createdAt: Date;
  date: Date;
  weight: string | null;
  height: string | null;
  headCircumference: string | null;
  notes: string | null;
  createdBy: number;
}

export default function GrowthTrackingTab() {
  const { toast } = useToast();
  const { selectedBaby, setSelectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentRecord, setCurrentRecord] = useState<GrowthRecord | null>(null);
  const [date, setDate] = useState<Date>(new Date());
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [headCircumference, setHeadCircumference] = useState("");
  const [notes, setNotes] = useState("");
  
  // Query for all babies for baby selection
  const { data: babies } = useQuery({
    queryKey: ['/api/babies'],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Fetch growth records
  const { data: growthRecords, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby?.id, 'growth'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby.id}/growth`);
      return res.json();
    },
    enabled: !!selectedBaby
  });
  
  // Create growth record
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      date: Date;
      weight: string;
      height: string;
      headCircumference: string;
      notes: string;
    }) => {
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/growth`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'growth'] });
      toast({
        title: "Success",
        description: "Growth record added successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add growth record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update growth record
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      date: Date;
      weight: string;
      height: string;
      headCircumference: string;
      notes: string;
    }) => {
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/growth/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'growth'] });
      toast({
        title: "Success",
        description: "Growth record updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update growth record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete growth record
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/growth/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'growth'] });
      toast({
        title: "Success",
        description: "Growth record deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete growth record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setDate(new Date());
    setWeight("");
    setHeight("");
    setHeadCircumference("");
    setNotes("");
    setCurrentRecord(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!weight && !height && !headCircumference) {
      toast({
        title: "Error",
        description: "Please enter at least one measurement",
        variant: "destructive",
      });
      return;
    }
    
    createMutation.mutate({
      babyId: selectedBaby.id,
      date,
      weight,
      height,
      headCircumference,
      notes
    });
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !selectedBaby.id || !currentRecord) {
      toast({
        title: "Error",
        description: "No baby or record selected",
        variant: "destructive",
      });
      return;
    }
    
    if (!weight && !height && !headCircumference) {
      toast({
        title: "Error",
        description: "Please enter at least one measurement",
        variant: "destructive",
      });
      return;
    }
    
    updateMutation.mutate({
      id: currentRecord.id,
      babyId: selectedBaby.id,
      date,
      weight,
      height,
      headCircumference,
      notes
    });
  };
  
  const handleEdit = (record: GrowthRecord) => {
    setCurrentRecord(record);
    setDate(new Date(record.date));
    setWeight(record.weight || "");
    setHeight(record.height || "");
    setHeadCircumference(record.headCircumference || "");
    setNotes(record.notes || "");
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this growth record?")) {
      deleteMutation.mutate(id);
    }
  };
  
  // Sort records by date (newest first)
  const sortedRecords = growthRecords 
    ? [...growthRecords].sort((a: any, b: any) => 
        new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];
  
  // Ensure a baby is selected before submitting
  const validateBabySelection = () => {
    if (!selectedBaby || !selectedBaby.id) {
      toast({
        title: "No baby selected",
        description: "Please select a baby before adding a growth record",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  return (
    <div className="space-y-4">
      {/* Add baby selector at the top */}
      <div className="mb-4">
        <BabySelector
          selectedBaby={selectedBaby?.id || null}
          onSelectBaby={(babyId) => {
            const baby = babies?.find(b => b.id === babyId);
            if (baby) {
              setSelectedBaby(baby);
            }
          }}
          showDetails
        />
      </div>
    
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Growth Tracking</h2>
          <p className="text-sm text-muted-foreground">
            Track your baby's physical growth over time
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => {
              // Validate baby selection before opening dialog
              if (!validateBabySelection()) {
                return;
              }
              setIsAddDialogOpen(true);
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Add Record
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Growth Record</DialogTitle>
              <DialogDescription>
                Record your baby's current measurements
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => date && setDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="weight" className="flex items-center">
                    <Scale className="h-4 w-4 mr-1" />
                    Weight
                  </Label>
                  <Input
                    id="weight"
                    placeholder="e.g., 7.5 kg"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height" className="flex items-center">
                    <Ruler className="h-4 w-4 mr-1" />
                    Height
                  </Label>
                  <Input
                    id="height"
                    placeholder="e.g., 65 cm"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="head" className="flex items-center">
                    <span className="text-xs mr-1">HC</span>
                    Head Circ.
                  </Label>
                  <Input
                    id="head"
                    placeholder="e.g., 40 cm"
                    value={headCircumference}
                    onChange={(e) => setHeadCircumference(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional notes or observations"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Save Record</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Growth Record</DialogTitle>
              <DialogDescription>
                Update your baby's measurements
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleUpdate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => date && setDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="weight" className="flex items-center">
                    <Scale className="h-4 w-4 mr-1" />
                    Weight
                  </Label>
                  <Input
                    id="weight"
                    placeholder="e.g., 7.5 kg"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height" className="flex items-center">
                    <Ruler className="h-4 w-4 mr-1" />
                    Height
                  </Label>
                  <Input
                    id="height"
                    placeholder="e.g., 65 cm"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="head" className="flex items-center">
                    <span className="text-xs mr-1">HC</span>
                    Head Circ.
                  </Label>
                  <Input
                    id="head"
                    placeholder="e.g., 40 cm"
                    value={headCircumference}
                    onChange={(e) => setHeadCircumference(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional notes or observations"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Update Record</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Display growth data in a table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center">
            <LineChart className="h-5 w-5 mr-2" />
            Growth History
          </CardTitle>
          <CardDescription>
            Track your baby's growth over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center p-4">Loading...</div>
          ) : sortedRecords.length > 0 ? (
            <Table>
              <TableCaption>Growth records ordered by most recent</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Weight</TableHead>
                  <TableHead>Height</TableHead>
                  <TableHead>Head Circumference</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedRecords.map((record: any) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">
                      {format(new Date(record.date), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell>
                      {record.weight || "-"}
                    </TableCell>
                    <TableCell>
                      {record.height || "-"}
                    </TableCell>
                    <TableCell>
                      {record.headCircumference || "-"}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {record.notes || "-"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleEdit(record)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-destructive"
                          onClick={() => handleDelete(record.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center p-6 text-muted-foreground">
              No growth records available. Click 'Add Record' to start tracking growth.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}