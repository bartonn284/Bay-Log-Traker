import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent,
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  User,
  PenLine,
  Weight,
  Ruler,
  Baby,
  HeartPulse,
  Info,
  Upload
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

interface Baby {
  id: number;
  name: string;
  ownerId: number;
  gender: string | null;
  dateOfBirth: Date | null;
  weight: string | null;
  height: string | null;
  width: string | null;
  bloodType: string | null;
  allergies: string | null;
  conditions: string | null;
  emergencyContact: string | null;
  doctor: string | null;
  doctorPhone: string | null;
  notes: string | null;
  hairColor: string | null;
  eyeColor: string | null;
  birthmarks: string | null;
  photoUrl: string | null;
  shareCode: string | null;
  shareCodeExpiry: Date | null;
  createdAt: Date;
}

export default function BabyInfoTab() {
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("basic");
  const [formData, setFormData] = useState({
    name: "",
    gender: "",
    dateOfBirth: null as Date | null,
    weight: "",
    height: "",
    width: "",
    bloodType: "",
    allergies: "",
    conditions: "",
    emergencyContact: "",
    doctor: "",
    doctorPhone: "",
    notes: "",
    hairColor: "",
    eyeColor: "",
    birthmarks: "",
    photoUrl: ""
  });
  
  // Fetch baby details
  const { data: baby, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby],
    queryFn: async () => {
      if (selectedBaby === null) return null;
      const res = await apiRequest("GET", `/api/babies/${selectedBaby}`);
      return res.json();
    },
    enabled: selectedBaby !== null
  });
  
  // Update baby information
  const updateMutation = useMutation({
    mutationFn: async (data: Partial<Baby>) => {
      if (selectedBaby === null) {
        throw new Error("No baby selected");
      }
      const res = await apiRequest("PATCH", `/api/babies/${selectedBaby}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby] });
      queryClient.invalidateQueries({ queryKey: ['/api/babies'] });
      toast({
        title: "Success",
        description: "Baby information updated successfully",
      });
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update baby information: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Populate form with baby data when available
  useEffect(() => {
    if (baby) {
      setFormData({
        name: baby.name || "",
        gender: baby.gender || "",
        dateOfBirth: baby.dateOfBirth ? new Date(baby.dateOfBirth) : null,
        weight: baby.weight || "",
        height: baby.height || "",
        width: baby.width || "",
        bloodType: baby.bloodType || "",
        allergies: baby.allergies || "",
        conditions: baby.conditions || "",
        emergencyContact: baby.emergencyContact || "",
        doctor: baby.doctor || "",
        doctorPhone: baby.doctorPhone || "",
        notes: baby.notes || "",
        hairColor: baby.hairColor || "",
        eyeColor: baby.eyeColor || "",
        birthmarks: baby.birthmarks || "",
        photoUrl: baby.photoUrl || ""
      });
    }
  }, [baby]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  // Handle form submission without refreshing the page
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault(); // Prevent form submission
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // Create a simple update object with just the fields we know are safe
      const updateData = {
        name: formData.name || "",
        gender: formData.gender || "",
        weight: formData.weight || "",
        height: formData.height || "",
        width: formData.width || "",
        bloodType: formData.bloodType || "",
        allergies: formData.allergies || "",
        doctor: formData.doctor || "",
        doctorPhone: formData.doctorPhone || "",
        conditions: formData.conditions || "",
        emergencyContact: formData.emergencyContact || "",
        photoUrl: formData.photoUrl || "",
        hairColor: formData.hairColor || "",
        eyeColor: formData.eyeColor || "", 
        birthmarks: formData.birthmarks || "",
        notes: formData.notes || ""
      };
      
      // Show loading toast
      toast({
        title: "Saving...",
        description: "Updating baby profile information"
      });
      
      // Submit the update - with a very simple object that doesn't include date fields
      updateMutation.mutate(updateData);
    } catch (error) {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: "Failed to update baby information. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Age calculation
  const calculateAge = (dateOfBirth: Date | null) => {
    if (!dateOfBirth) return "Unknown";
    
    const birthDate = new Date(dateOfBirth);
    const now = new Date();
    
    const yearDiff = now.getFullYear() - birthDate.getFullYear();
    const monthDiff = now.getMonth() - birthDate.getMonth();
    const dayDiff = now.getDate() - birthDate.getDate();
    
    if (yearDiff > 0) {
      return `${yearDiff} ${yearDiff === 1 ? 'year' : 'years'}`;
    } else if (monthDiff > 0) {
      return `${monthDiff} ${monthDiff === 1 ? 'month' : 'months'}`;
    } else {
      const days = dayDiff > 0 ? dayDiff : 0;
      return `${days} ${days === 1 ? 'day' : 'days'}`;
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Baby Information</h2>
          <p className="text-sm text-muted-foreground">
            View and manage your baby's profile information
          </p>
        </div>
        
        <Dialog open={isEditDialogOpen} onOpenChange={(open) => {
          if (open) {
            // When opening the dialog, pre-fill the form with current baby data
            if (selectedBaby) {
              // Get the baby data from the API
              const getBaby = async () => {
                try {
                  const res = await apiRequest("GET", `/api/babies/${selectedBaby}`);
                  const baby = await res.json();
                  
                  // Set form data with the baby's information
                  setFormData({
                    name: baby.name || "",
                    gender: baby.gender || "",
                    dateOfBirth: baby.dateOfBirth ? new Date(baby.dateOfBirth) : null,
                    weight: baby.weight || "",
                    height: baby.height || "",
                    width: baby.width || "",
                    bloodType: baby.bloodType || "",
                    allergies: baby.allergies || "",
                    conditions: baby.conditions || "",
                    emergencyContact: baby.emergencyContact || "",
                    doctor: baby.doctor || "",
                    doctorPhone: baby.doctorPhone || "",
                    notes: baby.notes || "",
                    hairColor: baby.hairColor || "",
                    eyeColor: baby.eyeColor || "",
                    birthmarks: baby.birthmarks || "",
                    photoUrl: baby.photoUrl || "",
                  });
                } catch (error) {
                  console.error("Error fetching baby data:", error);
                  toast({
                    title: "Error",
                    description: "Could not load baby information",
                    variant: "destructive"
                  });
                }
              };
              
              // Call the function to get baby data
              getBaby();
            }
          }
          setIsEditDialogOpen(open);
        }}>
          <Button 
            type="button"
            onClick={(e) => {
              e.preventDefault();
              setIsEditDialogOpen(true);
            }}
          >
            <PenLine className="h-4 w-4 mr-2" />
            Edit Info
          </Button>
          <DialogContent className="sm:max-w-[650px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Baby Information</DialogTitle>
              <DialogDescription>
                Update your baby's profile information
              </DialogDescription>
            </DialogHeader>
            
            <Tabs
              defaultValue="basic"
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic">Basic Info</TabsTrigger>
                <TabsTrigger value="medical">Medical Info</TabsTrigger>
                <TabsTrigger value="appearance">Appearance</TabsTrigger>
              </TabsList>
              
              <div className="baby-info-container">
                <TabsContent value="basic" className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Baby's name"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="gender">Gender</Label>
                      <Select
                        value={formData.gender || ""}
                        onValueChange={(value) => setFormData((prev) => ({ ...prev, gender: value }))}
                      >
                        <SelectTrigger id="gender">
                          <SelectValue placeholder="Select gender" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Date of Birth</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {formData.dateOfBirth 
                            ? format(formData.dateOfBirth, "PPP") 
                            : "Select birth date"
                          }
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={formData.dateOfBirth || undefined}
                          onSelect={(date) => 
                            setFormData((prev) => ({ ...prev, dateOfBirth: date || null }))
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight</Label>
                      <Input
                        id="weight"
                        name="weight"
                        value={formData.weight || ""}
                        onChange={handleChange}
                        placeholder="e.g., 7.5 lbs"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="height">Height</Label>
                      <Input
                        id="height"
                        name="height"
                        value={formData.height || ""}
                        onChange={handleChange}
                        placeholder="e.g., 20 in"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="width">Head Circumference</Label>
                      <Input
                        id="width"
                        name="width"
                        value={formData.width || ""}
                        onChange={handleChange}
                        placeholder="e.g., 14 in"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Baby Photo</Label>
                    <div className="flex items-center gap-2">
                      <div className="grid w-full items-center gap-1.5">
                        <Label htmlFor="baby-picture" className="sr-only">Baby Picture</Label>
                      <div className="grid gap-2">
                        <div className="flex flex-col space-y-2">
                          {/* Option 1: Upload an image file */}
                          <div>
                            <Label htmlFor="baby-picture">Upload a photo</Label>
                            <Input
                              id="baby-picture"
                              type="file"
                              accept="image/*"
                              className="cursor-pointer mt-1"
                              onClick={(e) => {
                                // Reset the input value on click to allow selecting the same file again
                                e.currentTarget.value = '';
                              }}
                              onInput={(e) => {
                                // Completely prevent any form submission that might be happening
                                e.preventDefault();
                                e.stopPropagation();
                              }}
                              onChange={(e) => {
                                // Very important - prevent any form submissions
                                e.preventDefault();
                                e.stopPropagation();
                                
                                // Get the selected file without triggering a form submit
                                const fileInput = e.target as HTMLInputElement;
                                const file = fileInput.files?.[0];
                                
                                if (!file) return;
                                
                                // Validate file size (limit to 5MB)
                                if (file.size > 5 * 1024 * 1024) {
                                  toast({
                                    title: "File too large",
                                    description: "Please select an image under 5MB",
                                    variant: "destructive"
                                  });
                                  return;
                                }
                                
                                // Show a loading toast
                                toast({
                                  title: "Processing image...",
                                  description: "Please wait while we prepare your image",
                                });
                                
                                // Process the file in a safer way
                                setTimeout(() => {
                                  // Use setTimeout to break out of the event cycle
                                  // This helps prevent form submissions
                                  const reader = new FileReader();
                                  
                                  reader.onloadend = () => {
                                    try {
                                      // Get the base64 data
                                      const base64String = reader.result as string;
                                      
                                      // Update state with the image data
                                      setFormData(prev => ({
                                        ...prev,
                                        photoUrl: base64String
                                      }));
                                      
                                      // Show success message
                                      toast({
                                        title: "Photo uploaded",
                                        description: "Image is ready. Click Save Changes when you're done.",
                                      });
                                      
                                      // Clear the file input to allow re-selecting the same file
                                      fileInput.value = '';
                                    } catch (error) {
                                      console.error("Error processing image:", error);
                                      toast({
                                        title: "Upload failed",
                                        description: "Could not process the image",
                                        variant: "destructive"
                                      });
                                    }
                                  };
                                  
                                  reader.onerror = () => {
                                    console.error("FileReader error:", reader.error);
                                    toast({
                                      title: "Upload error",
                                      description: "There was a problem reading your file",
                                      variant: "destructive"
                                    });
                                  };
                                  
                                  // Read the file as a data URL (base64)
                                  reader.readAsDataURL(file);
                                }, 0);
                              }}
                            />
                            <p className="text-xs text-muted-foreground mt-1">
                              Select an image file from your device
                            </p>
                          </div>

                          {/* Option 2: Enter URL directly */}
                          <div className="mt-2 pt-2 border-t">
                            <Label htmlFor="photoUrl">Or enter image URL</Label>
                            <Input
                              id="photoUrl"
                              name="photoUrl"
                              placeholder="https://example.com/baby.jpg"
                              value={formData.photoUrl || ""}
                              onChange={handleChange}
                              className="w-full mt-1"
                            />
                            <p className="text-xs text-muted-foreground mt-1">
                              Enter a direct link to an online image
                            </p>
                          </div>
                        </div>
                        
                        {/* Compact Image Preview */}
                        <div className="mt-2">
                          <Label className="mb-1 block">Preview</Label>
                          <div className="flex items-center space-x-3">
                            {formData.photoUrl ? (
                              <div className="rounded-lg overflow-hidden w-20 h-20 border shadow-sm flex-shrink-0">
                                <img 
                                  src={formData.photoUrl} 
                                  alt="Baby preview" 
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    e.currentTarget.src = "";
                                    toast({
                                      title: "Image error",
                                      description: "Could not load the image",
                                      variant: "destructive"
                                    });
                                  }}
                                />
                              </div>
                            ) : (
                              <div className="flex items-center justify-center w-20 h-20 rounded-lg border bg-muted flex-shrink-0">
                                <span className="text-xs text-muted-foreground">No image</span>
                              </div>
                            )}
                            <div className="text-xs text-muted-foreground">
                              {formData.photoUrl ? 
                                "Image ready to save. Click 'Save Changes' to update your baby's profile." : 
                                "Upload an image or provide a URL to add a photo to your baby's profile."}
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="medical" className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="bloodType">Blood Type</Label>
                      <Select
                        value={formData.bloodType || ""}
                        onValueChange={(value) => setFormData((prev) => ({ ...prev, bloodType: value }))}
                      >
                        <SelectTrigger id="bloodType">
                          <SelectValue placeholder="Select blood type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A+">A+</SelectItem>
                          <SelectItem value="A-">A-</SelectItem>
                          <SelectItem value="B+">B+</SelectItem>
                          <SelectItem value="B-">B-</SelectItem>
                          <SelectItem value="AB+">AB+</SelectItem>
                          <SelectItem value="AB-">AB-</SelectItem>
                          <SelectItem value="O+">O+</SelectItem>
                          <SelectItem value="O-">O-</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="allergies">Allergies</Label>
                      <Input
                        id="allergies"
                        name="allergies"
                        value={formData.allergies || ""}
                        onChange={handleChange}
                        placeholder="e.g., Peanuts, Dairy"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="conditions">Medical Conditions</Label>
                    <Textarea
                      id="conditions"
                      name="conditions"
                      value={formData.conditions || ""}
                      onChange={handleChange}
                      placeholder="Any medical conditions..."
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="doctor">Doctor's Name</Label>
                      <Input
                        id="doctor"
                        name="doctor"
                        value={formData.doctor || ""}
                        onChange={handleChange}
                        placeholder="Doctor's name"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="doctorPhone">Doctor's Phone</Label>
                      <Input
                        id="doctorPhone"
                        name="doctorPhone"
                        value={formData.doctorPhone || ""}
                        onChange={handleChange}
                        placeholder="Doctor's phone number"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="emergencyContact">Emergency Contact</Label>
                    <Input
                      id="emergencyContact"
                      name="emergencyContact"
                      value={formData.emergencyContact || ""}
                      onChange={handleChange}
                      placeholder="Emergency contact details"
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="appearance" className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="hairColor">Hair Color</Label>
                      <Input
                        id="hairColor"
                        name="hairColor"
                        value={formData.hairColor || ""}
                        onChange={handleChange}
                        placeholder="e.g., Brown, Blonde"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="eyeColor">Eye Color</Label>
                      <Input
                        id="eyeColor"
                        name="eyeColor"
                        value={formData.eyeColor || ""}
                        onChange={handleChange}
                        placeholder="e.g., Blue, Brown"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="birthmarks">Birthmarks or Distinguishing Features</Label>
                    <Textarea
                      id="birthmarks"
                      name="birthmarks"
                      value={formData.birthmarks || ""}
                      onChange={handleChange}
                      placeholder="Any birthmarks or distinguishing features..."
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      value={formData.notes || ""}
                      onChange={handleChange}
                      placeholder="Any additional notes..."
                    />
                  </div>
                </TabsContent>
                
                {/* Actions bar that's always accessible */}
                <div className="sticky bottom-0 pt-4 mt-4 border-t bg-background flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsEditDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="button"
                    variant="default"
                    onClick={(e) => {
                      e.preventDefault();
                      handleSubmit(e);
                    }}
                  >
                    Save Changes
                  </Button>
                </div>
              </div>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>
      
      {isLoading ? (
        <div className="text-center p-4">Loading baby information...</div>
      ) : baby ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle className="text-center text-lg">
                {baby.name}
                {baby.gender && (
                  <Badge 
                    variant="outline" 
                    className={`ml-2 ${baby.gender === 'male' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400' : 'bg-pink-50 text-pink-600 dark:bg-pink-900/20 dark:text-pink-400'}`}
                  >
                    {baby.gender === 'male' ? 'Boy' : baby.gender === 'female' ? 'Girl' : 'Other'}
                  </Badge>
                )}
              </CardTitle>
              {baby.dateOfBirth && (
                <CardDescription className="text-center">
                  Age: {calculateAge(new Date(baby.dateOfBirth))}
                </CardDescription>
              )}
            </CardHeader>
            <CardContent className="flex justify-center">
              {baby.photoUrl ? (
                <div className="w-40 h-40 rounded-full overflow-hidden">
                  <img 
                    src={baby.photoUrl} 
                    alt={baby.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="w-40 h-40 rounded-full bg-muted flex items-center justify-center">
                  <Baby className="h-20 w-20 text-muted-foreground/60" />
                </div>
              )}
              <Button 
                onClick={() => {
                  if (selectedBaby) {
                    setIsEditDialogOpen(true);
                  } else {
                    toast({
                      title: "Error",
                      description: "No baby selected",
                      variant: "destructive",
                    });
                  }
                }}
                variant="outline" 
                size="sm" 
                className="mt-4"
              >
                <Upload className="h-3.5 w-3.5 mr-1.5" />
                Upload Photo
              </Button>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">
                <div className="flex items-center">
                  <Info className="h-4 w-4 mr-2" />
                  Basic Information
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-y-3 text-sm">
                <div>
                  <span className="font-medium">Date of Birth:</span>
                  <div className="text-muted-foreground">
                    {baby.dateOfBirth ? format(new Date(baby.dateOfBirth), "PPP") : "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Weight:</span>
                  <div className="text-muted-foreground">
                    {baby.weight || "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Height:</span>
                  <div className="text-muted-foreground">
                    {baby.height || "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Head Circumference:</span>
                  <div className="text-muted-foreground">
                    {baby.width || "Not specified"}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-3">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">
                <div className="flex items-center">
                  <HeartPulse className="h-4 w-4 mr-2" />
                  Medical Information
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-y-3 gap-x-6 text-sm">
                <div>
                  <span className="font-medium">Blood Type:</span>
                  <div className="text-muted-foreground">
                    {baby.bloodType || "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Allergies:</span>
                  <div className="text-muted-foreground">
                    {baby.allergies || "None recorded"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Medical Conditions:</span>
                  <div className="text-muted-foreground">
                    {baby.conditions || "None recorded"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Doctor:</span>
                  <div className="text-muted-foreground">
                    {baby.doctor || "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Doctor's Phone:</span>
                  <div className="text-muted-foreground">
                    {baby.doctorPhone || "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Emergency Contact:</span>
                  <div className="text-muted-foreground">
                    {baby.emergencyContact || "Not specified"}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-3">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  Appearance
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-y-3 gap-x-6 text-sm">
                <div>
                  <span className="font-medium">Hair Color:</span>
                  <div className="text-muted-foreground">
                    {baby.hairColor || "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Eye Color:</span>
                  <div className="text-muted-foreground">
                    {baby.eyeColor || "Not specified"}
                  </div>
                </div>
                
                <div>
                  <span className="font-medium">Birthmarks:</span>
                  <div className="text-muted-foreground">
                    {baby.birthmarks || "None recorded"}
                  </div>
                </div>
              </div>
              
              {baby.notes && (
                <div className="mt-4 pt-3 border-t text-sm">
                  <span className="font-medium">Additional Notes:</span>
                  <div className="text-muted-foreground mt-1">
                    {baby.notes}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="text-center p-6 text-muted-foreground">
          <User className="h-12 w-12 mx-auto mb-3 text-muted-foreground/60" />
          <h3 className="font-medium mb-1">No baby information available</h3>
          <p className="text-sm">Please select a baby to view their information.</p>
        </div>
      )}
    </div>
  );
}