import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Thermometer, 
  Plus, 
  AlertTriangle, 
  PillIcon, 
  Stethoscope, 
  Trash2, 
  Edit 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface HealthRecord {
  id: number;
  babyId: number;
  createdAt: Date;
  date: Date;
  recordType: string;
  temperature: string | null;
  medicationName: string | null;
  medicationDose: string | null;
  medicationSchedule: string | null;
  doctorNotes: string | null;
  isSickDay: boolean | null;
  notes: string | null;
  createdBy: number;
}

export default function HealthRecordsTab() {
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentRecord, setCurrentRecord] = useState<HealthRecord | null>(null);
  const [recordType, setRecordType] = useState<string>("Temperature");
  const [date, setDate] = useState<Date>(new Date());
  const [temperature, setTemperature] = useState("");
  const [medicationName, setMedicationName] = useState("");
  const [medicationDose, setMedicationDose] = useState("");
  const [medicationSchedule, setMedicationSchedule] = useState("");
  const [doctorNotes, setDoctorNotes] = useState("");
  const [symptoms, setSymptoms] = useState("");
  const [illnessName, setIllnessName] = useState("");
  const [isSickDay, setIsSickDay] = useState(false);
  const [notes, setNotes] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  
  // Fetch health records
  const { data: healthRecords, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby?.id, 'health'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby.id}/health`);
      return res.json();
    },
    enabled: !!selectedBaby
  });
  
  // Create health record
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      recordType: string;
      date: Date;
      temperature?: string;
      medicationName?: string;
      medicationDose?: string;
      medicationSchedule?: string;
      doctorNotes?: string;
      isSickDay?: boolean;
      notes?: string;
    }) => {
      // Format data to store metadata in notes field until database schema is updated
      const finalData = { ...data };
      
      if (data.recordType === "Illness") {
        let notesWithMetadata = data.notes || "";
        
        if (symptoms) {
          notesWithMetadata += `\n\nSymptoms: ${symptoms}`;
        }
        
        if (illnessName) {
          notesWithMetadata += `\n\nIllness: ${illnessName}`;
        }
        
        if (isSickDay) {
          notesWithMetadata += `\n\nMarked as sick day`;
        }
        
        finalData.notes = notesWithMetadata.trim();
      }
      
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/health`, finalData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'health'] });
      toast({
        title: "Success",
        description: "Health record added successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add health record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update health record
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      recordType: string;
      date: Date;
      temperature?: string;
      medicationName?: string;
      medicationDose?: string;
      medicationSchedule?: string;
      doctorNotes?: string;
      isSickDay?: boolean;
      notes?: string;
    }) => {
      // Format data to store metadata in notes field until database schema is updated
      const finalData = { ...data };
      
      if (data.recordType === "Illness") {
        let notesWithMetadata = data.notes || "";
        
        if (symptoms) {
          notesWithMetadata += `\n\nSymptoms: ${symptoms}`;
        }
        
        if (illnessName) {
          notesWithMetadata += `\n\nIllness: ${illnessName}`;
        }
        
        if (isSickDay) {
          notesWithMetadata += `\n\nMarked as sick day`;
        }
        
        finalData.notes = notesWithMetadata.trim();
      }
      
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/health/${data.id}`, finalData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'health'] });
      toast({
        title: "Success",
        description: "Health record updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update health record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete health record
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/health/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'health'] });
      toast({
        title: "Success",
        description: "Health record deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete health record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setRecordType("Temperature");
    setDate(new Date());
    setTemperature("");
    setMedicationName("");
    setMedicationDose("");
    setMedicationSchedule("");
    setDoctorNotes("");
    setSymptoms("");
    setIllnessName("");
    setIsSickDay(false);
    setNotes("");
    setCurrentRecord(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    // Validate based on record type
    if (recordType === "Temperature" && !temperature) {
      toast({
        title: "Error",
        description: "Please enter a temperature",
        variant: "destructive",
      });
      return;
    }
    
    if (recordType === "Medication" && !medicationName) {
      toast({
        title: "Error",
        description: "Please enter a medication name",
        variant: "destructive",
      });
      return;
    }
    
    const data: any = {
      babyId: selectedBaby.id,
      recordType,
      date,
      notes,
    };
    
    // Add fields based on record type
    if (recordType === "Temperature") {
      data.temperature = temperature;
    } else if (recordType === "Medication") {
      data.medicationName = medicationName;
      data.medicationDose = medicationDose;
      data.medicationSchedule = medicationSchedule;
    } else if (recordType === "Doctor Visit") {
      data.doctorNotes = doctorNotes;
    } else if (recordType === "Illness") {
      data.temperature = temperature;
      data.isSickDay = isSickDay;
      // Symptoms and illness name will be added to notes by the mutation function
    }
    
    createMutation.mutate(data);
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !currentRecord) {
      toast({
        title: "Error",
        description: "No baby or record selected",
        variant: "destructive",
      });
      return;
    }
    
    // Validate based on record type
    if (recordType === "Temperature" && !temperature) {
      toast({
        title: "Error",
        description: "Please enter a temperature",
        variant: "destructive",
      });
      return;
    }
    
    if (recordType === "Medication" && !medicationName) {
      toast({
        title: "Error",
        description: "Please enter a medication name",
        variant: "destructive",
      });
      return;
    }
    
    const data: any = {
      id: currentRecord.id,
      babyId: selectedBaby.id,
      recordType,
      date,
      notes,
    };
    
    // Add fields based on record type
    if (recordType === "Temperature") {
      data.temperature = temperature;
    } else if (recordType === "Medication") {
      data.medicationName = medicationName;
      data.medicationDose = medicationDose;
      data.medicationSchedule = medicationSchedule;
    } else if (recordType === "Doctor Visit") {
      data.doctorNotes = doctorNotes;
    } else if (recordType === "Illness") {
      data.temperature = temperature;
      data.isSickDay = isSickDay;
      // Symptoms and illness name will be added to notes by the mutation function
    }
    
    updateMutation.mutate(data);
  };
  
  const handleEdit = (record: HealthRecord) => {
    setCurrentRecord(record);
    setRecordType(record.recordType);
    setDate(new Date(record.date));
    setTemperature(record.temperature || "");
    setMedicationName(record.medicationName || "");
    setMedicationDose(record.medicationDose || "");
    setMedicationSchedule(record.medicationSchedule || "");
    setDoctorNotes(record.doctorNotes || "");
    
    // Extract illness data from notes field if this is an illness record
    let symptomText = "";
    let illnessText = "";
    let isSickDayValue = false;
    let notesContent = record.notes || "";
    
    if (record.recordType === "Illness" && record.notes) {
      // Extract symptoms
      const symptomsMatch = record.notes.match(/Symptoms: (.*?)(\n\n|$)/);
      if (symptomsMatch) {
        symptomText = symptomsMatch[1];
        notesContent = notesContent.replace(symptomsMatch[0], "");
      }
      
      // Extract illness name
      const illnessMatch = record.notes.match(/Illness: (.*?)(\n\n|$)/);
      if (illnessMatch) {
        illnessText = illnessMatch[1];
        notesContent = notesContent.replace(illnessMatch[0], "");
      }
      
      // Check if marked as sick day
      isSickDayValue = record.notes.includes("Marked as sick day");
      if (isSickDayValue) {
        notesContent = notesContent.replace("Marked as sick day", "").trim();
      }
      
      // Clean up leftover newlines
      notesContent = notesContent.replace(/\n{3,}/g, "\n\n").trim();
    }
    
    setSymptoms(symptomText);
    setIllnessName(illnessText);
    setIsSickDay(isSickDayValue);
    setNotes(notesContent);
    
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this health record?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const renderAddForm = () => {
    return (
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Record Type</Label>
          <Select
            value={recordType}
            onValueChange={setRecordType}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select record type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Temperature">
                <div className="flex items-center">
                  <Thermometer className="h-4 w-4 mr-2 text-orange-500" />
                  Temperature
                </div>
              </SelectItem>
              <SelectItem value="Illness">
                <div className="flex items-center">
                  <AlertTriangle className="h-4 w-4 mr-2 text-red-500" />
                  Illness
                </div>
              </SelectItem>
              <SelectItem value="Medication">
                <div className="flex items-center">
                  <PillIcon className="h-4 w-4 mr-2 text-indigo-500" />
                  Medication
                </div>
              </SelectItem>
              <SelectItem value="Doctor Visit">
                <div className="flex items-center">
                  <Stethoscope className="h-4 w-4 mr-2 text-emerald-500" />
                  Doctor Visit
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="date">Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={date}
                onSelect={(date) => date && setDate(date)}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>
        
        {/* Temperature Fields */}
        {(recordType === "Temperature" || recordType === "Illness") && (
          <div className="space-y-2">
            <Label htmlFor="temperature">Temperature</Label>
            <Input
              id="temperature"
              placeholder="e.g., 98.6°F"
              value={temperature}
              onChange={(e) => setTemperature(e.target.value)}
            />
          </div>
        )}
        
        {/* Illness Fields */}
        {recordType === "Illness" && (
          <>
            <div className="space-y-2">
              <Label htmlFor="symptoms">Symptoms</Label>
              <Textarea
                id="symptoms"
                placeholder="Describe any symptoms"
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="illness">Illness/Diagnosis</Label>
              <Input
                id="illness"
                placeholder="e.g., Common Cold"
                value={illnessName}
                onChange={(e) => setIllnessName(e.target.value)}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="sick-day" 
                checked={isSickDay}
                onCheckedChange={(checked) => setIsSickDay(checked as boolean)}
              />
              <Label htmlFor="sick-day">Mark as sick day</Label>
            </div>
          </>
        )}
        
        {/* Medication Fields */}
        {recordType === "Medication" && (
          <>
            <div className="space-y-2">
              <Label htmlFor="medication-name">Medication Name</Label>
              <Input
                id="medication-name"
                placeholder="e.g., Acetaminophen"
                value={medicationName}
                onChange={(e) => setMedicationName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="medication-dose">Dosage</Label>
              <Input
                id="medication-dose"
                placeholder="e.g., 2.5mL"
                value={medicationDose}
                onChange={(e) => setMedicationDose(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="medication-schedule">Schedule</Label>
              <Input
                id="medication-schedule"
                placeholder="e.g., Every 6 hours"
                value={medicationSchedule}
                onChange={(e) => setMedicationSchedule(e.target.value)}
              />
            </div>
          </>
        )}
        
        {/* Doctor Visit Fields */}
        {recordType === "Doctor Visit" && (
          <div className="space-y-2">
            <Label htmlFor="doctor-notes">Doctor's Notes</Label>
            <Textarea
              id="doctor-notes"
              placeholder="Notes from the doctor's visit"
              value={doctorNotes}
              onChange={(e) => setDoctorNotes(e.target.value)}
            />
          </div>
        )}
        
        {/* Common Fields */}
        <div className="space-y-2">
          <Label htmlFor="notes">Additional Notes</Label>
          <Textarea
            id="notes"
            placeholder="Any additional notes or observations"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>
      </div>
    );
  };
  
  // Filter and sort health records
  const filteredRecords = (() => {
    let records = healthRecords || [];
    
    // First filter by type if needed
    if (activeFilter) {
      records = records.filter((record: HealthRecord) => record.recordType === activeFilter);
    }
    
    // Then sort by date (newest first)
    return [...records].sort((a: HealthRecord, b: HealthRecord) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  })();
  
  // Create record card component
  const HealthRecordCard = ({ record }: { record: HealthRecord }) => {
    const recordIcon = () => {
      switch (record.recordType) {
        case "Temperature":
          return <Thermometer className="h-5 w-5 text-orange-500" />;
        case "Illness":
          return <AlertTriangle className="h-5 w-5 text-red-500" />;
        case "Medication":
          return <PillIcon className="h-5 w-5 text-indigo-500" />;
        case "Doctor Visit":
          return <Stethoscope className="h-5 w-5 text-emerald-500" />;
        default:
          return <Thermometer className="h-5 w-5 text-primary" />;
      }
    };
    
    const recordColor = () => {
      switch (record.recordType) {
        case "Temperature":
          return "border-orange-500";
        case "Illness":
          return "border-red-500";
        case "Medication":
          return "border-indigo-500";
        case "Doctor Visit":
          return "border-emerald-500";
        default:
          return "border-primary";
      }
    };
    
    // Extract illness data from notes field if this is an illness record
    let symptoms = "";
    let illnessName = "";
    let isSickDay = false;
    
    if (record.recordType === "Illness" && record.notes) {
      // Extract symptoms
      const symptomsMatch = record.notes.match(/Symptoms: (.*?)(\n\n|$)/);
      if (symptomsMatch) {
        symptoms = symptomsMatch[1];
      }
      
      // Extract illness name
      const illnessMatch = record.notes.match(/Illness: (.*?)(\n\n|$)/);
      if (illnessMatch) {
        illnessName = illnessMatch[1];
      }
      
      // Check if marked as sick day
      isSickDay = record.notes.includes("Marked as sick day");
    }
    
    return (
      <Card className={`mb-4 border-l-4 ${recordColor()}`}>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                {recordIcon()}
              </div>
              <div>
                <CardTitle className="text-base font-medium">
                  {record.recordType}
                </CardTitle>
                <CardDescription>
                  {format(new Date(record.date), "PPP")}
                </CardDescription>
              </div>
            </div>
            <div className="flex space-x-1">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8" 
                onClick={() => handleEdit(record)}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 text-destructive" 
                onClick={() => handleDelete(record.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pb-4">
          {record.recordType === "Temperature" && record.temperature && (
            <div className="mb-3">
              <span className="text-sm text-muted-foreground">Temperature:</span>
              <p className="font-medium">{record.temperature}</p>
            </div>
          )}
          
          {record.recordType === "Illness" && (
            <>
              {record.temperature && (
                <div className="mb-2">
                  <span className="text-sm text-muted-foreground">Temperature:</span>
                  <p className="font-medium">{record.temperature}</p>
                </div>
              )}
              
              {symptoms && (
                <div className="mb-2">
                  <span className="text-sm text-muted-foreground">Symptoms:</span>
                  <p className="font-medium">{symptoms}</p>
                </div>
              )}
              
              {illnessName && (
                <div className="mb-2">
                  <span className="text-sm text-muted-foreground">Diagnosis:</span>
                  <p className="font-medium">{illnessName}</p>
                </div>
              )}
              
              {isSickDay && (
                <div className="mb-2">
                  <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                    Marked as sick day
                  </Badge>
                </div>
              )}
            </>
          )}
          
          {record.recordType === "Medication" && (
            <>
              {record.medicationName && (
                <div className="mb-2">
                  <span className="text-sm text-muted-foreground">Medication:</span>
                  <p className="font-medium">{record.medicationName}</p>
                </div>
              )}
              {record.medicationDose && (
                <div className="mb-2">
                  <span className="text-sm text-muted-foreground">Dose:</span>
                  <p className="font-medium">{record.medicationDose}</p>
                </div>
              )}
              {record.medicationSchedule && (
                <div className="mb-2">
                  <span className="text-sm text-muted-foreground">Schedule:</span>
                  <p className="font-medium">{record.medicationSchedule}</p>
                </div>
              )}
            </>
          )}
          
          {record.recordType === "Doctor Visit" && record.doctorNotes && (
            <div className="mb-3">
              <span className="text-sm text-muted-foreground">Doctor Notes:</span>
              <p className="font-medium">{record.doctorNotes}</p>
            </div>
          )}
          
          {record.notes && (
            <div className="mt-3 pt-3 border-t">
              <p className="text-sm text-muted-foreground">Notes:</p>
              <p className="text-sm mt-1">
                {record.recordType === "Illness" 
                  ? record.notes
                      .replace(/Symptoms: .*?(\n\n|$)/g, "")
                      .replace(/Illness: .*?(\n\n|$)/g, "")
                      .replace(/Marked as sick day/g, "")
                      .replace(/\n{3,}/g, "\n\n")
                      .trim()
                  : record.notes}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Health Records</h2>
          <p className="text-sm text-muted-foreground">
            Track illnesses, temperature, medication, and doctor visits
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Record
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Health Record</DialogTitle>
              <DialogDescription>
                Record a new health event for your baby
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {renderAddForm()}
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Save Record</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Health Record</DialogTitle>
              <DialogDescription>
                Update health event details
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleUpdate} className="space-y-4">
              {renderAddForm()}
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Update Record</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Filter Buttons */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        <Button 
          variant={activeFilter === null ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveFilter(null)}
        >
          All
        </Button>
        <Button 
          variant={activeFilter === "Temperature" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveFilter("Temperature")}
          className="flex items-center"
        >
          <Thermometer className="h-4 w-4 mr-1" />
          Temperature
        </Button>
        <Button 
          variant={activeFilter === "Illness" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveFilter("Illness")}
          className="flex items-center"
        >
          <AlertTriangle className="h-4 w-4 mr-1" />
          Illness
        </Button>
        <Button 
          variant={activeFilter === "Medication" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveFilter("Medication")}
          className="flex items-center"
        >
          <PillIcon className="h-4 w-4 mr-1" />
          Medication
        </Button>
        <Button 
          variant={activeFilter === "Doctor Visit" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveFilter("Doctor Visit")}
          className="flex items-center"
        >
          <Stethoscope className="h-4 w-4 mr-1" />
          Doctor Visit
        </Button>
      </div>
      
      {/* Health Records List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center p-4">Loading...</div>
        ) : filteredRecords.length > 0 ? (
          filteredRecords.map((record: HealthRecord) => (
            <HealthRecordCard key={record.id} record={record} />
          ))
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            No health records available. Click 'Add Record' to start tracking health.
          </div>
        )}
      </div>
    </div>
  );
}