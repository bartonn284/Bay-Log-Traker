import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatDate, calculateAge } from "@/lib/utils";
import { Baby } from "@shared/schema";
import { 
  AlertTriangle, 
  Weight, 
  Ruler, 
  Heart, 
  Activity,
  User, 
  Phone, 
  Utensils, 
  MoonStar,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface EmergencyProfileCardProps {
  baby: Baby;
  onExportPdf?: () => void;
}

export function EmergencyProfileCard({ baby, onExportPdf }: EmergencyProfileCardProps) {
  // Guard clause to prevent rendering with incomplete data
  if (!baby || !baby.name) {
    return null;
  }
  
  // Get baby age - with safety check to prevent errors
  const ageDisplay = baby.dateOfBirth ? calculateAge(new Date(baby.dateOfBirth)) : 'Unknown';
  const birthDateFormatted = baby.dateOfBirth ? formatDate(new Date(baby.dateOfBirth)) : '';

  return (
    <Card className="w-full overflow-hidden mb-6">
      <CardContent className="p-0">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-2 rounded-none">
            <TabsTrigger value="profile">Profile Info</TabsTrigger>
            <TabsTrigger value="health">Health Summary</TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile" className="pt-0">
            {/* Header with baby photo and main details */}
            <div className="bg-purple-100 dark:bg-purple-900/30 p-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16 border-2 border-white">
                  {baby.photoUrl ? (
                    <AvatarImage src={baby.photoUrl} alt={baby.name} />
                  ) : (
                    <AvatarFallback className="bg-purple-200 text-2xl">
                      {baby.gender === 'male' ? '👦' : baby.gender === 'female' ? '👧' : '👶'}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold">{baby.name}</h2>
                  <p className="text-sm">{ageDisplay} - {birthDateFormatted}</p>
                  
                  {baby.allergies && (
                    <div className="flex items-center mt-1 text-red-600 dark:text-red-400">
                      <AlertTriangle className="h-4 w-4 mr-1" />
                      <span className="text-sm">Allergies: {baby.allergies}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Physical stats - grid layout */}
            <div className="grid grid-cols-2 border-b">
              <div className="p-4 border-r">
                <div className="flex items-start gap-2">
                  <Weight className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="text-xl font-bold">{baby.weight || "N/A"}</div>
                    <div className="text-sm text-muted-foreground">Weight</div>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-start gap-2">
                  <Ruler className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="text-xl font-bold">{baby.height || "N/A"}</div>
                    <div className="text-sm text-muted-foreground">Height</div>
                  </div>
                </div>
              </div>
              <div className="p-4 border-r border-t">
                <div className="flex items-start gap-2">
                  <Activity className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="text-xl font-bold">{baby.width || "N/A"}</div>
                    <div className="text-sm text-muted-foreground">Head Circ.</div>
                  </div>
                </div>
              </div>
              <div className="p-4 border-t">
                <div className="flex items-start gap-2">
                  <Heart className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="text-xl font-bold">{baby.bloodType || "N/A"}</div>
                    <div className="text-sm text-muted-foreground">Blood Type</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Medical contacts */}
            <div className="grid grid-cols-2 border-b">
              <div className="p-4 border-r">
                <div className="flex items-start gap-2">
                  <User className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="font-medium">{baby.doctor || "Not specified"}</div>
                    <div className="text-sm text-muted-foreground">Pediatrician</div>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-start gap-2">
                  <Phone className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="font-medium">{baby.emergencyContact || "Not specified"}</div>
                    <div className="text-sm text-muted-foreground">Emergency contact</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Care preferences */}
            <div className="grid grid-cols-2 border-b">
              <div className="p-4 border-r">
                <div className="flex items-start gap-2">
                  <Utensils className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="font-medium">{baby.feedingPreferences || "Not specified"}</div>
                    <div className="text-sm text-muted-foreground">Feeding</div>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-start gap-2">
                  <MoonStar className="h-5 w-5 text-purple-500 mt-1" />
                  <div>
                    <div className="font-medium">{baby.soothingMethods || "Not specified"}</div>
                    <div className="text-sm text-muted-foreground">Mood</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Export Button */}
            <div className="p-4">
              <Button 
                variant="default"
                onClick={onExportPdf}
                className="w-full"
              >
                <FileText className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="health" className="pt-0">
            {/* Header with baby photo and main details */}
            <div className="bg-purple-100 dark:bg-purple-900/30 p-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16 border-2 border-white">
                  {baby.photoUrl ? (
                    <AvatarImage src={baby.photoUrl} alt={baby.name} />
                  ) : (
                    <AvatarFallback className="bg-purple-200 text-2xl">
                      {baby.gender === 'male' ? '👦' : baby.gender === 'female' ? '👧' : '👶'}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold">{baby.name}</h2>
                  <p className="text-sm">Health Summary</p>
                </div>
              </div>
            </div>
            
            {/* Health summary statistics */}
            <div className="p-4 space-y-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <h3 className="text-lg font-bold text-blue-700 dark:text-blue-400 mb-2">
                  Recent Health Records
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  View recent health tracking data and doctor visits
                </p>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Last temperature check:</span>
                    <span className="font-medium">Not available</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Recent illnesses:</span>
                    <span className="font-medium">None recorded</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last doctor visit:</span>
                    <span className="font-medium">Not available</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                <h3 className="text-lg font-bold text-green-700 dark:text-green-400 mb-2">
                  Growth Statistics
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Tracking baby's growth progress
                </p>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Current weight:</span>
                    <span className="font-medium">{baby.weight || "Not recorded"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Current height:</span>
                    <span className="font-medium">{baby.height || "Not recorded"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Head circumference:</span>
                    <span className="font-medium">{baby.width || "Not recorded"}</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Export Button */}
            <div className="p-4">
              <Button 
                variant="default"
                onClick={onExportPdf}
                className="w-full"
              >
                <FileText className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}