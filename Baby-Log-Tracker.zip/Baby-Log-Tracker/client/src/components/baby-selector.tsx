import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Baby } from "@shared/schema";
import { format, differenceInDays } from "date-fns";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Loader2, Heart, ChevronRight, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BabySelectorProps {
  selectedBaby: number | null;
  onSelectBaby: (babyId: number) => void;
  showQuickNav?: boolean;
  showDetails?: boolean;
  className?: string;
}

export function BabySelector({ 
  selectedBaby, 
  onSelectBaby, 
  showQuickNav = false,
  showDetails = false,
  className = ""
}: BabySelectorProps) {
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // Fetch babies
  const {
    data: babies,
    isLoading,
  } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
  });

  // Set first baby as selected if none selected
  useEffect(() => {
    if (babies && babies.length > 0 && (selectedBaby === null || selectedBaby === undefined)) {
      onSelectBaby(babies[0].id);
    }
  }, [babies, selectedBaby, onSelectBaby]);

  // Update current index when selectedBaby changes
  useEffect(() => {
    if (babies && selectedBaby) {
      const index = babies.findIndex(baby => baby.id === selectedBaby);
      if (index !== -1) {
        setCurrentIndex(index);
      }
    }
  }, [babies, selectedBaby]);

  // Handle quick navigation
  const navigateBaby = (direction: 'prev' | 'next') => {
    if (!babies || babies.length <= 1) return;

    let newIndex = direction === 'prev' 
      ? (currentIndex - 1 + babies.length) % babies.length
      : (currentIndex + 1) % babies.length;

    setCurrentIndex(newIndex);
    onSelectBaby(babies[newIndex].id);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-10">
        <Loader2 className="h-4 w-4 animate-spin text-primary" />
      </div>
    );
  }

  if (!babies || babies.length === 0) {
    return (
      <div className="text-sm text-muted-foreground">
        No babies added yet
      </div>
    );
  }

  // Calculate baby's age
  const calculateAge = (dateOfBirth: Date | null) => {
    if (!dateOfBirth) return null;

    try {
      const birthDate = new Date(dateOfBirth);
      const now = new Date();
      const diffDays = differenceInDays(now, birthDate);

      if (diffDays < 30) {
        return `${diffDays} days`;
      } else if (diffDays < 365) {
        const months = Math.floor(diffDays / 30);
        return `${months} month${months > 1 ? 's' : ''}`;
      } else {
        const years = Math.floor(diffDays / 365);
        const remainingMonths = Math.floor((diffDays % 365) / 30);
        return `${years}y ${remainingMonths > 0 ? `${remainingMonths}m` : ''}`;
      }
    } catch (e) {
      console.error("Error calculating age:", e);
      return null;
    }
  };

  // Get baby data for simplified view or full details
  const selectedBabyData = babies.find(b => b.id === selectedBaby);
  if (!selectedBabyData) return null;

  // Simple mini-dashboard for quick switching and basic info
  if (!showDetails) {
    return (
      <div className={`${className} w-full`}>
        <div className="flex items-center bg-card/50 p-2 rounded-md border border-border/40 shadow-sm">
          <div className="flex-shrink-0 mr-3">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              {selectedBabyData.gender === 'male' ? (
                <span className="text-blue-500 text-xl">♂</span>
              ) : selectedBabyData.gender === 'female' ? (
                <span className="text-pink-500 text-xl">♀</span>
              ) : (
                <span className="text-purple-500 text-xl">⚥</span>
              )}
            </div>
          </div>
          
          <div className="min-w-0 flex-1">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-semibold truncate bg-gradient-to-r from-primary to-blue-400 text-transparent bg-clip-text">
                {selectedBabyData.name}
              </h3>

              <Select
                value={selectedBaby?.toString()}
                onValueChange={(value) => onSelectBaby(parseInt(value))}
              >
                <SelectTrigger className="h-7 text-xs px-2 min-w-[90px] border-0 bg-transparent hover:bg-accent focus:ring-0">
                  <span className="text-xs text-muted-foreground">Switch Baby</span>
                </SelectTrigger>
                <SelectContent>
                  {babies.map((baby) => (
                    <SelectItem key={baby.id} value={baby.id.toString()}>
                      {baby.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex gap-x-3 text-[10px] text-muted-foreground">
              {selectedBabyData.dateOfBirth && (
                <div className="flex items-center">
                  <span>{format(new Date(selectedBabyData.dateOfBirth), "MMM dd, yyyy")}</span>
                </div>
              )}
              
              {selectedBabyData.weight && (
                <div className="flex items-center">
                  <span>{selectedBabyData.weight}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Detailed card with baby info
  const age = calculateAge(selectedBabyData.dateOfBirth);

  return (
    <Card className={`${className}`}>
      <CardContent className="pt-4 pb-2">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">Baby Profile</h3>

          <div className="flex items-center">
            {showQuickNav && (
              <Select
                value={selectedBaby?.toString()}
                onValueChange={(value) => onSelectBaby(parseInt(value))}
              >
                <SelectTrigger className="w-[140px] h-8 mx-1">
                  <SelectValue placeholder="Select Baby" />
                </SelectTrigger>
                <SelectContent>
                  {babies.map((baby) => (
                    <SelectItem key={baby.id} value={baby.id.toString()}>
                      {baby.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {!showQuickNav && (
              <Select
                value={selectedBaby?.toString()}
                onValueChange={(value) => onSelectBaby(parseInt(value))}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Select Baby" />
                </SelectTrigger>
                <SelectContent>
                  {babies.map((baby) => (
                    <SelectItem key={baby.id} value={baby.id.toString()}>
                      {baby.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        </div>

        <div className="flex items-start md:items-center flex-col md:flex-row">
          <div className="rounded-full bg-primary/10 p-3 mr-3">
            {selectedBabyData.gender === 'male' ? (
              <span className="text-blue-500 text-2xl">♂</span>
            ) : selectedBabyData.gender === 'female' ? (
              <span className="text-pink-500 text-2xl">♀</span>
            ) : (
              <span className="text-purple-500 text-2xl">⚥</span>
            )}
          </div>

          <div className="flex-1">
            <h3 className="text-xl font-bold bg-gradient-to-r from-primary to-blue-400 text-transparent bg-clip-text">
              {selectedBabyData.name}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-4 gap-y-1 mt-1">
              {selectedBabyData.dateOfBirth && (
                <div className="flex items-center">
                  <Heart className="h-3 w-3 text-muted-foreground mr-1" />
                  <span className="text-xs text-muted-foreground mr-1">Born:</span> 
                  <span className="text-xs font-medium">{format(new Date(selectedBabyData.dateOfBirth), "MMM dd, yyyy")}</span>
                </div>
              )}

              {age && (
                <div className="flex items-center">
                  <span className="text-xs text-muted-foreground mr-1">Age:</span> 
                  <span className="text-xs font-medium">{age}</span>
                </div>
              )}

              {selectedBabyData.weight && (
                <div className="flex items-center">
                  <span className="text-xs text-muted-foreground mr-1">Weight:</span> 
                  <span className="text-xs font-medium">{selectedBabyData.weight}</span>
                </div>
              )}

              {selectedBabyData.width && (
                <div className="flex items-center">
                  <span className="text-xs text-muted-foreground mr-1">Width:</span> 
                  <span className="text-xs font-medium">{selectedBabyData.width}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}