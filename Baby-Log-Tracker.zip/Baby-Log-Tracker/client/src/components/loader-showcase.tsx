import React, { useState } from "react";
import { BabySpinner } from "@/components/baby-spinner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export function LoaderShowcase() {
  const [spinnerType, setSpinnerType] = useState<"rattle" | "bottle" | "diaper" | "cradle">("rattle");
  const [spinnerSize, setSpinnerSize] = useState<"sm" | "md" | "lg" | "xl">("md");
  const [showText, setShowText] = useState(false);
  const [animationSpeed, setAnimationSpeed] = useState(1);
  
  return (
    <div className="space-y-8">
      <Tabs defaultValue="gallery" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="gallery">Spinner Gallery</TabsTrigger>
          <TabsTrigger value="customize">Customize Spinner</TabsTrigger>
        </TabsList>
        
        <TabsContent value="gallery" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <SpinnerCard type="rattle" title="Rattle Spinner" description="Perfect for general loading states" />
            <SpinnerCard type="bottle" title="Bottle Spinner" description="Ideal for feeding-related loading" />
            <SpinnerCard type="diaper" title="Diaper Spinner" description="For diaper change tracking" />
            <SpinnerCard type="cradle" title="Cradle Spinner" description="Great for sleep tracking loading" />
          </div>
          
          <div className="mt-6 bg-white dark:bg-gray-950 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-3">Size Comparison</h2>
            <div className="grid grid-cols-4 gap-4">
              <div className="flex flex-col items-center">
                <div className="h-20 flex items-center justify-center">
                  <BabySpinner type="rattle" size="sm" />
                </div>
                <span className="text-xs text-gray-500">Small</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="h-20 flex items-center justify-center">
                  <BabySpinner type="rattle" size="md" />
                </div>
                <span className="text-xs text-gray-500">Medium</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="h-20 flex items-center justify-center">
                  <BabySpinner type="rattle" size="lg" />
                </div>
                <span className="text-xs text-gray-500">Large</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="h-20 flex items-center justify-center">
                  <BabySpinner type="rattle" size="xl" />
                </div>
                <span className="text-xs text-gray-500">X-Large</span>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="customize" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Spinner Settings</CardTitle>
                <CardDescription>Customize your baby spinner</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="spinner-type">Spinner Type</Label>
                  <Select value={spinnerType} onValueChange={(value) => setSpinnerType(value as any)}>
                    <SelectTrigger id="spinner-type">
                      <SelectValue placeholder="Select spinner type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rattle">Rattle</SelectItem>
                      <SelectItem value="bottle">Bottle</SelectItem>
                      <SelectItem value="diaper">Diaper</SelectItem>
                      <SelectItem value="cradle">Cradle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="spinner-size">Spinner Size</Label>
                  <Select value={spinnerSize} onValueChange={(value) => setSpinnerSize(value as any)}>
                    <SelectTrigger id="spinner-size">
                      <SelectValue placeholder="Select spinner size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sm">Small</SelectItem>
                      <SelectItem value="md">Medium</SelectItem>
                      <SelectItem value="lg">Large</SelectItem>
                      <SelectItem value="xl">Extra Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-text">Show Text</Label>
                    <Switch id="show-text" checked={showText} onCheckedChange={setShowText} />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="animation-speed">Animation Speed: {animationSpeed}x</Label>
                  <Slider 
                    id="animation-speed"
                    min={0.5} 
                    max={2} 
                    step={0.1} 
                    value={[animationSpeed]} 
                    onValueChange={(value) => setAnimationSpeed(value[0])}
                    className="py-4"
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Preview</CardTitle>
                <CardDescription>See how your spinner looks</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px] flex flex-col items-center justify-center">
                <div 
                  className="flex items-center justify-center"
                  style={{ 
                    animationDuration: `${1 / animationSpeed}s`,
                    animationTimingFunction: 'linear'
                  }}
                >
                  <BabySpinner 
                    type={spinnerType} 
                    size={spinnerSize} 
                    showText={showText} 
                  />
                </div>
                
                <div className="mt-6 text-sm text-gray-500">
                  <code className="bg-gray-100 dark:bg-gray-800 p-2 rounded">
                    {`<BabySpinner type="${spinnerType}" size="${spinnerSize}" ${showText ? 'showText' : ''} />`}
                  </code>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function SpinnerCard({ 
  type, 
  title, 
  description 
}: { 
  type: "rattle" | "bottle" | "diaper" | "cradle"; 
  title: string; 
  description: string; 
}) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-32 flex items-center justify-center mb-4">
          <BabySpinner type={type} size="lg" />
        </div>
        <CardDescription>{description}</CardDescription>
      </CardContent>
    </Card>
  );
}