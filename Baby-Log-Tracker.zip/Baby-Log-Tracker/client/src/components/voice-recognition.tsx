import React, { useState, useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Mic, Loader2, Square } from "lucide-react";

interface VoiceRecognitionProps {
  onResult: (text: string) => void;
  onParsed?: (data: any) => void;
  parseCommand?: boolean;
  className?: string;
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  buttonText?: string;
}

export function VoiceRecognition({
  onResult,
  onParsed,
  parseCommand = false,
  className = "",
  variant = "outline",
  size = "default",
  buttonText = "Voice Input"
}: VoiceRecognitionProps) {
  const [isListening, setIsListening] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Initialize speech recognition
    try {
      // @ts-ignore - Browser APIs aren't fully typed
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = 'en-US';
        
        recognitionRef.current.onstart = () => {
          setIsListening(true);
          setError(null);
        };
        
        recognitionRef.current.onend = () => {
          setIsListening(false);
        };
        
        recognitionRef.current.onerror = (event: any) => {
          setError(event.error);
          setIsListening(false);
        };
        
        recognitionRef.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          onResult(transcript);
          
          if (parseCommand && onParsed) {
            parseVoiceCommand(transcript);
          }
        };
      } else {
        setError("Speech recognition not supported in this browser");
      }
    } catch (err) {
      setError("Error initializing speech recognition");
      console.error(err);
    }
    
    // Cleanup function
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [onResult, onParsed, parseCommand]);
  
  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      try {
        if (recognitionRef.current) {
          recognitionRef.current.start();
        }
      } catch (err) {
        console.error('Error starting speech recognition:', err);
        setError("Failed to start listening. Try again.");
      }
    }
  };
  
  const parseVoiceCommand = async (text: string) => {
    setIsLoading(true);
    
    try {
      // Log the raw text for debugging
      console.log('Raw voice input:', text);
      
      // Clean text before parsing (remove filler words, etc.)
      const cleanedText = text
        .replace(/\bum\b|\buh\b|\bhm\b|\blike\b|\byou know\b|\bI mean\b/gi, '')  // Remove filler words
        .replace(/\bcan you\b|\bplease\b|\bcould you\b/gi, '')  // Remove polite requests
        .trim();
        
      console.log('Cleaned voice input:', cleanedText);
      
      // Do basic parsing on the client side
      const data = parseVoiceText(cleanedText);
      
      // Log the parsed data for debugging
      console.log('Parsed voice data:', data);
      
      if (onParsed) {
        onParsed(data);
      }
    } catch (err) {
      console.error('Error parsing voice command:', err);
      setError("Failed to parse command");
    } finally {
      setIsLoading(false);
    }
  };
  
  // Basic client-side parsing for voice commands
  const parseVoiceText = (text: string): any => {
    // Normalize text to lowercase
    const normalizedText = text.toLowerCase().trim();
    
    // Default response with current time
    const data: {
      type: string;
      time: string;
      notes: string;
      // Feeding related fields
      amount?: number;
      side?: string;
      duration?: number;
      feedingType?: string;
      // Sleep related fields
      sleepStatus?: string;
      // Diaper related fields
      diaperType?: string;
      consistency?: string;
      // Medication related fields
      medicationType?: string;
      dose?: string;
      // Supply related fields
      supplyName?: string;
      supplyCategory?: string;
      supplyStatus?: string;
      supplyPriority?: string;
      // Milestone related fields
      milestoneType?: string;
      milestoneCategory?: string;
      // Mood related fields
      mood?: string;
      crying?: boolean;
      cryDuration?: number;
      cryReason?: string;
    } = {
      type: 'unknown',
      time: new Date().toISOString(),
      notes: '',
      crying: false,
    };
    
    // Check for feeding related commands using regex for better pattern matching
    if (/\b(bottle|formula)\b/.test(normalizedText)) {
      data.type = 'bottle';
      
      // Try to extract amount with enhanced pattern matching
      // Matches formats like "2 oz", "2.5 ounces", "2 and a half oz", etc.
      const amountPatterns = [
        /(\d+(?:\.\d+)?)\s*(?:oz|ounce)s?/i,                   // 2 oz, 2.5 ounces
        /(\d+)\s*and\s*(?:a\s*)?(half|quarter)\s*(?:oz|ounce)s?/i,  // 2 and a half oz
        /(\d+)\s*(?:oz|ounce)s?/i                              // 2 oz (simpler fallback)
      ];
      
      for (const pattern of amountPatterns) {
        const match = normalizedText.match(pattern);
        if (match) {
          // Basic number format
          if (!match[2]) {
            data.amount = parseFloat(match[1]);
          } 
          // Format with "and a half/quarter"
          else {
            const baseAmount = parseInt(match[1]);
            const fraction = match[2].toLowerCase() === 'half' ? 0.5 : 0.25;
            data.amount = baseAmount + fraction;
          }
          break;
        }
      }
    } 
    else if (/\b(breast|breastfeed|nursing|nurse)\b/.test(normalizedText)) {
      data.type = 'breast';
      
      // Try to extract side with more precise pattern matching
      if (/\b(left|left\s*side|left\s*breast)\b/.test(normalizedText)) {
        data.side = 'left';
      } else if (/\b(right|right\s*side|right\s*breast)\b/.test(normalizedText)) {
        data.side = 'right';
      } else if (/\b(both|both\s*sides|both\s*breasts)\b/.test(normalizedText)) {
        data.side = 'both';
      } else {
        // Default if side is not specified
        data.side = 'both';
      }
      
      // Try to extract duration with enhanced patterns
      const durationPatterns = [
        /for\s+(\d+)(?:\.\d+)?\s*(minute|min)s?/i,             // for 10 minutes
        /(\d+)(?:\.\d+)?\s*(minute|min)s?\s+of\s+nursing/i,     // 10 minutes of nursing
        /breastfed\s+for\s+(\d+)(?:\.\d+)?\s*(minute|min)s?/i,  // breastfed for 10 minutes
        /nursed\s+for\s+(\d+)(?:\.\d+)?\s*(minute|min)s?/i,     // nursed for 10 minutes
        /(\d+)(?:\.\d+)?\s*(minute|min)s?/i                     // 10 minutes (simpler fallback)
      ];
      
      for (const pattern of durationPatterns) {
        const match = normalizedText.match(pattern);
        if (match) {
          data.duration = parseInt(match[1]);
          break;
        }
      }
    }
    else if (/\b(feed(ing)?|fed|eat(ing)?|ate|gave|had|finished)\b/.test(normalizedText)) {
      data.type = 'feeding';
      
      // Further determine if it's bottle or breast with more precise patterns
      if (/\b(bottle|formula)\b/.test(normalizedText)) {
        data.feedingType = 'bottle';
        
        // Try to extract amount with the same enhanced patterns as above
        const amountPatterns = [
          /(\d+(?:\.\d+)?)\s*(?:oz|ounce)s?/i,
          /(\d+)\s*and\s*(?:a\s*)?(half|quarter)\s*(?:oz|ounce)s?/i,
          /(\d+)\s*(?:oz|ounce)s?/i
        ];
        
        for (const pattern of amountPatterns) {
          const match = normalizedText.match(pattern);
          if (match) {
            if (!match[2]) {
              data.amount = parseFloat(match[1]);
            } else {
              const baseAmount = parseInt(match[1]);
              const fraction = match[2].toLowerCase() === 'half' ? 0.5 : 0.25;
              data.amount = baseAmount + fraction;
            }
            break;
          }
        }
      } 
      else if (/\b(breast|breastfeed|nursing|nurse)\b/.test(normalizedText)) {
        data.feedingType = 'breast';
        
        // Extract side with the same patterns as above
        if (/\b(left|left\s*side|left\s*breast)\b/.test(normalizedText)) {
          data.side = 'left';
        } else if (/\b(right|right\s*side|right\s*breast)\b/.test(normalizedText)) {
          data.side = 'right';
        } else if (/\b(both|both\s*sides|both\s*breasts)\b/.test(normalizedText)) {
          data.side = 'both';
        } else {
          data.side = 'both';
        }
        
        // Extract duration with the same patterns as above
        const durationPatterns = [
          /for\s+(\d+)(?:\.\d+)?\s*(minute|min)s?/i,
          /(\d+)(?:\.\d+)?\s*(minute|min)s?\s+of\s+nursing/i,
          /breastfed\s+for\s+(\d+)(?:\.\d+)?\s*(minute|min)s?/i,
          /nursed\s+for\s+(\d+)(?:\.\d+)?\s*(minute|min)s?/i,
          /(\d+)(?:\.\d+)?\s*(minute|min)s?/i
        ];
        
        for (const pattern of durationPatterns) {
          const match = normalizedText.match(pattern);
          if (match) {
            data.duration = parseInt(match[1]);
            break;
          }
        }
      }
      // If type not specified, default to bottle as it's more common
      else {
        data.feedingType = 'bottle';
        // Try to find an amount
        const amountMatch = normalizedText.match(/(\d+(?:\.\d+)?)\s*(?:oz|ounce)s?/i);
        if (amountMatch) {
          data.amount = parseFloat(amountMatch[1]);
        }
      }
    }
    
    // Check for sleep related commands using more precise patterns, including past tense
    else if (/\bsleep(ing|s)?\b/.test(normalizedText) || /\bnap(ping|s)?\b/.test(normalizedText) || 
        /\basleep\b/.test(normalizedText) || /\bfell asleep\b/.test(normalizedText) || 
        /\b(put|went)( baby)? to (bed|sleep)\b/.test(normalizedText) ||
        /\bdown for (a )?(nap|sleep)\b/.test(normalizedText) || 
        /\bslept\b/.test(normalizedText) || /\bnapped\b/.test(normalizedText) ||
        /\bhad (a )?(nap|sleep)\b/.test(normalizedText) ||
        /\btook (a )?(nap|sleep)\b/.test(normalizedText)) {
      data.type = 'sleep';
      
      // Check if it's about ending a sleep session or reporting a completed sleep
      if (/\bwoke( up)?\b/.test(normalizedText) || /\bawake\b/.test(normalizedText) || 
          /\bend(ed|ing)?\b/.test(normalizedText) || /\bfinish(ed)?\b/.test(normalizedText) ||
          /\bstop(ped)?\b/.test(normalizedText) || /\bwake(n)?(ed)?\b/.test(normalizedText) ||
          /\bgot up\b/.test(normalizedText) || /\bno longer (sleeping|napping)\b/.test(normalizedText)) {
        data.sleepStatus = 'end';
      } 
      // Special handling for past tense expressions which indicate completed sleep
      else if (/\bslept\b/.test(normalizedText) || /\bnapped\b/.test(normalizedText) || 
              /\bhad (a )?(nap|sleep)\b/.test(normalizedText) || /\btook (a )?(nap|sleep)\b/.test(normalizedText)) {
        // For past tense expressions, we'll treat it as a completed sleep session
        // Default to recording as a start event, but with the duration if provided
        data.sleepStatus = 'start';
        data.type = 'completed_sleep'; // Mark as completed sleep for special handling later
      }
      else {
        data.sleepStatus = 'start';
      }
      
      // Enhanced patterns for sleep duration
      // Look for patterns like:
      // - "slept for 2 hours and 30 minutes"
      // - "napped for 45 minutes"
      // - "2.5 hour nap"
      
      // Hours and minutes with optional "and" or connecting words
      const hourMinPattern = /(\d+)(?:\s*\.\s*(\d+))?\s*(?:hour|hr)s?(?:\s*(?:and|with|plus)\s*|\s+)(\d+)\s*(?:minute|min)s?/i;
      
      // Decimal hours like "2.5 hours"
      const decimalHourPattern = /(\d+)(?:\s*\.\s*(\d+))\s*(?:hour|hr)s?/i;
      
      // Whole hours
      const hourPattern = /(\d+)\s*(?:hour|hr)s?/i;
      
      // Minutes only
      const minutePattern = /(\d+)\s*(?:minute|min)s?/i;
      
      // Duration with "for" preposition - e.g., "slept for 2 hours"
      const forDurationPattern = /for\s+(\d+)(?:\s*\.\s*(\d+))?\s*(?:hour|hr)s?/i;
      const forMinutesPattern = /for\s+(\d+)\s*(?:minute|min)s?/i;

      // First check for hour and minute pattern
      const hourMinMatch = normalizedText.match(hourMinPattern);
      if (hourMinMatch) {
        const hours = parseInt(hourMinMatch[1]);
        const minutes = parseInt(hourMinMatch[3]);
        data.duration = hours * 60 + minutes;
      } 
      // Check for decimal hours (e.g., 2.5 hours)
      else if (decimalHourPattern.test(normalizedText)) {
        const match = normalizedText.match(decimalHourPattern);
        if (match) {
          const hours = parseInt(match[1]);
          const decimal = match[2] ? parseInt(match[2]) : 0;
          // Convert decimal part to minutes (e.g., 0.5 hours = 30 minutes)
          const minutes = decimal === 5 ? 30 : decimal * 6; // Handle common case of .5 meaning half hour
          data.duration = hours * 60 + minutes;
        }
      }
      // Check for "for X hours" pattern
      else if (forDurationPattern.test(normalizedText)) {
        const match = normalizedText.match(forDurationPattern);
        if (match) {
          const hours = parseInt(match[1]);
          const decimal = match[2] ? parseInt(match[2]) : 0;
          const minutes = decimal === 5 ? 30 : decimal * 6;
          data.duration = hours * 60 + minutes;
        }
      }
      // Then check for just hours
      else if (hourPattern.test(normalizedText)) {
        const match = normalizedText.match(hourPattern);
        if (match) {
          const hours = parseInt(match[1]);
          data.duration = hours * 60;
        }
      } 
      // Check for "for X minutes" pattern
      else if (forMinutesPattern.test(normalizedText)) {
        const match = normalizedText.match(forMinutesPattern);
        if (match) {
          data.duration = parseInt(match[1]);
        }
      }
      // Finally check for just minutes
      else if (minutePattern.test(normalizedText)) {
        const match = normalizedText.match(minutePattern);
        if (match) {
          data.duration = parseInt(match[1]);
        }
      }
    }
    
    // Check for diaper related commands with expanded vocabulary and past tense
    else if (normalizedText.includes('diaper') || normalizedText.includes('change') || 
        normalizedText.includes('changed') || normalizedText.includes('nappy') || 
        normalizedText.includes('toilet') || normalizedText.includes('bathroom') || 
        normalizedText.includes('potty') || normalizedText.includes('soiled') ||
        normalizedText.includes('soaked') || /\bhad (a )?dirty\b/.test(normalizedText) ||
        // Add more natural phrases
        /\bneeds? (a )?change\b/.test(normalizedText) || /\bhad (a )?diaper\b/.test(normalizedText) ||
        /\bchanging\b/.test(normalizedText) || /\bwent (to the )?(bathroom|potty)\b/.test(normalizedText) ||
        // More specific patterns for better recognition
        /\bwet\b/.test(normalizedText) || /\bpee(d)?\b/.test(normalizedText) || 
        /\bpoo(p)?(ed)?\b/.test(normalizedText) || /\bpoopy\b/.test(normalizedText)) {
      data.type = 'diaper';
      
      // First, check for mixed type descriptions (both wet and dirty)
      if (normalizedText.includes('both') || normalizedText.includes('mixed') || 
          normalizedText.includes('wet and dirty') || normalizedText.includes('pee and poop') ||
          (/\bwet\b/.test(normalizedText) && /\bdirty\b/.test(normalizedText)) ||
          (/\bpee\b/.test(normalizedText) && /\bpoop\b/.test(normalizedText))) {
        data.diaperType = 'mixed';
      } 
      // Then check for dirty only
      else if (/\bdirty\b/.test(normalizedText) || /\bpoo(p)?(ed)?\b/.test(normalizedText) || 
          /\bstool\b/.test(normalizedText) || /\bbm\b/.test(normalizedText) || 
          /\bbowel\b/.test(normalizedText) || /\bnumber two\b/.test(normalizedText) ||
          /\bpoopy\b/.test(normalizedText)) {
        data.diaperType = 'dirty';
      } 
      // Finally, check for wet or default to wet if type is ambiguous
      else if (/\bwet\b/.test(normalizedText) || /\bpee(d)?\b/.test(normalizedText) || 
          /\burine\b/.test(normalizedText) || /\bwee\b/.test(normalizedText) ||
          /\bnumber one\b/.test(normalizedText)) {
        data.diaperType = 'wet';
      } else {
        // Default to wet if not specified - most common type
        data.diaperType = 'wet';
      }
      
      // Try to determine consistency for dirty diapers using more specific patterns
      if (data.diaperType === 'dirty' || data.diaperType === 'mixed') {
        if (/\bsolid\b/.test(normalizedText) || /\bhard\b/.test(normalizedText) || 
            /\bfirm\b/.test(normalizedText) || /\bformed\b/.test(normalizedText)) {
          data.consistency = 'solid';
        } else if (/\bsoft\b/.test(normalizedText) || /\bmushy\b/.test(normalizedText) || 
            /\bnormal\b/.test(normalizedText) || /\bpasty\b/.test(normalizedText)) {
          data.consistency = 'soft';
        } else if (/\bliquid\b/.test(normalizedText) || /\brunny\b/.test(normalizedText) || 
            /\bwatery\b/.test(normalizedText) || /\bdiarrhea\b/.test(normalizedText) ||
            /\bloose\b/.test(normalizedText)) {
          data.consistency = 'liquid';
        }
      }
    }
    
    // Check for medication related commands
    else if (normalizedText.includes('medicine') || normalizedText.includes('medication') || 
             normalizedText.includes('tylenol') || normalizedText.includes('ibuprofen') || 
             normalizedText.includes('motrin') || normalizedText.includes('vitamin') ||
             /\bgave\s+(\w+)\s+(medicine|medication|dose)\b/.test(normalizedText)) {
      data.type = 'medication';
      
      // Try to determine medication type with expanded recognition
      if (normalizedText.includes('tylenol') || normalizedText.includes('acetaminophen') || normalizedText.includes('paracetamol')) {
        data.medicationType = 'tylenol';
      } else if (normalizedText.includes('motrin') || normalizedText.includes('ibuprofen') || normalizedText.includes('advil')) {
        data.medicationType = 'ibuprofen';
      } else if (normalizedText.includes('vitamin') || normalizedText.includes('supplement')) {
        data.medicationType = 'vitamin';
      } else if (normalizedText.includes('antibiotic') || normalizedText.includes('amoxicillin')) {
        data.medicationType = 'antibiotic';
      } else if (normalizedText.includes('antifungal') || normalizedText.includes('nystatin')) {
        data.medicationType = 'antifungal';
      }
      
      // Try to extract dose with enhanced pattern matching
      const dosePatterns = [
        /(\d+(?:\.\d+)?)\s*(ml|cc|mg|mcg|g)/i,  // 5 ml, 10 mg
        /(\d+)\s*and\s*(?:a\s*)?(half|quarter)\s*(ml|cc|mg)/i,  // 2 and a half ml
        /(\d+)\s*(milliliter|milligram)s?/i,  // 5 milliliters
        /(\d+)\s*dropper(ful)?s?/i  // 2 droppers
      ];
      
      for (const pattern of dosePatterns) {
        const match = normalizedText.match(pattern);
        if (match) {
          data.dose = match[0];
          break;
        }
      }
    }
    
    // Check for mood & cry tracking
    else if (/\b(mood|feeling|happy|sad|fussy|gassy|crying|cried|upset)\b/.test(normalizedText)) {
      data.type = 'mood';
      
      // Detect mood type
      if (/\b(happy|smiling|laughing|good mood|great mood|excellent mood|playful|content|joy|joyful)\b/.test(normalizedText)) {
        data.mood = 'happy';
      } else if (/\b(fussy|irritable|cranky|unhappy|annoyed|frustrated|whiny|fuss)\b/.test(normalizedText)) {
        data.mood = 'fussy';
      } else if (/\b(gassy|gas|bloated|burping|burps|passing gas|tummy troubles|stomach pain)\b/.test(normalizedText)) {
        data.mood = 'gassy';
      } else if (/\b(sleepy|tired|exhausted|drowsy|yawning|needs sleep|wants to sleep)\b/.test(normalizedText)) {
        data.mood = 'tired';
      } else if (/\b(calm|quiet|relaxed|peaceful|serene|content|settled)\b/.test(normalizedText)) {
        data.mood = 'calm';
      } else if (/\b(crying|cried|sobbing|weeping|tears|upset|wailing|screaming)\b/.test(normalizedText)) {
        data.mood = 'upset';
      } else if (/\b(hungry|hunger|wanting food|starving|ready to eat)\b/.test(normalizedText)) {
        data.mood = 'hungry';
      }
      
      // Set the crying flag if crying-related words are present
      if (/\b(crying|cried|sobbing|weeping|tears|upset|wailing|screaming)\b/.test(normalizedText)) {
        data.crying = true;
        
        // Look for duration patterns similar to sleep duration
        const durationPatterns = [
          /cried\s+for\s+(\d+)\s+(minute|min|hour|hr)s?/i,
          /crying\s+for\s+(\d+)\s+(minute|min|hour|hr)s?/i,
          /for\s+(\d+)\s+(minute|min|hour|hr)s?\s+of\s+crying/i,
          /(\d+)\s+(minute|min|hour|hr)s?\s+crying\s+episode/i,
          /(\d+)\s+(minute|min|hour|hr)s?\s+of\s+crying/i,
          /(\d+)\s+(minute|min|hour|hr)s?\s+crying/i,
          /cried\s+(\d+)\s+(minute|min|hour|hr)s?/i,
          /been\s+crying\s+for\s+(\d+)\s+(minute|min|hour|hr)s?/i,
          /has\s+cried\s+for\s+(\d+)\s+(minute|min|hour|hr)s?/i,
        ];
        
        for (const pattern of durationPatterns) {
          const match = normalizedText.match(pattern);
          if (match) {
            let duration = parseInt(match[1]);
            // Convert hours to minutes if needed
            if (match[2].toLowerCase().startsWith('hour') || match[2].toLowerCase() === 'hr') {
              duration *= 60;
            }
            data.cryDuration = duration;
            break;
          }
        }
      }
      
      // Try to detect cry reason
      const cryReasons = [
        { pattern: /\b(hungry|hunger|wants? food|wants? to eat|feeding|bottle|breast|starving)\b/i, reason: 'hunger' },
        { pattern: /\b(pain|hurt|hurting|uncomfortable|discomfort|ache|hurts|ouch)\b/i, reason: 'pain' },
        { pattern: /\b(tired|sleepy|exhausted|needs? nap|needs? sleep|overtired)\b/i, reason: 'overtired' },
        { pattern: /\b(gas|gassy|bloated|stomach ache|tummy ache|burping|flatulence)\b/i, reason: 'gas' },
        { pattern: /\b(overstimulated|too much|overwhelmed|too loud|too bright|sensory overload)\b/i, reason: 'overstimulation' },
        { pattern: /\b(separation|missing|alone|lonely|wants parent|wants mommy|wants daddy)\b/i, reason: 'separation' },
        { pattern: /\b(unknown|not sure|unsure|no reason|can't tell|don't know|unclear)\b/i, reason: 'unknown' }
      ];
      
      for (const { pattern, reason } of cryReasons) {
        if (pattern.test(normalizedText)) {
          data.cryReason = reason;
          break;
        }
      }
    }
    
    // Check for supply tracking commands
    else if (/\b(supply|supplies|need|restock|shopping list|buy|purchase|ran out|low on|add to list)\b/.test(normalizedText)) {
      data.type = 'supply';
      
      // Parse the supply name - anything after "need" or similar keywords
      const supplyNamePatterns = [
        /need\s+(?:to\s+)?(?:buy|get|purchase|restock)\s+([\w\s]+)/i,
        /(?:buy|get|purchase|restock)\s+([\w\s]+)/i,
        /(?:low|running low|out|ran out)\s+(?:of|on)\s+([\w\s]+)/i,
        /add\s+([\w\s]+)\s+to\s+(?:shopping|supply|grocery)(?:\s+list)?/i,
        /\b(diapers|wipes|formula|bottles|pacifiers|clothes|medicine|baby food)\b/i
      ];
      
      for (const pattern of supplyNamePatterns) {
        const match = normalizedText.match(pattern);
        if (match) {
          // Take the first capture group and clean it
          data.supplyName = match[1].trim().replace(/\s+/, ' ');
          break;
        }
      }
      
      // Try to determine supply category
      const categories = [
        { pattern: /\b(diaper|nappy|pampers|huggies|luvs)\b/i, category: 'diapers' },
        { pattern: /\b(wipe|baby wipe|wet wipe|cleaning|tissue)\b/i, category: 'wipes' },
        { pattern: /\b(formula|milk|similac|enfamil|baby milk|bottle milk)\b/i, category: 'formula' },
        { pattern: /\b(bottle|nipple|feeding|dr brown|avent)\b/i, category: 'feeding' },
        { pattern: /\b(pacifier|soother|binky|dummy|nuby)\b/i, category: 'pacifiers' },
        { pattern: /\b(clothes|outfit|onesie|bodysuit|romper|sleeper|pajama|sock)\b/i, category: 'clothing' },
        { pattern: /\b(medicine|medication|medicine|tylenol|ibuprofen|motrin|saline)\b/i, category: 'medicine' },
        { pattern: /\b(food|cereal|puree|snack|puffs|yogurt|baby food)\b/i, category: 'food' },
        { pattern: /\b(lotion|cream|oil|ointment|powder|wash|shampoo|soap|bath)\b/i, category: 'bathtime' },
        { pattern: /\b(toy|book|rattle|teether|play)\b/i, category: 'toys' }
      ];
      
      for (const { pattern, category } of categories) {
        if (pattern.test(normalizedText)) {
          data.supplyCategory = category;
          break;
        }
      }
      
      // Try to determine supply priority or status
      if (/\b(urgent|emergency|critical|immediately|asap|right away|really need|desperate|out of)\b/i.test(normalizedText)) {
        data.supplyPriority = 'high';
      } else if (/\b(important|soon|within.*days|running low|low on|almost out|getting low)\b/i.test(normalizedText)) {
        data.supplyPriority = 'medium';
      } else if (/\b(sometime|eventually|not urgent|not critical|can wait|when possible|optional)\b/i.test(normalizedText)) {
        data.supplyPriority = 'low';
      } else {
        data.supplyPriority = 'medium'; // Default to medium priority
      }
    }
    
    // Check for milestone tracking
    else if (/\b(milestone|achievement|first|did|doing|began|started|learned|learning|attempted|trying)\b/.test(normalizedText)) {
      data.type = 'milestone';
      
      // Try to determine milestone category
      const milestoneCategories = [
        { pattern: /\b(smile|smiling|laugh|laughing|giggle|coo|babble|talk|word|say|speech|sound)\b/i, category: 'social' },
        { pattern: /\b(roll|rolled|rolling|crawl|crawling|sit|sitting|stand|standing|walk|walking|step|steps|climb|run|motor)\b/i, category: 'motor' },
        { pattern: /\b(grab|grabbing|reach|reaching|hold|holding|throw|throwing|pick up|hand-eye|hand|finger|touch)\b/i, category: 'cognitive' },
        { pattern: /\b(feed|feeding|eat|eating|solid|food|drink|drinking|cup|spoon)\b/i, category: 'food' },
        { pattern: /\b(tooth|teeth|teething)\b/i, category: 'other' }
      ];
      
      for (const { pattern, category } of milestoneCategories) {
        if (pattern.test(normalizedText)) {
          data.milestoneCategory = category;
          break;
        }
      }
      
      // Try to determine specific milestone type
      if (/\b(smile|smiling|first smile|smiled|social smile)\b/i.test(normalizedText)) {
        data.milestoneType = 'first_smile';
      } else if (/\b(laugh|laughing|first laugh|laughed)\b/i.test(normalizedText)) {
        data.milestoneType = 'first_laugh';
      } else if (/\b(roll|rolling|rolled|roll over|rolled over)\b/i.test(normalizedText)) {
        data.milestoneType = 'rolling_over';
      } else if (/\b(sit|sitting|sat|sit up|sat up|sitting up)\b/i.test(normalizedText)) {
        data.milestoneType = 'sitting_up';
      } else if (/\b(crawl|crawling|crawled)\b/i.test(normalizedText)) {
        data.milestoneType = 'crawling';
      } else if (/\b(stand|standing|stood|stand up|stood up)\b/i.test(normalizedText)) {
        data.milestoneType = 'standing';
      } else if (/\b(walk|walking|walked|step|steps|stepped)\b/i.test(normalizedText)) {
        data.milestoneType = 'walking';
      } else if (/\b(word|say|said|speech|talk|talked|saying|saying)\b/i.test(normalizedText)) {
        data.milestoneType = 'first_word';
      } else if (/\b(tooth|teeth|first tooth)\b/i.test(normalizedText)) {
        data.milestoneType = 'first_tooth';
      } else if (/\b(solid|food|eat solid|first food)\b/i.test(normalizedText)) {
        data.milestoneType = 'solid_food';
      }
    }
    
    // Try to extract time if mentioned - enhanced with more natural language patterns
    const timePatterns = [
      // Standard time formats
      /(\d{1,2}):(\d{2})\s*(am|pm|a\.m\.|p\.m\.)/i,  // 3:30 PM or 3:30 p.m.
      /(\d{1,2})\s*(am|pm|a\.m\.|p\.m\.)/i,          // 3 PM or 3 p.m.
      
      // More natural language patterns
      /at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?/i,  // at 3, at 3 PM, at 3:30
      /around\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?/i,  // around 3, around 3 PM
      /about\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?/i,   // about 3, about 3 PM
      
      // Clock terminology
      /at\s+(\d{1,2})\s+o'clock/i,  // at 3 o'clock
      /(\d{1,2})\s+o'clock/i,       // 3 o'clock
      
      // Half hour and quarter hour expressions
      /half\s+past\s+(\d{1,2})/i,   // half past 3 (3:30)
      /quarter\s+past\s+(\d{1,2})/i, // quarter past 3 (3:15)
      /quarter\s+to\s+(\d{1,2})/i,   // quarter to 4 (3:45)
      
      // Morning, afternoon, evening context
      /(\d{1,2})(?::(\d{2}))?\s+in\s+the\s+(morning|afternoon|evening)/i,
      
      // Relative times
      /(this|just)\s+(morning|afternoon|evening)/i
    ];
    
    // First try specific time patterns
    let timeFound = false;
    
    for (const pattern of timePatterns) {
      const match = normalizedText.match(pattern);
      if (match) {
        const timeDate = new Date();
        
        // Handle special expressions for half and quarter hours
        if (pattern.toString().includes('half\\s+past')) {
          const hours = parseInt(match[1]);
          timeDate.setHours(hours, 30, 0, 0);
        }
        else if (pattern.toString().includes('quarter\\s+past')) {
          const hours = parseInt(match[1]);
          timeDate.setHours(hours, 15, 0, 0);
        }
        else if (pattern.toString().includes('quarter\\s+to')) {
          const hours = parseInt(match[1]) - 1;
          timeDate.setHours(hours, 45, 0, 0);
        }
        // Handle morning/afternoon/evening context
        else if (match[3] && ['morning', 'afternoon', 'evening'].includes(match[3].toLowerCase())) {
          let hours = parseInt(match[1]);
          const minutes = match[2] ? parseInt(match[2]) : 0;
          const timeContext = match[3].toLowerCase();
          
          // Adjust hours based on context
          if (timeContext === 'afternoon' && hours < 12) {
            hours += 12;
          } else if (timeContext === 'evening' && hours < 12) {
            hours += 12;
          } else if (timeContext === 'morning' && hours === 12) {
            hours = 0;
          }
          
          timeDate.setHours(hours, minutes, 0, 0);
        }
        // Handle relative time expressions
        else if (match[1] && match[2] && ['morning', 'afternoon', 'evening'].includes(match[2].toLowerCase())) {
          const timeContext = match[2].toLowerCase();
          
          // Set time based on typical times of day
          if (timeContext === 'morning') {
            timeDate.setHours(9, 0, 0, 0);  // Default morning to 9 AM
          } else if (timeContext === 'afternoon') {
            timeDate.setHours(15, 0, 0, 0); // Default afternoon to 3 PM
          } else if (timeContext === 'evening') {
            timeDate.setHours(19, 0, 0, 0); // Default evening to 7 PM
          }
        }
        // Standard time format handling
        else {
          let hours = parseInt(match[1]);
          let minutes = 0;
          
          // Check if minutes are specified in the match
          if (match[2] && !isNaN(parseInt(match[2]))) {
            minutes = parseInt(match[2]);
          }
          
          // Check for AM/PM
          const lastGroup = match[match.length - 1];
          if (lastGroup && /pm|p\.m\./i.test(lastGroup) && hours < 12) {
            hours += 12;
          } else if (lastGroup && /am|a\.m\./i.test(lastGroup) && hours === 12) {
            hours = 0;
          }
          
          timeDate.setHours(hours, minutes, 0, 0);
        }
        
        data.time = timeDate.toISOString();
        timeFound = true;
        break;
      }
    }
    
    // If no specific time was found, check for relative time expressions
    if (!timeFound) {
      if (/just now|right now|a moment ago|moments ago/.test(normalizedText)) {
        // Use current time
        data.time = new Date().toISOString();
      } else if (/(\d+)\s+(minute|min)s?\s+ago/.test(normalizedText)) {
        const match = normalizedText.match(/(\d+)\s+(minute|min)s?\s+ago/);
        if (match) {
          const minutesAgo = parseInt(match[1]);
          const timeDate = new Date();
          timeDate.setMinutes(timeDate.getMinutes() - minutesAgo);
          data.time = timeDate.toISOString();
        }
      } else if (/(\d+)\s+(hour|hr)s?\s+ago/.test(normalizedText)) {
        const match = normalizedText.match(/(\d+)\s+(hour|hr)s?\s+ago/);
        if (match) {
          const hoursAgo = parseInt(match[1]);
          const timeDate = new Date();
          timeDate.setHours(timeDate.getHours() - hoursAgo);
          data.time = timeDate.toISOString();
        }
      }
    }
    
    // Add the original text as notes
    data.notes = text;
    
    return data;
  };

  return (
    <div className="flex flex-col">
      <Button
        variant={variant}
        size={size}
        className={`${className} ${isListening ? 'animate-pulse bg-red-500 hover:bg-red-600 text-white' : ''}`}
        onClick={toggleListening}
        disabled={isLoading}
      >
        {isLoading ? (
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
        ) : isListening ? (
          <Square className="h-4 w-4 mr-2" />
        ) : (
          <Mic className="h-4 w-4 mr-2" />
        )}
        {isListening ? "Listening..." : buttonText}
      </Button>

      {error && (
        <div className="mt-2 text-sm text-red-500">
          {error === "no-speech" ? 
            "No speech was detected. Please try again." : 
          error === "aborted" ? 
            "Speech recognition was aborted. Please try again." : 
          error === "network" ? 
            "Network error. Please check your connection." : 
          error === "not-allowed" ? 
            "Microphone access denied. Please check your browser permissions." : 
          error === "Speech recognition not supported in this browser" ?
            "Sorry, your browser doesn't support speech recognition. Try Chrome." :
            `Error: ${error}`}
        </div>
      )}
    </div>
  );
}