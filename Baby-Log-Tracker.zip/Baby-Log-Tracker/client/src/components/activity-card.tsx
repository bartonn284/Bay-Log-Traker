import { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

type ActivityCardProps = {
  title: string;
  color: "feeding" | "sleep" | "diaper";
  icon: "feeding" | "sleep" | "diaper";
  onAddClick: () => void;
  items: any[];
  renderItem: (item: any) => {
    title: string;
    subtitle: string;
    time: string;
    duration: string;
  };
};

const colorMap = {
  feeding: {
    bg: "bg-[#5B9BD5] bg-opacity-10",
    border: "border-[#5B9BD5] border-opacity-20",
    text: "text-[#5B9BD5]",
    button: "bg-[#5B9BD5]",
  },
  sleep: {
    bg: "bg-[#9C7BD5] bg-opacity-10",
    border: "border-[#9C7BD5] border-opacity-20",
    text: "text-[#9C7BD5]",
    button: "bg-[#9C7BD5]",
  },
  diaper: {
    bg: "bg-[#F6A192] bg-opacity-10",
    border: "border-[#F6A192] border-opacity-20",
    text: "text-[#F6A192]",
    button: "bg-[#F6A192]",
  },
};

const iconMap = {
  feeding: (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-5 w-5 text-white"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 3v1m0 16v1m-9-9h1M4 12h1m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
      />
    </svg>
  ),
  sleep: (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-5 w-5 text-white"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
      />
    </svg>
  ),
  diaper: (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-5 w-5 text-white"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
      />
    </svg>
  ),
};

export function ActivityCard({
  title,
  color,
  icon,
  onAddClick,
  items,
  renderItem,
}: ActivityCardProps) {
  const { bg, border, text, button } = colorMap[color];
  const iconElement = iconMap[icon];

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border overflow-hidden">
      <div className={`${bg} px-4 py-3 border-b ${border}`}>
        <div className="flex items-center">
          <div className={`w-8 h-8 rounded-full ${button} flex items-center justify-center mr-2`}>
            {iconElement}
          </div>
          <h3 className="font-semibold">{title}</h3>
          <div className="ml-auto">
            <Button 
              className={`circle-btn ${button} text-white shadow-sm`}
              size="icon"
              onClick={onAddClick}
            >
              <Plus className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        {items.length === 0 ? (
          <div className="text-center py-4 text-muted-foreground">
            No {title.toLowerCase()} records yet
          </div>
        ) : (
          items.map((item, index) => {
            const { title, subtitle, time, duration } = renderItem(item);
            return (
              <div 
                key={item.id || index}
                className={`flex items-center justify-between py-2 ${
                  index < items.length - 1 ? "border-b border-border" : ""
                }`}
              >
                <div>
                  <div className="font-semibold">{title}</div>
                  <div className="text-sm text-muted-foreground">{subtitle}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-semibold">{time}</div>
                  {duration && <div className="text-xs text-muted-foreground">{duration}</div>}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
