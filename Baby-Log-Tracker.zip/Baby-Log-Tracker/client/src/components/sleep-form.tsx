import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, Loader2, Star } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";

const sleepSchema = z.object({
  type: z.enum(["nap", "night"]),
  startTime: z.string(),
  endTime: z.string().optional(),
  quality: z.string().optional(),
  notes: z.string().optional(),
});

type SleepFormValues = z.infer<typeof sleepSchema>;

type SleepFormProps = {
  babyId: number;
  onBack: () => void;
  onSuccess: () => void;
};

export function SleepForm({ babyId, onBack, onSuccess }: SleepFormProps) {
  const form = useForm<SleepFormValues>({
    resolver: zodResolver(sleepSchema),
    defaultValues: {
      type: "nap",
      startTime: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      endTime: format(new Date(new Date().getTime() + 60 * 60 * 1000), "yyyy-MM-dd'T'HH:mm"), // Default to 1 hour later
      quality: "3",
      notes: "",
    },
  });
  
  const sleepMutation = useMutation({
    mutationFn: async (data: SleepFormValues) => {
      const startTime = new Date(data.startTime);
      const endTime = data.endTime ? new Date(data.endTime) : undefined;
      
      // Calculate duration in minutes if both start and end times are provided
      let duration: number | undefined;
      if (startTime && endTime) {
        duration = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60));
      }
      
      const payload = {
        type: data.type,
        startTime: startTime.toISOString(),
        endTime: endTime?.toISOString(),
        duration,
        quality: data.quality ? parseInt(data.quality) : null,
        notes: data.notes || null,
      };
      
      const res = await apiRequest("POST", `/api/babies/${babyId}/sleeps`, payload);
      return await res.json();
    },
    onSuccess: () => {
      onSuccess();
    },
  });
  
  const onSubmit = (data: SleepFormValues) => {
    sleepMutation.mutate(data);
  };
  
  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Button
          variant="ghost"
          size="icon"
          className="mr-2 p-1 rounded-full hover:bg-neutral-100"
          onClick={onBack}
        >
          <ChevronLeft className="h-6 w-6 text-neutral-700" />
        </Button>
        <h2 className="text-xl font-semibold text-[#9C7BD5]">Record Sleep</h2>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Sleep Type</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="grid grid-cols-2 gap-3"
                  >
                    <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                      field.value === "night"
                        ? "border-[#9C7BD5] bg-[#9C7BD5] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="night"
                        id="night"
                        className="sr-only"
                      />
                      <label
                        htmlFor="night"
                        className="flex items-center cursor-pointer w-full"
                      >
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                          field.value === "night"
                            ? "border-[#9C7BD5] bg-white"
                            : "border-neutral-300"
                        }`}>
                          {field.value === "night" && (
                            <div className="w-3 h-3 rounded-full bg-[#9C7BD5]"></div>
                          )}
                        </div>
                        <span className="font-medium">Night Sleep</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                      field.value === "nap"
                        ? "border-[#9C7BD5] bg-[#9C7BD5] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="nap"
                        id="nap"
                        className="sr-only"
                      />
                      <label
                        htmlFor="nap"
                        className="flex items-center cursor-pointer w-full"
                      >
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                          field.value === "nap"
                            ? "border-[#9C7BD5] bg-white"
                            : "border-neutral-300"
                        }`}>
                          {field.value === "nap" && (
                            <div className="w-3 h-3 rounded-full bg-[#9C7BD5]"></div>
                          )}
                        </div>
                        <span className="font-medium">Nap</span>
                      </label>
                    </div>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="startTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Start Time</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="datetime-local"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="endTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>End Time</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="datetime-local"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="quality"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Quality</FormLabel>
                <FormControl>
                  <div className="flex space-x-2">
                    {[1, 2, 3, 4, 5].map((value) => (
                      <Button
                        key={value}
                        type="button"
                        className={`w-10 h-10 flex items-center justify-center rounded-full ${
                          parseInt(field.value || "0") >= value
                            ? "bg-[#9C7BD5] text-white"
                            : "bg-neutral-200 text-neutral-500"
                        }`}
                        onClick={() => field.onChange(value.toString())}
                      >
                        <Star className="h-6 w-6" />
                      </Button>
                    ))}
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    placeholder="Add any additional notes"
                    rows={3}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button
            type="submit"
            className="w-full bg-[#9C7BD5] text-white font-semibold py-3 px-4"
            disabled={sleepMutation.isPending}
          >
            {sleepMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            Save Sleep Record
          </Button>
        </form>
      </Form>
    </div>
  );
}
