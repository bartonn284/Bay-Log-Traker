import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AlarmClock, Bell, Calendar, Plus, Syringe, Clock, Pill, MoonStar, Baby } from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ReminderList, ReminderType } from "../reminders/reminder-list";
import { CustomReminderList } from "../reminders/custom-reminder-list";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ReminderForm } from "../reminders/reminder-form";
import { useBabyContext } from "@/hooks/use-baby-context";

export function ReminderDashboard() {
  const [activeTab, setActiveTab] = useState<string>("all");
  const [isAddReminderOpen, setIsAddReminderOpen] = useState<boolean>(false);
  const { selectedBaby } = useBabyContext();
  
  // Get all system reminders (vaccine, appointments, etc.)
  const { data: systemReminders, isLoading: isSystemLoading } = useQuery<any[]>({
    queryKey: ["/api/reminders"],
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
  });
  
  // Get all custom reminders (feeding, medication, etc.)
  const { data: customReminders, isLoading: isCustomLoading } = useQuery<any[]>({
    queryKey: ["/api/custom-reminders/active"],
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
  });
  
  // Check if we have any reminders
  const hasSystemReminders = !isSystemLoading && systemReminders && systemReminders.length > 0;
  const hasCustomReminders = !isCustomLoading && customReminders && customReminders.length > 0;
  const hasAnyReminders = hasSystemReminders || hasCustomReminders;
  
  // Function to get reminder count by type
  const getCustomReminderCountByType = (type: string) => {
    if (!customReminders) return 0;
    return customReminders.filter(reminder => reminder.type === type).length;
  };
  
  const getSystemReminderCountByType = (type: ReminderType) => {
    if (!systemReminders) return 0;
    return systemReminders.filter(reminder => reminder.type === type).length;
  };
  
  if (!hasAnyReminders && !isSystemLoading && !isCustomLoading) {
    return (
      <Card className="glass-effect border border-border/30 overflow-hidden mb-6">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 pb-3">
          <CardTitle className="text-base flex items-center text-gradient">
            <Bell className="h-4 w-4 mr-2" />
            Active Reminders
          </CardTitle>
          <CardDescription>
            No active reminders found. Add a reminder to stay on top of your baby's needs.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4 px-4 text-center">
          <Dialog open={isAddReminderOpen} onOpenChange={setIsAddReminderOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5">
                <Plus className="h-3.5 w-3.5" />
                <span>Add Reminder</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Reminder</DialogTitle>
                <DialogDescription>
                  Set up a custom reminder for feeding, medication, or other needs.
                </DialogDescription>
              </DialogHeader>
              <ReminderForm onSuccess={() => setIsAddReminderOpen(false)} />
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-effect border border-border/30 overflow-hidden mb-6">
      <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center text-gradient">
            <Bell className="h-4 w-4 mr-2" />
            Active Reminders
          </CardTitle>
          
          <Dialog open={isAddReminderOpen} onOpenChange={setIsAddReminderOpen}>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline" className="h-8 gap-1.5 bg-card/50 hover:bg-card">
                <Plus className="h-3.5 w-3.5" />
                <span>Add Reminder</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Reminder</DialogTitle>
                <DialogDescription>
                  Set up a custom reminder for feeding, medication, or other needs.
                </DialogDescription>
              </DialogHeader>
              <ReminderForm onSuccess={() => setIsAddReminderOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mt-1">
        <div className="px-4">
          <TabsList className="grid grid-cols-5 h-9 mb-2">
            <TabsTrigger value="all" className="text-xs">
              All
              {hasAnyReminders && (
                <Badge variant="secondary" className="ml-1.5 text-[10px]">
                  {/* Count each reminder individually by type to avoid duplicates */}
                  {getCustomReminderCountByType('feeding') + 
                   getCustomReminderCountByType('sleep') + 
                   getCustomReminderCountByType('medication') +
                   getSystemReminderCountByType(ReminderType.VACCINE) +
                   getSystemReminderCountByType(ReminderType.APPOINTMENT) + 
                   getSystemReminderCountByType(ReminderType.HEALTH_CHECK) +
                   getSystemReminderCountByType(ReminderType.MILESTONE) +
                   getSystemReminderCountByType(ReminderType.GROWTH_CHECK)}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="feeding" className="text-xs flex items-center gap-1">
              <Baby className="h-3 w-3" />
              <span>Feeding</span>
              {getCustomReminderCountByType('feeding') > 0 && (
                <Badge variant="secondary" className="ml-1 text-[10px]">
                  {getCustomReminderCountByType('feeding')}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="sleep" className="text-xs flex items-center gap-1">
              <MoonStar className="h-3 w-3" />
              <span>Naps</span>
              {getCustomReminderCountByType('sleep') > 0 && (
                <Badge variant="secondary" className="ml-1 text-[10px]">
                  {getCustomReminderCountByType('sleep')}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="medication" className="text-xs flex items-center gap-1">
              <Pill className="h-3 w-3" />
              <span>Meds</span>
              {getCustomReminderCountByType('medication') > 0 && (
                <Badge variant="secondary" className="ml-1 text-[10px]">
                  {getCustomReminderCountByType('medication')}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="health" className="text-xs flex items-center gap-1">
              <Syringe className="h-3 w-3" />
              <span>Health</span>
              {(getSystemReminderCountByType(ReminderType.VACCINE) + 
                getSystemReminderCountByType(ReminderType.APPOINTMENT) +
                getSystemReminderCountByType(ReminderType.HEALTH_CHECK)) > 0 && (
                <Badge variant="secondary" className="ml-1 text-[10px]">
                  {getSystemReminderCountByType(ReminderType.VACCINE) + 
                    getSystemReminderCountByType(ReminderType.APPOINTMENT) +
                    getSystemReminderCountByType(ReminderType.HEALTH_CHECK)}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="all" className="mt-0">
          <CardContent className="pt-0 px-3">
            {hasCustomReminders && <CustomReminderList filterType={null} />}
            {hasSystemReminders && <ReminderList />}
          </CardContent>
        </TabsContent>
        
        <TabsContent value="feeding" className="mt-0">
          <CardContent className="pt-0 px-3">
            {customReminders && customReminders.some((r: any) => r.type === 'feeding') ? (
              <CustomReminderList filterType="feeding" />
            ) : (
              <div className="text-center py-2 text-sm text-muted-foreground">
                No feeding reminders found
              </div>
            )}
          </CardContent>
        </TabsContent>
        
        <TabsContent value="sleep" className="mt-0">
          <CardContent className="pt-0 px-3">
            {customReminders && customReminders.some((r: any) => r.type === 'sleep') ? (
              <CustomReminderList filterType="sleep" />
            ) : (
              <div className="text-center py-2 text-sm text-muted-foreground">
                No sleep/nap reminders found
              </div>
            )}
          </CardContent>
        </TabsContent>
        
        <TabsContent value="medication" className="mt-0">
          <CardContent className="pt-0 px-3">
            {customReminders && customReminders.some((r: any) => r.type === 'medication') ? (
              <CustomReminderList filterType="medication" />
            ) : (
              <div className="text-center py-2 text-sm text-muted-foreground">
                No medication reminders found
              </div>
            )}
          </CardContent>
        </TabsContent>
        
        <TabsContent value="health" className="mt-0">
          <CardContent className="pt-0 px-3">
            <ReminderList 
              filterTypes={[
                ReminderType.VACCINE, 
                ReminderType.APPOINTMENT, 
                ReminderType.HEALTH_CHECK
              ]} 
            />
          </CardContent>
        </TabsContent>
      </Tabs>
    </Card>
  );
}