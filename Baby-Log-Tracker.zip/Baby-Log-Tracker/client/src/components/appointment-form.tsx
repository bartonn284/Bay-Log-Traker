import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CalendarIcon, Clock } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Appointment } from "../../shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

// Schema for the form
const appointmentSchema = z.object({
  title: z.string().min(1, { message: "Title is required" }),
  appointmentType: z.string().min(1, { message: "Appointment type is required" }),
  date: z.date({ required_error: "Date is required" }),
  time: z.string().optional(),
  location: z.string().optional(),
  doctorName: z.string().optional(),
  notes: z.string().optional(),
  reminderSet: z.boolean().default(false),
  reminderTime: z.date().optional().nullable(),
  completed: z.boolean().default(false),
});

type FormValues = z.infer<typeof appointmentSchema>;

type AppointmentFormProps = {
  appointment: Appointment | null;
  babyId: number;
  onSuccess: () => void;
};

export default function AppointmentForm({ appointment, babyId, onSuccess }: AppointmentFormProps) {
  const { toast } = useToast();
  const [showReminderCalendar, setShowReminderCalendar] = useState(false);

  // Default values
  const defaultValues: Partial<FormValues> = appointment
    ? {
        ...appointment,
        date: new Date(appointment.date),
        reminderTime: appointment.reminderTime ? new Date(appointment.reminderTime) : null,
      }
    : {
        title: "",
        appointmentType: "",
        date: new Date(),
        time: "",
        location: "",
        doctorName: "",
        notes: "",
        reminderSet: false,
        reminderTime: null,
        completed: false,
      };

  // Create form
  const form = useForm<FormValues>({
    resolver: zodResolver(appointmentSchema),
    defaultValues,
  });

  // Watch the reminderSet field to toggle visibility of reminder date/time
  const reminderSet = form.watch("reminderSet");

  // Create mutation for saving the appointment
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      // Check if babyId is valid before making the request
      if (!babyId) {
        throw new Error("No baby selected. Please select a baby first.");
      }
      
      const response = await fetch(`/api/babies/${babyId}/appointments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        throw new Error("Failed to create appointment");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Appointment created",
        description: "Your appointment has been successfully created.",
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create appointment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!appointment) return null;
      
      // Check if babyId is valid before making the request
      if (!babyId) {
        throw new Error("No baby selected. Please select a baby first.");
      }

      const response = await fetch(`/api/babies/${babyId}/appointments/${appointment.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        throw new Error("Failed to update appointment");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Appointment updated",
        description: "Your appointment has been successfully updated.",
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update appointment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    // Check if babyId is valid
    if (!babyId || isNaN(babyId)) {
      toast({
        title: "Error",
        description: "No baby selected. Please select a baby first.",
        variant: "destructive",
      });
      return;
    }
    
    if (appointment) {
      updateMutation.mutate(values);
    } else {
      createMutation.mutate(values);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-2">
        {/* Title */}
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Title*</FormLabel>
              <FormControl>
                <Input placeholder="Enter appointment title" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Appointment Type */}
        <FormField
          control={form.control}
          name="appointmentType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Appointment Type*</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select appointment type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="check-up">Regular check-up</SelectItem>
                  <SelectItem value="sick-visit">Sick visit</SelectItem>
                  <SelectItem value="specialist">Specialist visit</SelectItem>
                  <SelectItem value="vaccination">Vaccination</SelectItem>
                  <SelectItem value="test">Medical test</SelectItem>
                  <SelectItem value="procedure">Medical procedure</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Date */}
        <FormField
          control={form.control}
          name="date"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel>Date*</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full pl-3 text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "PPP")
                      ) : (
                        <span>Pick a date</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={field.onChange}
                    disabled={(date) => date < new Date("1900-01-01")}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Time */}
        <FormField
          control={form.control}
          name="time"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Time</FormLabel>
              <FormControl>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input 
                    placeholder="e.g., 9:00 AM" 
                    className="pl-10"
                    {...field} 
                    value={field.value || ""} 
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Location */}
        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location</FormLabel>
              <FormControl>
                <Input placeholder="Enter location" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Doctor Name */}
        <FormField
          control={form.control}
          name="doctorName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Doctor/Healthcare Provider</FormLabel>
              <FormControl>
                <Input placeholder="Enter doctor's name" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Notes */}
        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Enter any additional notes" 
                  {...field} 
                  value={field.value || ""} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Reminder */}
        <FormField
          control={form.control}
          name="reminderSet"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
              <div className="space-y-0.5">
                <FormLabel>Set Reminder</FormLabel>
                <div className="text-sm text-muted-foreground">
                  Get notified before the appointment
                </div>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        {/* Reminder Time (conditional) */}
        {reminderSet && (
          <FormField
            control={form.control}
            name="reminderTime"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Reminder Time</FormLabel>
                <Popover open={showReminderCalendar} onOpenChange={setShowReminderCalendar}>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a reminder date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value || undefined}
                      onSelect={(date) => {
                        field.onChange(date);
                        setShowReminderCalendar(false);
                      }}
                      disabled={(date) => date > form.getValues("date") || date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        {/* Completed Status (for editing) */}
        {appointment && (
          <FormField
            control={form.control}
            name="completed"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>Mark as Completed</FormLabel>
                  <div className="text-sm text-muted-foreground">
                    Appointment has been attended
                  </div>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        )}

        {/* Submit Button */}
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Saving..." : appointment ? "Update Appointment" : "Create Appointment"}
        </Button>
      </form>
    </Form>
  );
}