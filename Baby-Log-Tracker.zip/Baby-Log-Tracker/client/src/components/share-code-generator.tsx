import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { QRCodeSVG } from "qrcode.react";
import { useToast } from "@/hooks/use-toast";
import { Copy, QrCode, Check, RefreshCcw, Clock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Baby } from "@shared/schema";
import { format, formatDistanceToNow } from "date-fns";

type ShareCodeGeneratorProps = {
  babyId: number;
  babyName: string;
  shareCode: string | null;
};

export function ShareCodeGenerator({ babyId, babyName, shareCode: initialShareCode }: ShareCodeGeneratorProps) {
  const { toast } = useToast();
  const [isCopied, setIsCopied] = useState(false);
  const [showQR, setShowQR] = useState(false);

  // Fetch the latest baby data to ensure we have the most current share code
  const { data: babyData } = useQuery<Baby>({
    queryKey: ["/api/babies", babyId],
    enabled: !!babyId,
  });

  // Use the most up-to-date share code
  const currentShareCode = babyData?.shareCode || initialShareCode;
  const shareCodeExpiry = babyData?.shareCodeExpiry ? new Date(babyData.shareCodeExpiry) : null;
  
  // Check if the share code is expired
  const isShareCodeExpired = shareCodeExpiry ? new Date() > shareCodeExpiry : false;
  
  // Format the expiry time
  const formattedExpiry = shareCodeExpiry ? format(shareCodeExpiry, "MMM dd, yyyy 'at' h:mm a") : '';
  const expiryFromNow = shareCodeExpiry ? formatDistanceToNow(shareCodeExpiry, { addSuffix: true }) : '';
  
  const appUrl = window.location.origin;
  const joinUrl = currentShareCode && !isShareCodeExpired ? `${appUrl}/join-baby?code=${currentShareCode}` : "";

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setIsCopied(true);
      toast({
        title: "Copied!",
        description: "The share code has been copied to your clipboard.",
      });
      // Keep copied indicator visible longer
      setTimeout(() => setIsCopied(false), 5000);
      return true;
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please try again or manually select and copy the code.",
        variant: "destructive",
      });
      return false;
    }
  };

  // Create a mutation for generating new codes
  const generateCodeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("GET", `/api/babies/${babyId}/debug-generate-code`);
      return await response.json();
    },
    onSuccess: (data) => {
      // Update the cache
      queryClient.setQueryData(["/api/babies", babyId], (oldData: any) => {
        if (oldData) {
          return {
            ...oldData,
            shareCode: data.shareCode,
            shareCodeExpiry: data.expiresAt,
          };
        }
        return oldData;
      });
      
      // Also update the babies list cache
      queryClient.invalidateQueries({
        queryKey: ["/api/babies"],
      });
      
      // Format expiry time for toast
      const expiryDate = new Date(data.expiresAt);
      const expiryTimeFromNow = formatDistanceToNow(expiryDate);
      
      toast({
        title: "Success!",
        description: `New share code generated. Valid for ${expiryTimeFromNow}.`,
      });
    },
    onError: (error: Error) => {
      console.error("Failed to generate code:", error);
      toast({
        title: "Error",
        description: "Failed to generate a new share code. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="bg-white dark:bg-gray-950 rounded-xl overflow-hidden border border-gray-100 dark:border-gray-800 shadow-md">
      <div className="bg-gradient-to-r from-indigo-500 to-purple-500 p-4">
        <h2 className="text-xl font-bold text-white">Share {babyName}'s Data</h2>
        <p className="text-sm text-white/80">Connect with family members using a unique code</p>
      </div>

      <div className="p-6">
        {currentShareCode ? (
          <>
            <div className="mb-6">
              <div className="text-sm font-medium text-gray-500 mb-2">Share Code:</div>
              <div className="flex items-center space-x-2">
                <div className={cn(
                  "px-4 py-3 rounded-lg w-full",
                  isShareCodeExpired 
                    ? "bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800" 
                    : "bg-gray-100 dark:bg-gray-800"
                )}>
                  <div className="font-mono text-lg font-semibold text-center">{currentShareCode}</div>
                  {shareCodeExpiry && (
                    <div className="flex items-center justify-center mt-2 text-xs text-gray-500">
                      <Clock className="h-3 w-3 mr-1" />
                      {isShareCodeExpired 
                        ? <span className="text-red-500 font-medium">Expired - Generate a new code</span> 
                        : <span>Expires {expiryFromNow}</span>
                      }
                    </div>
                  )}
                </div>
                <Button 
                  size="icon" 
                  variant="outline"
                  onClick={() => copyToClipboard(currentShareCode)}
                  className={cn(
                    isCopied && "text-green-500 border-green-500",
                    "hover:bg-gray-100 dark:hover:bg-gray-800"
                  )}
                >
                  {isCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="flex justify-between items-center mb-6">
              <Button 
                variant="outline" 
                className="border-gray-200 dark:border-gray-700"
                onClick={() => generateCodeMutation.mutate()}
                disabled={generateCodeMutation.isPending}
              >
                {generateCodeMutation.isPending ? (
                  <>
                    <RefreshCcw className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <RefreshCcw className="h-4 w-4 mr-2" />
                    Generate New Code
                  </>
                )}
              </Button>
              
              <Dialog open={showQR} onOpenChange={setShowQR}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="border-gray-200 dark:border-gray-700">
                    <QrCode className="h-4 w-4 mr-2" />
                    Show QR Code
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogTitle>QR Code for {babyName}</DialogTitle>
                  <div className="flex flex-col items-center justify-center py-4">
                    <div className="bg-white p-4 rounded-lg">
                      <QRCodeSVG
                        value={joinUrl}
                        size={200}
                        bgColor={"#ffffff"}
                        fgColor={"#000000"}
                        level={"L"}
                        includeMargin={false}
                      />
                    </div>
                    <p className="mt-4 text-sm text-center text-gray-500">
                      Scan this code or share this link to join {babyName}'s profile
                    </p>
                    <div className="mt-4 text-xs font-mono text-gray-500 break-all bg-gray-100 dark:bg-gray-800 p-2 rounded w-full">
                      {joinUrl}
                    </div>
                    {shareCodeExpiry && (
                      <div className="flex items-center justify-center mt-4 text-sm text-gray-500">
                        <Clock className="h-4 w-4 mr-2" />
                        {isShareCodeExpired 
                          ? <span className="text-red-500">This code has expired</span> 
                          : <span>Code expires {expiryFromNow}</span>
                        }
                      </div>
                    )}
                    <DialogClose asChild>
                      <Button className="mt-4 w-full">Close</Button>
                    </DialogClose>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </>
        ) : (
          <div className="text-center py-10">
            <div className="text-gray-400 mb-4">No share code available</div>
            <Button 
              onClick={() => generateCodeMutation.mutate()}
              disabled={generateCodeMutation.isPending}
              className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white hover:opacity-90"
            >
              {generateCodeMutation.isPending ? (
                <>
                  <RefreshCcw className="h-4 w-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <RefreshCcw className="h-4 w-4 mr-2" />
                  Generate Share Code
                </>
              )}
            </Button>
          </div>
        )}

        <div className="border-t border-gray-100 dark:border-gray-800 pt-4 mt-2">
          <p className="text-xs text-gray-500 font-medium mb-1">How sharing works:</p>
          <ul className="text-xs text-gray-500 space-y-1">
            <li>• Share the 12-digit code with family members</li>
            <li>• They can enter this code in the "Join Baby" section</li>
            <li>• Or scan the QR code for instant access</li>
            <li>• Each code is valid for 5 minutes</li>
            <li>• Manage member permissions in Family Access below</li>
          </ul>
        </div>
      </div>
    </div>
  );
}