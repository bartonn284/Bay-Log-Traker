import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Plus, 
  Trash2, 
  Edit,
  Clock,
  FileText,
  Droplet,
  Sparkles
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface Diaper {
  id: number;
  babyId: number;
  createdAt: Date;
  time: Date;
  type: string;
  consistency: string | null;
  color: string | null;
  notes: string | null;
  createdBy: number;
}

export default function DiaperTab() {
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentDiaper, setCurrentDiaper] = useState<Diaper | null>(null);
  const [diaperType, setDiaperType] = useState("wet");
  const [time, setTime] = useState<Date>(new Date());
  const [consistency, setConsistency] = useState<string>("");
  const [color, setColor] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [date, setDate] = useState<Date>(new Date());
  const [timeFilter, setTimeFilter] = useState<"all" | "today" | "week">("today");
  
  // Fetch diaper records
  const { data: diapers, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby?.id, 'diapers'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby.id}/diapers`);
      return res.json();
    },
    enabled: !!selectedBaby
  });
  
  // Create diaper record
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      time: Date;
      type: string;
      consistency?: string;
      color?: string;
      notes?: string;
    }) => {
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/diapers`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'diapers'] });
      toast({
        title: "Success",
        description: "Diaper change recorded successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to record diaper change: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update diaper record
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      time: Date;
      type: string;
      consistency?: string;
      color?: string;
      notes?: string;
    }) => {
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/diapers/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'diapers'] });
      toast({
        title: "Success",
        description: "Diaper change updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update diaper change: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete diaper record
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/diapers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'diapers'] });
      toast({
        title: "Success",
        description: "Diaper change deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete diaper change: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setDiaperType("wet");
    setTime(new Date());
    setConsistency("");
    setColor("");
    setNotes("");
    setDate(new Date());
    setCurrentDiaper(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    // Combine date with time
    const combinedTime = combineDateTime(date, time);
    
    createMutation.mutate({
      babyId: selectedBaby.id,
      time: combinedTime,
      type: diaperType,
      consistency: diaperType === "dirty" || diaperType === "both" ? consistency || undefined : undefined,
      color: diaperType === "dirty" || diaperType === "both" ? color || undefined : undefined,
      notes: notes || undefined
    });
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !currentDiaper) {
      toast({
        title: "Error",
        description: "No baby or diaper record selected",
        variant: "destructive",
      });
      return;
    }
    
    // Combine date with time
    const combinedTime = combineDateTime(date, time);
    
    updateMutation.mutate({
      id: currentDiaper.id,
      babyId: selectedBaby.id,
      time: combinedTime,
      type: diaperType,
      consistency: diaperType === "dirty" || diaperType === "both" ? consistency || undefined : undefined,
      color: diaperType === "dirty" || diaperType === "both" ? color || undefined : undefined,
      notes: notes || undefined
    });
  };
  
  const handleEdit = (diaper: Diaper) => {
    setCurrentDiaper(diaper);
    setDiaperType(diaper.type);
    setTime(new Date(diaper.time));
    setConsistency(diaper.consistency || "");
    setColor(diaper.color || "");
    setNotes(diaper.notes || "");
    setDate(new Date(diaper.time));
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this diaper change record?")) {
      deleteMutation.mutate(id);
    }
  };
  
  // Helper function to combine date and time
  const combineDateTime = (date: Date, time: Date) => {
    const result = new Date(date);
    result.setHours(time.getHours());
    result.setMinutes(time.getMinutes());
    result.setSeconds(time.getSeconds());
    return result;
  };
  
  // Filter diaper records based on time filter
  const filteredDiapers = (() => {
    if (!diapers) return [];
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    weekAgo.setHours(0, 0, 0, 0);
    
    if (timeFilter === "today") {
      return diapers.filter((diaper: Diaper) => {
        const diaperDate = new Date(diaper.time);
        diaperDate.setHours(0, 0, 0, 0);
        return diaperDate.getTime() === today.getTime();
      });
    } else if (timeFilter === "week") {
      return diapers.filter((diaper: Diaper) => {
        const diaperDate = new Date(diaper.time);
        return diaperDate >= weekAgo;
      });
    }
    
    return diapers;
  })();
  
  // Sort diaper records by time (newest first)
  const sortedDiapers = filteredDiapers.sort((a: Diaper, b: Diaper) => 
    new Date(b.time).getTime() - new Date(a.time).getTime()
  );
  
  // Get icon and color for diaper type
  const getDiaperTypeInfo = (type: string) => {
    switch (type) {
      case "wet":
        return {
          icon: <Droplet className="h-5 w-5 text-blue-500" />,
          bgColor: "bg-blue-100 dark:bg-blue-900/30",
          badge: "Wet"
        };
      case "dirty":
        return {
          icon: <Sparkles className="h-5 w-5 text-amber-500" />,
          bgColor: "bg-amber-100 dark:bg-amber-900/30",
          badge: "Dirty"
        };
      case "both":
        return {
          icon: <div className="flex items-center">
            <Droplet className="h-5 w-5 text-blue-500 mr-1" />
            <Sparkles className="h-5 w-5 text-amber-500" />
          </div>,
          bgColor: "bg-green-100 dark:bg-green-900/30",
          badge: "Wet & Dirty"
        };
      default:
        return {
          icon: <Droplet className="h-5 w-5 text-gray-500" />,
          bgColor: "bg-gray-100 dark:bg-gray-900/30",
          badge: "Unknown"
        };
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Diaper Tracking</h2>
          <p className="text-sm text-muted-foreground">
            Track your baby's diaper changes
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Select value={timeFilter} onValueChange={(value: "all" | "today" | "week") => setTimeFilter(value)}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Time filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This week</SelectItem>
            </SelectContent>
          </Select>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Diaper
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Record Diaper Change</DialogTitle>
                <DialogDescription>
                  Track a new diaper change for your baby
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Diaper Type</Label>
                  <RadioGroup
                    value={diaperType}
                    onValueChange={setDiaperType}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="wet" id="wet" />
                      <Label htmlFor="wet" className="flex items-center">
                        <Droplet className="h-4 w-4 text-blue-500 mr-1" />
                        Wet
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="dirty" id="dirty" />
                      <Label htmlFor="dirty" className="flex items-center">
                        <Sparkles className="h-4 w-4 text-amber-500 mr-1" />
                        Dirty
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="both" id="both" />
                      <Label htmlFor="both" className="flex items-center">
                        <Droplet className="h-4 w-4 text-blue-500 mr-1" />
                        <Sparkles className="h-4 w-4 text-amber-500 mr-1" />
                        Both
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(date) => date && setDate(date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label>Time</Label>
                  <Input
                    type="time"
                    value={format(time, "HH:mm")}
                    onChange={(e) => {
                      const [hours, minutes] = e.target.value.split(":");
                      const newTime = new Date();
                      newTime.setHours(parseInt(hours));
                      newTime.setMinutes(parseInt(minutes));
                      setTime(newTime);
                    }}
                  />
                </div>
                
                {(diaperType === "dirty" || diaperType === "both") && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Consistency</Label>
                      <Select
                        value={consistency}
                        onValueChange={setConsistency}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="solid">Solid</SelectItem>
                          <SelectItem value="soft">Soft</SelectItem>
                          <SelectItem value="loose">Loose</SelectItem>
                          <SelectItem value="watery">Watery</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Color</Label>
                      <Select
                        value={color}
                        onValueChange={setColor}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="yellow">Yellow</SelectItem>
                          <SelectItem value="green">Green</SelectItem>
                          <SelectItem value="brown">Brown</SelectItem>
                          <SelectItem value="black">Black</SelectItem>
                          <SelectItem value="red">Red</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Any additional notes..."
                  />
                </div>
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Save Diaper Change</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Diaper Change</DialogTitle>
            <DialogDescription>
              Update diaper change information
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleUpdate} className="space-y-4">
            <div className="space-y-2">
              <Label>Diaper Type</Label>
              <RadioGroup
                value={diaperType}
                onValueChange={setDiaperType}
                className="flex space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="wet" id="edit-wet" />
                  <Label htmlFor="edit-wet" className="flex items-center">
                    <Droplet className="h-4 w-4 text-blue-500 mr-1" />
                    Wet
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="dirty" id="edit-dirty" />
                  <Label htmlFor="edit-dirty" className="flex items-center">
                    <Sparkles className="h-4 w-4 text-amber-500 mr-1" />
                    Dirty
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="both" id="edit-both" />
                  <Label htmlFor="edit-both" className="flex items-center">
                    <Droplet className="h-4 w-4 text-blue-500 mr-1" />
                    <Sparkles className="h-4 w-4 text-amber-500 mr-1" />
                    Both
                  </Label>
                </div>
              </RadioGroup>
            </div>
            
            <div className="space-y-2">
              <Label>Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(date) => date && setDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label>Time</Label>
              <Input
                type="time"
                value={format(time, "HH:mm")}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(":");
                  const newTime = new Date();
                  newTime.setHours(parseInt(hours));
                  newTime.setMinutes(parseInt(minutes));
                  setTime(newTime);
                }}
              />
            </div>
            
            {(diaperType === "dirty" || diaperType === "both") && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Consistency</Label>
                  <Select
                    value={consistency}
                    onValueChange={setConsistency}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="solid">Solid</SelectItem>
                      <SelectItem value="soft">Soft</SelectItem>
                      <SelectItem value="loose">Loose</SelectItem>
                      <SelectItem value="watery">Watery</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Color</Label>
                  <Select
                    value={color}
                    onValueChange={setColor}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="yellow">Yellow</SelectItem>
                      <SelectItem value="green">Green</SelectItem>
                      <SelectItem value="brown">Brown</SelectItem>
                      <SelectItem value="black">Black</SelectItem>
                      <SelectItem value="red">Red</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
            
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional notes..."
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">Update Diaper Change</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Diaper Changes List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center p-4">Loading...</div>
        ) : sortedDiapers.length > 0 ? (
          sortedDiapers.map((diaper: Diaper) => {
            const typeInfo = getDiaperTypeInfo(diaper.type);
            
            return (
              <Card key={diaper.id} className="mb-4">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full ${typeInfo.bgColor} flex items-center justify-center mr-3`}>
                        {typeInfo.icon}
                      </div>
                      <div>
                        <CardTitle className="text-base font-medium">
                          Diaper Change
                        </CardTitle>
                        <CardDescription>
                          {format(new Date(diaper.time), "PPP p")}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex space-x-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => handleEdit(diaper)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive" 
                        onClick={() => handleDelete(diaper.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <div className="grid grid-cols-2 gap-y-2 text-sm">
                    <div className="flex items-center">
                      <Badge 
                        variant="outline" 
                        className={`
                          ${diaper.type === 'wet' && 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400'}
                          ${diaper.type === 'dirty' && 'bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400'}
                          ${diaper.type === 'both' && 'bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400'}
                        `}
                      >
                        {typeInfo.badge}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{format(new Date(diaper.time), "h:mm a")}</span>
                    </div>
                    
                    {(diaper.type === "dirty" || diaper.type === "both") && (
                      <>
                        {diaper.consistency && (
                          <div className="flex items-center">
                            <span className="text-sm text-muted-foreground mr-2">Consistency:</span>
                            <span className="capitalize">{diaper.consistency}</span>
                          </div>
                        )}
                        
                        {diaper.color && (
                          <div className="flex items-center">
                            <span className="text-sm text-muted-foreground mr-2">Color:</span>
                            <span className="capitalize">{diaper.color}</span>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                  
                  {diaper.notes && (
                    <div className="mt-3 pt-3 border-t">
                      <div className="flex items-start">
                        <FileText className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
                        <p className="text-sm">{diaper.notes}</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            No diaper changes recorded. Click 'Add Diaper' to start tracking your baby's changes.
          </div>
        )}
      </div>
    </div>
  );
}