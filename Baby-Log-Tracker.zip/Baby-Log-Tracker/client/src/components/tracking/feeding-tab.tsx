import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Utensils, 
  Plus, 
  Trash2, 
  Edit,
  Baby as BabyIcon,
  Clock,
  Timer,
  FileText
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface Feeding {
  id: number;
  babyId: number;
  createdAt: Date;
  type: string;
  startTime: Date;
  endTime: Date | null;
  duration: number | null;
  amount: string | null;
  side: string | null;
  notes: string | null;
  createdBy: number;
}

export default function FeedingTab() {
  const { toast } = useToast();
  const { selectedBaby, selectedBabyData, isReady } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentFeeding, setCurrentFeeding] = useState<Feeding | null>(null);
  const [feedingType, setFeedingType] = useState("breast");
  const [startTime, setStartTime] = useState<Date>(new Date());
  const [endTime, setEndTime] = useState<Date | null>(null);
  const [duration, setDuration] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [side, setSide] = useState<string>("left");
  const [notes, setNotes] = useState<string>("");
  const [date, setDate] = useState<Date>(new Date());
  const [timeFilter, setTimeFilter] = useState<"all" | "today" | "week">("today");
  
  // Fetch feedings
  const { data: feedings, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBabyData?.id, 'feedings'],
    queryFn: async () => {
      if (!selectedBabyData) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBabyData.id}/feedings`);
      return res.json();
    },
    enabled: !!selectedBabyData && isReady
  });
  
  // Create feeding
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      type: string;
      startTime: Date;
      endTime?: Date;
      duration?: number;
      amount?: string;
      side?: string;
      notes?: string;
    }) => {
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/feedings`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBabyData?.id, 'feedings'] });
      toast({
        title: "Success",
        description: "Feeding added successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add feeding: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update feeding
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      type: string;
      startTime: Date;
      endTime?: Date;
      duration?: number;
      amount?: string;
      side?: string;
      notes?: string;
    }) => {
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/feedings/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBabyData?.id, 'feedings'] });
      toast({
        title: "Success",
        description: "Feeding updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update feeding: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete feeding
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      if (!selectedBabyData) return;
      await apiRequest("DELETE", `/api/babies/${selectedBabyData.id}/feedings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBabyData?.id, 'feedings'] });
      toast({
        title: "Success",
        description: "Feeding deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete feeding: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setFeedingType("breast");
    setStartTime(new Date());
    setEndTime(null);
    setDuration("");
    setAmount("");
    setSide("left");
    setNotes("");
    setDate(new Date());
    setCurrentFeeding(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBabyData) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    // Combine date with time
    const combinedStartTime = combineDateTime(date, startTime);
    let combinedEndTime = null;
    if (endTime) {
      combinedEndTime = combineDateTime(date, endTime);
    }
    
    // Calculate duration if not provided
    let calculatedDuration = null;
    if (duration) {
      calculatedDuration = parseInt(duration);
    } else if (combinedEndTime) {
      calculatedDuration = Math.round(
        (combinedEndTime.getTime() - combinedStartTime.getTime()) / (1000 * 60)
      );
    }
    
    createMutation.mutate({
      babyId: selectedBabyData.id,
      type: feedingType,
      startTime: combinedStartTime,
      endTime: combinedEndTime || undefined,
      duration: calculatedDuration || undefined,
      amount: amount || undefined,
      side: feedingType === "breast" ? side : undefined,
      notes: notes || undefined
    });
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBabyData || !currentFeeding) {
      toast({
        title: "Error",
        description: "No baby or feeding selected",
        variant: "destructive",
      });
      return;
    }
    
    // Combine date with time
    const combinedStartTime = combineDateTime(date, startTime);
    let combinedEndTime = null;
    if (endTime) {
      combinedEndTime = combineDateTime(date, endTime);
    }
    
    // Calculate duration if not provided
    let calculatedDuration = null;
    if (duration) {
      calculatedDuration = parseInt(duration);
    } else if (combinedEndTime) {
      calculatedDuration = Math.round(
        (combinedEndTime.getTime() - combinedStartTime.getTime()) / (1000 * 60)
      );
    }
    
    updateMutation.mutate({
      id: currentFeeding.id,
      babyId: selectedBabyData.id,
      type: feedingType,
      startTime: combinedStartTime,
      endTime: combinedEndTime || undefined,
      duration: calculatedDuration || undefined,
      amount: amount || undefined,
      side: feedingType === "breast" ? side : undefined,
      notes: notes || undefined
    });
  };
  
  const handleEdit = (feeding: Feeding) => {
    setCurrentFeeding(feeding);
    setFeedingType(feeding.type);
    setStartTime(new Date(feeding.startTime));
    setEndTime(feeding.endTime ? new Date(feeding.endTime) : null);
    setDuration(feeding.duration ? feeding.duration.toString() : "");
    setAmount(feeding.amount || "");
    setSide(feeding.side || "left");
    setNotes(feeding.notes || "");
    setDate(new Date(feeding.startTime));
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this feeding?")) {
      deleteMutation.mutate(id);
    }
  };
  
  // Helper function to combine date and time
  const combineDateTime = (date: Date, time: Date) => {
    const result = new Date(date);
    result.setHours(time.getHours());
    result.setMinutes(time.getMinutes());
    result.setSeconds(time.getSeconds());
    return result;
  };
  
  // Filter feedings based on time filter
  const filteredFeedings = (() => {
    if (!feedings) return [];
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    weekAgo.setHours(0, 0, 0, 0);
    
    if (timeFilter === "today") {
      return feedings.filter((feeding: Feeding) => {
        const feedingDate = new Date(feeding.startTime);
        feedingDate.setHours(0, 0, 0, 0);
        return feedingDate.getTime() === today.getTime();
      });
    } else if (timeFilter === "week") {
      return feedings.filter((feeding: Feeding) => {
        const feedingDate = new Date(feeding.startTime);
        return feedingDate >= weekAgo;
      });
    }
    
    return feedings;
  })();
  
  // Sort feedings by startTime (newest first)
  const sortedFeedings = filteredFeedings.sort((a: Feeding, b: Feeding) => 
    new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
  );
  
  // Get icon for feeding type
  const getFeedingTypeIcon = (type: string) => {
    switch (type) {
      case "breast":
        return <BabyIcon className="h-5 w-5 text-pink-500" />;
      case "bottle":
        return <BabyIcon className="h-5 w-5 text-blue-500" />;
      case "formula":
        return <BabyIcon className="h-5 w-5 text-purple-500" />;
      case "solids":
        return <Utensils className="h-5 w-5 text-amber-500" />;
      default:
        return <Utensils className="h-5 w-5 text-gray-500" />;
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Feeding Tracking</h2>
          <p className="text-sm text-muted-foreground">
            Track your baby's feeding times and details
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Select value={timeFilter} onValueChange={(value: "all" | "today" | "week") => setTimeFilter(value)}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Time filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This week</SelectItem>
            </SelectContent>
          </Select>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Feeding
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Feeding</DialogTitle>
                <DialogDescription>
                  Record a new feeding for your baby
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Feeding Type</Label>
                  <Select 
                    value={feedingType} 
                    onValueChange={setFeedingType}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select feeding type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="breast">Breast</SelectItem>
                      <SelectItem value="bottle">Bottle</SelectItem>
                      <SelectItem value="formula">Formula</SelectItem>
                      <SelectItem value="solids">Solids</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(date) => date && setDate(date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Time</Label>
                    <Input
                      type="time"
                      value={format(startTime, "HH:mm")}
                      onChange={(e) => {
                        const [hours, minutes] = e.target.value.split(":");
                        const newTime = new Date();
                        newTime.setHours(parseInt(hours));
                        newTime.setMinutes(parseInt(minutes));
                        setStartTime(newTime);
                      }}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>End Time (optional)</Label>
                    <Input
                      type="time"
                      value={endTime ? format(endTime, "HH:mm") : ""}
                      onChange={(e) => {
                        if (e.target.value) {
                          const [hours, minutes] = e.target.value.split(":");
                          const newTime = new Date();
                          newTime.setHours(parseInt(hours));
                          newTime.setMinutes(parseInt(minutes));
                          setEndTime(newTime);
                        } else {
                          setEndTime(null);
                        }
                      }}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Duration (minutes)</Label>
                    <Input
                      type="number"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      placeholder="e.g., 15"
                    />
                  </div>
                  
                  {(feedingType === "bottle" || feedingType === "formula" || feedingType === "solids") && (
                    <div className="space-y-2">
                      <Label>Amount</Label>
                      <Input
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder={feedingType === "solids" ? "e.g., 2 tbsp" : "e.g., 4 oz"}
                      />
                    </div>
                  )}
                  
                  {feedingType === "breast" && (
                    <div className="space-y-2">
                      <Label>Side</Label>
                      <RadioGroup
                        value={side}
                        onValueChange={setSide}
                        className="flex space-x-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="left" id="left" />
                          <Label htmlFor="left">Left</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="right" id="right" />
                          <Label htmlFor="right">Right</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="both" id="both" />
                          <Label htmlFor="both">Both</Label>
                        </div>
                      </RadioGroup>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Any additional notes..."
                  />
                </div>
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Save Feeding</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Feeding</DialogTitle>
            <DialogDescription>
              Update feeding information
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleUpdate} className="space-y-4">
            <div className="space-y-2">
              <Label>Feeding Type</Label>
              <Select 
                value={feedingType} 
                onValueChange={setFeedingType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select feeding type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breast">Breast</SelectItem>
                  <SelectItem value="bottle">Bottle</SelectItem>
                  <SelectItem value="formula">Formula</SelectItem>
                  <SelectItem value="solids">Solids</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(date) => date && setDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Time</Label>
                <Input
                  type="time"
                  value={format(startTime, "HH:mm")}
                  onChange={(e) => {
                    const [hours, minutes] = e.target.value.split(":");
                    const newTime = new Date();
                    newTime.setHours(parseInt(hours));
                    newTime.setMinutes(parseInt(minutes));
                    setStartTime(newTime);
                  }}
                />
              </div>
              
              <div className="space-y-2">
                <Label>End Time (optional)</Label>
                <Input
                  type="time"
                  value={endTime ? format(endTime, "HH:mm") : ""}
                  onChange={(e) => {
                    if (e.target.value) {
                      const [hours, minutes] = e.target.value.split(":");
                      const newTime = new Date();
                      newTime.setHours(parseInt(hours));
                      newTime.setMinutes(parseInt(minutes));
                      setEndTime(newTime);
                    } else {
                      setEndTime(null);
                    }
                  }}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Duration (minutes)</Label>
                <Input
                  type="number"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  placeholder="e.g., 15"
                />
              </div>
              
              {(feedingType === "bottle" || feedingType === "formula" || feedingType === "solids") && (
                <div className="space-y-2">
                  <Label>Amount</Label>
                  <Input
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder={feedingType === "solids" ? "e.g., 2 tbsp" : "e.g., 4 oz"}
                  />
                </div>
              )}
              
              {feedingType === "breast" && (
                <div className="space-y-2">
                  <Label>Side</Label>
                  <RadioGroup
                    value={side}
                    onValueChange={setSide}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="left" id="edit-left" />
                      <Label htmlFor="edit-left">Left</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="right" id="edit-right" />
                      <Label htmlFor="edit-right">Right</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="both" id="edit-both" />
                      <Label htmlFor="edit-both">Both</Label>
                    </div>
                  </RadioGroup>
                </div>
              )}
            </div>
            
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional notes..."
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">Update Feeding</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Feedings List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center p-4">Loading...</div>
        ) : sortedFeedings.length > 0 ? (
          sortedFeedings.map((feeding: Feeding) => (
            <Card key={feeding.id} className="mb-4">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                      {getFeedingTypeIcon(feeding.type)}
                    </div>
                    <div>
                      <CardTitle className="text-base font-medium capitalize">
                        {feeding.type} Feeding
                        {feeding.type === "breast" && feeding.side && (
                          <span className="ml-1 text-sm font-normal">
                            ({feeding.side} side)
                          </span>
                        )}
                      </CardTitle>
                      <CardDescription>
                        {format(new Date(feeding.startTime), "PPP p")}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8" 
                      onClick={() => handleEdit(feeding)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-destructive" 
                      onClick={() => handleDelete(feeding.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-4">
                <div className="grid grid-cols-2 gap-y-2 text-sm">
                  {feeding.duration && (
                    <div className="flex items-center">
                      <Timer className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{feeding.duration} minutes</span>
                    </div>
                  )}
                  
                  {feeding.amount && (
                    <div className="flex items-center">
                      <Utensils className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{feeding.amount}</span>
                    </div>
                  )}
                  
                  {feeding.startTime && feeding.endTime && (
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>
                        {format(new Date(feeding.startTime), "h:mm a")} - {format(new Date(feeding.endTime), "h:mm a")}
                      </span>
                    </div>
                  )}
                </div>
                
                {feeding.notes && (
                  <div className="mt-3 pt-3 border-t">
                    <div className="flex items-start">
                      <FileText className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
                      <p className="text-sm">{feeding.notes}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            No feedings recorded. Click 'Add Feeding' to track your baby's first feeding.
          </div>
        )}
      </div>
    </div>
  );
}