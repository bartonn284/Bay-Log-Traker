import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  CalendarIcon, 
  Moon, 
  Plus, 
  Trash2, 
  Edit,
  Clock,
  Timer,
  FileText,
  Stars
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";

interface Sleep {
  id: number;
  babyId: number;
  createdAt: Date;
  type: string;
  startTime: Date;
  endTime: Date | null;
  duration: number | null;
  quality: number | null;
  notes: string | null;
  createdBy: number;
}

export default function SleepTab() {
  const { toast } = useToast();
  const { selectedBaby } = useBabyContext();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentSleep, setCurrentSleep] = useState<Sleep | null>(null);
  const [sleepType, setSleepType] = useState("nap");
  const [startTime, setStartTime] = useState<Date>(new Date());
  const [endTime, setEndTime] = useState<Date | null>(null);
  const [duration, setDuration] = useState<string>("");
  const [quality, setQuality] = useState<number>(5);
  const [notes, setNotes] = useState<string>("");
  const [date, setDate] = useState<Date>(new Date());
  const [timeFilter, setTimeFilter] = useState<"all" | "today" | "week">("today");
  
  // Fetch sleep records
  const { data: sleepRecords, isLoading } = useQuery({
    queryKey: ['/api/babies', selectedBaby?.id, 'sleep'],
    queryFn: async () => {
      if (!selectedBaby) return [];
      const res = await apiRequest("GET", `/api/babies/${selectedBaby.id}/sleep`);
      return res.json();
    },
    enabled: !!selectedBaby
  });
  
  // Create sleep record
  const createMutation = useMutation({
    mutationFn: async (data: {
      babyId: number;
      type: string;
      startTime: Date;
      endTime?: Date;
      duration?: number;
      quality?: number;
      notes?: string;
    }) => {
      const res = await apiRequest("POST", `/api/babies/${data.babyId}/sleep`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'sleep'] });
      toast({
        title: "Success",
        description: "Sleep record added successfully",
      });
      resetForm();
      setIsAddDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add sleep record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update sleep record
  const updateMutation = useMutation({
    mutationFn: async (data: {
      id: number;
      babyId: number;
      type: string;
      startTime: Date;
      endTime?: Date;
      duration?: number;
      quality?: number;
      notes?: string;
    }) => {
      const res = await apiRequest("PATCH", `/api/babies/${data.babyId}/sleep/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'sleep'] });
      toast({
        title: "Success",
        description: "Sleep record updated successfully",
      });
      resetForm();
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update sleep record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete sleep record
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${selectedBaby?.id}/sleep/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/babies', selectedBaby?.id, 'sleep'] });
      toast({
        title: "Success",
        description: "Sleep record deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete sleep record: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const resetForm = () => {
    setSleepType("nap");
    setStartTime(new Date());
    setEndTime(null);
    setDuration("");
    setQuality(5);
    setNotes("");
    setDate(new Date());
    setCurrentSleep(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby) {
      toast({
        title: "Error",
        description: "No baby selected",
        variant: "destructive",
      });
      return;
    }
    
    // Combine date with time
    const combinedStartTime = combineDateTime(date, startTime);
    let combinedEndTime = null;
    if (endTime) {
      combinedEndTime = combineDateTime(date, endTime);
    }
    
    // Calculate duration if not provided
    let calculatedDuration = null;
    if (duration) {
      calculatedDuration = parseInt(duration);
    } else if (combinedEndTime) {
      calculatedDuration = Math.round(
        (combinedEndTime.getTime() - combinedStartTime.getTime()) / (1000 * 60)
      );
    }
    
    createMutation.mutate({
      babyId: selectedBaby.id,
      type: sleepType,
      startTime: combinedStartTime,
      endTime: combinedEndTime || undefined,
      duration: calculatedDuration || undefined,
      quality: quality || undefined,
      notes: notes || undefined
    });
  };
  
  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBaby || !currentSleep) {
      toast({
        title: "Error",
        description: "No baby or sleep record selected",
        variant: "destructive",
      });
      return;
    }
    
    // Combine date with time
    const combinedStartTime = combineDateTime(date, startTime);
    let combinedEndTime = null;
    if (endTime) {
      combinedEndTime = combineDateTime(date, endTime);
    }
    
    // Calculate duration if not provided
    let calculatedDuration = null;
    if (duration) {
      calculatedDuration = parseInt(duration);
    } else if (combinedEndTime) {
      calculatedDuration = Math.round(
        (combinedEndTime.getTime() - combinedStartTime.getTime()) / (1000 * 60)
      );
    }
    
    updateMutation.mutate({
      id: currentSleep.id,
      babyId: selectedBaby.id,
      type: sleepType,
      startTime: combinedStartTime,
      endTime: combinedEndTime || undefined,
      duration: calculatedDuration || undefined,
      quality: quality || undefined,
      notes: notes || undefined
    });
  };
  
  const handleEdit = (sleep: Sleep) => {
    setCurrentSleep(sleep);
    setSleepType(sleep.type);
    setStartTime(new Date(sleep.startTime));
    setEndTime(sleep.endTime ? new Date(sleep.endTime) : null);
    setDuration(sleep.duration ? sleep.duration.toString() : "");
    setQuality(sleep.quality || 5);
    setNotes(sleep.notes || "");
    setDate(new Date(sleep.startTime));
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this sleep record?")) {
      deleteMutation.mutate(id);
    }
  };
  
  // Helper function to combine date and time
  const combineDateTime = (date: Date, time: Date) => {
    const result = new Date(date);
    result.setHours(time.getHours());
    result.setMinutes(time.getMinutes());
    result.setSeconds(time.getSeconds());
    return result;
  };
  
  // Filter sleep records based on time filter
  const filteredSleepRecords = (() => {
    if (!sleepRecords) return [];
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    weekAgo.setHours(0, 0, 0, 0);
    
    if (timeFilter === "today") {
      return sleepRecords.filter((sleep: Sleep) => {
        const sleepDate = new Date(sleep.startTime);
        sleepDate.setHours(0, 0, 0, 0);
        return sleepDate.getTime() === today.getTime();
      });
    } else if (timeFilter === "week") {
      return sleepRecords.filter((sleep: Sleep) => {
        const sleepDate = new Date(sleep.startTime);
        return sleepDate >= weekAgo;
      });
    }
    
    return sleepRecords;
  })();
  
  // Sort sleep records by startTime (newest first)
  const sortedSleepRecords = filteredSleepRecords.sort((a: Sleep, b: Sleep) => 
    new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
  );
  
  // Helper function to format duration in hours and minutes
  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };
  
  // Helper function to get quality stars
  const renderQualityStars = (quality: number | null) => {
    if (!quality) return null;
    
    const stars = [];
    for (let i = 0; i < 5; i++) {
      stars.push(
        <Stars 
          key={i} 
          className={`h-4 w-4 ${i < quality ? "text-yellow-500" : "text-gray-300"}`} 
        />
      );
    }
    
    return <div className="flex">{stars}</div>;
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Sleep Tracking</h2>
          <p className="text-sm text-muted-foreground">
            Track your baby's sleep patterns and quality
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Select value={timeFilter} onValueChange={(value: "all" | "today" | "week") => setTimeFilter(value)}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Time filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This week</SelectItem>
            </SelectContent>
          </Select>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Sleep
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Sleep Record</DialogTitle>
                <DialogDescription>
                  Record a new sleep session for your baby
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Sleep Type</Label>
                  <Select 
                    value={sleepType} 
                    onValueChange={setSleepType}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select sleep type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nap">Nap</SelectItem>
                      <SelectItem value="night">Night Sleep</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(date) => date && setDate(date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Time</Label>
                    <Input
                      type="time"
                      value={format(startTime, "HH:mm")}
                      onChange={(e) => {
                        const [hours, minutes] = e.target.value.split(":");
                        const newTime = new Date();
                        newTime.setHours(parseInt(hours));
                        newTime.setMinutes(parseInt(minutes));
                        setStartTime(newTime);
                      }}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>End Time (optional)</Label>
                    <Input
                      type="time"
                      value={endTime ? format(endTime, "HH:mm") : ""}
                      onChange={(e) => {
                        if (e.target.value) {
                          const [hours, minutes] = e.target.value.split(":");
                          const newTime = new Date();
                          newTime.setHours(parseInt(hours));
                          newTime.setMinutes(parseInt(minutes));
                          setEndTime(newTime);
                        } else {
                          setEndTime(null);
                        }
                      }}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Duration (minutes)</Label>
                  <Input
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    placeholder="e.g., 120"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Sleep Quality</Label>
                    <span className="text-sm text-muted-foreground">{quality}/5</span>
                  </div>
                  <Slider
                    value={[quality]}
                    min={1}
                    max={5}
                    step={1}
                    onValueChange={(value) => setQuality(value[0])}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>Poor</span>
                    <span>Excellent</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Any additional notes..."
                  />
                </div>
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Save Sleep Record</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Sleep Record</DialogTitle>
            <DialogDescription>
              Update sleep record information
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleUpdate} className="space-y-4">
            <div className="space-y-2">
              <Label>Sleep Type</Label>
              <Select 
                value={sleepType} 
                onValueChange={setSleepType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select sleep type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nap">Nap</SelectItem>
                  <SelectItem value="night">Night Sleep</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(date) => date && setDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Time</Label>
                <Input
                  type="time"
                  value={format(startTime, "HH:mm")}
                  onChange={(e) => {
                    const [hours, minutes] = e.target.value.split(":");
                    const newTime = new Date();
                    newTime.setHours(parseInt(hours));
                    newTime.setMinutes(parseInt(minutes));
                    setStartTime(newTime);
                  }}
                />
              </div>
              
              <div className="space-y-2">
                <Label>End Time (optional)</Label>
                <Input
                  type="time"
                  value={endTime ? format(endTime, "HH:mm") : ""}
                  onChange={(e) => {
                    if (e.target.value) {
                      const [hours, minutes] = e.target.value.split(":");
                      const newTime = new Date();
                      newTime.setHours(parseInt(hours));
                      newTime.setMinutes(parseInt(minutes));
                      setEndTime(newTime);
                    } else {
                      setEndTime(null);
                    }
                  }}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Duration (minutes)</Label>
              <Input
                type="number"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="e.g., 120"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Sleep Quality</Label>
                <span className="text-sm text-muted-foreground">{quality}/5</span>
              </div>
              <Slider
                value={[quality]}
                min={1}
                max={5}
                step={1}
                onValueChange={(value) => setQuality(value[0])}
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Poor</span>
                <span>Excellent</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional notes..."
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">Update Sleep Record</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Sleep Records List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center p-4">Loading...</div>
        ) : sortedSleepRecords.length > 0 ? (
          sortedSleepRecords.map((sleep: Sleep) => (
            <Card key={sleep.id} className="mb-4">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full ${sleep.type === 'nap' ? 'bg-indigo-100 dark:bg-indigo-900/30' : 'bg-purple-100 dark:bg-purple-900/30'} flex items-center justify-center mr-3`}>
                      <Moon className={`h-5 w-5 ${sleep.type === 'nap' ? 'text-indigo-500' : 'text-purple-500'}`} />
                    </div>
                    <div>
                      <CardTitle className="text-base font-medium capitalize">
                        {sleep.type === 'nap' ? 'Nap' : 'Night Sleep'}
                      </CardTitle>
                      <CardDescription>
                        {format(new Date(sleep.startTime), "PPP p")}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8" 
                      onClick={() => handleEdit(sleep)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-destructive" 
                      onClick={() => handleDelete(sleep.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-4">
                <div className="grid grid-cols-2 gap-y-2 text-sm">
                  {sleep.duration && (
                    <div className="flex items-center">
                      <Timer className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{formatDuration(sleep.duration)}</span>
                    </div>
                  )}
                  
                  {sleep.startTime && sleep.endTime && (
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>
                        {format(new Date(sleep.startTime), "h:mm a")} - {format(new Date(sleep.endTime), "h:mm a")}
                      </span>
                    </div>
                  )}
                  
                  {sleep.quality && (
                    <div className="flex items-center col-span-2 mt-1">
                      <span className="mr-2 text-sm text-muted-foreground">Quality:</span>
                      {renderQualityStars(sleep.quality)}
                    </div>
                  )}
                </div>
                
                {sleep.notes && (
                  <div className="mt-3 pt-3 border-t">
                    <div className="flex items-start">
                      <FileText className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
                      <p className="text-sm">{sleep.notes}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            No sleep records recorded. Click 'Add Sleep' to start tracking your baby's sleep.
          </div>
        )}
      </div>
    </div>
  );
}