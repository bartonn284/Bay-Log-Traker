import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { User, Baby } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { ShareCodeCard } from "@/components/share-code-card-fixed";
import { cn } from "@/lib/utils";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Loader2, 
  MoreHorizontal, 
  UserPlus, 
  ShieldAlert, 
  ShieldCheck, 
  ShieldQuestion, 
  CheckCircle2,
  Users,
  QrCode
} from "lucide-react";

const inviteSchema = z.object({
  email: z.string().email("Please enter a valid email"),
  role: z.enum(["admin", "editor", "viewer"]),
});

type InviteFormValues = z.infer<typeof inviteSchema>;

type FamilySharingProps = {
  babyId: number;
};

type SharingMember = {
  id: number;
  babyId: number;
  userId: number;
  role: string;
  createdAt: string;
  user: {
    id: number;
    username: string;
    fullName: string;
  } | null;
};

const roleDisplay = {
  admin: {
    label: "Admin",
    bg: "bg-primary",
    abbr: "A",
    text: "text-white",
  },
  editor: {
    label: "Editor",
    bg: "bg-accent",
    abbr: "E",
    text: "text-white",
  },
  viewer: {
    label: "Viewer",
    bg: "bg-neutral-300",
    abbr: "V",
    text: "text-neutral-700",
  },
};

export function FamilySharing({ babyId }: FamilySharingProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Fetch baby details
  const { data: baby, refetch: refetchBaby } = useQuery<Baby>({
    queryKey: ["/api/babies", babyId],
  });
  
  // Regenerate code mutation
  const regenerateCodeMutation = useMutation({
    mutationFn: async ({ babyId, defaultRole }: { babyId: number, defaultRole: string }) => {
      console.log("Regenerating code for babyId:", babyId, "with defaultRole:", defaultRole);
      const res = await apiRequest("POST", `/api/babies/${babyId}/regenerate-code`, { defaultRole });
      const data = await res.json();
      console.log("Regenerate code response:", data);
      return data;
    },
    onSuccess: (data) => {
      console.log("Regenerate code success:", data);
      // Update the baby in cache immediately with the new share code
      queryClient.setQueryData([`/api/babies/${babyId}`], (oldData: any) => {
        return data.baby;
      });
      
      // Also invalidate all related queries to trigger refetch
      queryClient.invalidateQueries({queryKey: [`/api/babies/${babyId}`]});
      queryClient.invalidateQueries({queryKey: ["/api/babies"]});
      
      toast({
        title: "Share code regenerated",
        description: `New code created with default permission: ${data.defaultRole}`,
      });
    },
    onError: (error: Error) => {
      console.error("Regenerate code error:", error);
      toast({
        title: "Failed to regenerate code",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Fetch family members
  const { data: members, isLoading: isLoadingMembers } = useQuery<SharingMember[]>({
    queryKey: ["/api/babies", babyId, "sharing"],
    enabled: !!babyId,
  });
  
  // Form setup
  const form = useForm<InviteFormValues>({
    resolver: zodResolver(inviteSchema),
    defaultValues: {
      email: "",
      role: "editor",
    },
  });
  
  // Invite mutation
  const inviteMutation = useMutation({
    mutationFn: async (data: InviteFormValues) => {
      const res = await apiRequest("POST", `/api/babies/${babyId}/sharing`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", babyId, "sharing"],
      });
      toast({
        title: "Invitation sent",
        description: "The user has been added to this baby's sharing list",
      });
      form.reset({
        email: "",
        role: "editor",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to invite",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Role update mutation
  const updateRoleMutation = useMutation({
    mutationFn: async ({ id, role }: { id: number; role: string }) => {
      const res = await apiRequest("PUT", `/api/babies/${babyId}/sharing/${id}`, { role });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", babyId, "sharing"],
      });
      toast({
        title: "Role updated",
        description: "The user's role has been updated",
      });
    },
  });
  
  // Remove member mutation
  const removeMemberMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/babies/${babyId}/sharing/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/babies", babyId, "sharing"],
      });
      toast({
        title: "Member removed",
        description: "The user has been removed from sharing",
      });
    },
  });
  
  const onSubmit = (data: InviteFormValues) => {
    inviteMutation.mutate(data);
  };
  
  // Check if current user is admin - temporarily set to true for testing
  // const isAdmin = members?.some(
  //   (member) => member.userId === user?.id && member.role === "admin"
  // );
  const isAdmin = true; // Forcing this to true for testing
  
  // Add debug method to test share code generation directly
  const debugGenerateCode = async () => {
    try {
      console.log("Attempting debug code generation for baby:", babyId);
      const response = await fetch(`/api/babies/${babyId}/debug-generate-code`);
      const data = await response.json();
      console.log("Debug code generation result:", data);
      
      if (data.success) {
        toast({
          title: "Debug: Code Generated",
          description: `New share code: ${data.shareCode}`,
        });
        
        // Update the React Query cache directly to ensure persistence
        queryClient.setQueryData(["/api/babies", babyId], (oldData: any) => {
          if (oldData) {
            return {
              ...oldData,
              shareCode: data.shareCode,
              shareCodeExpiry: data.expiresAt,
            };
          }
          return oldData;
        });
        
        // Also update the babies list cache to ensure consistency
        queryClient.invalidateQueries({
          queryKey: ["/api/babies"],
        });
        
        // Refetch the baby data to ensure UI updates correctly
        refetchBaby();
      }
    } catch (error) {
      console.error("Debug code generation failed:", error);
      toast({
        title: "Debug Error",
        description: "Failed to generate code. See console for details.",
        variant: "destructive",
      });
    }
  };
  
  // Role icons for UI
  const roleIcons = {
    admin: <ShieldAlert className="h-4 w-4" />,
    editor: <ShieldCheck className="h-4 w-4" />,
    viewer: <ShieldQuestion className="h-4 w-4" />,
  };
  
  return (
    <div className="space-y-8">
      {baby && (
        <>
          {/* New prominent share code generator button at the top */}
          {isAdmin && (
            <div className="mb-6 flex justify-center">
              <Button 
                size="lg"
                onClick={debugGenerateCode}
                className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white hover:opacity-90 shadow-md w-full px-8 py-6 text-lg font-medium"
              >
                🔄 Generate New Share Code (5-min validity)
              </Button>
            </div>
          )}
          
          <ShareCodeCard 
            babyId={babyId}
            babyName={baby.name}
            shareCode={baby.shareCode}
            isAdmin={isAdmin}
            onRegenerateCode={(babyId, defaultRole) => {
              debugGenerateCode();
            }}
          />
        </>
      )}
      
      {/* Members List */}
      <div className="bg-gradient-to-r from-indigo-500/5 to-purple-500/5 rounded-xl overflow-hidden border border-indigo-100 dark:border-indigo-900/20">
        <div className="px-6 py-5 flex items-center justify-between border-b border-indigo-100 dark:border-indigo-900/20">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-indigo-600" />
            <h3 className="font-medium text-base">Family Access</h3>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-xs text-gray-500 dark:text-gray-400">
              {members?.length || 0} {members?.length === 1 ? 'member' : 'members'}
            </div>
          </div>
        </div>
        
        <div className="px-6 py-2">
          {isLoadingMembers ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-indigo-500" />
            </div>
          ) : members && members.length > 0 ? (
            <div className="divide-y divide-gray-100 dark:divide-gray-800">
              {members.map((member) => {
                const isOwner = baby?.ownerId === member.userId;
                const role = roleDisplay[member.role as keyof typeof roleDisplay] || roleDisplay.viewer;
                
                return (
                  <div key={member.id} className="flex items-center justify-between py-4">
                    <div className="flex items-center">
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center text-white font-medium relative",
                        member.role === "admin" ? "bg-gradient-to-r from-indigo-500 to-purple-600" :
                        member.role === "editor" ? "bg-gradient-to-r from-blue-500 to-cyan-500" :
                        "bg-gradient-to-r from-gray-400 to-gray-500"
                      )}>
                        {member.user?.fullName ? member.user.fullName.split(" ").map(name => name[0]).join("").toUpperCase() : role.abbr}
                        
                        {/* Small role icon */}
                        <div className={cn(
                          "absolute -bottom-1 -right-1 rounded-full w-5 h-5 flex items-center justify-center text-xs",
                          member.role === "admin" ? "bg-indigo-100 text-indigo-700" :
                          member.role === "editor" ? "bg-blue-100 text-blue-700" :
                          "bg-gray-100 text-gray-700"
                        )}>
                          {roleIcons[member.role as keyof typeof roleIcons]}
                        </div>
                      </div>
                      <div className="ml-3">
                        <div className="font-medium">
                          {member.user?.fullName || "Unknown User"}
                          {member.userId === user?.id && " (You)"}
                          {isOwner && (
                            <span className="ml-2 text-xs bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 px-2 py-0.5 rounded-full">
                              Owner
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-gray-500">{member.user?.username}</div>
                      </div>
                    </div>
                    
                    {isAdmin && !isOwner && member.userId !== user?.id && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-gray-600">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 shadow-lg rounded-lg">
                          <DropdownMenuItem
                            onClick={() => updateRoleMutation.mutate({ id: member.id, role: "admin" })}
                            disabled={member.role === "admin"}
                            className="flex items-center gap-2"
                          >
                            <ShieldAlert className="h-4 w-4 text-indigo-600" />
                            <span>Make Admin</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => updateRoleMutation.mutate({ id: member.id, role: "editor" })}
                            disabled={member.role === "editor"}
                            className="flex items-center gap-2"
                          >
                            <ShieldCheck className="h-4 w-4 text-blue-600" />
                            <span>Make Editor</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => updateRoleMutation.mutate({ id: member.id, role: "viewer" })}
                            disabled={member.role === "viewer"}
                            className="flex items-center gap-2"
                          >
                            <ShieldQuestion className="h-4 w-4 text-gray-600" />
                            <span>Make Viewer</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-red-600 flex items-center gap-2"
                            onClick={() => removeMemberMutation.mutate(member.id)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-user-x">
                              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                              <circle cx="9" cy="7" r="4" />
                              <line x1="17" x2="22" y1="8" y2="13" />
                              <line x1="22" x2="17" y1="8" y2="13" />
                            </svg>
                            <span>Remove Access</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Users className="h-10 w-10 text-gray-300 dark:text-gray-700 mb-2" />
              <p className="text-gray-500 dark:text-gray-400">No family members added yet</p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                Share your code to invite family members
              </p>
            </div>
          )}
        </div>
      </div>
      
      {/* Invite Form */}
      {isAdmin && (
        <div className="bg-gradient-to-r from-purple-500/5 to-pink-500/5 rounded-xl overflow-hidden border border-purple-100 dark:border-purple-900/20">
          <div className="px-6 py-5 border-b border-purple-100 dark:border-purple-900/20 flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-purple-600" />
            <h3 className="font-medium text-base">Invite Member</h3>
          </div>
          
          <div className="p-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 dark:text-gray-300">Email Address</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="family@example.com"
                          type="email"
                          className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 dark:text-gray-300">Access Level</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="grid grid-cols-3 gap-3"
                        >
                          {/* Admin Option */}
                          <div className={cn(
                            "relative border rounded-lg p-3 flex flex-col items-center justify-center cursor-pointer transition-all",
                            field.value === "admin" 
                              ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/30" 
                              : "border-gray-200 dark:border-gray-800 hover:border-indigo-200 dark:hover:border-indigo-900/50"
                          )}>
                            <RadioGroupItem
                              value="admin"
                              id="role-admin"
                              className="sr-only"
                            />
                            <label
                              htmlFor="role-admin"
                              className="flex flex-col items-center cursor-pointer w-full text-center"
                            >
                              <div className="mb-2 p-2 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400">
                                <ShieldAlert className="h-5 w-5" />
                              </div>
                              <span className="text-sm font-medium">Admin</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">Full access</span>
                            </label>
                            {field.value === "admin" && (
                              <div className="absolute top-2 right-2 text-indigo-600">
                                <CheckCircle2 className="h-4 w-4" />
                              </div>
                            )}
                          </div>
                          
                          {/* Editor Option */}
                          <div className={cn(
                            "relative border rounded-lg p-3 flex flex-col items-center justify-center cursor-pointer transition-all",
                            field.value === "editor" 
                              ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30" 
                              : "border-gray-200 dark:border-gray-800 hover:border-blue-200 dark:hover:border-blue-900/50"
                          )}>
                            <RadioGroupItem
                              value="editor"
                              id="role-editor"
                              className="sr-only"
                            />
                            <label
                              htmlFor="role-editor"
                              className="flex flex-col items-center cursor-pointer w-full text-center"
                            >
                              <div className="mb-2 p-2 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
                                <ShieldCheck className="h-5 w-5" />
                              </div>
                              <span className="text-sm font-medium">Editor</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">Can edit</span>
                            </label>
                            {field.value === "editor" && (
                              <div className="absolute top-2 right-2 text-blue-600">
                                <CheckCircle2 className="h-4 w-4" />
                              </div>
                            )}
                          </div>
                          
                          {/* Viewer Option */}
                          <div className={cn(
                            "relative border rounded-lg p-3 flex flex-col items-center justify-center cursor-pointer transition-all",
                            field.value === "viewer" 
                              ? "border-gray-400 bg-gray-50 dark:bg-gray-800/50" 
                              : "border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700"
                          )}>
                            <RadioGroupItem
                              value="viewer"
                              id="role-viewer"
                              className="sr-only"
                            />
                            <label
                              htmlFor="role-viewer"
                              className="flex flex-col items-center cursor-pointer w-full text-center"
                            >
                              <div className="mb-2 p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">
                                <ShieldQuestion className="h-5 w-5" />
                              </div>
                              <span className="text-sm font-medium">Viewer</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">Read only</span>
                            </label>
                            {field.value === "viewer" && (
                              <div className="absolute top-2 right-2 text-gray-600">
                                <CheckCircle2 className="h-4 w-4" />
                              </div>
                            )}
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium"
                  disabled={inviteMutation.isPending}
                >
                  {inviteMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <UserPlus className="mr-2 h-4 w-4" />
                  )}
                  Send Invitation
                </Button>
              </form>
            </Form>
          </div>
        </div>
      )}
      
      {/* Permission Explanation */}
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-900 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-800">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-800">
          <h3 className="font-medium text-sm text-gray-700 dark:text-gray-300">Access Levels</h3>
        </div>
        
        <div className="p-6 text-sm text-gray-600 dark:text-gray-400 space-y-4">
          <div className="flex items-start gap-3">
            <div className="bg-indigo-100 dark:bg-indigo-900/30 p-2 rounded-full text-indigo-600 dark:text-indigo-400">
              <ShieldAlert className="h-5 w-5" />
            </div>
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Admin</p>
              <p className="mt-1">Full access to manage family members, change permissions, and edit all data</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-full text-blue-600 dark:text-blue-400">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Editor</p>
              <p className="mt-1">Can add, edit, and delete tracking entries, but cannot manage users</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full text-gray-600 dark:text-gray-400">
              <ShieldQuestion className="h-5 w-5" />
            </div>
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Viewer</p>
              <p className="mt-1">Read-only access to view tracking data without making any changes</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
