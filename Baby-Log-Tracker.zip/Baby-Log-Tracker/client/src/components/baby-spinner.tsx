import React from "react";
import { cn } from "@/lib/utils";

type BabySpinnerProps = {
  type?: "rattle" | "bottle" | "diaper" | "cradle";
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  showText?: boolean;
};

export function BabySpinner({ 
  type = "rattle", 
  size = "md",
  className = "",
  showText = true
}: BabySpinnerProps) {
  const sizeClasses = {
    sm: "w-5 h-5",
    md: "w-8 h-8",
    lg: "w-12 h-12",
    xl: "w-20 h-20",
  };

  const getSize = () => sizeClasses[size];
  
  const renderSpinnerContent = () => {
    switch (type) {
      case "bottle":
        return (
          <div className="relative flex items-center justify-center">
            <svg 
              viewBox="0 0 24 24" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className={cn("animate-wiggle", getSize())}
            >
              <path 
                d="M12 16C15.866 16 19 12.866 19 9C19 5.134 15.866 2 12 2C8.13401 2 5 5.134 5 9C5 12.866 8.13401 16 12 16Z" 
                fill="#DBEAFE" 
                className="animate-pulse"
              />
              <path 
                d="M10 9c0-1.1.9-2 2-2s2 .9 2 2-.9 2-2 2-2-.9-2-2z"
                fill="#93C5FD"
              />
              <path 
                d="M14 19.338C14 20.164 13.105 21 12 21C10.895 21 10 20.164 10 19.338C10 18.513 11.079 18 12 18C12.921 18 14 18.513 14 19.338Z" 
                fill="#3B82F6"
              />
              <path 
                d="M14.777 9.5C14.777 10.2797 14.497 11.0387 13.9829 11.6383C13.4688 12.2379 12.7535 12.6494 11.9671 12.7826C11.1807 12.9159 10.3735 12.7632 9.68543 12.3492C8.99735 11.9352 8.47519 11.2856 8.21422 10.5225C7.95326 9.75943 7.9692 8.9297 8.25956 8.17593C8.54992 7.42216 9.09529 6.79339 9.79892 6.41084C10.5026 6.02828 11.3228 5.91463 12.1015 6.09003C12.8802 6.26544 13.5739 6.71969 14.0613 7.37511"
                stroke="#1E40AF" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M12 16L12 18" 
                stroke="#1E40AF" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M16 4L15.5 3.5" 
                stroke="#1E40AF" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M8 4L8.5 3.5" 
                stroke="#1E40AF" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
            </svg>
          </div>
        );
      
      case "diaper":
        return (
          <div className="relative flex items-center justify-center">
            <svg 
              viewBox="0 0 24 24" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className={cn("animate-bounce", getSize())}
            >
              <path 
                d="M4 10C4 8.89543 4.89543 8 6 8H18C19.1046 8 20 8.89543 20 10V18C20 19.1046 19.1046 20 18 20H6C4.89543 20 4 19.1046 4 18V10Z" 
                fill="#E0E7FF"
                className="animate-pulse"
              />
              <path 
                d="M8 8V6C8 4.89543 8.89543 4 10 4H14C15.1046 4 16 4.89543 16 6V8" 
                stroke="#4F46E5" 
                strokeWidth="1.5"
              />
              <path 
                d="M8 15H16" 
                stroke="#4F46E5" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M8 12H16" 
                stroke="#4F46E5" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M8 18H16" 
                stroke="#4F46E5" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
            </svg>
          </div>
        );
      
      case "cradle":
        return (
          <div className="relative flex items-center justify-center">
            <svg 
              viewBox="0 0 24 24" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className={cn("animate-rock", getSize())}
            >
              <path 
                d="M6 19C6 19 6 14 12 14C18 14 18 19 18 19" 
                stroke="#EC4899" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M4 19H20" 
                stroke="#EC4899" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M12 14C14.2091 14 16 12.2091 16 10C16 7.79086 14.2091 6 12 6C9.79086 6 8 7.79086 8 10C8 12.2091 9.79086 14 12 14Z" 
                fill="#FCE7F3"
                className="animate-pulse"
              />
              <path 
                d="M12 6C12 6 13 8 13 10C13 12 12 14 12 14C12 14 11 12 11 10C11 8 12 6 12 6Z" 
                stroke="#EC4899" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <path 
                d="M8 10H16" 
                stroke="#EC4899" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
            </svg>
          </div>
        );
      
      default: // rattle
        return (
          <div className="relative flex items-center justify-center">
            <svg 
              viewBox="0 0 24 24" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className={cn("animate-shake", getSize())}
            >
              <circle 
                cx="10" 
                cy="10" 
                r="6" 
                fill="#DBEAFE" 
                className="animate-pulse"
              />
              <circle 
                cx="10" 
                cy="10" 
                r="4" 
                fill="#93C5FD"
              />
              <circle 
                cx="10" 
                cy="10" 
                r="3" 
                stroke="#1D4ED8" 
                strokeWidth="1.5"
              />
              <path 
                d="M14 14L19 19" 
                stroke="#1D4ED8" 
                strokeWidth="1.5" 
                strokeLinecap="round"
              />
              <circle 
                cx="19" 
                cy="19" 
                r="2" 
                fill="#93C5FD" 
                stroke="#1D4ED8" 
                strokeWidth="1.5"
              />
              <circle 
                cx="7" 
                cy="10" 
                r="1" 
                fill="#1D4ED8"
              />
              <circle 
                cx="10" 
                cy="7" 
                r="1" 
                fill="#1D4ED8"
              />
              <circle 
                cx="13" 
                cy="10" 
                r="1" 
                fill="#1D4ED8"
              />
              <circle 
                cx="10" 
                cy="13" 
                r="1" 
                fill="#1D4ED8"
              />
            </svg>
          </div>
        );
    }
  };

  const loadingText = {
    rattle: "Shaking things up...",
    bottle: "Preparing formula...",
    diaper: "Changing diaper...",
    cradle: "Rocking baby...",
  };

  return (
    <div className={cn("flex flex-col items-center justify-center", className)}>
      {renderSpinnerContent()}
      {showText && (
        <p className="mt-3 text-sm font-medium text-gray-600 animate-pulse">
          {loadingText[type]}
        </p>
      )}
    </div>
  );
}