// This file contains the selector for choosing between multiple baby profiles
// It supports both simple and detailed views

import { format } from "date-fns";
import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Baby } from "@shared/schema";

interface BabySelectorProps {
  selectedBaby: number | null;
  onSelectBaby: (babyId: number) => void;
  showDetails?: boolean;
  showQuickNav?: boolean;
  className?: string;
}

export function BabySelector({
  selectedBaby,
  onSelectBaby,
  showDetails = false,
  showQuickNav = false,
  className = "",
}: BabySelectorProps) {
  const { data: babies, isLoading } = useQuery<Baby[]>({
    queryKey: ["/api/babies"],
  });

  // If babies not loaded or no babies exist
  if (isLoading || !babies || babies.length === 0) {
    return null;
  }
  
  // Get selected baby data
  const selectedBabyData = babies.find(b => b.id === selectedBaby);
  if (!selectedBabyData) return null;
  
  // Calculate baby's age
  const calculateAge = (dateOfBirth: string | null) => {
    if (!dateOfBirth) return null;
    
    try {
      const birthDate = new Date(dateOfBirth);
      const now = new Date();
      
      // Calculate difference in milliseconds
      const diffTime = Math.abs(now.getTime() - birthDate.getTime());
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays < 30) {
        return `${diffDays} day${diffDays > 1 ? 's' : ''}`;
      } else if (diffDays < 365) {
        const months = Math.floor(diffDays / 30);
        return `${months} month${months > 1 ? 's' : ''}`;
      } else {
        const years = Math.floor(diffDays / 365);
        const remainingMonths = Math.floor((diffDays % 365) / 30);
        return `${years}y ${remainingMonths > 0 ? `${remainingMonths}m` : ''}`;
      }
    } catch (e) {
      console.error("Error calculating age:", e);
      return null;
    }
  };

  const age = calculateAge(selectedBabyData.dateOfBirth);

  // Simple mini-dashboard for quick switching and basic info
  if (!showDetails) {
    return (
      <div className={`${className} w-full`}>
        <div className="flex items-center bg-card/50 p-2 rounded-md border border-border/40 shadow-sm">
          <div className="flex-shrink-0 mr-3">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              {selectedBabyData.gender === 'male' ? (
                <span className="text-blue-500 text-xl">♂</span>
              ) : selectedBabyData.gender === 'female' ? (
                <span className="text-pink-500 text-xl">♀</span>
              ) : (
                <span className="text-purple-500 text-xl">⚥</span>
              )}
            </div>
          </div>
          
          <div className="min-w-0 flex-1">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-semibold max-w-[200px] truncate bg-gradient-to-r from-primary to-blue-400 text-transparent bg-clip-text mr-2">
                {selectedBabyData.name}
              </h3>

              <Select
                value={selectedBaby?.toString()}
                onValueChange={(value) => onSelectBaby(parseInt(value))}
              >
                <SelectTrigger className="h-7 text-xs px-2 w-[80px] ml-auto border-0 bg-transparent hover:bg-accent focus:ring-0">
                  <span className="text-xs text-muted-foreground">Switch</span>
                </SelectTrigger>
                <SelectContent>
                  {babies.map((baby) => (
                    <SelectItem key={baby.id} value={baby.id.toString()}>
                      {baby.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex gap-x-3 text-[10px] text-muted-foreground">
              {selectedBabyData.dateOfBirth && (
                <div className="flex items-center">
                  <span>{format(new Date(selectedBabyData.dateOfBirth), "MMM dd, yyyy")}</span>
                </div>
              )}
              
              {age && (
                <div className="flex items-center">
                  <span>Age: {age}</span>
                </div>
              )}
              
              {selectedBabyData.weight && (
                <div className="flex items-center">
                  <span>Weight: {selectedBabyData.weight}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Detailed card with baby info
  return (
    <Card className={`${className}`}>
      <CardContent className="pt-4 pb-2">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">Baby Profile</h3>

          <div className="flex items-center">
            {showQuickNav && (
              <Select
                value={selectedBaby?.toString()}
                onValueChange={(value) => onSelectBaby(parseInt(value))}
              >
                <SelectTrigger className="w-[140px] h-8 mx-1">
                  <SelectValue placeholder="Select Baby" />
                </SelectTrigger>
                <SelectContent>
                  {babies.map((baby) => (
                    <SelectItem key={baby.id} value={baby.id.toString()}>
                      {baby.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {!showQuickNav && (
              <Select
                value={selectedBaby?.toString()}
                onValueChange={(value) => onSelectBaby(parseInt(value))}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Select Baby" />
                </SelectTrigger>
                <SelectContent>
                  {babies.map((baby) => (
                    <SelectItem key={baby.id} value={baby.id.toString()}>
                      {baby.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        </div>

        <div className="flex items-start md:items-center flex-col md:flex-row">
          <div className="rounded-full bg-primary/10 p-3 mr-3">
            {selectedBabyData.gender === 'male' ? (
              <span className="text-blue-500 text-2xl">♂</span>
            ) : selectedBabyData.gender === 'female' ? (
              <span className="text-pink-500 text-2xl">♀</span>
            ) : (
              <span className="text-purple-500 text-2xl">⚥</span>
            )}
          </div>

          <div className="flex-1">
            <h3 className="text-xl font-bold bg-gradient-to-r from-primary to-blue-400 text-transparent bg-clip-text">
              {selectedBabyData.name}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-4 gap-y-1 mt-1">
              {selectedBabyData.dateOfBirth && (
                <div className="flex items-center">
                  <Heart className="h-3 w-3 text-muted-foreground mr-1" />
                  <span className="text-xs text-muted-foreground mr-1">Born:</span> 
                  <span className="text-xs font-medium">{format(new Date(selectedBabyData.dateOfBirth), "MMM dd, yyyy")}</span>
                </div>
              )}

              {age && (
                <div className="flex items-center">
                  <span className="text-xs text-muted-foreground mr-1">Age:</span> 
                  <span className="text-xs font-medium">{age}</span>
                </div>
              )}

              {selectedBabyData.weight && (
                <div className="flex items-center">
                  <span className="text-xs text-muted-foreground mr-1">Weight:</span> 
                  <span className="text-xs font-medium">{selectedBabyData.weight}</span>
                </div>
              )}

              {selectedBabyData.width && (
                <div className="flex items-center">
                  <span className="text-xs text-muted-foreground mr-1">Width:</span> 
                  <span className="text-xs font-medium">{selectedBabyData.width}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}