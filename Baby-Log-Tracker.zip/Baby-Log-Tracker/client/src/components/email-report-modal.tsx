import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { X } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface EmailReportModalProps {
  open: boolean;
  onClose: () => void;
  babyId: number;
  dateRange: {
    startDate: string;
    endDate: string;
  }
}

// Form validation schema
const formSchema = z.object({
  recipientEmail: z.string().email({ message: "Please enter a valid email address" }),
  senderName: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function EmailReportModal({ open, onClose, babyId, dateRange }: EmailReportModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  // Format date range for display
  const formattedStartDate = format(new Date(dateRange.startDate), "MMM d, yyyy");
  const formattedEndDate = format(new Date(dateRange.endDate), "MMM d, yyyy");
  
  // Define form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      recipientEmail: "",
      senderName: "",
    },
  });
  
  const onSubmit = async (values: FormValues) => {
    setIsSubmitting(true);
    
    try {
      // Show an alternate option with a PDF if the email doesn't work
      const response = await apiRequest("POST", `/api/babies/${babyId}/email-report`, {
        ...values,
        startDate: dateRange.startDate,
        endDate: dateRange.endDate,
      });
      
      if (response.ok) {
        toast({
          title: "Report Sent",
          description: "The baby activity report has been sent successfully.",
          variant: "default",
        });
        onClose();
      } else {
        // If email sending fails, suggest PDF as an alternative
        const errorData = await response.json();
        toast({
          title: "Email Service Unavailable",
          description: "Unable to send email at this time. Try using the PDF export option instead.",
          variant: "destructive",
        });
        
        // Add a small delay then close the modal
        setTimeout(() => {
          onClose();
          // Show a second toast with more specific instructions
          toast({
            title: "Try PDF Export",
            description: "Click the 'Export PDF' button to download a report you can share manually.",
            duration: 5000,
          });
        }, 1500);
      }
    } catch (error) {
      console.error("Email error:", error);
      toast({
        title: "Email Service Unavailable",
        description: "Unable to send emails at this time. Please use the PDF export option instead.",
        variant: "destructive",
      });
      
      // Close the modal after a short delay
      setTimeout(onClose, 2000);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Email Baby Report</DialogTitle>
          <DialogDescription>
            Send a detailed baby activity report covering {formattedStartDate} to {formattedEndDate}.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="recipientEmail"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recipient Email</FormLabel>
                  <FormControl>
                    <Input placeholder="doctor@example.com" {...field} />
                  </FormControl>
                  <FormDescription>
                    Email address of the person who should receive this report.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="senderName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Name (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Your name" {...field} />
                  </FormControl>
                  <FormDescription>
                    Your name will be included as the sender of this report.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Sending..." : "Send Report"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}