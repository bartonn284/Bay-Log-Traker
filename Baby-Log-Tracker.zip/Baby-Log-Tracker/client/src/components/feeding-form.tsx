import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";

const feedingSchema = z.object({
  type: z.enum(["breast", "bottle", "formula", "solids"]),
  amount: z.string().optional(),
  side: z.enum(["left", "right", "both"]).optional(),
  startTime: z.string(),
  duration: z.string().optional(),
  mood: z.enum(["happy", "calm", "fussy", "crying", "hungry"]).optional(),
  notes: z.string().optional(),
});

type FeedingFormValues = z.infer<typeof feedingSchema>;

type FeedingFormProps = {
  babyId: number;
  onBack: () => void;
  onSuccess: () => void;
};

export function FeedingForm({ babyId, onBack, onSuccess }: FeedingFormProps) {
  const [showSide, setShowSide] = useState(true); // Set to true initially since default type is "breast"
  
  const form = useForm<FeedingFormValues>({
    resolver: zodResolver(feedingSchema),
    defaultValues: {
      type: "breast",
      amount: "",
      side: "both",
      startTime: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      duration: "",
      mood: "calm",
      notes: "",
    },
  });
  
  const feedingMutation = useMutation({
    mutationFn: async (data: FeedingFormValues) => {
      const duration = data.duration ? parseInt(data.duration) : null;
      
      const payload = {
        type: data.type,
        amount: data.amount || null,
        side: data.type === "breast" ? data.side : null,
        startTime: new Date(data.startTime).toISOString(),
        duration,
        mood: data.mood || null,
        notes: data.notes || null,
      };
      
      const res = await apiRequest("POST", `/api/babies/${babyId}/feedings`, payload);
      return await res.json();
    },
    onSuccess: () => {
      onSuccess();
    },
  });
  
  const onSubmit = (data: FeedingFormValues) => {
    feedingMutation.mutate(data);
  };
  
  // Show side selection only for breastfeeding
  const watchType = form.watch("type");
  
  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Button
          variant="ghost"
          size="icon"
          className="mr-2 p-1 rounded-full hover:bg-neutral-100"
          onClick={onBack}
        >
          <ChevronLeft className="h-6 w-6 text-neutral-700" />
        </Button>
        <h2 className="text-xl font-semibold text-[#5B9BD5]">Record Feeding</h2>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Feeding Type</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={(value) => {
                      field.onChange(value);
                      setShowSide(value === "breast");
                    }}
                    defaultValue={field.value}
                    className="grid grid-cols-2 gap-3"
                  >
                    <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                      field.value === "breast"
                        ? "border-[#5B9BD5] bg-[#5B9BD5] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="breast"
                        id="breast"
                        className="sr-only"
                      />
                      <label
                        htmlFor="breast"
                        className="flex items-center cursor-pointer w-full"
                      >
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                          field.value === "breast"
                            ? "border-[#5B9BD5] bg-white"
                            : "border-neutral-300"
                        }`}>
                          {field.value === "breast" && (
                            <div className="w-3 h-3 rounded-full bg-[#5B9BD5]"></div>
                          )}
                        </div>
                        <span className="font-medium">Breastfeeding</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                      field.value === "bottle"
                        ? "border-[#5B9BD5] bg-[#5B9BD5] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="bottle"
                        id="bottle"
                        className="sr-only"
                      />
                      <label
                        htmlFor="bottle"
                        className="flex items-center cursor-pointer w-full"
                      >
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                          field.value === "bottle"
                            ? "border-[#5B9BD5] bg-white"
                            : "border-neutral-300"
                        }`}>
                          {field.value === "bottle" && (
                            <div className="w-3 h-3 rounded-full bg-[#5B9BD5]"></div>
                          )}
                        </div>
                        <span className="font-medium">Bottle</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                      field.value === "formula"
                        ? "border-[#5B9BD5] bg-[#5B9BD5] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="formula"
                        id="formula"
                        className="sr-only"
                      />
                      <label
                        htmlFor="formula"
                        className="flex items-center cursor-pointer w-full"
                      >
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                          field.value === "formula"
                            ? "border-[#5B9BD5] bg-white"
                            : "border-neutral-300"
                        }`}>
                          {field.value === "formula" && (
                            <div className="w-3 h-3 rounded-full bg-[#5B9BD5]"></div>
                          )}
                        </div>
                        <span className="font-medium">Formula</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                      field.value === "solids"
                        ? "border-[#5B9BD5] bg-[#5B9BD5] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="solids"
                        id="solids"
                        className="sr-only"
                      />
                      <label
                        htmlFor="solids"
                        className="flex items-center cursor-pointer w-full"
                      >
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                          field.value === "solids"
                            ? "border-[#5B9BD5] bg-white"
                            : "border-neutral-300"
                        }`}>
                          {field.value === "solids" && (
                            <div className="w-3 h-3 rounded-full bg-[#5B9BD5]"></div>
                          )}
                        </div>
                        <span className="font-medium">Solids</span>
                      </label>
                    </div>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        className="pr-12"
                        placeholder="0"
                        type="number"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        <span className="text-neutral-500">oz</span>
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="duration"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Duration</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        className="pr-12"
                        placeholder="0"
                        type="number"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        <span className="text-neutral-500">min</span>
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          {showSide && (
            <FormField
              control={form.control}
              name="side"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Side (for breastfeeding)</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="grid grid-cols-3 gap-3"
                    >
                      <div className={`border rounded-lg p-3 flex items-center justify-center cursor-pointer ${
                        field.value === "left"
                          ? "border-[#5B9BD5] bg-[#5B9BD5] bg-opacity-10"
                          : "border-neutral-200"
                      }`}>
                        <RadioGroupItem
                          value="left"
                          id="left"
                          className="sr-only"
                        />
                        <label
                          htmlFor="left"
                          className="font-medium cursor-pointer w-full text-center"
                        >
                          Left
                        </label>
                      </div>
                      
                      <div className={`border rounded-lg p-3 flex items-center justify-center cursor-pointer ${
                        field.value === "right"
                          ? "border-[#5B9BD5] bg-[#5B9BD5] bg-opacity-10"
                          : "border-neutral-200"
                      }`}>
                        <RadioGroupItem
                          value="right"
                          id="right"
                          className="sr-only"
                        />
                        <label
                          htmlFor="right"
                          className="font-medium cursor-pointer w-full text-center"
                        >
                          Right
                        </label>
                      </div>
                      
                      <div className={`border rounded-lg p-3 flex items-center justify-center cursor-pointer ${
                        field.value === "both"
                          ? "border-[#5B9BD5] bg-[#5B9BD5] bg-opacity-10"
                          : "border-neutral-200"
                      }`}>
                        <RadioGroupItem
                          value="both"
                          id="both"
                          className="sr-only"
                        />
                        <label
                          htmlFor="both"
                          className="font-medium cursor-pointer w-full text-center"
                        >
                          Both
                        </label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          <FormField
            control={form.control}
            name="startTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Time</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="datetime-local"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="mood"
            render={({ field }) => (
              <FormItem className="mb-4">
                <FormLabel>Baby's Mood</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="grid grid-cols-5 gap-2"
                  >
                    <div className={`border rounded-lg p-2 flex flex-col items-center cursor-pointer ${
                      field.value === "happy"
                        ? "border-green-500 bg-green-50 dark:bg-green-900/20"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="happy"
                        id="mood-happy"
                        className="sr-only"
                      />
                      <label
                        htmlFor="mood-happy"
                        className="flex flex-col items-center cursor-pointer w-full"
                      >
                        <div className="text-2xl mb-1">😀</div>
                        <span className="text-xs">Happy</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-2 flex flex-col items-center cursor-pointer ${
                      field.value === "calm"
                        ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="calm"
                        id="mood-calm"
                        className="sr-only"
                      />
                      <label
                        htmlFor="mood-calm"
                        className="flex flex-col items-center cursor-pointer w-full"
                      >
                        <div className="text-2xl mb-1">😌</div>
                        <span className="text-xs">Calm</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-2 flex flex-col items-center cursor-pointer ${
                      field.value === "fussy"
                        ? "border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="fussy"
                        id="mood-fussy"
                        className="sr-only"
                      />
                      <label
                        htmlFor="mood-fussy"
                        className="flex flex-col items-center cursor-pointer w-full"
                      >
                        <div className="text-2xl mb-1">😕</div>
                        <span className="text-xs">Fussy</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-2 flex flex-col items-center cursor-pointer ${
                      field.value === "crying"
                        ? "border-red-500 bg-red-50 dark:bg-red-900/20"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="crying"
                        id="mood-crying"
                        className="sr-only"
                      />
                      <label
                        htmlFor="mood-crying"
                        className="flex flex-col items-center cursor-pointer w-full"
                      >
                        <div className="text-2xl mb-1">😢</div>
                        <span className="text-xs">Crying</span>
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-2 flex flex-col items-center cursor-pointer ${
                      field.value === "hungry"
                        ? "border-orange-500 bg-orange-50 dark:bg-orange-900/20"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="hungry"
                        id="mood-hungry"
                        className="sr-only"
                      />
                      <label
                        htmlFor="mood-hungry"
                        className="flex flex-col items-center cursor-pointer w-full"
                      >
                        <div className="text-2xl mb-1">🍼</div>
                        <span className="text-xs">Hungry</span>
                      </label>
                    </div>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    placeholder="Add any additional notes"
                    rows={3}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button
            type="submit"
            className="w-full bg-[#5B9BD5] text-white font-semibold py-3 px-4"
            disabled={feedingMutation.isPending}
          >
            {feedingMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            Save Feeding
          </Button>
        </form>
      </Form>
    </div>
  );
}
