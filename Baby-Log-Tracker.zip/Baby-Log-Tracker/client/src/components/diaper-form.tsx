import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";

const diaperSchema = z.object({
  type: z.enum(["wet", "dirty", "both"]),
  consistency: z.enum(["normal", "hard", "runny"]).optional(),
  color: z.string().optional(),
  time: z.string(),
  notes: z.string().optional(),
});

type DiaperFormValues = z.infer<typeof diaperSchema>;

type DiaperFormProps = {
  babyId: number;
  onBack: () => void;
  onSuccess: () => void;
};

const diaper_colors = [
  { value: "yellow-600", display: "Dark Yellow", style: "bg-yellow-600" },
  { value: "yellow-300", display: "Light Yellow", style: "bg-yellow-300" },
  { value: "green-800", display: "Dark Green", style: "bg-green-800" },
  { value: "green-600", display: "Green", style: "bg-green-600" },
  { value: "amber-800", display: "Brown", style: "bg-amber-800" },
  { value: "red-700", display: "Red", style: "bg-red-700" },
  { value: "black", display: "Black", style: "bg-black" },
];

export function DiaperForm({ babyId, onBack, onSuccess }: DiaperFormProps) {
  const form = useForm<DiaperFormValues>({
    resolver: zodResolver(diaperSchema),
    defaultValues: {
      type: "both",
      consistency: "normal",
      color: "yellow-600", // default color
      time: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      notes: "",
    },
  });
  
  const watchType = form.watch("type");
  const showDirtyOptions = watchType === "dirty" || watchType === "both";
  
  const diaperMutation = useMutation({
    mutationFn: async (data: DiaperFormValues) => {
      const payload = {
        type: data.type,
        consistency: showDirtyOptions ? data.consistency : null,
        color: showDirtyOptions ? data.color : null,
        time: new Date(data.time).toISOString(),
        notes: data.notes || null,
      };
      
      const res = await apiRequest("POST", `/api/babies/${babyId}/diapers`, payload);
      return await res.json();
    },
    onSuccess: () => {
      onSuccess();
    },
  });
  
  const onSubmit = (data: DiaperFormValues) => {
    diaperMutation.mutate(data);
  };
  
  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Button
          variant="ghost"
          size="icon"
          className="mr-2 p-1 rounded-full hover:bg-neutral-100"
          onClick={onBack}
        >
          <ChevronLeft className="h-6 w-6 text-neutral-700" />
        </Button>
        <h2 className="text-xl font-semibold text-[#F6A192]">Record Diaper Change</h2>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Diaper Type</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="grid grid-cols-3 gap-3"
                  >
                    <div className={`border rounded-lg p-3 flex items-center justify-center cursor-pointer ${
                      field.value === "wet"
                        ? "border-[#F6A192] bg-[#F6A192] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="wet"
                        id="wet"
                        className="sr-only"
                      />
                      <label
                        htmlFor="wet"
                        className="font-medium cursor-pointer w-full text-center"
                      >
                        Wet Only
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-3 flex items-center justify-center cursor-pointer ${
                      field.value === "dirty"
                        ? "border-[#F6A192] bg-[#F6A192] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="dirty"
                        id="dirty"
                        className="sr-only"
                      />
                      <label
                        htmlFor="dirty"
                        className="font-medium cursor-pointer w-full text-center"
                      >
                        Dirty Only
                      </label>
                    </div>
                    
                    <div className={`border rounded-lg p-3 flex items-center justify-center cursor-pointer ${
                      field.value === "both"
                        ? "border-[#F6A192] bg-[#F6A192] bg-opacity-10"
                        : "border-neutral-200"
                    }`}>
                      <RadioGroupItem
                        value="both"
                        id="both"
                        className="sr-only"
                      />
                      <label
                        htmlFor="both"
                        className="font-medium cursor-pointer w-full text-center"
                      >
                        Both
                      </label>
                    </div>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {showDirtyOptions && (
            <FormField
              control={form.control}
              name="consistency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Consistency (if dirty)</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="grid grid-cols-3 gap-3"
                    >
                      <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                        field.value === "normal"
                          ? "border-[#F6A192] bg-[#F6A192] bg-opacity-10"
                          : "border-neutral-200"
                      }`}>
                        <RadioGroupItem
                          value="normal"
                          id="normal"
                          className="sr-only"
                        />
                        <label
                          htmlFor="normal"
                          className="flex items-center cursor-pointer w-full"
                        >
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                            field.value === "normal"
                              ? "border-[#F6A192] bg-white"
                              : "border-neutral-300"
                          }`}>
                            {field.value === "normal" && (
                              <div className="w-3 h-3 rounded-full bg-[#F6A192]"></div>
                            )}
                          </div>
                          <span className="font-medium">Normal</span>
                        </label>
                      </div>
                      
                      <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                        field.value === "hard"
                          ? "border-[#F6A192] bg-[#F6A192] bg-opacity-10"
                          : "border-neutral-200"
                      }`}>
                        <RadioGroupItem
                          value="hard"
                          id="hard"
                          className="sr-only"
                        />
                        <label
                          htmlFor="hard"
                          className="flex items-center cursor-pointer w-full"
                        >
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                            field.value === "hard"
                              ? "border-[#F6A192] bg-white"
                              : "border-neutral-300"
                          }`}>
                            {field.value === "hard" && (
                              <div className="w-3 h-3 rounded-full bg-[#F6A192]"></div>
                            )}
                          </div>
                          <span className="font-medium">Hard</span>
                        </label>
                      </div>
                      
                      <div className={`border rounded-lg p-3 flex items-center cursor-pointer ${
                        field.value === "runny"
                          ? "border-[#F6A192] bg-[#F6A192] bg-opacity-10"
                          : "border-neutral-200"
                      }`}>
                        <RadioGroupItem
                          value="runny"
                          id="runny"
                          className="sr-only"
                        />
                        <label
                          htmlFor="runny"
                          className="flex items-center cursor-pointer w-full"
                        >
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-2 ${
                            field.value === "runny"
                              ? "border-[#F6A192] bg-white"
                              : "border-neutral-300"
                          }`}>
                            {field.value === "runny" && (
                              <div className="w-3 h-3 rounded-full bg-[#F6A192]"></div>
                            )}
                          </div>
                          <span className="font-medium">Runny</span>
                        </label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          {showDirtyOptions && (
            <FormField
              control={form.control}
              name="color"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Color (if dirty)</FormLabel>
                  <FormControl>
                    <div className="grid grid-cols-4 gap-2">
                      {diaper_colors.map((color) => (
                        <div
                          key={color.value}
                          onClick={() => field.onChange(color.value)}
                          className={`w-12 h-12 rounded-lg ${color.style} cursor-pointer border-2 ${
                            field.value === color.value ? "border-[#F6A192]" : "border-white"
                          } shadow-sm`}
                          title={color.display}
                        ></div>
                      ))}
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          <FormField
            control={form.control}
            name="time"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Time</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="datetime-local"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    placeholder="Add any additional notes"
                    rows={3}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button
            type="submit"
            className="w-full bg-[#F6A192] text-white font-semibold py-3 px-4"
            disabled={diaperMutation.isPending}
          >
            {diaperMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            Save Diaper Change
          </Button>
        </form>
      </Form>
    </div>
  );
}
