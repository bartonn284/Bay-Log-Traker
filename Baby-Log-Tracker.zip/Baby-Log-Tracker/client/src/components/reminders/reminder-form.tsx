import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useBabyContext } from "@/hooks/use-baby-context";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { CalendarIcon, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

// Form schema
const reminderFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  type: z.enum(["feeding", "sleep", "medication"], {
    required_error: "Please select a reminder type",
  }),
  startDate: z.date({
    required_error: "Start date is required",
  }),
  endDate: z.date().optional(),
  time: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, "Time must be in 24-hour format (HH:MM)"),
  daysOfWeek: z.string().optional(),
  recurringType: z.enum(["daily", "weekly", "custom"], {
    required_error: "Please select a recurring type",
  }),
  notificationSound: z.string().optional(),
  notes: z.string().optional(),
  enabled: z.boolean().default(true),
});

type ReminderFormValues = z.infer<typeof reminderFormSchema>;

// Default values
const defaultReminderValues: Partial<ReminderFormValues> = {
  title: "",
  type: "feeding",
  startDate: new Date(),
  time: "08:00",
  recurringType: "daily",
  enabled: true,
  notes: "",
};

type ReminderFormProps = {
  onSuccess?: () => void;
  onCancel?: () => void;
  defaultValues?: Partial<ReminderFormValues>;
};

export function ReminderForm({ onSuccess, onCancel, defaultValues = defaultReminderValues }: ReminderFormProps) {
  const { selectedBaby } = useBabyContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showStartDateCalendar, setShowStartDateCalendar] = useState(false);
  const [showEndDateCalendar, setShowEndDateCalendar] = useState(false);
  const [showDaysSelector, setShowDaysSelector] = useState(defaultValues.recurringType === "custom");

  // Initialize the form with default values
  const form = useForm<ReminderFormValues>({
    resolver: zodResolver(reminderFormSchema),
    defaultValues,
  });

  // Toggle days selector visibility when recurring type changes
  const watchRecurringType = form.watch("recurringType");
  if (watchRecurringType === "custom" && !showDaysSelector) {
    setShowDaysSelector(true);
  } else if (watchRecurringType !== "custom" && showDaysSelector) {
    setShowDaysSelector(false);
  }

  // Days of the week checkboxes
  const daysOfWeek = [
    { value: "0", label: "Sun" },
    { value: "1", label: "Mon" },
    { value: "2", label: "Tue" },
    { value: "3", label: "Wed" },
    { value: "4", label: "Thu" },
    { value: "5", label: "Fri" },
    { value: "6", label: "Sat" },
  ];

  // Create mutation function
  const createReminderMutation = useMutation({
    mutationFn: async (values: ReminderFormValues) => {
      if (!selectedBaby) {
        throw new Error("No baby selected");
      }

      // Add missing fields for complete reminder
      const message = `Reminder: ${values.title}`;

      // Ensure dates are properly formatted as Date objects
      const formattedValues = {
        ...values,
        // Required fields with sensible defaults
        title: values.title || "Reminder",
        type: values.type || "feeding",
        startDate: values.startDate ? new Date(values.startDate) : new Date(),
        endDate: values.endDate ? new Date(values.endDate) : null,
        time: values.time || "08:00",
        recurringType: values.recurringType || "daily",
        enabled: values.enabled !== undefined ? values.enabled : true,
        // Optional fields with defaults
        daysOfWeek: values.daysOfWeek || null,
        message: message,
        notes: values.notes || "",
        // Ensure babyId is explicitly included
        babyId: selectedBaby,
      };

      console.log("Submitting reminder data:", formattedValues);

      const res = await apiRequest(
        "POST",
        `/api/babies/${selectedBaby}/custom-reminders`,
        formattedValues
      );
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Reminder created",
        description: "Your reminder has been created successfully.",
      });
      
      // Invalidate reminders queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/custom-reminders/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      
      // Reset form
      form.reset(defaultValues);
      
      // Call success callback if provided
      if (onSuccess) {
        onSuccess();
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create reminder",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (values: ReminderFormValues) => {
    if (!selectedBaby) {
      toast({
        title: "No baby selected",
        description: "Please select a baby to create a reminder.",
        variant: "destructive",
      });
      return;
    }
    
    // Submit the data
    createReminderMutation.mutate(values);
  };

  // Handle days of week selection for custom recurring type
  const handleDayToggle = (dayValue: string) => {
    const currentDays = form.getValues("daysOfWeek") || "";
    const daysArray = currentDays.split(",").filter(day => day !== "");
    
    if (daysArray.includes(dayValue)) {
      // Remove the day if already selected
      const newDaysArray = daysArray.filter(day => day !== dayValue);
      form.setValue("daysOfWeek", newDaysArray.join(","));
    } else {
      // Add the day if not already selected
      daysArray.push(dayValue);
      form.setValue("daysOfWeek", daysArray.join(","));
    }
  };

  // Check if a day is selected
  const isDaySelected = (dayValue: string) => {
    const currentDays = form.getValues("daysOfWeek") || "";
    return currentDays.split(",").includes(dayValue);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        {/* Baby selector would go here if needed */}
        
        {/* Reminder Title */}
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem className="mb-1">
              <FormLabel className="text-xs">Reminder Title</FormLabel>
              <FormControl>
                <Input placeholder="Enter reminder title" {...field} className="h-9 text-sm" />
              </FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        {/* Reminder Type */}
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem className="mb-1">
              <FormLabel className="text-xs">Reminder Type</FormLabel>
              <Select
                onValueChange={field.onChange}
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger className="h-9 text-sm">
                    <SelectValue placeholder="Select reminder type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="feeding" className="text-sm">Feeding</SelectItem>
                  <SelectItem value="sleep" className="text-sm">Sleep/Nap</SelectItem>
                  <SelectItem value="medication" className="text-sm">Medication</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        {/* Start Date */}
        <FormField
          control={form.control}
          name="startDate"
          render={({ field }) => (
            <FormItem className="mb-1">
              <FormLabel className="text-xs">Start Date</FormLabel>
              <Popover open={showStartDateCalendar} onOpenChange={setShowStartDateCalendar}>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full h-9 pl-3 text-left font-normal text-xs",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "MMM d, yyyy")
                      ) : (
                        <span>Pick a start date</span>
                      )}
                      <CalendarIcon className="ml-auto h-3.5 w-3.5 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={(date) => {
                      if (date) {
                        field.onChange(date);
                        setShowStartDateCalendar(false);
                      }
                    }}
                    initialFocus
                    className="rounded-md"
                  />
                </PopoverContent>
              </Popover>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-2">
          {/* Reminder Time */}
          <FormField
            control={form.control}
            name="time"
            render={({ field }) => (
              <FormItem className="mb-1">
                <FormLabel className="text-xs">Time</FormLabel>
                <FormControl>
                  <div className="flex items-center">
                    <Clock className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
                    <Input
                      type="time"
                      placeholder="HH:MM"
                      className="h-9 text-sm"
                      {...field}
                    />
                  </div>
                </FormControl>
                <FormMessage className="text-xs" />
              </FormItem>
            )}
          />

          {/* Recurring Type */}
          <FormField
            control={form.control}
            name="recurringType"
            render={({ field }) => (
              <FormItem className="mb-1">
                <FormLabel className="text-xs">Repeat</FormLabel>
                <Select
                  onValueChange={(value) => {
                    field.onChange(value);
                    setShowDaysSelector(value === "custom");
                  }}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger className="h-9 text-sm">
                      <SelectValue placeholder="Repeat" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="daily" className="text-sm">Daily</SelectItem>
                    <SelectItem value="weekly" className="text-sm">Weekly</SelectItem>
                    <SelectItem value="custom" className="text-sm">Custom</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage className="text-xs" />
              </FormItem>
            )}
          />
        </div>

        {/* End Date (Optional) */}
        <FormField
          control={form.control}
          name="endDate"
          render={({ field }) => (
            <FormItem className="mb-1">
              <FormLabel className="text-xs">End Date (Optional)</FormLabel>
              <Popover open={showEndDateCalendar} onOpenChange={setShowEndDateCalendar}>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full h-9 pl-3 text-left font-normal text-xs",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "MMM d, yyyy")
                      ) : (
                        <span>No end date</span>
                      )}
                      <CalendarIcon className="ml-auto h-3.5 w-3.5 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <div className="p-2">
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start text-destructive text-xs py-1"
                      onClick={() => {
                        field.onChange(undefined);
                        setShowEndDateCalendar(false);
                      }}
                    >
                      Clear End Date
                    </Button>
                  </div>
                  <Calendar
                    mode="single"
                    selected={field.value || undefined}
                    onSelect={(date) => {
                      field.onChange(date);
                      setShowEndDateCalendar(false);
                    }}
                    initialFocus
                    disabled={(date) => {
                      // Disable dates before start date
                      const startDate = form.getValues("startDate");
                      return startDate ? date < startDate : false;
                    }}
                    className="rounded-md"
                  />
                </PopoverContent>
              </Popover>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        {/* Days of Week (for custom recurring type) */}
        {showDaysSelector && (
          <div className="space-y-1">
            <FormLabel className="text-xs">Select Days</FormLabel>
            <div className="flex flex-wrap gap-1">
              {daysOfWeek.map((day) => (
                <Button
                  key={day.value}
                  type="button"
                  variant={isDaySelected(day.value) ? "default" : "outline"}
                  className="h-8 w-10 text-xs px-0"
                  onClick={() => handleDayToggle(day.value)}
                >
                  {day.label}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Notes */}
        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem className="mb-1">
              <FormLabel className="text-xs">Notes (Optional)</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Add any additional notes here"
                  className="resize-none h-20 text-sm"
                  {...field}
                />
              </FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        {/* Enabled/Disabled Switch */}
        <FormField
          control={form.control}
          name="enabled"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-2 mb-1">
              <div className="space-y-0.5">
                <FormLabel className="text-xs">Enable Reminder</FormLabel>
                <div className="text-xs text-muted-foreground">
                  Turn this reminder on or off
                </div>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        {/* Form Actions */}
        <div className="flex justify-end space-x-2 mt-3">
          {onCancel && (
            <Button variant="outline" type="button" onClick={onCancel} className="h-9 text-xs">
              Cancel
            </Button>
          )}
          <Button type="submit" disabled={createReminderMutation.isPending} className="h-9 text-xs">
            {createReminderMutation.isPending ? "Creating..." : "Create Reminder"}
          </Button>
        </div>


      </form>
    </Form>
  );
}