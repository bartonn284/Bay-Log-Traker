import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

/**
 * A small badge component that shows if a baby has any reminders
 * Used in baby cards and profile headers
 */
export function ReminderBadge({ babyId }: { babyId: number }) {
  const { data, isLoading } = useQuery<{ hasReminders: boolean }>({
    queryKey: [`/api/babies/${babyId}/has-reminders`],
    // Don't refetch too often
    refetchInterval: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    retry: 3
  });

  // Show nothing if loading or no reminders
  if (isLoading || !data?.hasReminders) {
    return null;
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="outline" className="ml-2 px-1.5 py-0 h-5 cursor-pointer bg-amber-100 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 hover:bg-amber-200 dark:hover:bg-amber-900/30">
            <Bell className="h-3 w-3" />
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p className="text-xs">
            This baby has upcoming reminders
          </p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}