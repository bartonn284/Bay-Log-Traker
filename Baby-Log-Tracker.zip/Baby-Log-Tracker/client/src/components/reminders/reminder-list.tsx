import React, { useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { Bell, Calendar, AlertTriangle, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

// Types from our reminder service
export enum ReminderType {
  VACCINE = "vaccine",
  APPOINTMENT = "appointment",
  MILESTONE = "milestone",
  GROWTH_CHECK = "growth_check",
  HEALTH_CHECK = "health_check",
}

export interface Reminder {
  id: number;
  type: ReminderType;
  babyId: number;
  babyName: string;
  name: string;
  dueDate: Date;
  description: string;
}

interface ReminderListProps {
  filterTypes?: ReminderType[];
}

export function ReminderList({ filterTypes = [] }: ReminderListProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Only fetch reminders if we have specific filter types
  // This prevents showing reminders on pages where they're not needed
  const enabled = filterTypes.length > 0;
  
  const { data: reminders, isLoading, error } = useQuery<Reminder[]>({
    queryKey: ["/api/reminders"],
    enabled: enabled,
  });
  
  // Mutation to delete a system reminder (vaccine/appointment)
  const deleteReminderMutation = useMutation({
    mutationFn: async ({type, id}: {type: string, id: number}) => {
      let endpoint = '';
      
      // Different endpoints based on reminder type
      if (type === ReminderType.VACCINE) {
        endpoint = `/api/vaccines/${id}`;
      } else if (type === ReminderType.APPOINTMENT) {
        endpoint = `/api/appointments/${id}`;
      } else {
        throw new Error('Unsupported reminder type for deletion');
      }
      
      const response = await fetch(endpoint, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error(`Failed to delete ${type} reminder`);
      }
      
      return {type, id};
    },
    onSuccess: ({type}) => {
      // Invalidate the reminders query to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      
      toast({
        title: "Reminder deleted",
        description: `The ${type} reminder has been successfully removed`,
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete reminder: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  if (isLoading) {
    return <ReminderSkeleton />;
  }

  if (error) {
    return (
      <div className="p-4 mb-4 text-sm text-red-500 bg-red-100 rounded-lg dark:bg-red-900/20 dark:text-red-400">
        <AlertTriangle className="w-4 h-4 inline mr-2" />
        Failed to load reminders: {error.message}
      </div>
    );
  }

  if (!reminders || reminders.length === 0) {
    return (
      <Card className="mb-4">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center">
            <Bell className="w-4 h-4 mr-2" />
            Reminders
          </CardTitle>
          <CardDescription>
            You have no upcoming reminders right now
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  // Filter by type if specified
  const filteredReminders = useMemo(() => {
    if (!reminders) return [];
    
    // Apply type filter if provided
    if (filterTypes && filterTypes.length > 0) {
      return reminders.filter(reminder => filterTypes.includes(reminder.type));
    }
    
    return reminders;
  }, [reminders, filterTypes]);
  
  // Group reminders by baby
  const remindersByBaby = filteredReminders.reduce((acc, reminder) => {
    acc[reminder.babyId] = acc[reminder.babyId] || [];
    acc[reminder.babyId].push(reminder);
    return acc;
  }, {} as Record<string, Reminder[]>);

  // When viewed in the Health tab of the ReminderDashboard, use a simplified view
  if (filterTypes && filterTypes.length > 0) {
    return (
      <div className="space-y-3 py-1">
        {Object.entries(remindersByBaby).map(([babyId, babyReminders]) => (
          <div key={babyId} className="space-y-2">
            <div className="space-y-1.5">
              {babyReminders.map((reminder) => (
                <ReminderItem key={`${reminder.type}-${reminder.id}`} reminder={reminder} />
              ))}
            </div>
          </div>
        ))}
        
        {Object.keys(remindersByBaby).length === 0 && (
          <div className="text-center py-2 text-sm text-muted-foreground">
            No health reminders found
          </div>
        )}
      </div>
    );
  }
  
  // Don't show the standalone card view on pages where it's not explicitly needed
  return null;
}

function ReminderItem({ reminder }: { reminder: Reminder }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Mutation to delete a system reminder (vaccine/appointment)
  const deleteReminderMutation = useMutation({
    mutationFn: async ({type, id}: {type: string, id: number}) => {
      let endpoint = '';
      
      // Different endpoints based on reminder type
      if (type === ReminderType.VACCINE) {
        endpoint = `/api/vaccines/${id}`;
      } else if (type === ReminderType.APPOINTMENT) {
        endpoint = `/api/appointments/${id}`;
      } else {
        throw new Error('Unsupported reminder type for deletion');
      }
      
      const response = await fetch(endpoint, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error(`Failed to delete ${type} reminder`);
      }
      
      return {type, id};
    },
    onSuccess: ({type}) => {
      // Invalidate the reminders query to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      
      toast({
        title: "Reminder deleted",
        description: `The ${type} reminder has been successfully removed`,
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete reminder: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const getBadgeVariant = (type: ReminderType): "default" | "secondary" | "destructive" | "outline" => {
    switch (type) {
      case ReminderType.VACCINE:
        return "outline";
      case ReminderType.APPOINTMENT:
        return "default";
      case ReminderType.MILESTONE:
        return "outline";
      case ReminderType.GROWTH_CHECK:
        return "secondary";
      case ReminderType.HEALTH_CHECK:
        return "destructive";
      default:
        return "default";
    }
  };

  const getTypeLabel = (type: ReminderType) => {
    switch (type) {
      case ReminderType.VACCINE:
        return "Vaccine";
      case ReminderType.APPOINTMENT:
        return "Appointment";
      case ReminderType.MILESTONE:
        return "Milestone";
      case ReminderType.GROWTH_CHECK:
        return "Growth";
      case ReminderType.HEALTH_CHECK:
        return "Health";
      default:
        return "Other";
    }
  };
  
  // Only allow deletion of vaccines and appointments through the system reminders
  const canDelete = reminder.type === ReminderType.VACCINE || reminder.type === ReminderType.APPOINTMENT;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center justify-between p-2 text-sm bg-accent/20 rounded-md hover:bg-accent/30 transition">
            <div className="flex items-center">
              <Badge variant={getBadgeVariant(reminder.type)} className={`mr-2 ${
                reminder.type === ReminderType.VACCINE 
                  ? "bg-amber-100 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400" 
                  : reminder.type === ReminderType.MILESTONE
                  ? "bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400"
                  : ""
              }`}>
                {getTypeLabel(reminder.type)}
              </Badge>
              <span className="font-medium truncate max-w-[180px]">
                {reminder.name}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center text-muted-foreground">
                <Calendar className="w-3 h-3 mr-1" />
                <span className="text-xs">
                  {reminder.dueDate && !isNaN(new Date(reminder.dueDate).getTime()) 
                    ? format(new Date(reminder.dueDate), "MMM d") 
                    : "No due date"}
                </span>
              </div>
              {canDelete && (
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    deleteReminderMutation.mutate({type: reminder.type, id: reminder.id});
                  }}
                  className="bg-destructive/10 text-destructive hover:bg-destructive/20 ml-1 p-1 rounded-md transition-colors flex items-center gap-1"
                  aria-label="Delete reminder"
                  title="Delete reminder"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span className="text-[10px] font-medium">Delete</span>
                </button>
              )}
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{reminder.description}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function ReminderSkeleton() {
  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center">
          <Bell className="w-4 h-4 mr-2" />
          Reminders
        </CardTitle>
        <CardDescription>Loading upcoming reminders...</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-10 w-full rounded-md" />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}