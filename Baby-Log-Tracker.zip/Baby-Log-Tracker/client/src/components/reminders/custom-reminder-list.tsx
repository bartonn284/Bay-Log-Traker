import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useBabyContext } from "@/hooks/use-baby-context";
import { format, isToday, isTomorrow, parseISO } from "date-fns";
import { PlusCircle, AlarmClock, Trash2, Bell } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ReminderForm } from "./reminder-form";
import { useToast } from "@/hooks/use-toast";

interface CustomReminderListProps {
  filterType?: string | null;
}

type CustomReminderType = {
  id: number;
  babyId: number;
  userId: number;
  title: string;
  type: string;
  startDate?: string | Date;
  endDate?: string | Date;
  time?: string;
  recurringType: string;
  notes?: string;
  enabled: boolean;
};

// Component to display all active custom reminders
export function CustomReminderList({ filterType = null }: CustomReminderListProps) {
  const { selectedBaby } = useBabyContext();
  const [isAddReminderOpen, setIsAddReminderOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Query to fetch active custom reminders
  const { data: customReminders = [], isLoading, isError, error } = useQuery<CustomReminderType[]>({
    queryKey: ["/api/custom-reminders/active"],
    queryFn: async ({ signal }) => {
      const res = await fetch("/api/custom-reminders/active", { signal });
      if (!res.ok) {
        throw new Error("Failed to fetch custom reminders");
      }
      return await res.json();
    },
    enabled: true, // Always fetch reminders for the user
    refetchInterval: 3000, // Refetch every 3 seconds to ensure we have the latest data
  });
  
  // Mutation to delete a reminder
  const deleteReminderMutation = useMutation({
    mutationFn: async (reminderId: number) => {
      const response = await fetch(`/api/custom-reminders/${reminderId}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete reminder');
      }
      
      return reminderId;
    },
    onSuccess: () => {
      // Invalidate the reminders queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/custom-reminders/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      toast({
        title: "Reminder deleted",
        description: "The reminder has been successfully removed",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete reminder: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Filter the reminders based on the filter type
  const filteredReminders = filterType
    ? customReminders.filter(reminder => reminder.type === filterType)
    : customReminders;
  
  // Helper function to get type label and icon color
  const getTypeInfo = (type: string) => {
    switch (type) {
      case "feeding":
        return { label: "Feeding", color: "bg-green-500/10 text-green-500 dark:bg-green-900/20 dark:text-green-400" };
      case "sleep":
        return { label: "Sleep/Nap", color: "bg-blue-500/10 text-blue-500 dark:bg-blue-900/20 dark:text-blue-400" };
      case "medication":
        return { label: "Medication", color: "bg-red-500/10 text-red-500 dark:bg-red-900/20 dark:text-red-400" };
      case "vaccine":
        return { label: "Vaccines", color: "bg-purple-500/10 text-purple-500 dark:bg-purple-900/20 dark:text-purple-400" };
      case "appointment":
        return { label: "Appointments", color: "bg-amber-500/10 text-amber-500 dark:bg-amber-900/20 dark:text-amber-400" };
      default:
        return { label: "Other", color: "bg-accent/20 text-foreground" };
    }
  };
  
  // Helper function to format the date for display
  const formatReminderDate = (dateString: string) => {
    try {
      const date = parseISO(dateString);
      if (isToday(date)) {
        return "Today";
      } else if (isTomorrow(date)) {
        return "Tomorrow";
      } else {
        return format(date, "MMM d");
      }
    } catch (e) {
      return "Today";
    }
  };

  // Show loading state
  if (isLoading) {
    return (
      <div className="space-y-2">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  // Show error state
  if (isError && error) {
    return (
      <div className="text-center py-3 text-muted-foreground">
        <p>Error loading reminders: {error.message}</p>
      </div>
    );
  }

  // Show a message if no reminders found
  if (filteredReminders.length === 0) {
    return (
      <div className="text-center py-3">
        <p className="text-sm text-muted-foreground mb-3">No reminders set up yet</p>
        <Dialog open={isAddReminderOpen} onOpenChange={setIsAddReminderOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="gap-1">
              <PlusCircle className="h-4 w-4" />
              Add Reminder
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Reminder</DialogTitle>
              <DialogDescription>
                Set up reminders for feeding times, naps, and medication schedules.
              </DialogDescription>
            </DialogHeader>
            <ReminderForm 
              onSuccess={() => setIsAddReminderOpen(false)}
              onCancel={() => setIsAddReminderOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // Group reminders by type for display
  const remindersByType = filteredReminders.reduce((acc: Record<string, CustomReminderType[]>, reminder) => {
    const reminderType = reminder.type || 'other';
    if (!acc[reminderType]) {
      acc[reminderType] = [];
    }
    acc[reminderType].push(reminder);
    return acc;
  }, {});

  return (
    <div className="space-y-3 py-1">
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-medium">Active Reminders</h3>
        <Dialog open={isAddReminderOpen} onOpenChange={setIsAddReminderOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" className="h-7 w-7">
              <PlusCircle className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Reminder</DialogTitle>
              <DialogDescription>
                Set up reminders for feeding times, naps, and medication schedules.
              </DialogDescription>
            </DialogHeader>
            <ReminderForm 
              onSuccess={() => setIsAddReminderOpen(false)}
              onCancel={() => setIsAddReminderOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="space-y-2">
        {Object.keys(remindersByType).map(type => (
          <div key={type} className="space-y-1">
            <div className="flex items-center gap-1.5">
              <Badge variant="outline" className={`text-xs px-2 py-0 ${getTypeInfo(type).color}`}>
                {getTypeInfo(type).label}
              </Badge>
            </div>
            <div className="space-y-1.5">
              {remindersByType[type].map((reminder) => (
                <TooltipProvider key={reminder.id}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center justify-between p-2 text-xs bg-accent/10 rounded-md hover:bg-accent/20 transition">
                        <div className="flex items-center">
                          <AlarmClock className="h-3.5 w-3.5 mr-2 text-primary/60" />
                          <span className="font-medium truncate">{reminder.title || "Untitled Reminder"}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-muted-foreground whitespace-nowrap">
                            {reminder.time && typeof reminder.time === 'string' ? reminder.time.substring(0, 5) : ''}
                          </span>
                          {reminder.startDate && (
                            <Badge variant="outline" className="text-[10px] px-1.5 h-4">
                              {typeof reminder.startDate === 'string' ? formatReminderDate(reminder.startDate) : 'Today'}
                            </Badge>
                          )}
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              if (window.confirm("Are you sure you want to delete this reminder?")) {
                                deleteReminderMutation.mutate(reminder.id);
                              }
                            }}
                            className="bg-red-100/50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30 ml-1 p-1 rounded-md transition-colors flex items-center gap-1"
                            aria-label="Delete reminder"
                            title="Delete reminder"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                            <span className="text-[10px] font-medium">Delete</span>
                          </button>
                        </div>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <div className="text-xs">
                        <p className="font-medium">{reminder.title || "Reminder"}</p>
                        {reminder.notes && <p className="mt-1">{reminder.notes}</p>}
                        {reminder.recurringType && (
                          <p className="mt-1 text-muted-foreground">
                            {reminder.recurringType === "daily" 
                              ? "Repeats daily" 
                              : reminder.recurringType === "weekly" 
                              ? "Repeats weekly"
                              : "Custom schedule"}
                          </p>
                        )}
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}