import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Trash } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function DeleteAllReminders() {
  const [isDeleting, setIsDeleting] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteAllRemindersMutation = useMutation({
    mutationFn: async () => {
      setIsDeleting(true);
      try {
        // First get all active reminders
        const res = await fetch('/api/custom-reminders/active');
        if (!res.ok) {
          throw new Error('Failed to fetch reminders');
        }
        
        const reminders = await res.json();
        
        // Then delete each one
        let deleted = 0;
        for (const reminder of reminders) {
          const deleteRes = await fetch(`/api/custom-reminders/${reminder.id}`, {
            method: 'DELETE',
          });
          
          if (deleteRes.ok) {
            deleted++;
          }
        }
        
        return {
          success: true,
          message: `Successfully deleted ${deleted} of ${reminders.length} reminders.`
        };
      } catch (error) {
        return {
          success: false,
          message: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`
        };
      } finally {
        setIsDeleting(false);
      }
    },
    onSuccess: (data) => {
      setResult(data);
      // Invalidate all reminders queries to refresh UI
      queryClient.invalidateQueries({ queryKey: ['/api/custom-reminders/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      
      toast({
        title: data.success ? 'Success' : 'Error',
        description: data.message,
        variant: data.success ? 'default' : 'destructive',
      });
    },
    onError: (error) => {
      setResult({
        success: false,
        message: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
      
      toast({
        title: 'Error',
        description: `Failed to delete reminders: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: 'destructive',
      });
    }
  });

  const handleDeleteAll = () => {
    if (!isConfirming) {
      setIsConfirming(true);
      return;
    }
    
    deleteAllRemindersMutation.mutate();
    setIsConfirming(false);
  };

  return (
    <div className="p-4 border border-border rounded-lg">
      <h3 className="text-lg font-medium mb-4">Reminder Management</h3>
      
      {result && (
        <Alert className={`mb-4 ${result.success ? 'bg-green-100 dark:bg-green-900/20 border-green-200 dark:border-green-800' : 'bg-red-100 dark:bg-red-900/20 border-red-200 dark:border-red-800'}`}>
          <AlertTitle>{result.success ? 'Success' : 'Error'}</AlertTitle>
          <AlertDescription>{result.message}</AlertDescription>
        </Alert>
      )}
      
      <div className="flex flex-col gap-2">
        <Button 
          variant="destructive" 
          className="w-full gap-2"
          onClick={handleDeleteAll}
          disabled={isDeleting}
        >
          <Trash className="h-4 w-4" />
          {isDeleting ? 'Deleting Reminders...' : 
            isConfirming ? 'Click again to confirm' : 'Delete All Reminders'}
        </Button>
        
        {isConfirming && (
          <Button
            variant="outline"
            className="w-full"
            onClick={() => setIsConfirming(false)}
          >
            Cancel
          </Button>
        )}
      </div>
    </div>
  );
}