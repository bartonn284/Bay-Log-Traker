import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatDate, calculateAge } from "@/lib/utils";
import { Baby } from "@shared/schema";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Separator } from "@/components/ui/separator";
import { 
  AlertTriangle, 
  Heart, 
  Info, 
  Baby as BabyIcon, 
  User, 
  Phone, 
  Lightbulb, 
  Utensils, 
  MoonStar
} from "lucide-react";

interface EmergencyInfoCardProps {
  baby: Baby;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

// Sample data - in a real app, this would come from actual tracking data
const feedingData = [
  { name: 'Breast', value: 40 },
  { name: 'Bottle', value: 30 },
  { name: 'Formula', value: 20 },
  { name: 'Solids', value: 10 },
];

const moodData = [
  { name: 'Happy', value: 55 },
  { name: 'Calm', value: 25 },
  { name: 'Fussy', value: 15 },
  { name: 'Crying', value: 5 },
];

const feedingDurationData = [
  { name: 'Mon', duration: 15 },
  { name: 'Tue', duration: 18 },
  { name: 'Wed', duration: 12 },
  { name: 'Thu', duration: 20 },
  { name: 'Fri', duration: 15 },
  { name: 'Sat', duration: 17 },
  { name: 'Sun', duration: 16 },
];

export function EmergencyInfoCard({ baby }: EmergencyInfoCardProps) {
  // Guard clause to prevent rendering with incomplete data
  if (!baby || !baby.name) {
    return null;
  }
  
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * Math.PI / 180);
    const y = cy + radius * Math.sin(-midAngle * Math.PI / 180);
  
    return (
      <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  // Get baby age - with safety check to prevent errors
  const ageDisplay = baby.dateOfBirth ? calculateAge(new Date(baby.dateOfBirth)) : 'Unknown';

  return (
    <Card className="w-full shadow-lg border border-primary/10 overflow-hidden bg-gradient-to-br from-card to-background">
      <CardHeader className="pb-3 relative">
        <div className="flex items-start justify-between">
          <div className="flex flex-col">
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-primary-foreground bg-clip-text text-transparent">
              Emergency Profile
            </CardTitle>
            <CardDescription>
              Essential information for {baby.name}'s care
            </CardDescription>
          </div>
          <Avatar className="w-16 h-16 ring-2 ring-primary/20">
            {baby.photoUrl ? (
              <AvatarImage src={baby.photoUrl} alt={baby.name} />
            ) : (
              <AvatarFallback className="bg-muted text-2xl">
                {baby.gender === 'male' ? '👶🏻' : baby.gender === 'female' ? '👶🏻' : '👶🏻'}
              </AvatarFallback>
            )}
          </Avatar>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="px-6 py-4 space-y-4">
          {/* Basic Info Section */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-primary">
              <BabyIcon className="h-4 w-4" />
              <h3 className="font-semibold">Baby Profile</h3>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm pl-6">
              <div className="flex flex-col">
                <span className="text-muted-foreground">Name:</span>
                <span className="font-medium">{baby.name}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">Age:</span>
                <span className="font-medium">{ageDisplay}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">DOB:</span>
                <span className="font-medium">{baby.dateOfBirth ? formatDate(new Date(baby.dateOfBirth)) : 'Unknown'}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">Gender:</span>
                <span className="font-medium capitalize">{baby.gender || 'Unknown'}</span>
              </div>
            </div>
          </div>

          {/* Allergies Section - Important */}
          {baby.allergies && (
            <div className="bg-destructive/10 rounded-lg p-3 border border-destructive/20">
              <div className="flex items-center gap-2 text-destructive mb-1">
                <AlertTriangle className="h-4 w-4" />
                <h3 className="font-semibold">Allergies</h3>
              </div>
              <p className="text-sm pl-6">{baby.allergies}</p>
            </div>
          )}

          {/* Physical Stats */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-primary">
              <Heart className="h-4 w-4" />
              <h3 className="font-semibold">Physical Stats</h3>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm pl-6">
              <div className="flex flex-col">
                <span className="text-muted-foreground">Weight:</span>
                <span className="font-medium">{baby.weight || 'Unknown'}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">Height:</span>
                <span className="font-medium">{baby.height || 'Unknown'}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">Head Circumference:</span>
                <span className="font-medium">{baby.width || 'Unknown'}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">Blood Type:</span>
                <span className="font-medium">{baby.bloodType || 'Unknown'}</span>
              </div>
            </div>
          </div>

          {/* Medical Essentials */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-primary">
              <Info className="h-4 w-4" />
              <h3 className="font-semibold">Medical Contacts</h3>
            </div>
            <div className="text-sm pl-6 space-y-2">
              <div className="flex flex-col">
                <span className="text-muted-foreground">Pediatrician/Hospital:</span>
                <span className="font-medium">{baby.doctor || 'Not specified'}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground">Emergency Contact:</span>
                <span className="font-medium">{baby.emergencyContact || 'Not specified'}</span>
              </div>
              {baby.conditions && (
                <div className="flex flex-col">
                  <span className="text-muted-foreground">Medical Conditions:</span>
                  <span className="font-medium">{baby.conditions}</span>
                </div>
              )}
            </div>
          </div>

          {/* Care Preferences */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-primary">
              <Lightbulb className="h-4 w-4" />
              <h3 className="font-semibold">Care Preferences</h3>
            </div>
            <div className="grid grid-cols-1 gap-2 text-sm pl-6">
              <div className="flex items-start gap-2">
                <Utensils className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex flex-col">
                  <span className="text-muted-foreground">Feeding Preferences:</span>
                  <span className="font-medium">{baby.feedingPreferences || 'Not specified'}</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <MoonStar className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div className="flex flex-col">
                  <span className="text-muted-foreground">Soothing Methods:</span>
                  <span className="font-medium">{baby.soothingMethods || 'Not specified'}</span>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Smart AI Tips - This would be dynamically generated based on baby data */}
          <div className="bg-primary/5 rounded-lg p-3 border border-primary/20">
            <div className="flex items-center gap-2 text-primary mb-1">
              <Lightbulb className="h-4 w-4" />
              <h3 className="font-semibold">Smart AI Tip</h3>
            </div>
            <p className="text-sm pl-6">Based on {baby.name}'s feeding patterns, try offering smaller, more frequent feedings to reduce fussiness.</p>
          </div>

          {/* Charts and Trends */}
          <div className="pt-2">
            <Tabs defaultValue="7days" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="7days">7 Days</TabsTrigger>
                <TabsTrigger value="month">Month</TabsTrigger>
                <TabsTrigger value="all">All Time</TabsTrigger>
              </TabsList>
              <TabsContent value="7days" className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="h-48">
                    <h4 className="text-sm font-medium text-center mb-2">Feeding Types</h4>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={feedingData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={renderCustomizedLabel}
                          outerRadius={60}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {feedingData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Legend layout="horizontal" verticalAlign="bottom" align="center" />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="h-48">
                    <h4 className="text-sm font-medium text-center mb-2">Mood Distribution</h4>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={moodData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={renderCustomizedLabel}
                          outerRadius={60}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {moodData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Legend layout="horizontal" verticalAlign="bottom" align="center" />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  
                  <div className="col-span-1 md:col-span-2 h-48">
                    <h4 className="text-sm font-medium text-center mb-2">Feeding Duration (Minutes)</h4>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={feedingDurationData}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 0,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="duration" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="month">
                <div className="h-40 flex items-center justify-center text-muted-foreground">
                  Monthly data charts would appear here
                </div>
              </TabsContent>
              
              <TabsContent value="all">
                <div className="h-40 flex items-center justify-center text-muted-foreground">
                  All-time data charts would appear here
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}