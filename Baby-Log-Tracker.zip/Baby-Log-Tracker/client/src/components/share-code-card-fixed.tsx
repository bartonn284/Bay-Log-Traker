import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, Copy, RefreshCcw, QrCode, Check, Clock } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { useState, useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

type ShareCodeCardProps = {
  babyName: string;
  shareCode: string | null;
  babyId?: number;
  isAdmin?: boolean;
  onRegenerateCode?: (babyId: number, defaultRole: string) => void;
};

export function ShareCodeCard({ 
  babyName, 
  shareCode, 
  babyId, 
  isAdmin = false,
  onRegenerateCode 
}: ShareCodeCardProps) {
  const { toast } = useToast();
  const [isCopied, setIsCopied] = useState(false);
  const [defaultRole, setDefaultRole] = useState<string>("viewer");
  const [showQRCode, setShowQRCode] = useState(false);
  const [currentShareCode, setCurrentShareCode] = useState<string | null>(shareCode);
  const [shareCodeExpiry, setShareCodeExpiry] = useState<Date | null>(null);
  const [expiryTimeDisplay, setExpiryTimeDisplay] = useState<string>("");
  const [isExpired, setIsExpired] = useState<boolean>(false);
  
  const appUrl = window.location.origin;
  // Only create join URL if share code exists
  const joinUrl = currentShareCode ? `${appUrl}/join-baby?code=${currentShareCode}` : "";
  
  // Fetch and initialize baby info with share code details from the server
  useEffect(() => {
    if (shareCode) {
      setCurrentShareCode(shareCode);
      
      if (babyId) {
        const initializeShareCodeDetails = async () => {
          try {
            const response = await fetch(`/api/babies/${babyId}`);
            const data = await response.json();
            
            if (data && data.shareCodeExpiry) {
              const expiryDate = new Date(data.shareCodeExpiry);
              setShareCodeExpiry(expiryDate);
              
              if (new Date() > expiryDate) {
                setIsExpired(true);
              } else {
                setIsExpired(false);
                setExpiryTimeDisplay(formatDistanceToNow(expiryDate, { addSuffix: true }));
              }
            }
          } catch (error) {
            console.error("Failed to fetch share code details:", error);
          }
        };
        
        initializeShareCodeDetails();
      }
    }
  }, [shareCode, babyId]);
  
  // Set up refresh timer for expiry countdown
  useEffect(() => {
    // Refresh expiry time display every second
    const timer = setInterval(() => {
      if (shareCodeExpiry) {
        if (new Date() > shareCodeExpiry) {
          setIsExpired(true);
        } else {
          setIsExpired(false);
          setExpiryTimeDisplay(formatDistanceToNow(shareCodeExpiry, { addSuffix: true }));
        }
      }
    }, 1000);
    
    return () => clearInterval(timer);
  }, [shareCodeExpiry]);

  const copyToClipboard = async (text: string, successMessage: string) => {
    try {
      // Try to copy to clipboard using the Clipboard API
      await navigator.clipboard.writeText(text);
      
      toast({
        title: "Copied!",
        description: successMessage,
      });
      
      return true;
    } catch (err) {
      // Fallback method for browsers that don't support Clipboard API
      try {
        // Create a temporary input element
        const tempInput = document.createElement('input');
        tempInput.value = text;
        document.body.appendChild(tempInput);
        tempInput.select();
        
        // Execute copy command
        document.execCommand('copy');
        
        // Clean up
        document.body.removeChild(tempInput);
        
        toast({
          title: "Copied!",
          description: successMessage,
        });
        
        return true;
      } catch (fallbackErr) {
        toast({
          title: "Failed to copy",
          description: "Could not copy to clipboard. Please try again or manually select and copy the text.",
          variant: "destructive"
        });
        
        return false;
      }
    }
  };

  const handleCopyCode = async () => {
    if (!currentShareCode || isExpired) return;
    
    const success = await copyToClipboard(
      currentShareCode,
      "The share code has been copied to your clipboard."
    );
    
    if (success) {
      setIsCopied(true);
      // Keep the copied indicator visible longer
      setTimeout(() => setIsCopied(false), 5000); // Extended to 5 seconds
    }
  };
  
  const handleCopyJoinUrl = async () => {
    if (!currentShareCode || isExpired) return;
    await copyToClipboard(
      joinUrl,
      "The join URL has been copied to your clipboard."
    );
  };
  
  const handleRegenerateCode = () => {
    if (babyId && onRegenerateCode) {
      console.log("ShareCodeCard: Requesting regenerate code for babyId:", babyId, "with role:", defaultRole);
      onRegenerateCode(babyId, defaultRole);
    } else {
      console.error("ShareCodeCard: Cannot regenerate code", {
        babyId,
        onRegenerateCode: !!onRegenerateCode
      });
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 p-[1px] rounded-xl shadow-xl">
        <div className="bg-white dark:bg-gray-950 rounded-xl p-6">
          <div className="mb-6">
            <h2 className="text-xl font-bold bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 inline-block text-transparent bg-clip-text">
              Share {babyName}'s Data
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Connect with family members through this secure code
            </p>
          </div>
          
          {/* Share code section */}
          <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 mb-6 border border-gray-100 dark:border-gray-800">
            {!currentShareCode ? (
              <div className="text-center py-2 text-gray-500">
                No share code available yet. Click "New Code" below to generate one.
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className={cn(
                    "font-mono tracking-wide text-center py-2 text-lg font-medium w-full",
                    isExpired && "text-red-500"
                  )}>
                    {currentShareCode}
                  </div>
                  
                  <Button 
                    size="icon" 
                    variant="ghost"
                    onClick={handleCopyCode}
                    disabled={isExpired}
                    className={cn(
                      "transition-all duration-200 hover:bg-gray-200 dark:hover:bg-gray-800",
                      isCopied && "text-green-500",
                      isExpired && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    {isCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
                
                {shareCodeExpiry && (
                  <div className="flex items-center justify-center text-xs text-gray-500">
                    <Clock className="h-3 w-3 mr-1" />
                    {isExpired ? (
                      <span className="text-red-500 font-medium">Expired - Generate a new code</span>
                    ) : (
                      <span>Expires {expiryTimeDisplay}</span>
                    )}
                  </div>
                )}
                
                <Dialog open={showQRCode} onOpenChange={setShowQRCode}>
                  <DialogTrigger asChild>
                    <Button 
                      size="icon" 
                      variant="ghost"
                      className="hover:bg-gray-200 dark:hover:bg-gray-800"
                    >
                      <QrCode className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md rounded-xl bg-white dark:bg-gray-950 p-0 border-none shadow-2xl">
                    <div className="p-6">
                      <DialogTitle className="text-xl font-bold bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 inline-block text-transparent bg-clip-text">
                        QR Share
                      </DialogTitle>
                      
                      <div className="flex flex-col items-center justify-center mt-6">
                        <div className="bg-white p-2 rounded-xl">
                          <QRCodeSVG 
                            value={joinUrl} 
                            size={200} 
                            bgColor={"#ffffff"}
                            fgColor={"#000000"}
                            level={"L"}
                            includeMargin={false}
                          />
                        </div>
                        
                        <p className="mt-4 text-sm text-center text-gray-500">
                          Scan to join {babyName}'s profile
                        </p>
                        
                        <div className="mt-6 w-full">
                          <div className="flex items-center mb-4">
                            <Input
                              value={joinUrl}
                              readOnly
                              className="text-xs font-mono bg-gray-50 dark:bg-gray-900 border-0"
                            />
                            <Button 
                              size="icon" 
                              variant="ghost"
                              onClick={handleCopyJoinUrl}
                              className="ml-2 hover:bg-gray-200 dark:hover:bg-gray-800"
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <DialogClose asChild>
                            <Button 
                              variant="default" 
                              className="w-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white hover:opacity-90"
                            >
                              Close
                            </Button>
                          </DialogClose>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            )}
          </div>
          
          {/* Regenerate section */}
          {isAdmin && babyId && (
            <div className="mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h4 className="text-sm font-medium">Permission Level</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Set default access for new members
                  </p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Select 
                    value={defaultRole} 
                    onValueChange={setDefaultRole}
                  >
                    <SelectTrigger className="w-28 bg-gray-50 dark:bg-gray-900 border-gray-100 dark:border-gray-800">
                      <SelectValue placeholder="Role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Admin</SelectItem>
                      <SelectItem value="editor">Editor</SelectItem>
                      <SelectItem value="viewer">Viewer</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button 
                    variant="outline" 
                    onClick={onRegenerateCode ? handleRegenerateCode : undefined}
                    className="border-gray-100 dark:border-gray-800"
                  >
                    <RefreshCcw className="h-3 w-3 mr-2" />
                    New Code
                  </Button>
                </div>
              </div>
              
              <div className="mt-6 border-t border-gray-100 dark:border-gray-800 pt-4">
                <div className="flex justify-center">
                  <Button 
                    size="lg"
                    onClick={async () => {
                      try {
                        console.log("Attempting debug code generation for baby:", babyId);
                        const response = await fetch(`/api/babies/${babyId}/debug-generate-code`);
                        const data = await response.json();
                        console.log("Debug code generation result:", data);
                        
                        if (data.success) {
                          // Update component's local state
                          setCurrentShareCode(data.shareCode);
                          setShareCodeExpiry(new Date(data.expiresAt));
                          setIsExpired(false);
                          setExpiryTimeDisplay(formatDistanceToNow(new Date(data.expiresAt), { addSuffix: true }));
                          
                          toast({
                            title: "Code Generated",
                            description: `New share code: ${data.shareCode}`,
                          });
                          
                          // Update the React Query cache to reflect the new code
                          queryClient.setQueryData(["/api/babies", babyId], (oldData: any) => {
                            if (oldData) {
                              return {
                                ...oldData,
                                shareCode: data.shareCode,
                                shareCodeExpiry: data.expiresAt,
                              };
                            }
                            return oldData;
                          });
                          
                          // Also invalidate the babies list cache
                          queryClient.invalidateQueries({
                            queryKey: ["/api/babies"],
                          });
                        }
                      } catch (error) {
                        console.error("Code generation failed:", error);
                        toast({
                          title: "Generation Error",
                          description: "Failed to generate code. Try again.",
                          variant: "destructive",
                        });
                      }
                    }}
                    className="w-full sm:w-auto bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white hover:opacity-90 shadow-md"
                  >
                    Generate Code
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          {/* Tips section */}
          <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1 border-t border-gray-100 dark:border-gray-800 pt-4">
            <p className="font-medium">Quick tips:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Share the 12-digit code directly</li>
              <li>Or let them scan the QR code to join instantly</li>
              <li>Permissions can be managed in Family Sharing</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}