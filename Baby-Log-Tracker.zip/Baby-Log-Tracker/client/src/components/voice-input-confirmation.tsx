import React, { useState } from 'react';
import { format } from 'date-fns';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mic, EditIcon, Check, FileEdit } from "lucide-react";

interface VoiceInputConfirmationProps {
  isOpen: boolean;
  onClose: () => void;
  parsedData: any;
  rawText: string;
  onConfirm: (data: any) => void;
}

export function VoiceInputConfirmation({
  isOpen,
  onClose,
  parsedData,
  rawText,
  onConfirm
}: VoiceInputConfirmationProps) {
  const [editedData, setEditedData] = useState<any>(parsedData);
  const [activeTab, setActiveTab] = useState<string>("preview");
  
  // Format the time for display
  const formattedTime = editedData?.time 
    ? format(new Date(editedData.time), 'h:mm a') 
    : format(new Date(), 'h:mm a');

  const handleInputChange = (field: string, value: any) => {
    setEditedData((prev: any) => ({
      ...prev,
      [field]: value
    }));
  };
  
  const handleConfirm = () => {
    onConfirm(editedData);
    onClose();
  };

  // Generate a human-readable summary of the activity
  const getSummary = () => {
    switch (editedData.type) {
      case 'bottle':
        return `Bottle feeding${editedData.amount ? ` of ${editedData.amount} oz` : ''} at ${formattedTime}`;
      
      case 'breast':
        return `Breast feeding${editedData.side ? ` (${editedData.side})` : ''}${editedData.duration ? ` for ${editedData.duration} min` : ''} at ${formattedTime}`;
      
      case 'feeding':
        if (editedData.feedingType === 'bottle') {
          return `Bottle feeding${editedData.amount ? ` of ${editedData.amount} oz` : ''} at ${formattedTime}`;
        } else if (editedData.feedingType === 'breast') {
          return `Breast feeding${editedData.side ? ` (${editedData.side})` : ''}${editedData.duration ? ` for ${editedData.duration} min` : ''} at ${formattedTime}`;
        }
        return `Feeding at ${formattedTime}`;
      
      case 'sleep':
        return editedData.sleepStatus === 'end'
          ? `Ended sleep at ${formattedTime}`
          : `Started sleep at ${formattedTime}`;
      
      case 'completed_sleep':
        return `Completed sleep${editedData.duration ? ` for ${editedData.duration} min` : ''} at ${formattedTime}`;
      
      case 'diaper':
        return `Diaper change (${editedData.diaperType || 'unspecified'})${editedData.consistency ? `, ${editedData.consistency} consistency` : ''} at ${formattedTime}`;
      
      case 'medication':
        return `Medication${editedData.medicationType ? ` (${editedData.medicationType})` : ''}${editedData.dose ? ` ${editedData.dose}` : ''} at ${formattedTime}`;
      
      case 'mood':
        return `Mood: ${editedData.mood || 'unspecified'}${editedData.cryDuration ? `, crying for ${editedData.cryDuration} min` : ''}${editedData.cryReason ? `, reason: ${editedData.cryReason}` : ''} at ${formattedTime}`;
      
      case 'supply':
        return `Supply: ${editedData.supplyName || 'unspecified'}${editedData.supplyCategory ? ` (${editedData.supplyCategory})` : ''}${editedData.supplyPriority ? `, priority: ${editedData.supplyPriority}` : ''} at ${formattedTime}`;
      
      case 'milestone':
        return `Milestone: ${editedData.milestoneType ? editedData.milestoneType.replace(/_/g, ' ') : 'unspecified'}${editedData.milestoneCategory ? ` (${editedData.milestoneCategory})` : ''} at ${formattedTime}`;
      
      default:
        return `Unknown activity at ${formattedTime}`;
    }
  };

  // Render different edit forms based on activity type
  const renderEditForm = () => {
    switch (editedData.type) {
      case 'bottle':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="amount">Amount (oz)</Label>
              <Input
                id="amount"
                type="number"
                step="0.5"
                value={editedData.amount || ''}
                onChange={(e) => handleInputChange('amount', parseFloat(e.target.value))}
              />
            </div>
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>
        );
      
      case 'breast':
        return (
          <div className="space-y-4">
            <div>
              <Label>Side</Label>
              <RadioGroup
                value={editedData.side || 'both'}
                onValueChange={(value) => handleInputChange('side', value)}
                className="flex space-x-2 mt-2"
              >
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="left" id="side-left" />
                  <Label htmlFor="side-left">Left</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="right" id="side-right" />
                  <Label htmlFor="side-right">Right</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="both" id="side-both" />
                  <Label htmlFor="side-both">Both</Label>
                </div>
              </RadioGroup>
            </div>
            <div>
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Input
                id="duration"
                type="number"
                value={editedData.duration || ''}
                onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
              />
            </div>
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>
        );

      case 'feeding':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="feedingType">Feeding Type</Label>
              <Select
                value={editedData.feedingType || 'bottle'}
                onValueChange={(value) => handleInputChange('feedingType', value)}
              >
                <SelectTrigger id="feedingType">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bottle">Bottle</SelectItem>
                  <SelectItem value="breast">Breast</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {editedData.feedingType === 'bottle' ? (
              <div>
                <Label htmlFor="amount">Amount (oz)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.5"
                  value={editedData.amount || ''}
                  onChange={(e) => handleInputChange('amount', parseFloat(e.target.value))}
                />
              </div>
            ) : (
              <>
                <div>
                  <Label>Side</Label>
                  <RadioGroup
                    value={editedData.side || 'both'}
                    onValueChange={(value) => handleInputChange('side', value)}
                    className="flex space-x-2 mt-2"
                  >
                    <div className="flex items-center space-x-1">
                      <RadioGroupItem value="left" id="side-left" />
                      <Label htmlFor="side-left">Left</Label>
                    </div>
                    <div className="flex items-center space-x-1">
                      <RadioGroupItem value="right" id="side-right" />
                      <Label htmlFor="side-right">Right</Label>
                    </div>
                    <div className="flex items-center space-x-1">
                      <RadioGroupItem value="both" id="side-both" />
                      <Label htmlFor="side-both">Both</Label>
                    </div>
                  </RadioGroup>
                </div>
                <div>
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={editedData.duration || ''}
                    onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
                  />
                </div>
              </>
            )}
            
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>
        );
      
      case 'sleep':
        return (
          <div className="space-y-4">
            <div>
              <Label>Status</Label>
              <RadioGroup
                value={editedData.sleepStatus || 'start'}
                onValueChange={(value) => handleInputChange('sleepStatus', value)}
                className="flex space-x-2 mt-2"
              >
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="start" id="sleep-start" />
                  <Label htmlFor="sleep-start">Start sleep</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="end" id="sleep-end" />
                  <Label htmlFor="sleep-end">End sleep</Label>
                </div>
              </RadioGroup>
            </div>
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>
        );
      
      case 'diaper':
        return (
          <div className="space-y-4">
            <div>
              <Label>Type</Label>
              <RadioGroup
                value={editedData.diaperType || 'wet'}
                onValueChange={(value) => handleInputChange('diaperType', value)}
                className="flex space-x-2 mt-2"
              >
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="wet" id="diaper-wet" />
                  <Label htmlFor="diaper-wet">Wet</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="dirty" id="diaper-dirty" />
                  <Label htmlFor="diaper-dirty">Dirty</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="both" id="diaper-both" />
                  <Label htmlFor="diaper-both">Both</Label>
                </div>
              </RadioGroup>
            </div>
            
            {(editedData.diaperType === 'dirty' || editedData.diaperType === 'both') && (
              <div>
                <Label htmlFor="consistency">Consistency</Label>
                <Select
                  value={editedData.consistency || ''}
                  onValueChange={(value) => handleInputChange('consistency', value)}
                >
                  <SelectTrigger id="consistency">
                    <SelectValue placeholder="Select consistency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="solid">Solid</SelectItem>
                    <SelectItem value="soft">Soft</SelectItem>
                    <SelectItem value="liquid">Liquid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>
        );
        
      case 'medication':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="medicationType">Medication Type</Label>
              <Input
                id="medicationType"
                type="text"
                value={editedData.medicationType || ''}
                onChange={(e) => handleInputChange('medicationType', e.target.value)}
                placeholder="e.g., Tylenol, Ibuprofen, Vitamin D"
              />
            </div>
            <div>
              <Label htmlFor="dose">Dose</Label>
              <Input
                id="dose"
                type="text"
                value={editedData.dose || ''}
                onChange={(e) => handleInputChange('dose', e.target.value)}
                placeholder="e.g., 2.5ml, 1/2 tablet"
              />
            </div>
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="e.g., For fever, Given after meal"
              />
            </div>
          </div>
        );
      
      case 'mood':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="mood">Mood</Label>
              <Select
                value={editedData.mood || 'happy'}
                onValueChange={(value) => handleInputChange('mood', value)}
              >
                <SelectTrigger id="mood">
                  <SelectValue placeholder="Select mood" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="happy">Happy</SelectItem>
                  <SelectItem value="calm">Calm</SelectItem>
                  <SelectItem value="fussy">Fussy</SelectItem>
                  <SelectItem value="upset">Upset</SelectItem>
                  <SelectItem value="gassy">Gassy</SelectItem>
                  <SelectItem value="tired">Tired</SelectItem>
                  <SelectItem value="hungry">Hungry</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="crying">Crying?</Label>
              <Select
                value={editedData.crying ? 'yes' : 'no'}
                onValueChange={(value) => handleInputChange('crying', value === 'yes')}
              >
                <SelectTrigger id="crying">
                  <SelectValue placeholder="Was baby crying?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes</SelectItem>
                  <SelectItem value="no">No</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {editedData.crying && (
              <>
                <div>
                  <Label htmlFor="cryDuration">Crying Duration (minutes)</Label>
                  <Input
                    id="cryDuration"
                    type="number"
                    value={editedData.cryDuration || ''}
                    onChange={(e) => handleInputChange('cryDuration', parseInt(e.target.value))}
                  />
                </div>
                <div>
                  <Label htmlFor="cryReason">Reason for Crying</Label>
                  <Select
                    value={editedData.cryReason || ''}
                    onValueChange={(value) => handleInputChange('cryReason', value)}
                  >
                    <SelectTrigger id="cryReason">
                      <SelectValue placeholder="Select reason" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hunger">Hunger</SelectItem>
                      <SelectItem value="pain">Pain/Discomfort</SelectItem>
                      <SelectItem value="overtired">Overtired</SelectItem>
                      <SelectItem value="gas">Gas/Colic</SelectItem>
                      <SelectItem value="separation">Separation Anxiety</SelectItem>
                      <SelectItem value="overstimulation">Overstimulation</SelectItem>
                      <SelectItem value="unknown">Unknown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
            
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="Any additional details about baby's mood"
              />
            </div>
          </div>
        );
      
      case 'supply':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="supplyName">Supply Name</Label>
              <Input
                id="supplyName"
                type="text"
                value={editedData.supplyName || ''}
                onChange={(e) => handleInputChange('supplyName', e.target.value)}
                placeholder="e.g., Diapers, Wipes, Formula"
              />
            </div>
            <div>
              <Label htmlFor="supplyCategory">Category</Label>
              <Select
                value={editedData.supplyCategory || 'other'}
                onValueChange={(value) => handleInputChange('supplyCategory', value)}
              >
                <SelectTrigger id="supplyCategory">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="diapers">Diapers</SelectItem>
                  <SelectItem value="wipes">Wipes</SelectItem>
                  <SelectItem value="formula">Formula</SelectItem>
                  <SelectItem value="feeding">Feeding Supplies</SelectItem>
                  <SelectItem value="clothing">Clothing</SelectItem>
                  <SelectItem value="medicine">Medicine</SelectItem>
                  <SelectItem value="food">Baby Food</SelectItem>
                  <SelectItem value="bathtime">Bath Supplies</SelectItem>
                  <SelectItem value="toys">Toys</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="supplyPriority">Priority</Label>
              <Select
                value={editedData.supplyPriority || 'medium'}
                onValueChange={(value) => handleInputChange('supplyPriority', value)}
              >
                <SelectTrigger id="supplyPriority">
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="e.g., Specific brand, size, or quantity needed"
              />
            </div>
          </div>
        );
        
      case 'milestone':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="milestoneType">Milestone</Label>
              <Select
                value={editedData.milestoneType || 'other'}
                onValueChange={(value) => handleInputChange('milestoneType', value)}
              >
                <SelectTrigger id="milestoneType">
                  <SelectValue placeholder="Select milestone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="first_smile">First Smile</SelectItem>
                  <SelectItem value="first_laugh">First Laugh</SelectItem>
                  <SelectItem value="rolling_over">Rolling Over</SelectItem>
                  <SelectItem value="sitting_up">Sitting Up</SelectItem>
                  <SelectItem value="crawling">Crawling</SelectItem>
                  <SelectItem value="standing">Standing</SelectItem>
                  <SelectItem value="walking">Walking</SelectItem>
                  <SelectItem value="first_word">First Word</SelectItem>
                  <SelectItem value="first_tooth">First Tooth</SelectItem>
                  <SelectItem value="solid_food">First Solid Food</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="milestoneCategory">Category</Label>
              <Select
                value={editedData.milestoneCategory || 'other'}
                onValueChange={(value) => handleInputChange('milestoneCategory', value)}
              >
                <SelectTrigger id="milestoneCategory">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="motor">Motor Skills</SelectItem>
                  <SelectItem value="social">Social/Emotional</SelectItem>
                  <SelectItem value="cognitive">Cognitive</SelectItem>
                  <SelectItem value="food">Food/Eating</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="Additional details about this milestone"
              />
            </div>
          </div>
        );
      
      default:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="type">Activity Type</Label>
              <Select
                value={editedData.type}
                onValueChange={(value) => handleInputChange('type', value)}
              >
                <SelectTrigger id="type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="feeding">Feeding</SelectItem>
                  <SelectItem value="bottle">Bottle</SelectItem>
                  <SelectItem value="breast">Breast</SelectItem>
                  <SelectItem value="sleep">Sleep</SelectItem>
                  <SelectItem value="diaper">Diaper</SelectItem>
                  <SelectItem value="medication">Medication</SelectItem>
                  <SelectItem value="mood">Mood</SelectItem>
                  <SelectItem value="supply">Supply</SelectItem>
                  <SelectItem value="milestone">Milestone</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={format(new Date(editedData.time), 'HH:mm')}
                onChange={(e) => {
                  const [hours, minutes] = e.target.value.split(':').map(Number);
                  const newDate = new Date(editedData.time);
                  newDate.setHours(hours, minutes);
                  handleInputChange('time', newDate.toISOString());
                }}
              />
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={editedData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>
        );
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Confirm Voice Input</DialogTitle>
          <DialogDescription>
            Please review and confirm the information captured from your voice command.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-2">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="preview">
              <Check className="h-4 w-4 mr-2" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="edit">
              <FileEdit className="h-4 w-4 mr-2" />
              Edit
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="preview" className="p-4 border rounded-md mt-2">
            <div className="space-y-4">
              <div className="font-medium">{getSummary()}</div>
              <div className="text-sm text-muted-foreground border-t pt-2">
                <div className="font-medium mb-1">What I heard:</div>
                <div className="italic">"{rawText}"</div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="edit" className="p-4 border rounded-md mt-2">
            {renderEditForm()}
          </TabsContent>
        </Tabs>
        
        <DialogFooter className="sm:justify-start mt-4">
          <Button
            type="submit"
            variant={activeTab === "preview" ? "default" : "secondary"}
            onClick={handleConfirm}
          >
            Save
          </Button>
          <Button 
            type="button" 
            variant="outline" 
            onClick={onClose}
          >
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}