import { Link } from "wouter";
import { Baby, Home, Clock, Plus, FileText, Settings, ShoppingBasket, BarChart2, Milk, Mic, Moon, Utensils, Lightbulb } from "lucide-react";
import { useState, lazy, Suspense } from "react";
import { useLogModal } from "@/hooks/use-log-modal";

type BottomNavigationProps = {
  currentTab: string;
  onLogButtonClick?: () => void;
};

// Lazy load the voice input button
const VoiceInputButton = lazy(() => import('@/components/voice-input-button').then(
  module => ({ default: module.VoiceInputButton })
));

export function BottomNavigation({ currentTab, onLogButtonClick }: BottomNavigationProps) {
  const [showVoiceInput, setShowVoiceInput] = useState(false);
  const [showActivityMenu, setShowActivityMenu] = useState(false);
  const { open } = useLogModal();
  
  const handleLogClick = () => {
    if (onLogButtonClick) {
      onLogButtonClick();
    } else {
      // If no specific handler is provided, use the global log modal
      open();
    }
  };
  
  const handleLongPress = () => {
    setShowActivityMenu(true);
  };
  
  return (
    <nav className="glass-effect border-t border-border/30 py-2 fixed bottom-0 left-0 right-0 max-w-md mx-auto rounded-t-xl shadow-lg z-40">
      {/* Mobile navigation - scrollable for small screens */}
      <div className="flex items-center justify-between px-1 sm:px-3 overflow-x-auto hide-scrollbar">
        <Link href="/">
          <div className={`flex flex-col items-center py-1 px-2 sm:px-3 cursor-pointer min-w-[60px] transition-all duration-200
            ${currentTab === "home" 
              ? "text-gradient font-medium" 
              : "text-muted-foreground hover:text-foreground"}`}>
            <Home className={`h-5 w-5 sm:h-6 sm:w-6 ${currentTab === "home" ? "text-primary" : ""}`} />
            <span className="text-[10px] sm:text-xs mt-1">Home</span>
          </div>
        </Link>
        
        <Link href="/data">
          <div className={`flex flex-col items-center py-1 px-2 sm:px-3 cursor-pointer min-w-[60px] transition-all duration-200
            ${currentTab === "data" 
              ? "text-gradient font-medium" 
              : "text-muted-foreground hover:text-foreground"}`}>
            <BarChart2 className={`h-5 w-5 sm:h-6 sm:w-6 ${currentTab === "data" ? "text-primary" : ""}`} />
            <span className="text-[10px] sm:text-xs mt-1">Data</span>
          </div>
        </Link>
        
        {/* Log button moved to middle position */}
        <div className="flex flex-col items-center py-1 px-2 relative min-w-[60px]">
          <div className="relative z-10">
            <button 
              className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-r from-[hsl(var(--gradient-start))] to-[hsl(var(--gradient-end))] flex items-center justify-center shadow-lg -mt-6 transform translate-y-0.5 btn-glow hover:scale-105 transition-all duration-300"
              onClick={handleLogClick}
              onContextMenu={(e) => {
                e.preventDefault();
                handleLongPress();
              }}
              onTouchStart={() => {
                // For mobile: show activity menu on long press
                const timer = setTimeout(() => {
                  setShowActivityMenu(true);
                }, 500);
                return () => clearTimeout(timer);
              }}
            >
              <Plus className="h-6 w-6 sm:h-7 sm:w-7 text-white" />
            </button>
          </div>
          <span className="text-[10px] sm:text-xs mt-1 text-gradient font-medium">Log</span>
        </div>
        


        <Link href="/supplies">
          <div className={`flex flex-col items-center py-1 px-2 sm:px-3 cursor-pointer min-w-[60px] transition-all duration-200
            ${currentTab === "supplies" || currentTab === "pumping" 
              ? "text-gradient font-medium" 
              : "text-muted-foreground hover:text-foreground"}`}>
            <ShoppingBasket className={`h-5 w-5 sm:h-6 sm:w-6 ${currentTab === "supplies" || currentTab === "pumping" ? "text-primary" : ""}`} />
            <span className="text-[10px] sm:text-xs mt-1">Supplies</span>
          </div>
        </Link>
        
        <Link href="/reports">
          <div className={`flex flex-col items-center py-1 px-2 sm:px-3 cursor-pointer min-w-[60px] transition-all duration-200
            ${currentTab === "reports" 
              ? "text-gradient font-medium" 
              : "text-muted-foreground hover:text-foreground"}`}>
            <FileText className={`h-5 w-5 sm:h-6 sm:w-6 ${currentTab === "reports" ? "text-primary" : ""}`} />
            <span className="text-[10px] sm:text-xs mt-1">Reports</span>
          </div>
        </Link>
        
        <Link href="/settings">
          <div className={`flex flex-col items-center py-1 px-2 sm:px-3 cursor-pointer min-w-[60px] transition-all duration-200
            ${currentTab === "settings" 
              ? "text-gradient font-medium" 
              : "text-muted-foreground hover:text-foreground"}`}>
            <Settings className={`h-5 w-5 sm:h-6 sm:w-6 ${currentTab === "settings" ? "text-primary" : ""}`} />
            <span className="text-[10px] sm:text-xs mt-1">Settings</span>
          </div>
        </Link>
      </div>
      
      {/* Activity menu modal */}
      {showActivityMenu && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-md z-50 flex items-center justify-center">
          <div className="glass-effect border border-border/30 rounded-xl p-6 w-11/12 max-w-md shadow-lg">
            <div className="text-center mb-6">
              <h3 className="text-gradient text-xl font-bold">Log Activity</h3>
              <p className="text-sm text-muted-foreground mt-1">Choose an activity to log</p>
            </div>
            
            <div className="flex flex-col gap-3 mb-6">
              <div className="grid grid-cols-2 gap-3">
                <button 
                  className="bg-feeding/10 hover:bg-feeding/20 text-feeding border border-feeding/30 p-4 rounded-xl flex flex-col items-center gap-2 transition-all duration-200 hover:shadow-md card-hover"
                  onClick={() => {
                    setShowActivityMenu(false);
                    if (onLogButtonClick) onLogButtonClick();
                  }}
                >
                  <Utensils className="h-5 w-5 mb-1" />
                  <span className="text-sm font-medium">Feeding</span>
                </button>
                
                <button 
                  className="bg-sleep/10 hover:bg-sleep/20 text-sleep border border-sleep/30 p-4 rounded-xl flex flex-col items-center gap-2 transition-all duration-200 hover:shadow-md card-hover"
                  onClick={() => {
                    setShowActivityMenu(false);
                    if (onLogButtonClick) onLogButtonClick();
                  }}
                >
                  <Moon className="h-5 w-5 mb-1" />
                  <span className="text-sm font-medium">Sleep</span>
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <button 
                  className="bg-diaper/10 hover:bg-diaper/20 text-diaper border border-diaper/30 p-4 rounded-xl flex flex-col items-center gap-2 transition-all duration-200 hover:shadow-md card-hover"
                  onClick={() => {
                    setShowActivityMenu(false);
                    if (onLogButtonClick) onLogButtonClick();
                  }}
                >
                  <Baby className="h-5 w-5 mb-1" />
                  <span className="text-sm font-medium">Diaper</span>
                </button>
                
                <button 
                  className="bg-primary/10 hover:bg-primary/20 text-primary border border-primary/30 p-4 rounded-xl flex flex-col items-center gap-2 transition-all duration-200 hover:shadow-md card-hover"
                  onClick={() => {
                    setShowActivityMenu(false);
                    setShowVoiceInput(true);
                  }}
                >
                  <Mic className="h-5 w-5 mb-1" />
                  <span className="text-sm font-medium">Voice Log</span>
                </button>
              </div>
            </div>
            
            <button 
              className="w-full py-2.5 text-sm font-medium text-muted-foreground border border-border/50 rounded-lg hover:bg-muted/50 transition-colors duration-200"
              onClick={() => setShowActivityMenu(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      
      {/* Voice input modal */}
      {showVoiceInput && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-md z-50 flex items-center justify-center">
          <div className="glass-effect border border-border/30 rounded-xl p-6 w-11/12 max-w-md shadow-lg">
            <div className="text-center mb-6">
              <h3 className="text-gradient text-xl font-bold">Voice Input</h3>
              <p className="text-sm text-muted-foreground mt-1">Speak to log an activity</p>
            </div>
            
            <Suspense fallback={<div className="text-center p-6 flex justify-center items-center">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            </div>}>
              <VoiceInputButton 
                className="w-full" 
                buttonText="Tap to speak"
                onClose={() => setShowVoiceInput(false)}
              />
            </Suspense>
            
            <button 
              className="mt-6 w-full py-2.5 text-sm font-medium text-muted-foreground border border-border/50 rounded-lg hover:bg-muted/50 transition-colors duration-200"
              onClick={() => setShowVoiceInput(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
