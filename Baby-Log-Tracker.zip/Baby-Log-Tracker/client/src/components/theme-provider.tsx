import React, { createContext, useContext, useEffect, useState } from "react";

type Theme = "light" | "dark" | "system";
type ColorTheme = "default" | "vibrant" | "pastel";

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: Theme;
  defaultColorTheme?: ColorTheme;
  storageKey?: string;
  colorStorageKey?: string;
}

interface ThemeProviderState {
  theme: Theme;
  colorTheme: ColorTheme;
  setTheme: (theme: Theme) => void;
  setColorTheme: (colorTheme: ColorTheme) => void;
}

const initialState: ThemeProviderState = {
  theme: "light",
  colorTheme: "default",
  setTheme: () => null,
  setColorTheme: () => null,
};

const ThemeProviderContext = createContext<ThemeProviderState>(initialState);

export function ThemeProvider({
  children,
  defaultTheme = "light",
  defaultColorTheme = "default",
  storageKey = "ui-theme",
  colorStorageKey = "baby-color-theme",
  ...props
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(
    () => (localStorage.getItem(storageKey) as Theme) || defaultTheme
  );
  
  const [colorTheme, setColorTheme] = useState<ColorTheme>(
    () => (localStorage.getItem(colorStorageKey) as ColorTheme) || defaultColorTheme
  );

  useEffect(() => {
    const root = window.document.documentElement;
    
    root.classList.remove("light", "dark");
    
    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)")
        .matches
        ? "dark"
        : "light";
      
      root.classList.add(systemTheme);
      return;
    }
    
    root.classList.add(theme);
    
    // Apply additional dark mode enhancements specifically for readability
    if (theme === "dark") {
      // Ensure text has enough contrast in dark mode regardless of theme
      root.style.setProperty('--foreground', '210 40% 98%');
      root.style.setProperty('--card-foreground', '210 40% 98%');
    } else {
      // Reset these properties when switching back to light
      root.style.removeProperty('--foreground');
      root.style.removeProperty('--card-foreground');
    }
  }, [theme]);
  
  useEffect(() => {
    const root = window.document.documentElement;
    
    // Remove all color theme classes
    root.classList.remove("theme-default", "theme-vibrant", "theme-pastel");
    
    // Add the selected color theme class
    root.classList.add(`theme-${colorTheme}`);
    
    // Apply theme-specific CSS variables with improved contrast for readability
    if (colorTheme === "vibrant") {
      // Vibrant theme with better contrast
      root.style.setProperty('--primary', '270 80% 50%');
      root.style.setProperty('--primary-foreground', '0 0% 100%');
      root.style.setProperty('--foreground', '270 30% 15%');
      root.style.setProperty('--card-foreground', '270 30% 15%');
      root.style.setProperty('--muted-foreground', '270 30% 30%');
      root.style.setProperty('--accent', '325 80% 96%');
      root.style.setProperty('--accent-foreground', '325 70% 35%');
      root.style.setProperty('--feeding', '195 90% 45%');
      root.style.setProperty('--sleep', '285 85% 50%');
      root.style.setProperty('--diaper', '150 85% 35%');
    } else if (colorTheme === "pastel") {
      // Pastel theme with better contrast
      root.style.setProperty('--primary', '180 70% 40%');
      root.style.setProperty('--primary-foreground', '0 0% 100%');
      root.style.setProperty('--foreground', '180 50% 15%');
      root.style.setProperty('--card-foreground', '180 50% 15%');
      root.style.setProperty('--muted-foreground', '180 30% 30%');
      root.style.setProperty('--accent', '95 60% 90%');
      root.style.setProperty('--accent-foreground', '95 50% 25%');
      root.style.setProperty('--feeding', '190 80% 45%');
      root.style.setProperty('--sleep', '260 60% 45%');
      root.style.setProperty('--diaper', '120 60% 40%');
    } else {
      // Reset to default theme with good readability
      root.style.removeProperty('--primary');
      root.style.removeProperty('--primary-foreground');
      root.style.removeProperty('--foreground');
      root.style.removeProperty('--card-foreground');
      root.style.removeProperty('--muted-foreground');
      root.style.removeProperty('--accent');
      root.style.removeProperty('--accent-foreground');
      root.style.removeProperty('--feeding');
      root.style.removeProperty('--sleep');
      root.style.removeProperty('--diaper');
    }
  }, [colorTheme]);

  const value = {
    theme,
    colorTheme,
    setTheme: (theme: Theme) => {
      localStorage.setItem(storageKey, theme);
      setTheme(theme);
    },
    setColorTheme: (colorTheme: ColorTheme) => {
      localStorage.setItem(colorStorageKey, colorTheme);
      setColorTheme(colorTheme);
    },
  };

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);
  
  if (context === undefined)
    throw new Error("useTheme must be used within a ThemeProvider");
  
  return context;
};