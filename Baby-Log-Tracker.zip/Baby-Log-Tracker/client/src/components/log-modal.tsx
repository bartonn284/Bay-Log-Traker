import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useBabyContext } from "@/hooks/use-baby-context";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { X, Baby, MoonStar, Droplets, Mic, MicOff } from "lucide-react";

type LogModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

// Define form schema for each log type
const feedingSchema = z.object({
  type: z.string(),
  side: z.string().optional(),
  amount: z.string().optional(),
  duration: z.coerce.number().optional(),
  notes: z.string().optional(),
});

const sleepSchema = z.object({
  type: z.string(),
  duration: z.coerce.number().optional(),
  quality: z.coerce.number().min(1).max(5).optional(),
  notes: z.string().optional(),
});

const diaperSchema = z.object({
  type: z.string(),
  consistency: z.string().optional(),
  color: z.string().optional(),
  notes: z.string().optional(),
});

// Union type for all form data
type FormData = z.infer<typeof feedingSchema> | z.infer<typeof sleepSchema> | z.infer<typeof diaperSchema>;

export function LogModal({ isOpen, onClose }: LogModalProps) {
  const [activeTab, setActiveTab] = useState("feeding");
  const { selectedBaby } = useBabyContext();
  const { toast } = useToast();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const recognitionRef = useRef<any>(null);
  
  // Set up voice recognition
  useEffect(() => {
    if (typeof window !== "undefined" && 'webkitSpeechRecognition' in window) {
      // @ts-ignore - using webkit speech recognition
      const SpeechRecognition = window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';
      
      recognitionRef.current.onresult = (event: any) => {
        const transcriptText = event.results[0][0].transcript;
        setTranscript(transcriptText);
        parseVoiceCommand(transcriptText);
      };
      
      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
        toast({
          title: "Voice recognition error",
          description: `Error: ${event.error}. Please try again.`,
          variant: "destructive"
        });
      };
      
      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
    
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [toast]);
  
  const toggleListening = () => {
    if (!recognitionRef.current) {
      toast({
        title: "Voice recognition not supported",
        description: "Your browser does not support voice recognition.",
        variant: "destructive"
      });
      return;
    }
    
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setTranscript("");
      recognitionRef.current.start();
      setIsListening(true);
    }
  };
  
  const parseVoiceCommand = (command: string) => {
    const lowerCommand = command.toLowerCase();
    console.log("Voice command:", lowerCommand);
    
    // Detect activity type
    let detectedTab = "";
    if (lowerCommand.includes("feed") || lowerCommand.includes("breast") || lowerCommand.includes("bottle") || lowerCommand.includes("formula")) {
      detectedTab = "feeding";
      
      // Set feeding type
      if (lowerCommand.includes("breast")) {
        feedingForm.setValue("type", "breast");
        
        // Detect side
        if (lowerCommand.includes("left")) {
          feedingForm.setValue("side", "left");
        } else if (lowerCommand.includes("right")) {
          feedingForm.setValue("side", "right");
        } else if (lowerCommand.includes("both")) {
          feedingForm.setValue("side", "both");
        }
      } else if (lowerCommand.includes("formula") || (lowerCommand.includes("bottle") && !lowerCommand.includes("breastmilk"))) {
        feedingForm.setValue("type", "bottle");
        
        // Extract amount
        const amountMatch = lowerCommand.match(/(\d+)\s*(ounce|oz|ml|milliliter)/);
        if (amountMatch) {
          feedingForm.setValue("amount", `${amountMatch[1]}${amountMatch[2].startsWith('o') ? 'oz' : 'ml'}`);
        }
      } else if (lowerCommand.includes("breastmilk") || lowerCommand.includes("breast milk")) {
        feedingForm.setValue("type", "bottle_breastmilk");
        
        // Extract amount
        const amountMatch = lowerCommand.match(/(\d+)\s*(ounce|oz|ml|milliliter)/);
        if (amountMatch) {
          feedingForm.setValue("amount", `${amountMatch[1]}${amountMatch[2].startsWith('o') ? 'oz' : 'ml'}`);
        }
      } else if (lowerCommand.includes("solid")) {
        feedingForm.setValue("type", "solid");
      }
      
      // Extract duration
      const durationMatch = lowerCommand.match(/(\d+)\s*(minute|min|minutes)/);
      if (durationMatch) {
        feedingForm.setValue("duration", parseInt(durationMatch[1]));
      }
      
      // Set notes
      feedingForm.setValue("notes", command);
    } 
    else if (lowerCommand.includes("sleep") || lowerCommand.includes("nap")) {
      detectedTab = "sleep";
      
      // Set sleep type
      if (lowerCommand.includes("night")) {
        sleepForm.setValue("type", "night");
      } else {
        sleepForm.setValue("type", "nap");
      }
      
      // Extract duration
      const durationMatch = lowerCommand.match(/(\d+)\s*(minute|min|minutes|hour|hr|hours)/);
      if (durationMatch) {
        let duration = parseInt(durationMatch[1]);
        if (durationMatch[2].includes('hour')) {
          duration *= 60; // Convert hours to minutes
        }
        sleepForm.setValue("duration", duration);
      }
      
      // Extract quality
      if (lowerCommand.includes("quality")) {
        for (let i = 1; i <= 5; i++) {
          if (lowerCommand.includes(`quality ${i}`) || lowerCommand.includes(`${i} quality`)) {
            sleepForm.setValue("quality", i);
            break;
          }
        }
      }
      
      // Set notes
      sleepForm.setValue("notes", command);
    } 
    else if (lowerCommand.includes("diaper") || lowerCommand.includes("poop") || lowerCommand.includes("pee") || lowerCommand.includes("wet")) {
      detectedTab = "diaper";
      
      // Set diaper type
      if (lowerCommand.includes("poop") || lowerCommand.includes("dirty")) {
        diaperForm.setValue("type", "dirty");
        
        // Extract color
        const colors = ["yellow", "green", "brown", "black", "red"];
        for (const color of colors) {
          if (lowerCommand.includes(color)) {
            diaperForm.setValue("color", color);
            break;
          }
        }
        
        // Extract consistency
        if (lowerCommand.includes("solid")) {
          diaperForm.setValue("consistency", "solid");
        } else if (lowerCommand.includes("soft")) {
          diaperForm.setValue("consistency", "soft");
        } else if (lowerCommand.includes("liquid") || lowerCommand.includes("runny")) {
          diaperForm.setValue("consistency", "liquid");
        }
      } else if (lowerCommand.includes("wet") || lowerCommand.includes("pee")) {
        diaperForm.setValue("type", "wet");
      } else if (lowerCommand.includes("mixed")) {
        diaperForm.setValue("type", "mixed");
      }
      
      // Set notes
      diaperForm.setValue("notes", command);
    }
    
    // Change to detected tab
    if (detectedTab) {
      setActiveTab(detectedTab);
      toast({
        title: "Voice command detected",
        description: `Detected a ${detectedTab} activity. Please review and submit.`,
      });
    } else {
      toast({
        title: "Voice command unclear",
        description: "Could not determine the activity type. Please select manually.",
      });
    }
  };

  // Initialize forms for each tab
  const feedingForm = useForm<z.infer<typeof feedingSchema>>({
    resolver: zodResolver(feedingSchema),
    defaultValues: {
      type: "breast",
      side: "left",
      amount: "",
      duration: 0,
      notes: "",
    },
  });

  const sleepForm = useForm<z.infer<typeof sleepSchema>>({
    resolver: zodResolver(sleepSchema),
    defaultValues: {
      type: "nap",
      duration: 0,
      quality: 3,
      notes: "",
    },
  });

  const diaperForm = useForm<z.infer<typeof diaperSchema>>({
    resolver: zodResolver(diaperSchema),
    defaultValues: {
      type: "wet",
      consistency: "",
      color: "",
      notes: "",
    },
  });

  // Mutations for each log type
  const feedingMutation = useMutation({
    mutationFn: async (data: z.infer<typeof feedingSchema>) => {
      const response = await apiRequest(
        "POST", 
        `/api/babies/${selectedBaby}/feedings`,
        {
          ...data,
          startTime: new Date().toISOString(),
        }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/feedings`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/daily`] });
      toast({
        title: "Feeding logged",
        description: "Your feeding entry has been successfully recorded.",
      });
      feedingForm.reset();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sleepMutation = useMutation({
    mutationFn: async (data: z.infer<typeof sleepSchema>) => {
      const response = await apiRequest(
        "POST", 
        `/api/babies/${selectedBaby}/sleeps`,
        {
          ...data,
          startTime: new Date().toISOString(),
        }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/sleep`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/daily`] });
      toast({
        title: "Sleep logged",
        description: "Your sleep entry has been successfully recorded.",
      });
      sleepForm.reset();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const diaperMutation = useMutation({
    mutationFn: async (data: z.infer<typeof diaperSchema>) => {
      const response = await apiRequest(
        "POST", 
        `/api/babies/${selectedBaby}/diapers`,
        {
          ...data,
          time: new Date().toISOString(),
        }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/diapers`] });
      queryClient.invalidateQueries({ queryKey: [`/api/babies/${selectedBaby}/daily`] });
      toast({
        title: "Diaper change logged",
        description: "Your diaper entry has been successfully recorded.",
      });
      diaperForm.reset();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!selectedBaby) {
      toast({
        title: "No baby selected",
        description: "Please select a baby to log activity for.",
        variant: "destructive",
      });
      return;
    }

    switch (activeTab) {
      case "feeding":
        feedingForm.handleSubmit((data) => feedingMutation.mutate(data))();
        break;
      case "sleep":
        sleepForm.handleSubmit((data) => sleepMutation.mutate(data))();
        break;
      case "diaper":
        diaperForm.handleSubmit((data) => diaperMutation.mutate(data))();
        break;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center">
      <Card className="w-[90%] max-w-md max-h-[90vh] overflow-y-auto">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>Log Activity</CardTitle>
            <div className="flex space-x-1">
              <Button 
                variant={isListening ? "destructive" : "outline"} 
                size="icon" 
                onClick={toggleListening}
                className="mr-1"
              >
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <CardDescription>
            {format(new Date(), "EEEE, MMMM d, yyyy")}
          </CardDescription>
        </CardHeader>

        <Tabs 
          defaultValue="feeding" 
          value={activeTab} 
          onValueChange={setActiveTab} 
          className="w-full"
        >
          <TabsList className="grid grid-cols-3 mb-4 mx-4">
            <TabsTrigger value="feeding" className="flex gap-1 items-center">
              <Baby className="h-4 w-4" />
              Feeding
            </TabsTrigger>
            <TabsTrigger value="sleep" className="flex gap-1 items-center">
              <MoonStar className="h-4 w-4" />
              Sleep
            </TabsTrigger>
            <TabsTrigger value="diaper" className="flex gap-1 items-center">
              <Droplets className="h-4 w-4" />
              Diaper
            </TabsTrigger>
          </TabsList>

          {/* Feeding Form */}
          <TabsContent value="feeding" className="mt-0">
            <CardContent className="pb-3">
              <Form {...feedingForm}>
                <div className="space-y-4">
                  <FormField
                    control={feedingForm.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Feeding Type</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select feeding type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="breast">Breastfeeding</SelectItem>
                            <SelectItem value="bottle">Bottle (Formula)</SelectItem>
                            <SelectItem value="bottle_breastmilk">Bottle (Breastmilk)</SelectItem>
                            <SelectItem value="solid">Solid Food</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {feedingForm.watch("type") === "breast" && (
                    <FormField
                      control={feedingForm.control}
                      name="side"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Side</FormLabel>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex gap-4"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="left" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                Left
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="right" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                Right
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="both" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                Both
                              </FormLabel>
                            </FormItem>
                          </RadioGroup>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  {(feedingForm.watch("type") === "bottle" || 
                    feedingForm.watch("type") === "bottle_breastmilk") && (
                    <FormField
                      control={feedingForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount (in oz/ml)</FormLabel>
                          <FormControl>
                            <Input type="text" placeholder="e.g. 4oz" {...field} />
                          </FormControl>
                          <FormDescription>
                            Enter the amount with units (e.g., 4oz, 120ml)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <FormField
                    control={feedingForm.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duration (minutes)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="0" 
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={feedingForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Add any observations or notes..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </Form>
            </CardContent>
          </TabsContent>

          {/* Sleep Form */}
          <TabsContent value="sleep" className="mt-0">
            <CardContent className="pb-3">
              <Form {...sleepForm}>
                <div className="space-y-4">
                  <FormField
                    control={sleepForm.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sleep Type</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select sleep type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="nap">Nap</SelectItem>
                            <SelectItem value="night">Night Sleep</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={sleepForm.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duration (minutes)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="0" 
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={sleepForm.control}
                    name="quality"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sleep Quality (1-5)</FormLabel>
                        <FormControl>
                          <div className="space-y-2">
                            <Slider 
                              min={1} 
                              max={5} 
                              step={1} 
                              defaultValue={[field.value || 3]} 
                              onValueChange={(values) => field.onChange(values[0])}
                            />
                            <div className="flex justify-between text-xs text-muted-foreground px-1">
                              <span>Poor</span>
                              <span>Excellent</span>
                            </div>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={sleepForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Add any observations or notes..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </Form>
            </CardContent>
          </TabsContent>

          {/* Diaper Form */}
          <TabsContent value="diaper" className="mt-0">
            <CardContent className="pb-3">
              <Form {...diaperForm}>
                <div className="space-y-4">
                  <FormField
                    control={diaperForm.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Diaper Type</FormLabel>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex gap-4"
                        >
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="wet" />
                            </FormControl>
                            <FormLabel className="font-normal cursor-pointer">
                              Wet
                            </FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="dirty" />
                            </FormControl>
                            <FormLabel className="font-normal cursor-pointer">
                              Dirty
                            </FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="both" />
                            </FormControl>
                            <FormLabel className="font-normal cursor-pointer">
                              Both
                            </FormLabel>
                          </FormItem>
                        </RadioGroup>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {(diaperForm.watch("type") === "dirty" || diaperForm.watch("type") === "both") && (
                    <>
                      <FormField
                        control={diaperForm.control}
                        name="consistency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Consistency</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select consistency" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="solid">Solid</SelectItem>
                                <SelectItem value="soft">Soft</SelectItem>
                                <SelectItem value="loose">Loose</SelectItem>
                                <SelectItem value="watery">Watery</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={diaperForm.control}
                        name="color"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Color</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select color" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="yellow">Yellow</SelectItem>
                                <SelectItem value="brown">Brown</SelectItem>
                                <SelectItem value="green">Green</SelectItem>
                                <SelectItem value="black">Black</SelectItem>
                                <SelectItem value="red">Red</SelectItem>
                                <SelectItem value="white">White</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}

                  <FormField
                    control={diaperForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Add any observations or notes..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </Form>
            </CardContent>
          </TabsContent>
        </Tabs>

        <CardFooter className="pt-0 flex justify-between">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={
              (activeTab === "feeding" && feedingMutation.isPending) ||
              (activeTab === "sleep" && sleepMutation.isPending) ||
              (activeTab === "diaper" && diaperMutation.isPending)
            }
          >
            {(activeTab === "feeding" && feedingMutation.isPending) ||
             (activeTab === "sleep" && sleepMutation.isPending) ||
             (activeTab === "diaper" && diaperMutation.isPending)
              ? "Saving..."
              : "Save"
            }
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}