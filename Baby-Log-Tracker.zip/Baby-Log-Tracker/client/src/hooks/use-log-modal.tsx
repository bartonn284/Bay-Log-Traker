import { create } from 'zustand';

interface LogModalState {
  isOpen: boolean;
  open: () => void;
  close: () => void;
  toggle: () => void;
}

// Global state for log modal visibility
export const useLogModal = create<LogModalState>((set) => ({
  isOpen: false,
  open: () => set({ isOpen: true }),
  close: () => set({ isOpen: false }),
  toggle: () => set((state) => ({ isOpen: !state.isOpen })),
}));