import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { Baby } from "@shared/schema";

type BabyContextType = {
  babies: Baby[];
  selectedBaby: Baby | null;
  setSelectedBaby: (baby: Baby | null) => void;
  isLoading: boolean;
  error: Error | null;
};

const BabyContext = createContext<BabyContextType | null>(null);

export function BabyProvider({ children }: { children: ReactNode }) {
  const [selectedBaby, setSelectedBaby] = useState<Baby | null>(null);
  
  const {
    data: babies = [],
    isLoading,
    error,
  } = useQuery<Baby[], Error>({
    queryKey: ["/api/babies"],
    queryFn: async ({ signal }) => {
      const res = await fetch("/api/babies", { signal });
      if (!res.ok) {
        throw new Error("Failed to fetch babies");
      }
      return await res.json();
    },
  });

  // Auto-select the first baby if none is selected and babies are loaded
  useEffect(() => {
    if (!selectedBaby && babies.length > 0) {
      setSelectedBaby(babies[0]);
    }
  }, [babies, selectedBaby]);

  return (
    <BabyContext.Provider
      value={{
        babies,
        selectedBaby,
        setSelectedBaby,
        isLoading,
        error,
      }}
    >
      {children}
    </BabyContext.Provider>
  );
}

export function useBaby() {
  const context = useContext(BabyContext);
  if (!context) {
    throw new Error("useBaby must be used within a BabyProvider");
  }
  return context;
}