import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Baby } from '@shared/schema';

interface BabyContextType {
  babies: Baby[];
  selectedBaby: number | null;
  setSelectedBaby: (babyId: number) => void;
  selectedBabyData: Baby | undefined;
  isLoading: boolean;
  isReady: boolean;
}

const BabyContext = createContext<BabyContextType | undefined>(undefined);

export function BabyProvider({ children }: { children: ReactNode }) {
  const [selectedBaby, setSelectedBaby] = useState<number | null>(null);
  const [isReady, setIsReady] = useState(false);
  
  // Get babies from API
  const { data: babies = [], isLoading } = useQuery<Baby[]>({
    queryKey: ['/api/babies']
  });
  
  // First, try to load the selected baby from localStorage
  useEffect(() => {
    if (!isReady && !isLoading && babies.length > 0) {
      // Try to get saved baby ID from localStorage
      const savedBabyId = localStorage.getItem('selectedBabyId');
      
      if (savedBabyId) {
        const babyId = parseInt(savedBabyId);
        // Check if this baby exists in our current babies list
        const exists = babies.some(b => b.id === babyId);
        
        if (exists) {
          setSelectedBaby(babyId);
        } else {
          // If saved baby doesn't exist anymore, default to first baby
          setSelectedBaby(babies[0].id);
        }
      } else {
        // No saved baby, default to first one
        setSelectedBaby(babies[0].id);
      }
      
      // Mark context as ready so components know they can use it
      setIsReady(true);
    }
  }, [babies, isLoading, isReady]);

  // Save selected baby to localStorage whenever it changes
  useEffect(() => {
    if (selectedBaby !== null) {
      localStorage.setItem('selectedBabyId', selectedBaby.toString());
    }
  }, [selectedBaby]);

  // Get selected baby data
  const selectedBabyData = selectedBaby !== null 
    ? babies.find(b => b.id === selectedBaby) 
    : undefined;

  return (
    <BabyContext.Provider value={{
      babies,
      selectedBaby,
      setSelectedBaby,
      selectedBabyData,
      isLoading,
      isReady
    }}>
      {children}
    </BabyContext.Provider>
  );
}

export function useBabyContext() {
  const context = useContext(BabyContext);
  
  if (context === undefined) {
    throw new Error('useBabyContext must be used within a BabyProvider');
  }
  
  return context;
}